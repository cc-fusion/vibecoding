import { Apple, Axe, Drumstick, Gem, Pickaxe, Sandwich, Shovel, Sword } from 'lucide-react';
import { BLOCKS, ITEMS, itemColor } from '../game/blocks';

export function ItemIcon({ id, size = 34 }: { id: number; size?: number }) {
  const color = itemColor(id), item = ITEMS[id];
  if (item?.tool) {
    const Icon = item.tool === 'pickaxe' ? Pickaxe : item.tool === 'axe' ? Axe : item.tool === 'shovel' ? Shovel : Sword;
    return <Icon size={size} strokeWidth={1.7} style={{ color, filter: 'drop-shadow(0 2px 1px #0006)' }} aria-label={item.name} />;
  }
  if (id === 115) return <Apple size={size} strokeWidth={1.8} style={{ color, filter: 'drop-shadow(0 2px 1px #0006)' }} />;
  if (id === 120 || id === 121) return <Drumstick size={size} strokeWidth={1.8} style={{ color, filter: 'drop-shadow(0 2px 1px #0006)' }} />;
  if (id === 116) return <Sandwich size={size} strokeWidth={1.8} style={{ color, filter: 'drop-shadow(0 2px 1px #0006)' }} />;
  if (id === 113 || id === 114) return <Gem size={size} strokeWidth={1.6} style={{ color, filter: `drop-shadow(0 0 5px ${color}88)` }} />;
  if (!BLOCKS[id]) return <span className="item-ingot" style={{ width: size * 0.8, height: size * 0.45, background: color }} aria-label={item?.name} />;
  return (
    <span className="voxel-icon" style={{ width: size, height: size, '--voxel-color': color } as React.CSSProperties} aria-label={BLOCKS[id].name}>
      <span className="voxel-top" /><span className="voxel-left" /><span className="voxel-right" />
    </span>
  );
}
