import { useState } from 'react';
import { Box, ChevronRight, Clock3, CloudRain, Gamepad2, Leaf, Play, Plus, Shield, Sparkles, Trash2 } from 'lucide-react';
import { GameMode, WorldMeta } from '../game/storage';

export function StartScreen({ worlds, onCreate, onContinue, onDelete }: {
  worlds: WorldMeta[]; onCreate: (name: string, seed: string, mode: GameMode) => void; onContinue: (id: string) => void; onDelete: (id: string) => void;
}) {
  const [name, setName] = useState('New Horizons'); const [seed, setSeed] = useState('terrevale'); const [mode, setMode] = useState<GameMode>('survival');
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const formatTime = (seconds: number) => seconds < 60 ? 'Just begun' : `${Math.floor(seconds / 60)} min played`;
  return (
    <main className="start-screen">
      <div className="menu-sky"><span className="menu-sun" /><span className="menu-cloud cloud-a" /><span className="menu-cloud cloud-b" /></div>
      <div className="menu-landscape" aria-hidden="true"><div className="ridge ridge-back" /><div className="ridge ridge-front" /><div className="voxel-tree tree-a" /><div className="voxel-tree tree-b" /></div>
      <header className="menu-header"><div className="brand-mark"><Box size={23} /><span>TERREVALE</span></div><span className="build-label">VOXEL SURVIVAL · LOCAL EDITION</span></header>
      <div className="menu-layout">
        <section className="menu-hero">
          <div className="eyebrow"><Leaf size={15} /> A world worth getting lost in</div>
          <h1>Shape the wild.<br /><em>Survive the night.</em></h1>
          <p>Cross living biomes, delve for echo crystal, build a shelter, and master a world that remembers every block.</p>
          <div className="feature-row"><span><Sparkles size={15} /> Procedural worlds</span><span><CloudRain size={15} /> Living weather</span><span><Shield size={15} /> Real survival</span></div>
          <div className="menu-controls"><span><kbd>WASD</kbd> Move</span><span><kbd>Mouse</kbd> Look</span><span><kbd>LMB</kbd> Mine / fight</span><span><kbd>RMB</kbd> Place / use</span><span><kbd>E</kbd> Backpack</span></div>
        </section>
        <section className="world-panel">
          <div className="panel-heading"><div><span className="section-kicker">BEGIN AN EXPEDITION</span><h2>Create a world</h2></div><Plus size={21} /></div>
          <label className="field-label">World name<input value={name} maxLength={28} onChange={e => setName(e.target.value)} placeholder="World name" /></label>
          <label className="field-label">Seed <span className="field-note">same seed, same terrain</span><input value={seed} maxLength={32} onChange={e => setSeed(e.target.value)} placeholder="Leave blank for random" /></label>
          <div className="mode-switch" role="group" aria-label="Game mode">
            <button className={mode === 'survival' ? 'active' : ''} onClick={() => setMode('survival')}><Shield size={17} /><span>Survival<small>Gather, craft & endure</small></span></button>
            <button className={mode === 'creative' ? 'active' : ''} onClick={() => setMode('creative')}><Sparkles size={17} /><span>Creative<small>Unlimited blocks & flight</small></span></button>
          </div>
          <button className="primary-button create-button" disabled={!name.trim()} onClick={() => onCreate(name.trim(), seed.trim() || Math.random().toString(36).slice(2), mode)}><Play size={18} fill="currentColor" /> Create & explore <ChevronRight size={18} /></button>
          <p className="save-note">Worlds save automatically in this browser. No account or server needed.</p>
        </section>
      </div>
      {worlds.length > 0 && <section className="saved-section"><div className="saved-heading"><h2>Continue a journey</h2><span>{worlds.length} saved {worlds.length === 1 ? 'world' : 'worlds'}</span></div><div className="world-list">
        {worlds.map(world => <article className="world-card" key={world.id}>
          <button className="world-continue" onClick={() => onContinue(world.id)}>
            <span className={`world-symbol ${world.mode}`}><Gamepad2 size={22} /></span>
            <span className="world-info"><strong>{world.name}</strong><small><Clock3 size={12} /> {formatTime(world.playTime)} · Level {world.level} · {world.mode}</small></span>
            <Play size={17} className="world-play" />
          </button>
          <button className={`world-delete ${confirmDelete === world.id ? 'confirm' : ''}`} title="Delete world" onClick={() => { if (confirmDelete === world.id) { onDelete(world.id); setConfirmDelete(null); } else setConfirmDelete(world.id); }}><Trash2 size={15} />{confirmDelete === world.id && <span>Confirm</span>}</button>
        </article>)}
      </div></section>}
      <footer className="menu-footer">Best experienced with a keyboard, mouse, and headphones <span>·</span> WebGL 2</footer>
    </main>
  );
}
