import { Apple, Cloud, CloudLightning, CloudRain, CloudSnow, Heart, MapPin, Moon, Sun } from 'lucide-react';
import { Snapshot } from '../game/Game';
import { itemName } from '../game/blocks';
import { ItemSlot } from './ItemSlot';

export function HUD({ snapshot, onSelect, showHints = true }: { snapshot: Snapshot; onSelect: (index: number) => void; showHints?: boolean }) {
  const time = `${Math.floor(snapshot.hours).toString().padStart(2, '0')}:${Math.floor((snapshot.hours % 1) * 60).toString().padStart(2, '0')}`;
  const night = snapshot.hours < 6 || snapshot.hours > 18.5;
  const WeatherIcon = snapshot.weather === 'Storm' ? CloudLightning : snapshot.weather === 'Snow' ? CloudSnow : snapshot.weather === 'Rain' ? CloudRain : Cloud;
  const selectedStack = snapshot.inventory[snapshot.selected];
  return <div className="hud" aria-live="off">
    <div className="world-status glass-panel">
      <div className="status-time">{night ? <Moon size={17} /> : <Sun size={17} />}<span>Day {snapshot.day}<strong>{time}</strong></span></div>
      <div className="status-divider" />
      <div className="status-place"><MapPin size={16} /><span>{snapshot.biome}<small><WeatherIcon size={12} /> {snapshot.weather === 'Snow' && snapshot.biome !== 'Tundra' ? 'Snow' : snapshot.weather}</small></span></div>
    </div>
    <div className="coordinate-chip">{Math.floor(snapshot.x)} &nbsp; {Math.floor(snapshot.y)} &nbsp; {Math.floor(snapshot.z)}</div>
    {snapshot.boss && <div className={`boss-hud phase-${snapshot.boss.phase}`}>
      <div className="boss-title"><span>{snapshot.boss.name}</span><small>PHASE {snapshot.boss.phase} · {snapshot.boss.telegraph ? snapshot.boss.telegraph.toUpperCase() : 'ENGAGED'}</small></div>
      <div className="boss-track"><span style={{ width: `${snapshot.boss.health / snapshot.boss.maxHealth * 100}%` }} /></div>
      {snapshot.boss.telegraph && <div className="boss-warning">{snapshot.boss.telegraph === 'slam' ? 'Move beyond the expanding shockwave' : snapshot.boss.telegraph === 'summon' ? 'The Guardian is calling reinforcements' : 'Ranged attack incoming — take cover'}</div>}
    </div>}
    <div className="crosshair-wrap">
      {snapshot.miningProgress > 0 && <div className="mine-ring" style={{ background: `conic-gradient(#f3e8c8 ${Math.min(1, snapshot.miningProgress) * 360}deg, #ffffff24 0deg)` }} />}
      <div className="crosshair"><i /><i /><i /><i /></div>
      {(snapshot.targetName || snapshot.targetHint) && <div className="target-label"><strong>{snapshot.targetName}</strong>{snapshot.targetHint && <span>{snapshot.targetHint}</span>}</div>}
    </div>
    <div className="survival-bars">
      <div className="stat-row health-row">{Array.from({ length: 10 }, (_, i) => <Heart key={i} size={19} fill={snapshot.health > i * 2 ? 'currentColor' : 'transparent'} className={snapshot.health <= 5 ? 'low-health' : ''} />)}</div>
      <div className="stat-row hunger-row">{Array.from({ length: 10 }, (_, i) => <Apple key={i} size={17} fill={snapshot.hunger >= (i + 1) * 2 ? 'currentColor' : 'transparent'} />)}</div>
    </div>
    <div className="hotbar-area">
      <div className="selected-item-name">{selectedStack ? itemName(selectedStack.id) : snapshot.mode === 'creative' ? 'Creative · F to fly' : 'Bare hands'}</div>
      <div className="hotbar">{snapshot.inventory.slice(0, 9).map((stack, i) => <ItemSlot key={i} stack={stack} compact selected={snapshot.selected === i} hotkey={`${i + 1}`} onClick={() => onSelect(i)} />)}</div>
      <div className="xp-row"><span className="level-number">{snapshot.level}</span><div className="xp-track"><span style={{ width: `${Math.max(0, Math.min(1, snapshot.levelProgress)) * 100}%` }} /></div><small>{snapshot.xp} XP</small></div>
    </div>
    {showHints && <div className="quick-hints"><span><kbd>E</kbd> Backpack</span><span><kbd>Q</kbd> Drop</span><span><kbd>F3</kbd> Debug</span></div>}
    {snapshot.queuedChunks > 2 && <div className="chunk-loader"><span className="loader-pulse" /> Shaping distant terrain · {snapshot.queuedChunks}</div>}
    {snapshot.underwater && <div className="underwater-overlay"><span className="bubble b1" /><span className="bubble b2" /><span className="bubble b3" /><div className="oxygen-row"><small>AIR</small>{Array.from({ length: 10 }, (_, i) => <i key={i} className={snapshot.air > i * 2 ? 'full' : ''} />)}</div></div>}
    {snapshot.debug && <div className="debug-panel"><strong>TERREVALE DEBUG</strong><span>{snapshot.fps.toFixed(0)} FPS · WebGL</span><span>XYZ {snapshot.x.toFixed(2)} / {snapshot.y.toFixed(2)} / {snapshot.z.toFixed(2)}</span><span>Chunks {snapshot.chunks}/{snapshot.totalChunks} · queued {snapshot.queuedChunks}</span><span>Seed biome {snapshot.biome}</span><span>Flight {snapshot.flying ? 'on' : 'off'}</span></div>}
  </div>;
}
