import { useMemo, useState } from 'react';
import { Backpack, BookOpen, Check, Hammer, LockKeyhole, Sparkles, X } from 'lucide-react';
import { B, BLOCKS, ITEMS, RECIPES, itemName } from '../game/blocks';
import { Snapshot } from '../game/Game';
import { canCraft, countItem } from '../game/inventory';
import { ItemSlot } from './ItemSlot';
import { ItemIcon } from './ItemIcon';

type Tab = 'inventory' | 'crafting' | 'guide';
const achievements = [
  ['wood', 'Getting Wood', 'Harvest your first log'], ['workbench', 'Workshop', 'Craft a workbench'], ['stone', 'Stone Age', 'Mine stone'],
  ['coal', 'Into the Depths', 'Uncover coal'], ['iron', 'Metallurgy', 'Harvest raw iron'], ['crystal', 'Echoes Below', 'Find deep echo crystal'],
  ['level5', 'Seasoned Explorer', 'Reach level 5'], ['summon', 'The Challenge', 'Awaken the Ancient Guardian'], ['guardian', 'Dawnbringer', 'Defeat the Ancient Guardian'],
];

export function InventoryPanel({ snapshot, onClose, onCraft, onMove, onGive }: {
  snapshot: Snapshot; onClose: () => void; onCraft: (id: string) => void; onMove: (from: number, to: number) => void; onGive: (id: number) => void;
}) {
  const [tab, setTab] = useState<Tab>('crafting'); const [picked, setPicked] = useState<number | null>(null); const [category, setCategory] = useState('All');
  const categories = ['All', 'Basics', 'Tools', 'Building', 'Survival'];
  const recipes = useMemo(() => RECIPES.filter(r => category === 'All' || r.category === category), [category]);
  const clickSlot = (index: number) => { if (picked == null) { if (snapshot.inventory[index]) setPicked(index); } else { onMove(picked, index); setPicked(null); } };
  const creativeItems = [...Object.keys(BLOCKS).map(Number).filter(id => id > 0 && id !== B.Water), ...Object.keys(ITEMS).map(Number)];
  return <div className="modal-backdrop inventory-backdrop">
    <section className="inventory-panel" role="dialog" aria-modal="true" aria-label="Backpack and crafting">
      <header className="inventory-header"><div className="inventory-title"><span className="inventory-emblem"><Backpack size={24} /></span><div><span>FIELD KIT</span><h2>Backpack & crafting</h2></div></div>
        <div className="inventory-header-right"><span className="level-badge">LEVEL {snapshot.level}</span><button className="icon-button" onClick={onClose} aria-label="Close backpack"><X size={21} /></button></div></header>
      <nav className="inventory-tabs"><button className={tab === 'crafting' ? 'active' : ''} onClick={() => setTab('crafting')}><Hammer size={16} /> Crafting</button><button className={tab === 'inventory' ? 'active' : ''} onClick={() => setTab('inventory')}><Backpack size={16} /> Inventory</button><button className={tab === 'guide' ? 'active' : ''} onClick={() => setTab('guide')}><BookOpen size={16} /> Field guide</button>
        <span className="station-status"><i className={snapshot.nearTable || snapshot.mode === 'creative' ? 'online' : ''} /> Workbench <i className={snapshot.nearFurnace || snapshot.mode === 'creative' ? 'online' : ''} /> Furnace</span></nav>
      <div className="inventory-content">
        {tab !== 'guide' && <section className="bag-section"><div className="bag-heading"><div><h3>{tab === 'crafting' ? 'Backpack' : 'All items'}</h3><p>{picked != null ? `Moving ${itemName(snapshot.inventory[picked]?.id ?? 0)} · choose a destination` : 'Select an item, then another slot to move it'}</p></div><span>{snapshot.inventory.filter(Boolean).length}/36 slots</span></div>
          <div className="inventory-grid">{snapshot.inventory.map((stack, displayIndex) => { const index = displayIndex < 27 ? displayIndex + 9 : displayIndex - 27; return <div key={index} className={displayIndex === 27 ? 'hotbar-separator' : ''}><ItemSlot stack={stack} selected={picked === index || (displayIndex >= 27 && snapshot.selected === index)} hotkey={displayIndex >= 27 ? `${index + 1}` : undefined} onClick={() => clickSlot(index)} /></div>; })}</div>
          {tab === 'inventory' && snapshot.mode === 'creative' && <div className="creative-palette"><h4><Sparkles size={15} /> Creative palette <small>Click to add a full stack</small></h4><div>{creativeItems.map(id => <button key={id} onClick={() => onGive(id)} title={itemName(id)}><ItemIcon id={id} size={28} /><span>{itemName(id)}</span></button>)}</div></div>}
        </section>}
        {tab === 'crafting' && <section className="recipe-section"><div className="recipe-top"><div><h3>Recipes</h3><p>Crafting consumes real materials and awards experience.</p></div><span>{RECIPES.length} known</span></div><div className="category-tabs">{categories.map(c => <button className={category === c ? 'active' : ''} key={c} onClick={() => setCategory(c)}>{c}</button>)}</div>
          <div className="recipe-list">{recipes.map(recipe => {
            const check = canCraft(snapshot.inventory, recipe, snapshot.mode === 'creative' ? 999 : snapshot.level, snapshot.nearTable || snapshot.mode === 'creative', snapshot.nearFurnace || snapshot.mode === 'creative');
            return <button className={`recipe-card ${check.ok ? 'available' : ''}`} key={recipe.id} disabled={!check.ok} onClick={() => onCraft(recipe.id)}>
              <span className="recipe-output"><ItemIcon id={recipe.output} size={38} /><b>{recipe.count > 1 ? recipe.count : ''}</b></span>
              <span className="recipe-info"><strong>{itemName(recipe.output)}</strong><span className="ingredients">{recipe.ingredients.map(ingredient => { const have = countItem(snapshot.inventory, ingredient.id); return <small className={have >= ingredient.count ? 'have' : ''} key={ingredient.id}>{itemName(ingredient.id)} {Math.min(have, ingredient.count)}/{ingredient.count}</small>; })}</span></span>
              <span className="recipe-meta">{recipe.station && <small>{recipe.station === 'table' ? 'Workbench' : 'Furnace'}</small>}{(recipe.level ?? 1) > 1 && <small>Level {recipe.level}</small>}{check.ok ? <Check size={17} /> : <LockKeyhole size={15} />}</span>
              {!check.ok && <span className="recipe-reason">{check.reason}</span>}
            </button>;
          })}</div>
        </section>}
        {tab === 'guide' && <section className="guide-section"><div className="guide-intro"><span>FIELD NOTES · {snapshot.mode.toUpperCase()}</span><h3>From first shelter to the deep guardian</h3><p>Progress is driven by what you harvest, craft, and defeat. Tools unlock harder resources; each level reveals more recipes.</p></div>
          <div className="guide-columns"><div><h4>Survival basics</h4><ol><li><b>Gather wood.</b> Hold left mouse on a tree trunk. Walk over dropped blocks to collect them.</li><li><b>Make planks and sticks.</b> Craft a workbench, place it with right mouse, then stand nearby for tools.</li><li><b>Prepare for dusk.</b> Stone tools, a furnace, food, and four walls make the first night much safer.</li><li><b>Delve deeper.</b> Iron lies below Y29. Echo crystal requires an iron pickaxe and generates below Y14.</li></ol><h4>Controls</h4><div className="guide-keys"><span><kbd>WASD</kbd> Move</span><span><kbd>Space</kbd> Jump / swim</span><span><kbd>Shift</kbd> Sprint</span><span><kbd>1–9</kbd> Hotbar</span><span><kbd>Q</kbd> Drop item</span><span><kbd>F</kbd> Fly in Creative</span><span><kbd>Ctrl</kbd> Descend while flying</span><span><kbd>Middle mouse</kbd> Pick block</span></div></div>
            <div><h4>Advancements <small>{snapshot.achievements.length}/{achievements.length}</small></h4><div className="achievement-list">{achievements.map(([id, name, description]) => { const done = snapshot.achievements.includes(id); return <div className={done ? 'done' : ''} key={id}><span>{done ? <Check size={15} /> : <LockKeyhole size={13} />}</span><p><b>{name}</b><small>{description}</small></p></div>; })}</div></div></div>
        </section>}
      </div>
      <footer className="inventory-footer"><span><kbd>E</kbd> or <kbd>Esc</kbd> to return</span><span>Changes are saved automatically</span></footer>
    </section>
  </div>;
}
