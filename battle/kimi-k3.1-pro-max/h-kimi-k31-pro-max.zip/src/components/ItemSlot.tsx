import { Stack, itemName } from '../game/blocks';
import { toolDurability } from '../game/inventory';
import { ItemIcon } from './ItemIcon';

export function ItemSlot({ stack, selected = false, hotkey, onClick, className = '', compact = false }: {
  stack: Stack | null; selected?: boolean; hotkey?: string; onClick?: () => void; className?: string; compact?: boolean;
}) {
  const durability = stack?.durability != null ? Math.max(0, stack.durability / toolDurability(stack.id)) : 1;
  return (
    <button type="button" className={`item-slot ${selected ? 'selected' : ''} ${compact ? 'compact' : ''} ${className}`} onClick={onClick} data-tooltip={stack ? itemName(stack.id) : 'Empty slot'} aria-label={stack ? `${itemName(stack.id)}, ${stack.count}` : 'Empty inventory slot'}>
      {hotkey && <span className="slot-hotkey">{hotkey}</span>}
      {stack && <><ItemIcon id={stack.id} size={compact ? 31 : 35} /><span className="slot-count">{stack.count > 1 ? stack.count : ''}</span>
        {stack.durability != null && <span className="durability-track"><span style={{ width: `${durability * 100}%`, background: durability < 0.25 ? '#d66a51' : '#8fc46b' }} /></span>}</>}
    </button>
  );
}
