import { useCallback, useEffect, useRef, useState } from 'react';
import { Box, Check, ChevronRight, Gauge, Keyboard, LogOut, MousePointer2, Play, RotateCcw, Save, Settings, Volume2, VolumeX, X } from 'lucide-react';
import { Game, Snapshot, ToastKind, UiMode } from './game/Game';
import { GameMode, SavedGame, deleteWorld, listWorlds, loadWorld, makeWorldId } from './game/storage';
import { stringSeed } from './game/noise';
import { StartScreen } from './components/StartScreen';
import { HUD } from './components/HUD';
import { InventoryPanel } from './components/InventoryPanel';

type Session = { id: string; name: string; seedLabel: string; seed: number; mode: GameMode; saved?: SavedGame | null };
type Toast = { id: number; message: string; kind: ToastKind };
type GameSettings = { renderDistance: number; sensitivity: number; sound: boolean; volume: number; hints: boolean };
const defaultSettings: GameSettings = { renderDistance: 4, sensitivity: 1, sound: true, volume: 0.7, hints: true };

function loadSettings(): GameSettings {
  try { return { ...defaultSettings, ...JSON.parse(localStorage.getItem('terrevale.settings') ?? '{}') }; } catch { return defaultSettings; }
}

export default function App() {
  const [worlds, setWorlds] = useState(listWorlds); const [session, setSession] = useState<Session | null>(null);
  const [game, setGame] = useState<Game | null>(null); const [snapshot, setSnapshot] = useState<Snapshot | null>(null);
  const [uiMode, setUiMode] = useState<UiMode>('paused'); const [loading, setLoading] = useState(false); const [error, setError] = useState('');
  const [toasts, setToasts] = useState<Toast[]>([]); const [settings, setSettings] = useState<GameSettings>(loadSettings);
  const [settingsOpen, setSettingsOpen] = useState(false); const [hurtNonce, setHurtNonce] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null); const toastId = useRef(0);

  const pushToast = useCallback((message: string, kind: ToastKind = 'info') => {
    const id = ++toastId.current; setToasts(current => [...current.slice(-3), { id, message, kind }]);
    window.setTimeout(() => setToasts(current => current.filter(toast => toast.id !== id)), kind === 'success' ? 4200 : 3200);
  }, []);

  useEffect(() => {
    if (!session) return;
    setLoading(true); setError(''); setSnapshot(null); setUiMode('paused'); let instance: Game | null = null;
    const timer = window.setTimeout(() => {
      if (!containerRef.current) return;
      try {
        instance = new Game(containerRef.current, {
          ...session, callbacks: { onSnapshot: setSnapshot, onToast: pushToast, onMode: setUiMode, onHurt: () => setHurtNonce(n => n + 1) },
        });
        setGame(instance); setLoading(false);
      } catch (caught) {
        console.error(caught); setError(caught instanceof Error ? caught.message : 'Unable to initialize the 3D world.'); setLoading(false);
      }
    }, 90);
    return () => { window.clearTimeout(timer); instance?.destroy(); setGame(null); };
  }, [session, pushToast]);

  useEffect(() => {
    if (!game) return;
    game.setRenderDistance(settings.renderDistance); game.setSensitivity(0.0022 * settings.sensitivity); game.setSound(settings.sound, settings.volume);
    try { localStorage.setItem('terrevale.settings', JSON.stringify(settings)); } catch { /* settings remain valid for this session */ }
  }, [game, settings]);

  useEffect(() => {
    const listener = (event: KeyboardEvent) => {
      if (event.code === 'Escape' && uiMode === 'inventory') { event.preventDefault(); game?.resume(); }
    };
    window.addEventListener('keydown', listener); return () => window.removeEventListener('keydown', listener);
  }, [game, uiMode]);

  const createWorld = (name: string, seedLabel: string, mode: GameMode) => setSession({ id: makeWorldId(), name, seedLabel, seed: stringSeed(seedLabel), mode });
  const continueWorld = (id: string) => {
    const saved = loadWorld(id); if (!saved) { pushToast('That save could not be read. It may be corrupted.', 'danger'); setWorlds(listWorlds()); return; }
    setSession({ id: saved.id, name: saved.name, seedLabel: saved.seedLabel, seed: saved.seed, mode: saved.mode, saved });
  };
  const returnToTitle = () => { game?.save(); setSession(null); setGame(null); setSnapshot(null); setWorlds(listWorlds()); setSettingsOpen(false); };

  if (!session) return <><StartScreen worlds={worlds} onCreate={createWorld} onContinue={continueWorld} onDelete={id => { deleteWorld(id); setWorlds(listWorlds()); }} /><ToastStack toasts={toasts} /></>;

  return <main className="game-shell">
    <div className="game-container" ref={containerRef} />
    {snapshot && uiMode === 'playing' && <HUD snapshot={snapshot} showHints={settings.hints} onSelect={index => game?.setSelected(index)} />}
    {uiMode === 'inventory' && snapshot && game && <InventoryPanel snapshot={snapshot} onClose={() => game.resume()} onCraft={id => game.craft(id)} onMove={(from, to) => game.moveInventorySlot(from, to)} onGive={id => game.creativeGive(id)} />}
    {uiMode === 'paused' && !loading && !error && <div className="modal-backdrop pause-backdrop"><section className="pause-panel">
      <div className="pause-brand"><span className="brand-mark"><Box size={20} /> TERREVALE</span><span>WORLD PAUSED</span></div>
      <div className="pause-copy"><span className="section-kicker">{snapshot ? `DAY ${snapshot.day} · ${snapshot.biome.toUpperCase()}` : 'EXPEDITION READY'}</span><h1>{snapshot ? 'Take a breath.' : session.name}</h1><p>{snapshot ? 'The valley will wait. Your progress has been saved locally.' : 'Your world has been shaped. Click below to capture the mouse and begin exploring.'}</p></div>
      {!settingsOpen ? <>
        <button className="primary-button" onClick={() => game?.resume()}><Play size={18} fill="currentColor" /> {snapshot ? 'Return to world' : 'Enter world'} <ChevronRight size={18} /></button>
        <div className="pause-secondary"><button onClick={() => setSettingsOpen(true)}><Settings size={17} /> Settings</button><button onClick={returnToTitle}><LogOut size={17} /> Save & exit</button></div>
        {settings.hints && <div className="pause-help"><span><MousePointer2 size={16} /><b>Left</b> mine / attack</span><span><MousePointer2 size={16} /><b>Right</b> place / use</span><span><Keyboard size={17} /><b>E</b> backpack & crafting</span></div>}
      </> : <SettingsPanel settings={settings} onChange={setSettings} onClose={() => setSettingsOpen(false)} />}
      <div className="pause-save-status"><Check size={13} /> Autosave every 25 seconds</div>
    </section></div>}
    {uiMode === 'dead' && <div className="modal-backdrop death-backdrop"><section className="death-panel"><span>THE WILD CLAIMS ANOTHER</span><h1>You fell.</h1><p>You keep your belongings, but lose 15% of your experience. Return to your original shelter and try a different approach.</p><button className="primary-button" onClick={() => game?.respawn()}><RotateCcw size={18} /> Respawn at shelter</button><button className="text-button" onClick={returnToTitle}>Save & return to title</button></section></div>}
    {loading && <div className="loading-screen"><div className="loading-cube"><i /><i /><i /></div><span className="section-kicker">GENERATING {session.seedLabel.toUpperCase()}</span><h1>Shaping your world</h1><p>Growing forests, carving caves, and waking the valley…</p><div className="loading-track"><span /></div></div>}
    {error && <div className="modal-backdrop"><section className="error-panel"><X size={28} /><h2>The world could not start</h2><p>{error}</p><small>Terrevale needs WebGL 2 and hardware acceleration. Try updating your browser or enabling graphics acceleration.</small><button className="primary-button" onClick={returnToTitle}>Return to title</button></section></div>}
    <ToastStack toasts={toasts} />
    {hurtNonce > 0 && <div key={hurtNonce} className="damage-vignette" />}
  </main>;
}

function SettingsPanel({ settings, onChange, onClose }: { settings: GameSettings; onChange: (settings: GameSettings) => void; onClose: () => void }) {
  const update = <K extends keyof GameSettings>(key: K, value: GameSettings[K]) => onChange({ ...settings, [key]: value });
  return <div className="settings-panel"><div className="settings-title"><h2>Settings</h2><button className="icon-button" onClick={onClose}><X size={18} /></button></div>
    <label><span><Gauge size={16} /> Render distance <b>{settings.renderDistance} chunks</b></span><input type="range" min="2" max="7" step="1" value={settings.renderDistance} onChange={e => update('renderDistance', Number(e.target.value))} /><small>Lower distances improve performance on integrated graphics.</small></label>
    <label><span><MousePointer2 size={16} /> Look sensitivity <b>{settings.sensitivity.toFixed(1)}×</b></span><input type="range" min="0.3" max="2" step="0.1" value={settings.sensitivity} onChange={e => update('sensitivity', Number(e.target.value))} /></label>
    <label><span><Volume2 size={16} /> Master volume <b>{Math.round(settings.volume * 100)}%</b></span><input type="range" min="0" max="1" step="0.05" value={settings.volume} onChange={e => update('volume', Number(e.target.value))} /></label>
    <button className="setting-toggle" onClick={() => update('sound', !settings.sound)}>{settings.sound ? <Volume2 size={17} /> : <VolumeX size={17} />} Procedural audio <span className={settings.sound ? 'toggle on' : 'toggle'}><i /></span></button>
    <button className="setting-toggle" onClick={() => update('hints', !settings.hints)}><Keyboard size={17} /> Control hints <span className={settings.hints ? 'toggle on' : 'toggle'}><i /></span></button>
    <button className="primary-button" onClick={onClose}><Save size={17} /> Apply & return</button>
  </div>;
}

function ToastStack({ toasts }: { toasts: Toast[] }) {
  return <div className="toast-stack">{toasts.map(toast => <div className={`game-toast ${toast.kind}`} key={toast.id}><span />{toast.message}</div>)}</div>;
}
