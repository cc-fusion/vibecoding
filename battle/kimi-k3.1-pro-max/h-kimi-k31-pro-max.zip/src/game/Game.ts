import * as THREE from 'three';
import { B, BLOCKS, ITEMS, RECIPES, Stack, itemColor, itemName, levelFromXp, maxStack, miningTime, xpForLevel } from './blocks';
import { createAtlas } from './materials';
import { RayHit, VoxelWorld, WORLD_HEIGHT } from './world';
import { PlayerController, PlayerInput } from './player';
import { EntityManager } from './entities';
import { Environment } from './environment';
import { ParticleSystem, WeatherSystem } from './effects';
import { GameAudio } from './audio';
import { addItem, consumeSelected, craft as craftRecipe, damageTool, emptyInventory, moveStack } from './inventory';
import { GameMode, SavedGame, saveWorld } from './storage';

export type UiMode = 'playing' | 'paused' | 'inventory' | 'dead';
export type ToastKind = 'info' | 'success' | 'danger';
export type Snapshot = {
  health: number; hunger: number; air: number; xp: number; level: number; levelProgress: number;
  inventory: (Stack | null)[]; selected: number; targetName: string; miningProgress: number; targetHint: string;
  x: number; y: number; z: number; biome: string; hours: number; day: number; weather: string;
  fps: number; chunks: number; totalChunks: number; queuedChunks: number; underwater: boolean; flying: boolean;
  mode: GameMode; nearTable: boolean; nearFurnace: boolean; debug: boolean; locked: boolean;
  achievements: string[]; bossDefeated: boolean;
  boss: { name: string; health: number; maxHealth: number; phase: number; telegraph: string } | null;
};
export type GameCallbacks = {
  onSnapshot: (snapshot: Snapshot) => void; onToast: (message: string, kind?: ToastKind) => void;
  onMode: (mode: UiMode) => void; onHurt: () => void;
};
type Options = { id: string; name: string; seedLabel: string; seed: number; mode: GameMode; saved?: SavedGame | null; callbacks: GameCallbacks };
type Drop = { id: number; count: number; durability?: number; mesh: THREE.Mesh; velocity: THREE.Vector3; age: number };

const ACHIEVEMENTS: Record<string, string> = {
  wood: 'Getting Wood', workbench: 'Workshop', stone: 'Stone Age', coal: 'Into the Depths', iron: 'Metallurgy',
  crystal: 'Echoes Below', summon: 'The Challenge', guardian: 'Dawnbringer', level5: 'Seasoned Explorer',
};

export class Game {
  readonly world: VoxelWorld;
  readonly player: PlayerController;
  readonly audio = new GameAudio();
  readonly id: string; readonly name: string; readonly seedLabel: string; readonly mode: GameMode;
  inventory: (Stack | null)[]; selected = 0;
  health = 20; hunger = 20; air = 20; xp = 0; hours = 8; day = 1; weather = 'Clear';
  uiMode: UiMode = 'paused'; sensitivity = 0.0022;
  private renderer: THREE.WebGLRenderer; private scene = new THREE.Scene(); private camera: THREE.PerspectiveCamera;
  private environment: Environment; private entities: EntityManager; private particles = new ParticleSystem(); private weatherSystem = new WeatherSystem();
  private blockLights: THREE.PointLight[] = []; private lightTimer = 0;
  private clock = new THREE.Clock(); private animation = 0; private accumulator = 0; private destroyed = false;
  private input: PlayerInput = { forward: false, back: false, left: false, right: false, jump: false, sprint: false, down: false };
  private keys = new Set<string>(); private leftMouse = false; private useCooldown = 0; private attackCooldown = 0;
  private miningKey = ''; private miningProgress = 0; private mineSound = 0; private hit: RayHit | null = null;
  private outline: THREE.LineSegments; private crack: THREE.Mesh;
  private drops: Drop[] = []; private dropGeometry = new THREE.BoxGeometry(0.28, 0.28, 0.28); private dropMaterials = new Map<number, THREE.MeshStandardMaterial>();
  private nearTable = false; private nearFurnace = false; private stationTimer = 0;
  private snapshotTimer = 0; private saveTimer = 20; private weatherTimer = 100 + Math.random() * 100;
  private playTime = 0; private fps = 60; private streamInfo = { loaded: 0, total: 0, queued: 0 };
  private spawnPoint = new THREE.Vector3(); private achievements: Set<string>; private bossDefeated = false; private bossEncounter = false;
  private invulnerable = 0; private starvationTimer = 0; private drownTimer = 0; private regenTimer = 0; private cactusTimer = 0;
  private shake = 0; private swing = 0; private walkBob = 0; private wasInWater = false; private debug = false;
  private heldGroup = new THREE.Group(); private heldItem = -1;
  private resizeObserver: ResizeObserver;

  constructor(private container: HTMLElement, private options: Options) {
    this.id = options.id; this.name = options.name; this.seedLabel = options.seedLabel; this.mode = options.mode;
    this.inventory = options.saved?.inventory?.length === 36 ? options.saved.inventory.map(s => s ? { ...s } : null) : emptyInventory();
    if (!options.saved && this.mode === 'survival') this.inventory[8] = { id: 116, count: 2 };
    this.selected = options.saved?.selected ?? 0; this.health = options.saved?.health ?? 20; this.hunger = options.saved?.hunger ?? 20; this.air = options.saved?.air ?? 20;
    this.xp = options.saved?.xp ?? 0; this.hours = options.saved?.hours ?? 8; this.day = options.saved?.day ?? 1;
    this.weather = options.saved?.weather ?? 'Clear'; this.playTime = options.saved?.playTime ?? 0;
    this.achievements = new Set(options.saved?.achievements ?? []); this.bossDefeated = options.saved?.bossDefeated ?? false;

    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.65)); this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace; this.renderer.toneMapping = THREE.ACESFilmicToneMapping; this.renderer.toneMappingExposure = 1.02;
    this.renderer.shadowMap.enabled = true; this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.domElement.className = 'game-canvas'; this.renderer.domElement.setAttribute('aria-label', 'Terrevale 3D game world');
    container.appendChild(this.renderer.domElement);
    this.camera = new THREE.PerspectiveCamera(74, container.clientWidth / Math.max(1, container.clientHeight), 0.05, 230);
    this.camera.rotation.order = 'YXZ'; this.scene.add(this.camera); this.camera.add(this.heldGroup);
    this.world = new VoxelWorld(options.seed, createAtlas(), options.saved?.edits);
    this.scene.add(this.world.scene); this.environment = new Environment(this.scene);
    this.player = new PlayerController(this.world); this.player.creative = this.mode === 'creative';
    this.entities = new EntityManager(this.world, {
      damagePlayer: (amount, source) => this.damagePlayer(amount, source),
      spawnDrop: (id, count, position) => this.spawnDrop(id, count, position),
      particles: (position, color, count, force) => this.particles.burst(position, color, count, force),
      sound: name => this.audio.play(name), awardXp: amount => this.awardXp(amount), shake: amount => { this.shake = Math.max(this.shake, amount); },
    });
    this.scene.add(this.entities.group, this.particles.points, this.weatherSystem.points);
    for (let i = 0; i < 4; i++) {
      const light = new THREE.PointLight('#ffffff', 0, 11, 2); light.visible = false; this.blockLights.push(light); this.scene.add(light);
    }

    const outlineGeometry = new THREE.EdgesGeometry(new THREE.BoxGeometry(1.008, 1.008, 1.008));
    this.outline = new THREE.LineSegments(outlineGeometry, new THREE.LineBasicMaterial({ color: '#18251f', transparent: true, opacity: 0.85, depthTest: false }));
    this.outline.renderOrder = 8; this.outline.visible = false; this.scene.add(this.outline);
    this.crack = new THREE.Mesh(new THREE.BoxGeometry(1.012, 1.012, 1.012, 2, 2, 2), new THREE.MeshBasicMaterial({ color: '#e9e1c9', wireframe: true, transparent: true, opacity: 0.2, depthTest: false }));
    this.crack.renderOrder = 9; this.crack.visible = false; this.scene.add(this.crack);

    if (options.saved?.player) {
      const p = options.saved.player; this.player.position.set(p.x, p.y, p.z); this.player.yaw = p.yaw; this.player.pitch = p.pitch;
    } else this.player.position.copy(this.chooseSpawn());
    this.spawnPoint.copy(this.player.position); this.world.prepareSpawn(this.player.position.x, this.player.position.z, 1);
    if (!options.saved) this.player.position.y = this.world.findSurface(this.player.position.x, this.player.position.z) + 0.02;
    this.spawnPoint.copy(this.player.position); this.entities.populate(this.player.position);
    this.weatherSystem.setWeather(this.weather, this.world.getBiome(this.player.position.x, this.player.position.z) === 'Tundra');
    this.updateHeldItem(); this.bindEvents();
    this.resizeObserver = new ResizeObserver(() => this.resize()); this.resizeObserver.observe(container);
    this.clock.start(); this.loop(); this.emitSnapshot();
  }

  private chooseSpawn() {
    for (let radius = 0; radius < 80; radius += 4) for (let a = 0; a < Math.PI * 2; a += Math.PI / 4) {
      const x = Math.floor(Math.cos(a) * radius), z = Math.floor(Math.sin(a) * radius);
      if (this.world.heightAt(x, z) > 27 && this.world.heightAt(x, z) < 43) return new THREE.Vector3(x + 0.5, this.world.heightAt(x, z) + 1.05, z + 0.5);
    }
    return new THREE.Vector3(0.5, this.world.heightAt(0, 0) + 1.05, 0.5);
  }

  private bindEvents() {
    window.addEventListener('keydown', this.onKeyDown); window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('mousemove', this.onMouseMove); window.addEventListener('mousedown', this.onMouseDown);
    window.addEventListener('mouseup', this.onMouseUp); window.addEventListener('blur', this.onBlur);
    document.addEventListener('pointerlockchange', this.onPointerLock); document.addEventListener('wheel', this.onWheel, { passive: false });
    this.renderer.domElement.addEventListener('contextmenu', this.onContextMenu); this.renderer.domElement.addEventListener('click', this.onCanvasClick);
    window.addEventListener('pagehide', this.onPageHide);
  }

  private onKeyDown = (event: KeyboardEvent) => {
    if (['KeyW', 'KeyA', 'KeyS', 'KeyD', 'Space', 'ShiftLeft', 'ShiftRight'].includes(event.code)) event.preventDefault();
    this.keys.add(event.code);
    if (event.code === 'KeyE' && !event.repeat) {
      if (this.uiMode === 'playing') this.openInventory(); else if (this.uiMode === 'inventory') this.resume(); return;
    }
    if (this.uiMode !== 'playing') return;
    if (event.code.startsWith('Digit')) { const n = Number(event.code.slice(5)); if (n >= 1 && n <= 9) this.setSelected(n - 1); }
    if (event.code === 'F3' && !event.repeat) { event.preventDefault(); this.debug = !this.debug; this.emitSnapshot(); }
    if (event.code === 'KeyF' && !event.repeat && this.mode === 'creative') { this.player.flying = !this.player.flying; this.toast(this.player.flying ? 'Flight enabled' : 'Flight disabled'); }
    if (event.code === 'KeyQ' && !event.repeat) this.dropSelected(event.ctrlKey);
    this.syncInput();
  };
  private onKeyUp = (event: KeyboardEvent) => { this.keys.delete(event.code); this.syncInput(); };
  private syncInput() {
    this.input.forward = this.keys.has('KeyW') || this.keys.has('ArrowUp'); this.input.back = this.keys.has('KeyS') || this.keys.has('ArrowDown');
    this.input.left = this.keys.has('KeyA') || this.keys.has('ArrowLeft'); this.input.right = this.keys.has('KeyD') || this.keys.has('ArrowRight');
    this.input.jump = this.keys.has('Space'); this.input.sprint = this.keys.has('ShiftLeft') || this.keys.has('ShiftRight');
    this.input.down = this.keys.has('ControlLeft') || this.keys.has('KeyC');
  }
  private onMouseMove = (event: MouseEvent) => { if (this.uiMode === 'playing' && document.pointerLockElement === this.renderer.domElement) this.player.look(event.movementX, event.movementY, this.sensitivity); };
  private onMouseDown = (event: MouseEvent) => {
    if (this.uiMode !== 'playing' || document.pointerLockElement !== this.renderer.domElement) return;
    if (event.button === 0) this.leftMouse = true;
    if (event.button === 2 && this.useCooldown <= 0) { this.useItem(); this.useCooldown = 0.19; }
    if (event.button === 1) { event.preventDefault(); this.pickBlock(); }
  };
  private onMouseUp = (event: MouseEvent) => { if (event.button === 0) { this.leftMouse = false; this.miningProgress = 0; this.miningKey = ''; } };
  private onWheel = (event: WheelEvent) => { if (this.uiMode !== 'playing') return; event.preventDefault(); this.setSelected((this.selected + (event.deltaY > 0 ? 1 : 8)) % 9); };
  private onContextMenu = (event: Event) => event.preventDefault();
  private onCanvasClick = () => { if (this.uiMode === 'paused') this.resume(); };
  private onBlur = () => { this.keys.clear(); this.leftMouse = false; this.syncInput(); };
  private onPageHide = () => this.save();
  private onPointerLock = () => {
    const locked = document.pointerLockElement === this.renderer.domElement;
    if (locked && this.uiMode !== 'dead' && this.uiMode !== 'inventory') this.setMode('playing');
    else if (!locked && this.uiMode === 'playing') { this.setMode('paused'); this.onBlur(); this.save(); }
    this.emitSnapshot();
  };

  setMode(mode: UiMode) { if (this.uiMode !== mode) { this.uiMode = mode; this.options.callbacks.onMode(mode); } }
  resume() { if (this.uiMode === 'dead') return; this.audio.init(); this.setMode('playing'); const request = this.renderer.domElement.requestPointerLock(); if (request && 'catch' in request) request.catch(() => this.setMode('paused')); }
  pause() { if (this.uiMode === 'dead') return; this.setMode('paused'); this.onBlur(); if (document.pointerLockElement) document.exitPointerLock(); this.save(); }
  openInventory() { if (this.uiMode !== 'playing') return; this.setMode('inventory'); this.onBlur(); if (document.pointerLockElement) document.exitPointerLock(); this.emitSnapshot(); }
  setSelected(index: number) { this.selected = Math.max(0, Math.min(8, index)); this.miningProgress = 0; this.updateHeldItem(); this.emitSnapshot(); }
  setRenderDistance(value: number) { this.world.renderDistance = Math.max(2, Math.min(7, Math.round(value))); }
  setSensitivity(value: number) { this.sensitivity = value; }
  setSound(enabled: boolean, volume = this.audio.volume) { this.audio.enabled = enabled; this.audio.volume = volume; this.audio.setEnabled(enabled); this.audio.setVolume(volume); }

  private selectedStack() { return this.inventory[this.selected]; }
  private targetEntity() {
    const target = this.entities.target(this.player.eye, this.player.direction, 4);
    if (target && (!this.hit || target.distance < this.hit.distance)) return target;
    return null;
  }

  private useItem() {
    if (this.uiMode !== 'playing') return;
    const stack = this.selectedStack();
    if (stack && ITEMS[stack.id]?.food) {
      if (this.hunger >= 20 && this.health >= 20) { this.toast('You are already well fed'); return; }
      this.hunger = Math.min(20, this.hunger + (ITEMS[stack.id].food ?? 0)); this.health = Math.min(20, this.health + 2);
      if (this.mode !== 'creative') consumeSelected(this.inventory, this.selected); this.audio.play('eat'); this.swing = 1; this.toast(`Ate ${itemName(stack.id)}`, 'success'); this.updateHeldItem(); return;
    }
    if (stack?.id === 114) {
      if (this.entities.boss) { this.toast('The Ancient Guardian is already here', 'danger'); return; }
      if (this.entities.summonGuardian(this.player.position, this.player.direction.setY(0).normalize())) {
        if (this.mode !== 'creative') consumeSelected(this.inventory, this.selected); this.bossEncounter = true; this.unlock('summon');
        this.toast('The Ancient Guardian awakens. Watch the ground!', 'danger'); this.shake = 0.8; this.updateHeldItem();
      }
      return;
    }
    this.hit = this.world.raycast(this.player.eye, this.player.direction, 6);
    if (!this.hit) return;
    if ((this.hit.id === B.CraftingTable || this.hit.id === B.Furnace) && !this.input.sprint) { this.openInventory(); return; }
    if (!stack || stack.id >= 100 || stack.id === B.Air || stack.id === B.Water) return;
    if (stack.count <= 0 && this.mode !== 'creative') return;
    const x = this.hit.x + this.hit.nx, y = this.hit.y + this.hit.ny, z = this.hit.z + this.hit.nz;
    if (y <= 0 || y >= WORLD_HEIGHT || this.world.getBlock(x, y, z) !== B.Air && this.world.getBlock(x, y, z) !== B.Water) return;
    if (this.player.intersectsBlock(x, y, z)) { this.toast('Cannot place a block inside yourself'); return; }
    if (this.world.setBlock(x, y, z, stack.id)) {
      if (this.mode !== 'creative') consumeSelected(this.inventory, this.selected);
      this.audio.play('place'); this.particles.burst(new THREE.Vector3(x + 0.5, y + 0.5, z + 0.5), BLOCKS[stack.id].color, 6, 1.6); this.swing = 0.7;
      this.updateHeldItem(); this.emitSnapshot();
    }
  }

  private pickBlock() {
    const hit = this.world.raycast(this.player.eye, this.player.direction, 6); if (!hit) return;
    const existing = this.inventory.findIndex((s, i) => i < 9 && s?.id === hit.id);
    if (existing >= 0) this.setSelected(existing);
    else if (this.mode === 'creative') { this.inventory[this.selected] = { id: hit.id, count: 64 }; this.updateHeldItem(); this.emitSnapshot(); }
  }

  private dropSelected(all: boolean) {
    const stack = this.selectedStack(); if (!stack) return;
    const count = all ? stack.count : 1;
    const direction = this.player.direction; const pos = this.player.eye.addScaledVector(direction, 0.65);
    const drop = this.spawnDrop(stack.id, count, pos, stack.durability);
    drop.velocity.addScaledVector(direction, 4).y += 2;
    if (this.mode !== 'creative') { stack.count -= count; if (stack.count <= 0) this.inventory[this.selected] = null; }
    this.updateHeldItem(); this.emitSnapshot();
  }

  private breakBlock(hit: RayHit) {
    const id = hit.id; if (id === B.Bedrock) return;
    if (!this.world.setBlock(hit.x, hit.y, hit.z, B.Air)) return;
    const position = new THREE.Vector3(hit.x + 0.5, hit.y + 0.5, hit.z + 0.5), def = BLOCKS[id];
    this.particles.burst(position, def.color, 20, 4.5); this.audio.play('break'); this.swing = 1;
    if (this.mode !== 'creative') {
      const drop = def.drop ?? id;
      if (drop && drop !== B.Air) this.spawnDrop(drop, 1, position);
      if ((id === B.Leaves || id === B.BirchLeaves) && Math.random() < 0.13) this.spawnDrop(115, 1, position);
      if (this.selectedStack() && ITEMS[this.selectedStack()!.id]?.tool) {
        const toolName = itemName(this.selectedStack()!.id);
        if (damageTool(this.inventory, this.selected)) { this.toast(`${toolName} broke`, 'danger'); this.updateHeldItem(); }
      }
      if ([B.OakLog, B.BirchLog, B.CoalOre, B.IronOre, B.Crystal, B.Glowstone].includes(id)) this.awardXp(def.xp ?? 0);
    }
    if (id === B.OakLog || id === B.BirchLog) this.unlock('wood');
    if (id === B.Stone || id === B.Cobblestone) this.unlock('stone');
    if (id === B.CoalOre) this.unlock('coal'); if (id === B.IronOre) this.unlock('iron'); if (id === B.Crystal) this.unlock('crystal');
    this.miningProgress = 0; this.miningKey = ''; this.updateHeldItem();
  }

  private updateInteraction(dt: number) {
    this.attackCooldown = Math.max(0, this.attackCooldown - dt); this.useCooldown = Math.max(0, this.useCooldown - dt); this.mineSound -= dt;
    this.hit = this.world.raycast(this.player.eye, this.player.direction, 6);
    this.outline.visible = !!this.hit;
    if (this.hit) this.outline.position.set(this.hit.x + 0.5, this.hit.y + 0.5, this.hit.z + 0.5);
    const entityTarget = this.leftMouse ? this.targetEntity() : null;
    if (entityTarget) {
      this.crack.visible = false; this.miningProgress = 0; this.miningKey = '';
      if (this.attackCooldown <= 0) {
        const stack = this.selectedStack(), item = stack ? ITEMS[stack.id] : null;
        this.entities.damage(entityTarget.entity, item?.damage ?? 1, this.player.direction.clone().setY(0).normalize());
        this.audio.play('hit'); this.attackCooldown = item?.tool === 'sword' ? 0.38 : 0.5; this.swing = 1;
        if (stack && item?.tool && this.mode !== 'creative' && damageTool(this.inventory, this.selected)) this.toast('Your tool broke', 'danger');
        this.updateHeldItem();
      }
      return;
    }
    if (!this.leftMouse || !this.hit) { this.crack.visible = false; if (!this.leftMouse) this.miningProgress = 0; return; }
    const key = `${this.hit.x},${this.hit.y},${this.hit.z}`;
    if (key !== this.miningKey) { this.miningKey = key; this.miningProgress = 0; }
    const duration = this.mode === 'creative' ? 0.05 : miningTime(this.hit.id, this.selectedStack());
    if (!Number.isFinite(duration)) { this.crack.visible = false; this.miningProgress = 0; return; }
    this.miningProgress += dt / duration; this.swing = Math.max(this.swing, 0.35);
    this.crack.visible = true; this.crack.position.copy(this.outline.position); (this.crack.material as THREE.MeshBasicMaterial).opacity = 0.12 + this.miningProgress * 0.6;
    this.crack.scale.setScalar(1 + Math.sin(this.miningProgress * 30) * 0.003);
    if (this.mineSound <= 0) { this.audio.play('hit'); this.mineSound = 0.22; this.particles.burst(new THREE.Vector3(this.hit.x + 0.5, this.hit.y + 0.5, this.hit.z + 0.5), BLOCKS[this.hit.id].color, 2, 1.4); }
    if (this.miningProgress >= 1) this.breakBlock(this.hit);
  }

  private spawnDrop(id: number, count: number, position: THREE.Vector3, durability?: number): Drop {
    for (const drop of this.drops) if (drop.id === id && drop.mesh.position.distanceToSquared(position) < 1.2 && drop.count + count <= maxStack(id)) { drop.count += count; return drop; }
    let material = this.dropMaterials.get(id);
    if (!material) { material = new THREE.MeshStandardMaterial({ color: itemColor(id), roughness: 0.72, emissive: id === 113 || id === 114 ? itemColor(id) : '#000000', emissiveIntensity: 0.35 }); this.dropMaterials.set(id, material); }
    const mesh = new THREE.Mesh(this.dropGeometry, material); mesh.position.copy(position); mesh.castShadow = true; this.scene.add(mesh);
    const drop: Drop = { id, count, durability, mesh, velocity: new THREE.Vector3((Math.random() - 0.5) * 1.5, 2.2, (Math.random() - 0.5) * 1.5), age: 0 };
    this.drops.push(drop); return drop;
  }

  private updateDrops(dt: number) {
    for (let i = this.drops.length - 1; i >= 0; i--) {
      const drop = this.drops[i]; drop.age += dt; drop.velocity.y -= 14 * dt;
      const next = drop.mesh.position.clone().addScaledVector(drop.velocity, dt);
      if (BLOCKS[this.world.getBlock(next.x, next.y - 0.16, next.z)]?.solid && drop.velocity.y < 0) {
        drop.mesh.position.y = Math.floor(next.y - 0.16) + 1.17; drop.velocity.y *= -0.2; drop.velocity.x *= 0.72; drop.velocity.z *= 0.72;
      } else drop.mesh.position.copy(next);
      drop.mesh.rotation.y += dt * 1.8; drop.mesh.rotation.x = 0.3; drop.mesh.position.y += Math.sin(drop.age * 3) * 0.0007;
      if (drop.age > 0.35 && drop.mesh.position.distanceToSquared(this.player.position.clone().add(new THREE.Vector3(0, 0.7, 0))) < 2.3) {
        const remaining = addItem(this.inventory, drop.id, drop.count, drop.durability); drop.count = remaining;
        if (remaining === 0) { this.scene.remove(drop.mesh); this.drops.splice(i, 1); this.audio.play('pickup'); this.emitSnapshot(); }
      }
      if (drop.mesh.position.y < -12) { this.scene.remove(drop.mesh); this.drops.splice(i, 1); }
    }
  }

  private updateBlockLights() {
    const sources = this.world.getNearbyLights(this.player.position, 20);
    for (let i = 0; i < this.blockLights.length; i++) {
      const light = this.blockLights[i], source = sources[i];
      if (!source) { light.visible = false; continue; }
      light.visible = true; light.position.set(source.x, source.y, source.z);
      light.color.set(source.id === B.Crystal ? '#79d9cf' : '#f2c675');
      light.intensity = source.id === B.Crystal ? 3.2 : 5.5; light.distance = source.id === B.Crystal ? 8 : 11;
    }
  }

  private updateStations() {
    this.nearTable = false; this.nearFurnace = false;
    const px = Math.floor(this.player.position.x), py = Math.floor(this.player.position.y), pz = Math.floor(this.player.position.z);
    for (let y = py - 2; y <= py + 3; y++) for (let z = pz - 3; z <= pz + 3; z++) for (let x = px - 3; x <= px + 3; x++) {
      const id = this.world.getBlock(x, y, z, false); if (id === B.CraftingTable) this.nearTable = true; if (id === B.Furnace) this.nearFurnace = true;
      if (this.nearTable && this.nearFurnace) return;
    }
  }

  craft(recipeId: string) {
    const result = craftRecipe(this.inventory, recipeId, this.mode === 'creative' ? 999 : levelFromXp(this.xp), this.nearTable || this.mode === 'creative', this.nearFurnace || this.mode === 'creative');
    if (!result.ok) { this.toast(result.reason, 'danger'); return false; }
    this.awardXp(result.recipe!.xp); this.audio.play('craft'); this.toast(`Crafted ${result.recipe!.count}× ${itemName(result.recipe!.output)}`, 'success');
    if (result.recipe!.output === B.CraftingTable) this.unlock('workbench'); this.updateHeldItem(); this.emitSnapshot(); this.save(); return true;
  }

  moveInventorySlot(from: number, to: number) { moveStack(this.inventory, from, to); this.updateHeldItem(); this.emitSnapshot(); }
  creativeGive(id: number) { if (this.mode !== 'creative') return; addItem(this.inventory, id, maxStack(id)); this.updateHeldItem(); this.emitSnapshot(); }

  private awardXp(amount: number) {
    if (!amount || this.mode === 'creative') return;
    const before = levelFromXp(this.xp); this.xp += amount; const after = levelFromXp(this.xp);
    if (after > before) { this.audio.play('level'); this.toast(`Level ${after} reached — new recipes available`, 'success'); }
    if (after >= 5) this.unlock('level5');
  }

  private unlock(id: string) {
    if (this.achievements.has(id)) return; this.achievements.add(id); this.toast(`Advancement: ${ACHIEVEMENTS[id] ?? id}`, 'success');
  }

  private damagePlayer(amount: number, source: string) {
    if (this.mode === 'creative' || this.uiMode !== 'playing' || this.invulnerable > 0) return;
    this.health = Math.max(0, this.health - amount); this.invulnerable = 0.48; this.shake = Math.max(this.shake, 0.4);
    this.audio.play('hurt'); this.options.callbacks.onHurt();
    if (this.health <= 0) { this.setMode('dead'); this.onBlur(); if (document.pointerLockElement) document.exitPointerLock(); this.toast(`Defeated by ${source}`, 'danger'); this.save(); }
  }

  respawn() {
    this.health = 20; this.hunger = 18; this.air = 20; this.xp = Math.floor(this.xp * 0.85); this.player.position.copy(this.spawnPoint); this.player.velocity.set(0, 0, 0);
    this.invulnerable = 2; this.setMode('paused'); this.save(); this.emitSnapshot(); this.resume();
  }

  private simulate(dt: number) {
    this.playTime += dt; this.saveTimer -= dt; this.invulnerable = Math.max(0, this.invulnerable - dt);
    this.hours += dt * 24 / 1200; if (this.hours >= 24) { this.hours -= 24; this.day++; }
    this.weatherTimer -= dt;
    if (this.weatherTimer <= 0) {
      const roll = Math.random(); this.weather = roll < 0.52 ? 'Clear' : roll < 0.8 ? 'Rain' : roll < 0.92 ? 'Storm' : 'Snow';
      this.weatherTimer = 100 + Math.random() * 150; this.toast(this.weather === 'Clear' ? 'The sky is clearing' : `${this.weather} is moving in`);
    }
    this.weatherSystem.setWeather(this.weather, this.world.getBiome(this.player.position.x, this.player.position.z) === 'Tundra');
    const result = this.player.update(dt, this.input);
    if (result.sprinting) this.hunger = Math.max(0, this.hunger - dt * 0.035);
    if (this.mode === 'survival') {
      this.hunger = Math.max(0, this.hunger - dt * 0.0028);
      if (this.hunger <= 0) { this.starvationTimer += dt; if (this.starvationTimer > 4) { this.damagePlayer(1, 'starvation'); this.starvationTimer = 0; } }
      else if (this.hunger > 17 && this.health < 20) { this.regenTimer += dt; if (this.regenTimer > 5) { this.health = Math.min(20, this.health + 1); this.hunger = Math.max(0, this.hunger - 0.6); this.regenTimer = 0; } }
      if (this.player.justLanded) { const impact = -this.player.justLanded; if (impact > 12) this.damagePlayer(Math.floor((impact - 10) * 1.35), 'a fall'); }
      this.cactusTimer -= dt;
      if (this.cactusTimer <= 0) {
        const p = this.player.position; let touching = false;
        for (const [x, z] of [[0.36, 0], [-0.36, 0], [0, 0.36], [0, -0.36]]) if (this.world.getBlock(p.x + x, p.y + 0.5, p.z + z) === B.Cactus) touching = true;
        if (touching) { this.damagePlayer(2, 'a cactus'); this.cactusTimer = 0.8; }
      }
    }
    if (this.player.stepDistance > (result.sprinting ? 1.65 : 2.05) && this.player.onGround) { this.audio.play('step'); this.player.stepDistance = 0; }
    if (this.player.inWater !== this.wasInWater) { if (this.player.inWater) this.audio.play('splash'); this.wasInWater = this.player.inWater; }
    if (this.mode === 'survival') {
      if (this.player.headUnderwater) {
        this.air = Math.max(0, this.air - dt);
        if (this.air <= 0) { this.drownTimer += dt; if (this.drownTimer >= 2) { this.damagePlayer(2, 'drowning'); this.drownTimer = 0; } }
      } else { this.air = Math.min(20, this.air + dt * 8); this.drownTimer = 0; }
    }
    this.updateInteraction(dt); this.updateDrops(dt);
    const night = this.hours < 6 || this.hours > 18.5; this.entities.update(dt, this.player.position, night);
    if (this.bossEncounter && !this.entities.boss) {
      this.bossEncounter = false;
      if (!this.bossDefeated) { this.bossDefeated = true; this.unlock('guardian'); this.toast('The valley is safe. Guardian treasures lie nearby!', 'success'); }
    }
    this.stationTimer -= dt; if (this.stationTimer <= 0) { this.updateStations(); this.stationTimer = 0.45; }
    this.lightTimer -= dt; if (this.lightTimer <= 0) { this.updateBlockLights(); this.lightTimer = 0.75; }
    if (this.saveTimer <= 0) { this.save(); this.saveTimer = 25; }
  }

  private clearHeldItem() {
    this.heldGroup.traverse(object => {
      if (object instanceof THREE.Mesh) {
        object.geometry.dispose();
        const materials = Array.isArray(object.material) ? object.material : [object.material]; materials.forEach(material => material.dispose());
      }
    });
    this.heldGroup.clear();
  }

  private updateHeldItem() {
    const id = this.selectedStack()?.id ?? -1; if (id === this.heldItem) return; this.heldItem = id; this.clearHeldItem();
    if (id < 0) return;
    const material = new THREE.MeshStandardMaterial({ color: itemColor(id), roughness: 0.75, depthTest: false });
    if (id < 100) {
      const cube = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.34, 0.34), material); cube.rotation.set(0.25, 0.6, 0.1); cube.renderOrder = 20; this.heldGroup.add(cube);
    } else if (ITEMS[id]?.tool) {
      const handle = new THREE.Mesh(new THREE.BoxGeometry(0.065, 0.55, 0.065), new THREE.MeshStandardMaterial({ color: '#765033', depthTest: false }));
      handle.rotation.z = -0.35; handle.renderOrder = 20; this.heldGroup.add(handle);
      const head = new THREE.Mesh(new THREE.BoxGeometry(ITEMS[id].tool === 'sword' ? 0.08 : 0.38, ITEMS[id].tool === 'sword' ? 0.55 : 0.13, 0.08), material);
      head.position.set(ITEMS[id].tool === 'sword' ? 0.1 : -0.09, 0.28, 0); head.rotation.z = ITEMS[id].tool === 'sword' ? -0.35 : 0.2; head.renderOrder = 20; this.heldGroup.add(head);
    } else {
      const item = new THREE.Mesh(new THREE.OctahedronGeometry(0.2, 0), material); item.renderOrder = 20; this.heldGroup.add(item);
    }
    this.heldGroup.position.set(0.52, -0.43, -0.82); this.heldGroup.rotation.set(-0.15, -0.15, 0.05);
  }

  private updateCamera(dt: number) {
    const speed = Math.hypot(this.player.velocity.x, this.player.velocity.z);
    if (this.player.onGround && speed > 0.3) this.walkBob += dt * speed * 1.65;
    const bob = this.player.onGround ? Math.sin(this.walkBob * 2) * Math.min(0.045, speed * 0.007) : 0;
    this.shake = Math.max(0, this.shake - dt * 1.8); this.swing = Math.max(0, this.swing - dt * 3.7);
    const shakeX = (Math.random() - 0.5) * this.shake * 0.08, shakeY = (Math.random() - 0.5) * this.shake * 0.07;
    this.camera.position.copy(this.player.eye); this.camera.position.y += bob + shakeY; this.camera.position.x += shakeX;
    this.camera.rotation.set(this.player.pitch + shakeY * 0.2, this.player.yaw, Math.sin(this.walkBob) * Math.min(0.012, speed * 0.002));
    const sprint = this.input.sprint && this.input.forward ? 1 : 0; this.camera.fov += ((74 + sprint * 6 + (this.player.flying ? 3 : 0)) - this.camera.fov) * Math.min(1, dt * 7); this.camera.updateProjectionMatrix();
    const swingCurve = Math.sin((1 - this.swing) * Math.PI) * (this.swing > 0 ? 1 : 0);
    this.heldGroup.position.set(0.52 - swingCurve * 0.17, -0.43 - swingCurve * 0.2 + bob * 0.5, -0.82 + swingCurve * 0.08);
    this.heldGroup.rotation.x = -0.15 - swingCurve * 0.8; this.heldGroup.rotation.z = 0.05 + swingCurve * 0.35;
    this.heldGroup.visible = this.uiMode === 'playing';
  }

  private emitSnapshot() {
    const level = levelFromXp(this.xp), currentXp = xpForLevel(level), nextXp = xpForLevel(level + 1);
    const targetRequired = this.hit ? miningTime(this.hit.id, this.selectedStack()) : 0;
    const boss = this.entities.boss;
    this.options.callbacks.onSnapshot({
      health: this.health, hunger: this.hunger, air: this.air, xp: this.xp, level, levelProgress: (this.xp - currentXp) / Math.max(1, nextXp - currentXp),
      inventory: this.inventory.map(s => s ? { ...s } : null), selected: this.selected, targetName: this.hit ? itemName(this.hit.id) : '',
      miningProgress: this.miningProgress, targetHint: this.hit && !Number.isFinite(targetRequired) ? this.hit.id === B.Bedrock ? 'Unbreakable' : `Requires ${BLOCKS[this.hit.id]?.tool ?? 'a better tool'} · tier ${BLOCKS[this.hit.id]?.tier ?? ''}` : '',
      x: this.player.position.x, y: this.player.position.y, z: this.player.position.z, biome: this.world.getBiome(this.player.position.x, this.player.position.z),
      hours: this.hours, day: this.day, weather: this.weather, fps: this.fps, chunks: this.streamInfo.loaded, totalChunks: this.streamInfo.total,
      queuedChunks: this.streamInfo.queued, underwater: this.player.headUnderwater, flying: this.player.flying, mode: this.mode,
      nearTable: this.nearTable, nearFurnace: this.nearFurnace, debug: this.debug, locked: document.pointerLockElement === this.renderer.domElement,
      achievements: [...this.achievements], bossDefeated: this.bossDefeated,
      boss: boss ? { name: 'Ancient Guardian', health: Math.max(0, boss.health), maxHealth: boss.maxHealth, phase: boss.health < boss.maxHealth * 0.3 ? 3 : boss.health < boss.maxHealth * 0.6 ? 2 : 1, telegraph: boss.attack } : null,
    });
  }

  private loop = () => {
    if (this.destroyed) return; this.animation = requestAnimationFrame(this.loop);
    const dt = Math.min(0.05, this.clock.getDelta()); this.fps += ((dt > 0 ? 1 / dt : 60) - this.fps) * 0.06;
    if (this.uiMode === 'playing') {
      this.accumulator = Math.min(this.accumulator + dt, 0.1);
      let steps = 0; while (this.accumulator >= 1 / 60 && steps++ < 5) { this.simulate(1 / 60); this.accumulator -= 1 / 60; }
    }
    const budget = this.uiMode === 'playing' ? 1 : 2;
    this.streamInfo = this.world.updateStreaming(this.player.position.x, this.player.position.z, budget, budget);
    this.environment.update(this.uiMode === 'playing' ? dt : 0, this.hours, this.camera.position, this.weather, this.player.headUnderwater, this.world.renderDistance);
    this.weatherSystem.update(dt, this.camera.position, (x, y, z) => !!BLOCKS[this.world.getBlock(x, y, z, false)]?.solid);
    this.world.updateTime(performance.now() * 0.001); this.particles.update(dt); this.updateCamera(dt);
    this.audio.update(this.weather, this.hours < 6 || this.hours > 18.5);
    this.renderer.render(this.scene, this.camera);
    this.snapshotTimer -= dt; if (this.snapshotTimer <= 0) { this.emitSnapshot(); this.snapshotTimer = 0.12; }
  };

  save() {
    const data: SavedGame = {
      version: 1, id: this.id, name: this.name, seedLabel: this.seedLabel, seed: this.world.seed, mode: this.mode,
      updatedAt: Date.now(), playTime: this.playTime, edits: this.world.serializeEdits(),
      player: { x: this.player.position.x, y: this.player.position.y, z: this.player.position.z, yaw: this.player.yaw, pitch: this.player.pitch },
      inventory: this.inventory.map(s => s ? { ...s } : null), selected: this.selected, health: this.health, hunger: this.hunger, air: this.air,
      xp: this.xp, hours: this.hours, day: this.day, weather: this.weather, achievements: [...this.achievements], bossDefeated: this.bossDefeated,
    };
    if (!saveWorld(data) && this.saveTimer < 0) this.toast('Local save failed — browser storage may be full', 'danger');
    return data;
  }

  private resize() {
    const width = this.container.clientWidth, height = Math.max(1, this.container.clientHeight);
    this.camera.aspect = width / height; this.camera.updateProjectionMatrix(); this.renderer.setSize(width, height);
  }

  private toast(message: string, kind: ToastKind = 'info') { this.options.callbacks.onToast(message, kind); }

  destroy() {
    if (this.destroyed) return; this.save(); this.destroyed = true; cancelAnimationFrame(this.animation); this.resizeObserver.disconnect();
    window.removeEventListener('keydown', this.onKeyDown); window.removeEventListener('keyup', this.onKeyUp); window.removeEventListener('mousemove', this.onMouseMove);
    window.removeEventListener('mousedown', this.onMouseDown); window.removeEventListener('mouseup', this.onMouseUp); window.removeEventListener('blur', this.onBlur);
    document.removeEventListener('pointerlockchange', this.onPointerLock); document.removeEventListener('wheel', this.onWheel);
    this.renderer.domElement.removeEventListener('contextmenu', this.onContextMenu); this.renderer.domElement.removeEventListener('click', this.onCanvasClick);
    window.removeEventListener('pagehide', this.onPageHide); if (document.pointerLockElement === this.renderer.domElement) document.exitPointerLock();
    this.entities.dispose(); this.particles.dispose(); this.weatherSystem.dispose(); this.environment.dispose(); this.world.dispose(); this.audio.dispose(); this.clearHeldItem();
    this.dropGeometry.dispose(); this.dropMaterials.forEach(m => m.dispose()); this.outline.geometry.dispose(); (this.outline.material as THREE.Material).dispose();
    this.crack.geometry.dispose(); (this.crack.material as THREE.Material).dispose(); this.renderer.dispose(); this.renderer.domElement.remove();
  }
}

export { RECIPES };
