import * as THREE from 'three';
import { B, BLOCKS } from './blocks';
import { VoxelWorld } from './world';

export type PlayerInput = { forward: boolean; back: boolean; left: boolean; right: boolean; jump: boolean; sprint: boolean; down: boolean };

export class PlayerController {
  position = new THREE.Vector3();
  velocity = new THREE.Vector3();
  yaw = 0; pitch = 0;
  onGround = false; inWater = false; headUnderwater = false;
  flying = false; creative = false;
  readonly halfWidth = 0.3; readonly height = 1.8; readonly eyeHeight = 1.62;
  private coyote = 0; private jumpBuffer = 0; private wasJump = false;
  distanceWalked = 0; stepDistance = 0;
  justLanded: number | null = null;

  constructor(private world: VoxelWorld) {}

  get eye() { return new THREE.Vector3(this.position.x, this.position.y + this.eyeHeight, this.position.z); }
  get direction() { return new THREE.Vector3(-Math.sin(this.yaw) * Math.cos(this.pitch), Math.sin(this.pitch), -Math.cos(this.yaw) * Math.cos(this.pitch)); }

  look(dx: number, dy: number, sensitivity: number) {
    this.yaw -= dx * sensitivity; this.pitch -= dy * sensitivity;
    this.pitch = Math.max(-Math.PI / 2 + 0.01, Math.min(Math.PI / 2 - 0.01, this.pitch));
  }

  private collides(pos: THREE.Vector3) {
    const eps = 0.0001;
    const minX = Math.floor(pos.x - this.halfWidth + eps), maxX = Math.floor(pos.x + this.halfWidth - eps);
    const minY = Math.floor(pos.y + eps), maxY = Math.floor(pos.y + this.height - eps);
    const minZ = Math.floor(pos.z - this.halfWidth + eps), maxZ = Math.floor(pos.z + this.halfWidth - eps);
    for (let y = minY; y <= maxY; y++) for (let z = minZ; z <= maxZ; z++) for (let x = minX; x <= maxX; x++) {
      const id = this.world.getBlock(x, y, z);
      if (BLOCKS[id]?.solid) return { x, y, z, id };
    }
    return null;
  }

  private moveAxis(axis: 'x' | 'y' | 'z', amount: number) {
    if (amount === 0) return;
    this.position[axis] += amount;
    let iterations = 0;
    while (iterations++ < 8) {
      const hit = this.collides(this.position); if (!hit) break;
      if (axis === 'x') this.position.x = amount > 0 ? hit.x - this.halfWidth - 0.001 : hit.x + 1 + this.halfWidth + 0.001;
      else if (axis === 'z') this.position.z = amount > 0 ? hit.z - this.halfWidth - 0.001 : hit.z + 1 + this.halfWidth + 0.001;
      else {
        if (amount > 0) this.position.y = hit.y - this.height - 0.001;
        else { this.position.y = hit.y + 1; this.onGround = true; }
        this.velocity.y = 0;
      }
      if (axis !== 'y') this.velocity[axis] = 0;
    }
  }

  update(dt: number, input: PlayerInput) {
    this.justLanded = null;
    const feetId = this.world.getBlock(this.position.x, this.position.y + 0.15, this.position.z);
    const waistId = this.world.getBlock(this.position.x, this.position.y + 0.8, this.position.z);
    this.inWater = feetId === B.Water || waistId === B.Water;
    this.headUnderwater = this.world.getBlock(this.position.x, this.position.y + this.eyeHeight, this.position.z) === B.Water;
    if (input.jump && !this.wasJump) this.jumpBuffer = 0.12;
    this.wasJump = input.jump; this.jumpBuffer = Math.max(0, this.jumpBuffer - dt);
    this.coyote = this.onGround ? 0.1 : Math.max(0, this.coyote - dt);

    let forward = Number(input.forward) - Number(input.back), strafe = Number(input.right) - Number(input.left);
    const length = Math.hypot(forward, strafe); if (length > 1) { forward /= length; strafe /= length; }
    const sprinting = input.sprint && forward > 0 && !this.inWater;
    const speed = this.flying ? (input.sprint ? 13 : 8) : this.inWater ? 3.2 : sprinting ? 6.6 : 4.35;
    const sin = Math.sin(this.yaw), cos = Math.cos(this.yaw);
    const targetX = (-sin * forward + cos * strafe) * speed;
    const targetZ = (-cos * forward - sin * strafe) * speed;
    const acceleration = this.onGround || this.flying ? 18 : this.inWater ? 8 : 5;
    this.velocity.x += (targetX - this.velocity.x) * Math.min(1, acceleration * dt);
    this.velocity.z += (targetZ - this.velocity.z) * Math.min(1, acceleration * dt);

    if (this.flying) {
      const up = Number(input.jump) - Number(input.down);
      this.velocity.y += (up * speed - this.velocity.y) * Math.min(1, 14 * dt);
      this.onGround = false;
    } else if (this.inWater) {
      this.velocity.y -= 5 * dt;
      this.velocity.y *= Math.pow(0.45, dt);
      if (input.jump) this.velocity.y = Math.min(4.2, this.velocity.y + 15 * dt);
    } else {
      this.velocity.y -= 24 * dt;
      if (this.jumpBuffer > 0 && this.coyote > 0) {
        this.velocity.y = 8.15; this.onGround = false; this.coyote = 0; this.jumpBuffer = 0;
      }
    }

    const oldX = this.position.x, oldZ = this.position.z;
    const impactVelocity = this.velocity.y;
    this.onGround = false;
    this.moveAxis('x', this.velocity.x * dt); this.moveAxis('z', this.velocity.z * dt); this.moveAxis('y', this.velocity.y * dt);
    if (this.onGround && impactVelocity < -11 && !this.inWater) this.justLanded = impactVelocity;
    const horizontal = Math.hypot(this.position.x - oldX, this.position.z - oldZ);
    this.distanceWalked += horizontal; this.stepDistance += horizontal;
    if (this.position.y < -8) { this.position.y = this.world.findSurface(this.position.x, this.position.z) + 1; this.velocity.set(0, 0, 0); }
    return { sprinting, speed: horizontal / Math.max(dt, 0.0001) };
  }

  intersectsBlock(x: number, y: number, z: number) {
    return this.position.x + this.halfWidth > x && this.position.x - this.halfWidth < x + 1 &&
      this.position.y + this.height > y && this.position.y < y + 1 &&
      this.position.z + this.halfWidth > z && this.position.z - this.halfWidth < z + 1;
  }
}
