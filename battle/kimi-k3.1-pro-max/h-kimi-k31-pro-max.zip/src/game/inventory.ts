import { ITEMS, RECIPES, Recipe, Stack, maxStack } from './blocks';

export const INVENTORY_SIZE = 36;
export const emptyInventory = (): (Stack | null)[] => Array.from({ length: INVENTORY_SIZE }, () => null);

export function addItem(slots: (Stack | null)[], id: number, count: number, durability?: number) {
  const max = maxStack(id);
  if (max > 1) {
    for (const slot of slots) {
      if (count <= 0) break;
      if (slot?.id === id && slot.count < max) { const amount = Math.min(count, max - slot.count); slot.count += amount; count -= amount; }
    }
  }
  while (count > 0) {
    const index = slots.findIndex(slot => slot === null); if (index < 0) break;
    const amount = Math.min(count, max); slots[index] = { id, count: amount };
    if (max === 1 && ITEMS[id]?.tool) slots[index]!.durability = durability ?? toolDurability(id);
    count -= amount;
  }
  return count;
}

export function countItem(slots: (Stack | null)[], id: number) {
  return slots.reduce((sum, slot) => sum + (slot?.id === id ? slot.count : 0), 0);
}

export function removeItem(slots: (Stack | null)[], id: number, count: number) {
  if (countItem(slots, id) < count) return false;
  for (let i = slots.length - 1; i >= 0 && count > 0; i--) {
    const slot = slots[i]; if (!slot || slot.id !== id) continue;
    const amount = Math.min(count, slot.count); slot.count -= amount; count -= amount;
    if (slot.count <= 0) slots[i] = null;
  }
  return true;
}

export function consumeSelected(slots: (Stack | null)[], selected: number) {
  const stack = slots[selected]; if (!stack) return;
  stack.count--; if (stack.count <= 0) slots[selected] = null;
}

export function damageTool(slots: (Stack | null)[], selected: number, amount = 1) {
  const stack = slots[selected]; if (!stack || !ITEMS[stack.id]?.tool || stack.durability == null) return false;
  stack.durability -= amount;
  if (stack.durability <= 0) { slots[selected] = null; return true; }
  return false;
}

export const toolDurability = (id: number) => ({ 1: 60, 2: 132, 3: 251 }[ITEMS[id]?.tier ?? 1] ?? 60);

export function canCraft(slots: (Stack | null)[], recipe: Recipe, level: number, nearTable: boolean, nearFurnace: boolean) {
  if ((recipe.level ?? 1) > level) return { ok: false, reason: `Requires level ${recipe.level}` };
  if (recipe.station === 'table' && !nearTable) return { ok: false, reason: 'Stand near a crafting table' };
  if (recipe.station === 'furnace' && !nearFurnace) return { ok: false, reason: 'Stand near a furnace' };
  for (const ingredient of recipe.ingredients) if (countItem(slots, ingredient.id) < ingredient.count) return { ok: false, reason: `Missing ${ingredient.count}× required material` };
  return { ok: true, reason: '' };
}

export type CraftResult = { ok: true; reason: ''; recipe: Recipe } | { ok: false; reason: string; recipe?: never };

export function craft(slots: (Stack | null)[], recipeId: string, level: number, nearTable: boolean, nearFurnace: boolean): CraftResult {
  const recipe = RECIPES.find(r => r.id === recipeId);
  if (!recipe) return { ok: false, reason: 'Unknown recipe' };
  const check = canCraft(slots, recipe, level, nearTable, nearFurnace); if (!check.ok) return { ok: false, reason: check.reason };
  const simulation = slots.map(slot => slot ? { ...slot } : null);
  for (const ingredient of recipe.ingredients) removeItem(simulation, ingredient.id, ingredient.count);
  if (addItem(simulation, recipe.output, recipe.count) > 0) return { ok: false, reason: 'Inventory is full' };
  for (let i = 0; i < slots.length; i++) slots[i] = simulation[i];
  return { ok: true, reason: '', recipe };
}

export function moveStack(slots: (Stack | null)[], from: number, to: number) {
  if (from === to || from < 0 || to < 0 || from >= slots.length || to >= slots.length) return;
  const a = slots[from], b = slots[to];
  if (!a) return;
  if (b && a.id === b.id && maxStack(a.id) > 1 && a.durability == null && b.durability == null) {
    const amount = Math.min(a.count, maxStack(a.id) - b.count); b.count += amount; a.count -= amount;
    if (a.count <= 0) slots[from] = null;
  } else { slots[from] = b; slots[to] = a; }
}
