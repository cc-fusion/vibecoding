export class GameAudio {
  private context: AudioContext | null = null;
  private master: GainNode | null = null;
  private wind: GainNode | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private nextMusic = 0;
  enabled = true; volume = 0.7;

  init() {
    if (this.context) { if (this.context.state === 'suspended') this.context.resume(); return; }
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    this.context = new AudioContextClass(); this.master = this.context.createGain();
    this.master.gain.value = this.enabled ? this.volume : 0; this.master.connect(this.context.destination);
    const length = this.context.sampleRate;
    this.noiseBuffer = this.context.createBuffer(1, length, this.context.sampleRate);
    const channel = this.noiseBuffer.getChannelData(0); for (let i = 0; i < length; i++) channel[i] = Math.random() * 2 - 1;
    const source = this.context.createBufferSource(); source.buffer = this.noiseBuffer; source.loop = true;
    const filter = this.context.createBiquadFilter(); filter.type = 'lowpass'; filter.frequency.value = 420;
    this.wind = this.context.createGain(); this.wind.gain.value = 0.016;
    source.connect(filter); filter.connect(this.wind); this.wind.connect(this.master); source.start();
    this.nextMusic = this.context.currentTime + 4;
  }

  setEnabled(enabled: boolean) { this.enabled = enabled; if (this.master && this.context) this.master.gain.setTargetAtTime(enabled ? this.volume : 0, this.context.currentTime, 0.03); }
  setVolume(volume: number) { this.volume = volume; if (this.master && this.context) this.master.gain.setTargetAtTime(this.enabled ? volume : 0, this.context.currentTime, 0.03); }

  private tone(frequency: number, duration: number, volume = 0.08, type: OscillatorType = 'sine', slide = 1) {
    if (!this.context || !this.master || !this.enabled) return;
    const now = this.context.currentTime, osc = this.context.createOscillator(), gain = this.context.createGain();
    osc.type = type; osc.frequency.setValueAtTime(frequency, now); osc.frequency.exponentialRampToValueAtTime(Math.max(20, frequency * slide), now + duration);
    gain.gain.setValueAtTime(volume, now); gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    osc.connect(gain); gain.connect(this.master); osc.start(now); osc.stop(now + duration + 0.02);
  }

  private noise(duration: number, volume: number, cutoff: number) {
    if (!this.context || !this.master || !this.noiseBuffer || !this.enabled) return;
    const now = this.context.currentTime, source = this.context.createBufferSource(), filter = this.context.createBiquadFilter(), gain = this.context.createGain();
    source.buffer = this.noiseBuffer; filter.type = 'lowpass'; filter.frequency.value = cutoff;
    gain.gain.setValueAtTime(volume, now); gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    source.connect(filter); filter.connect(gain); gain.connect(this.master); source.start(now); source.stop(now + duration + 0.01);
  }

  play(name: 'break' | 'place' | 'hit' | 'step' | 'hurt' | 'craft' | 'pickup' | 'shoot' | 'boss' | 'eat' | 'splash' | 'level') {
    switch (name) {
      case 'break': this.noise(0.15, 0.12, 680); this.tone(105, 0.1, 0.035, 'square', 0.7); break;
      case 'place': this.noise(0.07, 0.075, 950); this.tone(140, 0.07, 0.03, 'triangle', 0.85); break;
      case 'hit': this.noise(0.055, 0.05, 1300); break;
      case 'step': this.noise(0.045, 0.026, 540 + Math.random() * 150); break;
      case 'hurt': this.tone(120, 0.2, 0.11, 'sawtooth', 0.55); break;
      case 'craft': this.tone(440, 0.12, 0.06, 'triangle', 1.5); setTimeout(() => this.tone(660, 0.18, 0.04, 'triangle', 1.2), 65); break;
      case 'pickup': this.tone(560, 0.09, 0.04, 'sine', 1.45); break;
      case 'shoot': this.noise(0.12, 0.08, 1800); this.tone(210, 0.15, 0.04, 'square', 0.45); break;
      case 'boss': this.tone(64, 1.2, 0.16, 'sawtooth', 0.6); this.noise(0.8, 0.08, 300); break;
      case 'eat': this.noise(0.1, 0.05, 700); break;
      case 'splash': this.noise(0.25, 0.08, 1200); break;
      case 'level': [0, 100, 200].forEach((delay, i) => setTimeout(() => this.tone([440, 554, 659][i], 0.35, 0.05, 'sine', 1.02), delay)); break;
    }
  }

  update(weather: string, night: boolean) {
    if (!this.context || !this.master || !this.enabled) return;
    if (this.wind) this.wind.gain.setTargetAtTime(weather === 'Rain' ? 0.065 : weather === 'Storm' ? 0.1 : 0.016, this.context.currentTime, 0.6);
    if (this.context.currentTime > this.nextMusic) {
      const scale = night ? [220, 261.63, 293.66, 329.63] : [261.63, 329.63, 392, 440, 523.25];
      const root = scale[Math.floor(Math.random() * scale.length)];
      this.tone(root, 2.8, 0.015, 'sine', 0.998); this.tone(root / 2, 3.4, 0.012, 'triangle', 1);
      this.nextMusic = this.context.currentTime + 7 + Math.random() * 9;
    }
  }

  dispose() { this.context?.close(); this.context = null; }
}
