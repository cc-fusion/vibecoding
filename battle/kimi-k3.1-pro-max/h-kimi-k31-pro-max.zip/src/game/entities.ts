import * as THREE from 'three';
import { B, BLOCKS } from './blocks';
import { VoxelWorld } from './world';

export type EntityKind = 'deer' | 'boar' | 'zombie' | 'skeleton' | 'slime' | 'slimelet' | 'guardian';
export type EntityHooks = {
  damagePlayer: (amount: number, source: string) => void;
  spawnDrop: (id: number, count: number, position: THREE.Vector3) => void;
  particles: (position: THREE.Vector3, color: string, count?: number, force?: number) => void;
  sound: (name: 'hurt' | 'shoot' | 'boss' | 'break') => void;
  awardXp: (amount: number) => void;
  shake: (amount: number) => void;
};
type Entity = {
  id: number; kind: EntityKind; mesh: THREE.Group; position: THREE.Vector3; velocity: THREE.Vector3;
  health: number; maxHealth: number; width: number; height: number; speed: number; yaw: number;
  onGround: boolean; cooldown: number; wander: number; wanderAngle: number; telegraph: number;
  attack: '' | 'arrow' | 'slam' | 'boulder' | 'summon'; hitFlash: number; age: number; limbs: THREE.Object3D[];
  ring?: THREE.Mesh; aggressive: boolean; scale: number;
};
type Projectile = { mesh: THREE.Mesh; velocity: THREE.Vector3; life: number; damage: number; kind: 'arrow' | 'boulder' };

const STATS: Record<EntityKind, { health: number; width: number; height: number; speed: number; xp: number }> = {
  deer: { health: 14, width: 0.75, height: 1.45, speed: 2.2, xp: 5 },
  boar: { health: 22, width: 0.85, height: 1.05, speed: 2.5, xp: 8 },
  zombie: { health: 28, width: 0.62, height: 1.85, speed: 2.15, xp: 14 },
  skeleton: { health: 22, width: 0.58, height: 1.8, speed: 2.4, xp: 18 },
  slime: { health: 20, width: 0.9, height: 0.9, speed: 2.6, xp: 15 },
  slimelet: { health: 7, width: 0.45, height: 0.45, speed: 3.1, xp: 5 },
  guardian: { health: 320, width: 1.55, height: 3.8, speed: 2.25, xp: 180 },
};

export class EntityManager {
  readonly group = new THREE.Group();
  entities: Entity[] = []; projectiles: Projectile[] = [];
  boss: Entity | null = null;
  private nextId = 1; private spawnTimer = 2; private box = new THREE.BoxGeometry(1, 1, 1);
  private materials = new Map<string, THREE.MeshStandardMaterial>();

  constructor(private world: VoxelWorld, private hooks: EntityHooks) { this.group.name = 'Creatures'; }

  private material(color: string, emissive = false, transparent = false) {
    const key = `${color}-${emissive}-${transparent}`;
    if (!this.materials.has(key)) this.materials.set(key, new THREE.MeshStandardMaterial({ color, roughness: 0.82, emissive: emissive ? color : '#000000', emissiveIntensity: emissive ? 0.7 : 0, transparent, opacity: transparent ? 0.82 : 1 }));
    return this.materials.get(key)!;
  }

  private part(group: THREE.Group, color: string, size: [number, number, number], pos: [number, number, number], emissive = false, transparent = false) {
    const mesh = new THREE.Mesh(this.box, this.material(color, emissive, transparent)); mesh.scale.set(...size); mesh.position.set(...pos);
    mesh.castShadow = true; mesh.receiveShadow = true; group.add(mesh); return mesh;
  }

  private model(kind: EntityKind) {
    const group = new THREE.Group(), limbs: THREE.Object3D[] = [];
    if (kind === 'deer' || kind === 'boar') {
      const deer = kind === 'deer', body = deer ? '#9a7048' : '#554a3e', dark = deer ? '#66462f' : '#35332e';
      this.part(group, body, [0.72, 0.65, 1.15], [0, deer ? 0.9 : 0.62, 0]);
      this.part(group, body, [0.58, 0.58, 0.58], [0, deer ? 1.25 : 0.78, -0.68]);
      this.part(group, '#d9c6a0', [0.12, 0.12, 0.18], [-0.18, deer ? 1.26 : 0.78, -1.02]);
      this.part(group, '#d9c6a0', [0.12, 0.12, 0.18], [0.18, deer ? 1.26 : 0.78, -1.02]);
      for (const x of [-0.25, 0.25]) for (const z of [-0.38, 0.38]) {
        const leg = this.part(group, dark, [0.16, deer ? 0.65 : 0.43, 0.16], [x, deer ? 0.34 : 0.22, z]); limbs.push(leg);
      }
      if (deer) for (const x of [-0.18, 0.18]) {
        const antler = this.part(group, '#c8b58c', [0.07, 0.48, 0.07], [x, 1.72, -0.66]); antler.rotation.z = x * 1.4;
      }
      else for (const x of [-0.22, 0.22]) { const tusk = this.part(group, '#e4d7b9', [0.08, 0.1, 0.24], [x, 0.65, -1.02]); tusk.rotation.x = -0.35; }
    } else if (kind === 'zombie' || kind === 'skeleton') {
      const skeleton = kind === 'skeleton', skin = skeleton ? '#d2d0bc' : '#668357', cloth = skeleton ? '#858778' : '#486b68';
      this.part(group, cloth, [0.62, 0.75, 0.34], [0, 1.12, 0]);
      this.part(group, skin, [0.55, 0.55, 0.55], [0, 1.78, 0]);
      for (const x of [-0.2, 0.2]) this.part(group, '#202522', [0.09, 0.09, 0.03], [x, 1.84, -0.285]);
      for (const x of [-0.43, 0.43]) { const arm = this.part(group, skin, [0.18, 0.78, 0.18], [x, 1.12, -0.22]); arm.rotation.x = -1.15; limbs.push(arm); }
      for (const x of [-0.18, 0.18]) { const leg = this.part(group, cloth, [0.2, 0.75, 0.22], [x, 0.4, 0]); limbs.push(leg); }
      if (skeleton) { const bow = this.part(group, '#795334', [0.07, 0.85, 0.08], [0.58, 1.15, -0.58]); bow.rotation.z = 0.25; }
    } else if (kind === 'slime' || kind === 'slimelet') {
      const small = kind === 'slimelet', s = small ? 0.45 : 0.9;
      this.part(group, '#62a765', [s, s, s], [0, s / 2, 0], false, true);
      this.part(group, '#b0db8d', [s * 0.55, s * 0.55, s * 0.55], [0, s / 2, 0], false, true);
      for (const x of [-0.18, 0.18]) this.part(group, '#173a25', [s * 0.1, s * 0.13, 0.025], [x * (small ? 0.5 : 1), s * 0.62, -s / 2 - 0.01]);
    } else {
      this.part(group, '#454c49', [1.45, 1.65, 0.9], [0, 2.15, 0]);
      this.part(group, '#59615b', [1.05, 0.95, 0.9], [0, 3.35, 0]);
      this.part(group, '#e0b85f', [0.58, 0.58, 0.18], [0, 2.25, -0.52], true);
      for (const x of [-0.27, 0.27]) this.part(group, '#91e3d4', [0.16, 0.12, 0.06], [x, 3.45, -0.47], true);
      for (const x of [-1.02, 1.02]) { const arm = this.part(group, '#515954', [0.55, 1.85, 0.6], [x, 2.05, 0]); limbs.push(arm); }
      for (const x of [-0.43, 0.43]) { const leg = this.part(group, '#3d4441', [0.58, 1.25, 0.65], [x, 0.65, 0]); limbs.push(leg); }
      const ring = new THREE.Mesh(new THREE.RingGeometry(1.2, 1.38, 48), new THREE.MeshBasicMaterial({ color: '#ef9e58', transparent: true, opacity: 0.75, side: THREE.DoubleSide, depthWrite: false }));
      ring.rotation.x = -Math.PI / 2; ring.position.y = 0.04; ring.visible = false; group.add(ring);
      group.userData.ring = ring;
    }
    return { group, limbs };
  }

  spawn(kind: EntityKind, position: THREE.Vector3, aggressive = false) {
    const stats = STATS[kind], model = this.model(kind);
    const entity: Entity = {
      id: this.nextId++, kind, mesh: model.group, position: position.clone(), velocity: new THREE.Vector3(), health: stats.health,
      maxHealth: stats.health, width: stats.width, height: stats.height, speed: stats.speed, yaw: Math.random() * Math.PI * 2,
      onGround: false, cooldown: 1 + Math.random(), wander: 1 + Math.random() * 3, wanderAngle: Math.random() * Math.PI * 2,
      telegraph: 0, attack: '', hitFlash: 0, age: 0, limbs: model.limbs, aggressive, scale: kind === 'slimelet' ? 0.5 : 1,
    };
    if (kind === 'guardian') { entity.ring = model.group.userData.ring; this.boss = entity; }
    entity.mesh.position.copy(position); this.group.add(entity.mesh); this.entities.push(entity); return entity;
  }

  populate(player: THREE.Vector3) {
    for (let i = 0; i < 8; i++) this.trySpawn(player, false);
  }

  private trySpawn(player: THREE.Vector3, hostile: boolean) {
    const angle = Math.random() * Math.PI * 2, distance = hostile ? 18 + Math.random() * 18 : 12 + Math.random() * 25;
    const x = Math.floor(player.x + Math.cos(angle) * distance), z = Math.floor(player.z + Math.sin(angle) * distance);
    const y = this.world.findSurface(x, z); if (y <= 1 || y >= 65) return;
    if (this.world.getBlock(x, y - 1, z) === B.Water || this.world.getBlock(x, y, z) !== B.Air) return;
    const roll = Math.random();
    const kind: EntityKind = hostile ? roll < 0.46 ? 'zombie' : roll < 0.73 ? 'skeleton' : 'slime' : roll < 0.65 ? 'deer' : 'boar';
    this.spawn(kind, new THREE.Vector3(x + 0.5, y, z + 0.5));
  }

  summonGuardian(player: THREE.Vector3, direction: THREE.Vector3) {
    if (this.boss) return false;
    const x = Math.floor(player.x + direction.x * 7), z = Math.floor(player.z + direction.z * 7), y = this.world.findSurface(x, z);
    this.spawn('guardian', new THREE.Vector3(x + 0.5, y, z + 0.5), true); this.hooks.sound('boss'); return true;
  }

  private collides(entity: Entity, position: THREE.Vector3) {
    const half = entity.width / 2;
    for (let y = Math.floor(position.y + 0.01); y <= Math.floor(position.y + entity.height - 0.01); y++)
      for (let z = Math.floor(position.z - half + 0.01); z <= Math.floor(position.z + half - 0.01); z++)
        for (let x = Math.floor(position.x - half + 0.01); x <= Math.floor(position.x + half - 0.01); x++)
          if (BLOCKS[this.world.getBlock(x, y, z)]?.solid) return true;
    return false;
  }

  private move(entity: Entity, dt: number) {
    entity.velocity.y -= 21 * dt;
    const inWater = this.world.getBlock(entity.position.x, entity.position.y + entity.height * 0.35, entity.position.z) === B.Water;
    if (inWater) { entity.velocity.y += 27 * dt; entity.velocity.y = Math.min(2.2, entity.velocity.y); entity.velocity.x *= Math.pow(0.5, dt); entity.velocity.z *= Math.pow(0.5, dt); }
    const next = entity.position.clone();
    next.x += entity.velocity.x * dt;
    if (this.collides(entity, next)) { entity.velocity.x = 0; if (entity.onGround) entity.velocity.y = 7; }
    else entity.position.x = next.x;
    next.copy(entity.position); next.z += entity.velocity.z * dt;
    if (this.collides(entity, next)) { entity.velocity.z = 0; if (entity.onGround) entity.velocity.y = 7; }
    else entity.position.z = next.z;
    next.copy(entity.position); next.y += entity.velocity.y * dt; entity.onGround = false;
    if (this.collides(entity, next)) {
      if (entity.velocity.y < 0) { entity.position.y = Math.floor(next.y + 0.001) + 1; entity.onGround = true; }
      entity.velocity.y = 0;
    } else entity.position.y = next.y;
  }

  private steer(entity: Entity, angle: number, speed: number, dt: number) {
    entity.yaw = angle;
    entity.velocity.x += (Math.sin(angle) * speed - entity.velocity.x) * Math.min(1, dt * 7);
    entity.velocity.z += (Math.cos(angle) * speed - entity.velocity.z) * Math.min(1, dt * 7);
  }

  private fire(entity: Entity, player: THREE.Vector3, boulder: boolean, spread = 0) {
    const origin = entity.position.clone().add(new THREE.Vector3(0, entity.height * 0.7, 0));
    const target = player.clone().add(new THREE.Vector3(0, 1, 0));
    const direction = target.sub(origin).normalize(); direction.x += spread; direction.z += spread * 0.6; direction.normalize();
    const geometry = boulder ? new THREE.DodecahedronGeometry(0.34, 0) : new THREE.BoxGeometry(0.07, 0.07, 0.65);
    const material = this.material(boulder ? '#6f7369' : '#c9b78e'); const mesh = new THREE.Mesh(geometry, material);
    mesh.position.copy(origin); mesh.castShadow = true; if (!boulder) mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), direction);
    this.group.add(mesh);
    this.projectiles.push({ mesh, velocity: direction.multiplyScalar(boulder ? 9 : 15).add(new THREE.Vector3(0, boulder ? 2 : 0, 0)), life: 6, damage: boulder ? 14 : 7, kind: boulder ? 'boulder' : 'arrow' });
    this.hooks.sound('shoot');
  }

  private executeAttack(entity: Entity, player: THREE.Vector3, distance: number) {
    if (entity.attack === 'arrow') this.fire(entity, player, false);
    else if (entity.attack === 'slam') {
      this.hooks.particles(entity.position.clone().add(new THREE.Vector3(0, 0.3, 0)), '#b69a72', 40, 7); this.hooks.shake(0.7); this.hooks.sound('boss');
      if (distance < (entity.health < entity.maxHealth * 0.3 ? 8 : 6.5)) this.hooks.damagePlayer(entity.health < entity.maxHealth * 0.3 ? 22 : 17, 'Guardian shockwave');
      if (entity.health < entity.maxHealth * 0.3) for (let i = 0; i < 2; i++) this.spawn('zombie', entity.position.clone().add(new THREE.Vector3(i ? 2 : -2, 0.2, 1)), true);
    } else if (entity.attack === 'boulder') {
      this.fire(entity, player, true, 0); if (entity.health < entity.maxHealth * 0.6) { this.fire(entity, player, true, -0.18); this.fire(entity, player, true, 0.18); }
    } else if (entity.attack === 'summon') {
      for (let i = 0; i < 3; i++) this.spawn('slime', entity.position.clone().add(new THREE.Vector3(Math.cos(i * 2.1) * 3, 0.4, Math.sin(i * 2.1) * 3)), true);
    }
    entity.attack = ''; if (entity.ring) entity.ring.visible = false;
  }

  private updateEntity(entity: Entity, dt: number, player: THREE.Vector3, night: boolean) {
    entity.age += dt; entity.cooldown -= dt; entity.wander -= dt; entity.hitFlash = Math.max(0, entity.hitFlash - dt);
    const toPlayer = player.clone().sub(entity.position), distance = toPlayer.length();
    const angle = Math.atan2(toPlayer.x, toPlayer.z), hostile = ['zombie', 'skeleton', 'slime', 'slimelet', 'guardian'].includes(entity.kind) || (entity.kind === 'boar' && entity.aggressive);
    if (entity.kind === 'deer' || (entity.kind === 'boar' && !entity.aggressive)) {
      if (distance < 7 || entity.aggressive) entity.wanderAngle = angle + Math.PI;
      else if (entity.wander <= 0) { entity.wander = 2 + Math.random() * 4; entity.wanderAngle += (Math.random() - 0.5) * 2.4; }
      const moving = distance < 7 || entity.wander > 1;
      this.steer(entity, entity.wanderAngle, moving ? entity.speed * (distance < 7 ? 1.65 : 0.55) : 0, dt);
    } else if (entity.kind === 'skeleton') {
      if (distance < 27) {
        const desired = distance < 8 ? angle + Math.PI : distance > 15 ? angle : angle + Math.PI / 2;
        this.steer(entity, desired, entity.speed * (distance < 8 ? 1 : 0.6), dt);
        if (entity.cooldown <= 0 && entity.telegraph <= 0) { entity.telegraph = 0.62; entity.attack = 'arrow'; entity.cooldown = 2.4; }
      } else this.steer(entity, entity.wanderAngle, 0, dt);
    } else if (entity.kind === 'slime' || entity.kind === 'slimelet') {
      if (distance < 24) this.steer(entity, angle, entity.speed, dt);
      if (entity.onGround && entity.cooldown <= 0) { entity.velocity.y = entity.kind === 'slime' ? 7.5 : 6; entity.cooldown = 0.75 + Math.random() * 0.45; }
    } else if (hostile) {
      if (distance < (entity.kind === 'guardian' ? 48 : 25)) this.steer(entity, angle, entity.speed * (entity.kind === 'guardian' && entity.health < entity.maxHealth * 0.3 ? 1.4 : 1), dt);
      else if (entity.wander <= 0) { entity.wander = 3; entity.wanderAngle = Math.random() * Math.PI * 2; }
      if (entity.kind === 'guardian') {
        const phase = entity.health < entity.maxHealth * 0.3 ? 3 : entity.health < entity.maxHealth * 0.6 ? 2 : 1;
        if (entity.cooldown <= 0 && entity.telegraph <= 0) {
          entity.attack = phase === 3 && Math.random() < 0.25 ? 'summon' : distance < 8 || (phase === 1 && Math.random() < 0.65) ? 'slam' : 'boulder';
          entity.telegraph = entity.attack === 'slam' ? 1.15 : 0.9; entity.cooldown = phase === 3 ? 2.8 : phase === 2 ? 3.6 : 4.5;
          if (entity.ring) entity.ring.visible = entity.attack === 'slam';
        }
      }
    }
    if (entity.telegraph > 0) {
      entity.telegraph -= dt; entity.velocity.x *= 0.85; entity.velocity.z *= 0.85;
      if (entity.ring) { const s = 1 + (1.15 - Math.max(0, entity.telegraph)) * 4.2; entity.ring.scale.setScalar(s); (entity.ring.material as THREE.MeshBasicMaterial).opacity = 0.3 + Math.sin(entity.age * 24) * 0.2 + 0.3; }
      if (entity.telegraph <= 0) this.executeAttack(entity, player, distance);
    }
    if (hostile && entity.kind !== 'skeleton' && distance < entity.width / 2 + 0.9 && entity.cooldown <= 0 && entity.kind !== 'guardian') {
      this.hooks.damagePlayer(entity.kind === 'boar' ? 8 : entity.kind === 'slimelet' ? 3 : 6, entity.kind); entity.cooldown = 1.05;
      entity.velocity.add(toPlayer.normalize().multiplyScalar(3));
    }
    if (!night && (entity.kind === 'zombie' || entity.kind === 'skeleton') && entity.age > 8) {
      entity.health -= dt * 2.5; if (Math.random() < dt * 3) this.hooks.particles(entity.position.clone().add(new THREE.Vector3(0, entity.height, 0)), '#e5a454', 1, 1);
      if (entity.health <= 0) { this.kill(entity, false); return; }
    }
    this.move(entity, dt);
    entity.mesh.position.copy(entity.position); entity.mesh.rotation.y = entity.yaw + Math.PI;
    const stride = Math.sin(entity.age * 8 * Math.max(0.3, Math.hypot(entity.velocity.x, entity.velocity.z) / entity.speed)) * 0.45;
    entity.limbs.forEach((limb, i) => { if (entity.kind !== 'zombie' && entity.kind !== 'skeleton') limb.rotation.x = stride * (i % 2 ? 1 : -1); });
    const pulse = entity.hitFlash > 0 ? 1.09 : 1; entity.mesh.scale.setScalar(pulse);
    if (entity.kind === 'slime' || entity.kind === 'slimelet') entity.mesh.scale.y = 1 + Math.sin(entity.age * 9) * 0.07;
    if (entity.position.y < -10 || distance > 95 && entity.kind !== 'guardian') this.remove(entity);
  }

  private updateProjectiles(dt: number, player: THREE.Vector3) {
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i]; p.life -= dt; p.velocity.y -= (p.kind === 'boulder' ? 8 : 2.5) * dt;
      p.mesh.position.addScaledVector(p.velocity, dt); p.mesh.rotation.x += dt * 5; p.mesh.rotation.z += dt * 3;
      const pos = p.mesh.position;
      const hitWorld = BLOCKS[this.world.getBlock(pos.x, pos.y, pos.z)]?.solid;
      const hitPlayer = Math.abs(pos.x - player.x) < 0.48 && Math.abs(pos.z - player.z) < 0.48 && pos.y > player.y && pos.y < player.y + 1.85;
      if (hitPlayer) this.hooks.damagePlayer(p.damage, p.kind === 'boulder' ? 'Guardian boulder' : 'Skeleton arrow');
      if (hitPlayer || hitWorld || p.life <= 0) {
        if (hitWorld && p.kind === 'boulder') this.hooks.particles(pos, '#7c7b70', 18, 4);
        this.group.remove(p.mesh); p.mesh.geometry.dispose(); this.projectiles.splice(i, 1);
      }
    }
  }

  update(dt: number, player: THREE.Vector3, night: boolean) {
    this.spawnTimer -= dt;
    if (this.spawnTimer <= 0) {
      this.spawnTimer = 3.5;
      const hostileCount = this.entities.filter(e => ['zombie', 'skeleton', 'slime', 'slimelet'].includes(e.kind)).length;
      const passiveCount = this.entities.filter(e => e.kind === 'deer' || e.kind === 'boar').length;
      if (night && hostileCount < 11) this.trySpawn(player, true);
      if (!night && passiveCount < 9) this.trySpawn(player, false);
    }
    for (const entity of [...this.entities]) if (this.entities.includes(entity)) this.updateEntity(entity, dt, player, night);
    this.updateProjectiles(dt, player);
  }

  target(origin: THREE.Vector3, direction: THREE.Vector3, maxDistance: number) {
    let best: Entity | null = null, bestDistance = maxDistance;
    for (const entity of this.entities) {
      const center = entity.position.clone().add(new THREE.Vector3(0, entity.height * 0.55, 0));
      const relative = center.sub(origin), projection = relative.dot(direction);
      if (projection < 0 || projection > bestDistance) continue;
      const perpendicular = relative.addScaledVector(direction, -projection).length();
      if (perpendicular < entity.width * 0.75 + 0.28) { best = entity; bestDistance = projection; }
    }
    return best ? { entity: best, distance: bestDistance } : null;
  }

  damage(entity: Entity, amount: number, knockback: THREE.Vector3) {
    entity.health -= amount; entity.hitFlash = 0.16; entity.aggressive = true;
    entity.velocity.addScaledVector(knockback, 5); entity.velocity.y = Math.max(entity.velocity.y, 3.5);
    this.hooks.particles(entity.position.clone().add(new THREE.Vector3(0, entity.height * 0.6, 0)), entity.kind === 'skeleton' ? '#ddd9c4' : entity.kind === 'guardian' ? '#78d9c9' : '#a44339', 8, 3);
    if (entity.health <= 0) this.kill(entity, true);
  }

  private kill(entity: Entity, rewards: boolean) {
    if (!this.entities.includes(entity)) return;
    if (rewards) {
      this.hooks.awardXp(STATS[entity.kind].xp);
      const pos = entity.position.clone().add(new THREE.Vector3(0, 0.5, 0));
      if (entity.kind === 'deer') this.hooks.spawnDrop(120, 1 + Math.floor(Math.random() * 2), pos);
      else if (entity.kind === 'boar') this.hooks.spawnDrop(121, 1, pos);
      else if (entity.kind === 'zombie' && Math.random() < 0.5) this.hooks.spawnDrop(111, 1, pos);
      else if (entity.kind === 'skeleton') this.hooks.spawnDrop(Math.random() < 0.4 ? 112 : 100, 1, pos);
      else if ((entity.kind === 'slime' || entity.kind === 'slimelet') && Math.random() < 0.35) this.hooks.spawnDrop(113, 1, pos);
      else if (entity.kind === 'guardian') {
        this.hooks.spawnDrop(113, 8, pos); this.hooks.spawnDrop(110, 6, pos.clone().add(new THREE.Vector3(1, 0, 0))); this.hooks.spawnDrop(B.Glowstone, 3, pos.clone().add(new THREE.Vector3(-1, 0, 0)));
      }
    }
    if (entity.kind === 'slime' && rewards) for (let i = 0; i < 2; i++) this.spawn('slimelet', entity.position.clone().add(new THREE.Vector3(i ? 0.4 : -0.4, 0.2, 0)), true);
    if (entity.kind === 'guardian') this.boss = null;
    this.hooks.particles(entity.position.clone().add(new THREE.Vector3(0, entity.height / 2, 0)), '#d9d1b2', 20, 4); this.remove(entity);
  }

  private remove(entity: Entity) {
    this.group.remove(entity.mesh);
    if (entity.ring) { entity.ring.geometry.dispose(); (entity.ring.material as THREE.Material).dispose(); }
    const index = this.entities.indexOf(entity); if (index >= 0) this.entities.splice(index, 1);
    if (this.boss === entity) this.boss = null;
  }

  dispose() {
    for (const entity of [...this.entities]) this.remove(entity);
    this.box.dispose(); this.materials.forEach(m => m.dispose());
    this.projectiles.forEach(p => { this.group.remove(p.mesh); p.mesh.geometry.dispose(); }); this.group.clear(); this.entities = []; this.projectiles = [];
  }
}
