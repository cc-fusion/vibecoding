import * as THREE from 'three';

export class Environment {
  readonly sky: THREE.Mesh;
  readonly sun = new THREE.DirectionalLight('#fff3d6', 2.2);
  readonly hemisphere = new THREE.HemisphereLight('#bfe0ef', '#53604b', 0.8);
  readonly moon = new THREE.DirectionalLight('#91adcf', 0.15);
  private skyMaterial: THREE.ShaderMaterial;
  private stars: THREE.Points;
  private clouds: THREE.InstancedMesh;
  private cloudMaterial: THREE.MeshStandardMaterial;
  private flash = 0;
  private lightningTimer = 8;
  daylight = 1;

  constructor(private scene: THREE.Scene) {
    scene.fog = new THREE.Fog('#a8cbd2', 24, 90);
    this.skyMaterial = new THREE.ShaderMaterial({
      side: THREE.BackSide, depthWrite: false, fog: false,
      uniforms: { topColor: { value: new THREE.Color('#4f9fc8') }, horizonColor: { value: new THREE.Color('#c1d9d7') }, sunDirection: { value: new THREE.Vector3(0, 1, 0) }, sunColor: { value: new THREE.Color('#fff0c2') }, night: { value: 0 } },
      vertexShader: `varying vec3 vDir; void main(){ vDir=normalize(position); gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
      fragmentShader: `varying vec3 vDir; uniform vec3 topColor; uniform vec3 horizonColor; uniform vec3 sunDirection; uniform vec3 sunColor; uniform float night;
        void main(){ vec3 d=normalize(vDir); float h=smoothstep(-0.12,0.72,d.y); vec3 col=mix(horizonColor,topColor,h); float sun=pow(max(dot(d,normalize(sunDirection)),0.0),900.0); float halo=pow(max(dot(d,normalize(sunDirection)),0.0),24.0); float moon=pow(max(dot(d,normalize(-sunDirection)),0.0),1400.0); col+=sunColor*sun*1.35+sunColor*halo*0.1+vec3(0.65,0.76,1.0)*moon*night*1.1; gl_FragColor=vec4(col,1.0); }`,
    });
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(190, 32, 18), this.skyMaterial); this.sky.renderOrder = -10; scene.add(this.sky);

    const starPositions = new Float32Array(900 * 3);
    for (let i = 0; i < 900; i++) {
      const theta = Math.random() * Math.PI * 2, phi = Math.acos(Math.random() * 0.95);
      starPositions[i * 3] = Math.sin(phi) * Math.cos(theta) * 175; starPositions[i * 3 + 1] = Math.cos(phi) * 175; starPositions[i * 3 + 2] = Math.sin(phi) * Math.sin(theta) * 175;
    }
    const starGeo = new THREE.BufferGeometry(); starGeo.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
    this.stars = new THREE.Points(starGeo, new THREE.PointsMaterial({ color: '#dceaff', size: 0.48, transparent: true, opacity: 0, depthWrite: false, fog: false })); scene.add(this.stars);

    this.sun.castShadow = true; this.sun.shadow.mapSize.set(1536, 1536); this.sun.shadow.camera.left = -32; this.sun.shadow.camera.right = 32;
    this.sun.shadow.camera.top = 32; this.sun.shadow.camera.bottom = -32; this.sun.shadow.camera.near = 1; this.sun.shadow.camera.far = 150; this.sun.shadow.bias = -0.00035; this.sun.shadow.normalBias = 0.035;
    scene.add(this.sun, this.sun.target, this.moon, this.moon.target, this.hemisphere);

    this.cloudMaterial = new THREE.MeshStandardMaterial({ color: '#eef3ee', transparent: true, opacity: 0.55, roughness: 1, depthWrite: false });
    this.clouds = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), this.cloudMaterial, 100);
    const matrix = new THREE.Matrix4(), pos = new THREE.Vector3(), scale = new THREE.Vector3();
    let index = 0;
    for (let c = 0; c < 25; c++) {
      const cx = (Math.random() - 0.5) * 200, cz = (Math.random() - 0.5) * 200;
      for (let p = 0; p < 4; p++) {
        pos.set(cx + (p - 1.5) * 5 + Math.random() * 3, 57 + Math.random() * 2, cz + (Math.random() - 0.5) * 7);
        scale.set(7 + Math.random() * 8, 1.2 + Math.random(), 5 + Math.random() * 6); matrix.compose(pos, new THREE.Quaternion(), scale); this.clouds.setMatrixAt(index++, matrix);
      }
    }
    this.clouds.instanceMatrix.needsUpdate = true; scene.add(this.clouds);
  }

  update(dt: number, hours: number, player: THREE.Vector3, weather: string, underwater: boolean, renderDistance: number) {
    const angle = (hours - 6) / 24 * Math.PI * 2;
    const sunDirection = new THREE.Vector3(Math.cos(angle), Math.sin(angle), 0.28).normalize();
    const sunHeight = sunDirection.y;
    this.daylight = THREE.MathUtils.clamp(sunHeight * 2.7 + 0.24, 0.04, 1);
    const dawn = Math.pow(1 - Math.min(1, Math.abs(sunHeight) * 4), 2) * (sunHeight > -0.18 ? 1 : 0);
    const weatherDarken = weather === 'Storm' ? 0.55 : weather === 'Rain' || weather === 'Snow' ? 0.78 : 1;
    const dayTop = new THREE.Color('#4895c2'), dayHorizon = new THREE.Color('#bdd7d8');
    const nightTop = new THREE.Color('#050c19'), nightHorizon = new THREE.Color('#152637');
    const top = nightTop.clone().lerp(dayTop, this.daylight), horizon = nightHorizon.clone().lerp(dayHorizon, this.daylight);
    horizon.lerp(new THREE.Color('#e9a16f'), dawn * 0.52); top.multiplyScalar(weatherDarken); horizon.multiplyScalar(weatherDarken);
    if (this.flash > 0) { top.lerp(new THREE.Color('#d9e5ef'), this.flash); horizon.lerp(new THREE.Color('#e6edf2'), this.flash); this.flash = Math.max(0, this.flash - dt * 4); }
    this.skyMaterial.uniforms.topColor.value.copy(top); this.skyMaterial.uniforms.horizonColor.value.copy(horizon);
    this.skyMaterial.uniforms.sunDirection.value.copy(sunDirection); this.skyMaterial.uniforms.sunColor.value.set(dawn > 0.2 ? '#ffbf82' : '#fff1c9'); this.skyMaterial.uniforms.night.value = 1 - this.daylight;
    this.sky.position.copy(player); this.stars.position.copy(player); (this.stars.material as THREE.PointsMaterial).opacity = Math.max(0, 0.9 - this.daylight * 1.25) * weatherDarken;
    this.clouds.position.x = Math.floor(player.x / 200) * 200 + hours * 0.12; this.clouds.position.z = Math.floor(player.z / 200) * 200;
    this.cloudMaterial.opacity = (0.32 + this.daylight * 0.28) * (weather === 'Clear' ? 1 : 1.25); this.cloudMaterial.color.set(weather === 'Storm' ? '#7f8b8e' : '#e3ece9');
    this.sun.position.copy(player).addScaledVector(sunDirection, 75); this.sun.target.position.copy(player); this.sun.intensity = this.daylight * 2.15 * weatherDarken + this.flash * 1.5;
    this.sun.color.set(dawn > 0.2 ? '#ffca94' : '#fff2d7');
    this.moon.position.copy(player).addScaledVector(sunDirection, -60); this.moon.target.position.copy(player); this.moon.intensity = (1 - this.daylight) * 0.2;
    this.hemisphere.intensity = (0.17 + this.daylight * 0.66) * weatherDarken + this.flash;
    this.hemisphere.color.copy(top).lerp(new THREE.Color('#d8e5e5'), 0.42); this.hemisphere.groundColor.set(this.daylight < 0.2 ? '#182521' : '#56604a');
    const fog = this.scene.fog as THREE.Fog;
    if (underwater) { fog.color.set('#246681'); fog.near = 0; fog.far = 15; }
    else { fog.color.copy(horizon); fog.near = Math.max(18, renderDistance * 7); fog.far = Math.max(48, renderDistance * 17); }
    if (weather === 'Storm') {
      this.lightningTimer -= dt;
      if (this.lightningTimer <= 0) { this.flash = 0.75; this.lightningTimer = 7 + Math.random() * 18; }
    }
  }

  dispose() {
    this.sky.geometry.dispose(); this.skyMaterial.dispose(); this.stars.geometry.dispose(); (this.stars.material as THREE.Material).dispose();
    this.clouds.geometry.dispose(); this.cloudMaterial.dispose(); this.sun.shadow.map?.dispose();
  }
}
