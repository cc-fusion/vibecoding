import * as THREE from 'three';

export class ParticleSystem {
  readonly points: THREE.Points;
  private max = 1200;
  private positions = new Float32Array(this.max * 3);
  private colors = new Float32Array(this.max * 3);
  private velocities = Array.from({ length: this.max }, () => new THREE.Vector3());
  private lives = new Float32Array(this.max);
  private cursor = 0;

  constructor() {
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(this.positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(this.colors, 3));
    const material = new THREE.PointsMaterial({ size: 0.105, vertexColors: true, transparent: true, opacity: 0.9, depthWrite: false, sizeAttenuation: true });
    this.points = new THREE.Points(geometry, material); this.points.frustumCulled = false; this.points.renderOrder = 3;
    for (let i = 0; i < this.max; i++) this.positions[i * 3 + 1] = -1000;
  }

  burst(position: THREE.Vector3, color: string, count = 16, force = 4) {
    const c = new THREE.Color(color);
    for (let n = 0; n < count; n++) {
      const i = this.cursor++ % this.max, p = i * 3;
      this.positions[p] = position.x + (Math.random() - 0.5) * 0.55; this.positions[p + 1] = position.y + (Math.random() - 0.5) * 0.55; this.positions[p + 2] = position.z + (Math.random() - 0.5) * 0.55;
      this.colors[p] = c.r * (0.75 + Math.random() * 0.25); this.colors[p + 1] = c.g * (0.75 + Math.random() * 0.25); this.colors[p + 2] = c.b * (0.75 + Math.random() * 0.25);
      this.velocities[i].set((Math.random() - 0.5) * force, Math.random() * force * 0.9 + 0.8, (Math.random() - 0.5) * force);
      this.lives[i] = 0.45 + Math.random() * 0.65;
    }
    (this.points.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    (this.points.geometry.attributes.color as THREE.BufferAttribute).needsUpdate = true;
  }

  update(dt: number) {
    for (let i = 0; i < this.max; i++) {
      if (this.lives[i] <= 0) continue;
      this.lives[i] -= dt; const p = i * 3, v = this.velocities[i]; v.y -= 10 * dt;
      this.positions[p] += v.x * dt; this.positions[p + 1] += v.y * dt; this.positions[p + 2] += v.z * dt;
      if (this.lives[i] <= 0) this.positions[p + 1] = -1000;
    }
    (this.points.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
  }

  dispose() { this.points.geometry.dispose(); (this.points.material as THREE.Material).dispose(); }
}

export class WeatherSystem {
  readonly points: THREE.Points;
  private count = 1400;
  private positions = new Float32Array(this.count * 3);
  private speeds = new Float32Array(this.count);
  private material: THREE.PointsMaterial;
  intensity = 0; snow = false;

  constructor() {
    for (let i = 0; i < this.count; i++) { this.reset(i, new THREE.Vector3(), true); this.speeds[i] = 12 + Math.random() * 14; }
    const geometry = new THREE.BufferGeometry(); geometry.setAttribute('position', new THREE.BufferAttribute(this.positions, 3));
    this.material = new THREE.PointsMaterial({ color: '#b7d6e8', size: 0.055, transparent: true, opacity: 0.65, depthWrite: false });
    this.points = new THREE.Points(geometry, this.material); this.points.frustumCulled = false; this.points.visible = false;
  }

  private reset(i: number, center: THREE.Vector3, initial = false) {
    const p = i * 3, angle = Math.random() * Math.PI * 2, radius = Math.sqrt(Math.random()) * 24;
    this.positions[p] = center.x + Math.cos(angle) * radius;
    this.positions[p + 1] = center.y + (initial ? Math.random() * 18 - 4 : 13 + Math.random() * 5);
    this.positions[p + 2] = center.z + Math.sin(angle) * radius;
  }

  setWeather(weather: string, snow: boolean) {
    this.intensity = weather === 'Storm' ? 1 : weather === 'Rain' || weather === 'Snow' ? 0.62 : 0;
    this.snow = snow || weather === 'Snow'; this.points.visible = this.intensity > 0;
    this.material.color.set(this.snow ? '#eef7fa' : '#b7d6e8'); this.material.size = this.snow ? 0.12 : 0.055;
    this.points.geometry.setDrawRange(0, Math.floor(this.count * this.intensity));
  }

  update(dt: number, center: THREE.Vector3, isSolid?: (x: number, y: number, z: number) => boolean) {
    if (!this.points.visible) return;
    const active = Math.floor(this.count * this.intensity);
    for (let i = 0; i < active; i++) {
      const p = i * 3;
      this.positions[p + 1] -= this.speeds[i] * dt * (this.snow ? 0.12 : 1);
      if (this.snow) { this.positions[p] += Math.sin(i + performance.now() * 0.001) * dt * 0.45; this.positions[p + 2] += dt * 0.25; }
      if (this.positions[p + 1] < center.y - 4 || Math.abs(this.positions[p] - center.x) > 28 || Math.abs(this.positions[p + 2] - center.z) > 28 || isSolid?.(this.positions[p], this.positions[p + 1], this.positions[p + 2])) this.reset(i, center);
    }
    (this.points.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
  }

  dispose() { this.points.geometry.dispose(); this.material.dispose(); }
}
