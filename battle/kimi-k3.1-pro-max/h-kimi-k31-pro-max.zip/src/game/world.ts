import * as THREE from 'three';
import { B, BLOCKS } from './blocks';
import { fbm2, fbm3, randomAt } from './noise';
import { Atlas, FaceKind, createVoxelMaterials, textureKey, tileUV } from './materials';

export const CHUNK_SIZE = 16;
export const WORLD_HEIGHT = 72;
export const SEA_LEVEL = 25;
export type Biome = 'Meadow' | 'Forest' | 'Desert' | 'Tundra' | 'Mountains' | 'Marsh';
export const BIOMES: Biome[] = ['Meadow', 'Forest', 'Desert', 'Tundra', 'Mountains', 'Marsh'];

export type RayHit = { x: number; y: number; z: number; nx: number; ny: number; nz: number; id: number; distance: number };
export type LightSource = { x: number; y: number; z: number; id: number };
type Chunk = {
  cx: number; cz: number; data: Uint8Array; biomes: Uint8Array; dirty: boolean;
  group: THREE.Group | null; lastUsed: number; lights: LightSource[];
};
type MeshArrays = { p: number[]; n: number[]; uv: number[]; c: number[]; i: number[] };
const arrays = (): MeshArrays => ({ p: [], n: [], uv: [], c: [], i: [] });
const chunkKey = (cx: number, cz: number) => `${cx},${cz}`;
const indexOf = (x: number, y: number, z: number) => x + CHUNK_SIZE * (z + CHUNK_SIZE * y);
const floorDiv = (n: number, d: number) => Math.floor(n / d);
const mod = (n: number, d: number) => ((n % d) + d) % d;

const FACES = [
  { n: [1, 0, 0], v: [[1, 0, 0], [1, 1, 0], [1, 1, 1], [1, 0, 1]], kind: 'side', shade: 0.86 },
  { n: [-1, 0, 0], v: [[0, 0, 1], [0, 1, 1], [0, 1, 0], [0, 0, 0]], kind: 'side', shade: 0.78 },
  { n: [0, 1, 0], v: [[0, 1, 1], [1, 1, 1], [1, 1, 0], [0, 1, 0]], kind: 'top', shade: 1 },
  { n: [0, -1, 0], v: [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]], kind: 'bottom', shade: 0.58 },
  { n: [0, 0, 1], v: [[1, 0, 1], [1, 1, 1], [0, 1, 1], [0, 0, 1]], kind: 'side', shade: 0.91 },
  { n: [0, 0, -1], v: [[0, 0, 0], [0, 1, 0], [1, 1, 0], [1, 0, 0]], kind: 'side', shade: 0.82 },
] as const;

const BIOME_TINTS: Record<Biome, [number, number, number]> = {
  Meadow: [0.91, 1, 0.82], Forest: [0.72, 0.94, 0.68], Desert: [1, 1, 1],
  Tundra: [0.84, 0.96, 0.9], Mountains: [0.85, 0.94, 0.84], Marsh: [0.65, 0.82, 0.58],
};

export class VoxelWorld {
  readonly scene = new THREE.Group();
  readonly chunks = new Map<string, Chunk>();
  readonly seed: number;
  private edits = new Map<string, Map<number, number>>();
  private atlas: Atlas;
  private materials: ReturnType<typeof createVoxelMaterials>;
  private meshQueue = new Set<string>();
  private lastCull = 0;
  renderDistance = 4;

  constructor(seed: number, atlas: Atlas, savedEdits?: Record<string, [number, number][]>) {
    this.seed = seed; this.atlas = atlas; this.materials = createVoxelMaterials(atlas);
    this.scene.name = 'Voxel chunks';
    if (savedEdits) for (const [key, entries] of Object.entries(savedEdits)) this.edits.set(key, new Map(entries));
  }

  biomeAt(x: number, z: number): Biome {
    const temp = fbm2(x * 0.0021, z * 0.0021, this.seed + 300, 3);
    const wet = fbm2(x * 0.0027, z * 0.0027, this.seed + 700, 3);
    const h = this.heightAt(x, z, false);
    if (h > 43) return 'Mountains';
    if (temp < -0.19) return 'Tundra';
    if (temp > 0.17 && wet < 0.02) return 'Desert';
    if (wet > 0.25 && h < 31) return 'Marsh';
    if (wet > 0.025) return 'Forest';
    return 'Meadow';
  }

  heightAt(x: number, z: number, includeBiome = true): number {
    const continental = fbm2(x * 0.0024, z * 0.0024, this.seed, 4);
    const hills = fbm2(x * 0.011, z * 0.011, this.seed + 90, 3);
    const ridgeNoise = fbm2(x * 0.004, z * 0.004, this.seed + 820, 3);
    const mountain = Math.max(0, ridgeNoise - 0.055) * 58;
    let h = 29 + continental * 22 + hills * 7 + mountain;
    if (includeBiome) {
      const temp = fbm2(x * 0.0021, z * 0.0021, this.seed + 300, 3);
      if (temp > 0.17) h = 28 + continental * 10 + hills * 3;
    }
    return Math.max(5, Math.min(WORLD_HEIGHT - 9, Math.floor(h)));
  }

  private treeAt(x: number, z: number) {
    const cellX = Math.floor(x / 6), cellZ = Math.floor(z / 6);
    const rx = cellX * 6 + Math.floor(randomAt(cellX, cellZ, 1, this.seed + 1400) * 6);
    const rz = cellZ * 6 + Math.floor(randomAt(cellX, cellZ, 2, this.seed + 1400) * 6);
    if (rx !== x || rz !== z) return false;
    const biome = this.biomeAt(x, z);
    const chance = biome === 'Forest' ? 0.8 : biome === 'Meadow' ? 0.2 : biome === 'Tundra' ? 0.24 : biome === 'Marsh' ? 0.3 : 0;
    return randomAt(x, z, 9, this.seed) < chance && this.heightAt(x, z) > SEA_LEVEL;
  }

  private generateChunk(cx: number, cz: number): Chunk {
    const data = new Uint8Array(CHUNK_SIZE * CHUNK_SIZE * WORLD_HEIGHT);
    const biomes = new Uint8Array(CHUNK_SIZE * CHUNK_SIZE);
    for (let z = 0; z < CHUNK_SIZE; z++) for (let x = 0; x < CHUNK_SIZE; x++) {
      const wx = cx * CHUNK_SIZE + x, wz = cz * CHUNK_SIZE + z;
      const h = this.heightAt(wx, wz), biome = this.biomeAt(wx, wz);
      biomes[x + z * CHUNK_SIZE] = BIOMES.indexOf(biome);
      for (let y = 0; y <= Math.max(h, SEA_LEVEL); y++) {
        let id: number = B.Air;
        if (y === 0) id = B.Bedrock;
        else if (y <= h) {
          const depth = h - y;
          if (biome === 'Desert') id = depth < 4 ? B.Sand : depth < 8 ? B.Sandstone : B.Stone;
          else if (biome === 'Tundra') id = depth === 0 ? B.Snow : depth < 4 ? B.Dirt : B.Stone;
          else id = depth === 0 ? B.Grass : depth < 4 ? B.Dirt : B.Stone;
          if (biome === 'Marsh' && h <= SEA_LEVEL + 1 && depth < 2) id = randomAt(wx, y, wz, this.seed) > 0.45 ? B.Clay : B.Grass;
          if (id === B.Stone && depth > 3 && y > 3) {
            const cave = fbm3(wx * 0.052, y * 0.072, wz * 0.052, this.seed + 430, 3);
            const tunnel = Math.abs(fbm3(wx * 0.025, y * 0.045, wz * 0.025, this.seed + 941, 2));
            if (cave > 0.205 || (tunnel < 0.027 && y < h - 7)) id = B.Air;
          }
          if (id === B.Stone) {
            const ore = randomAt(wx, y, wz, this.seed + 222);
            if (y < 45 && ore < 0.014) id = B.CoalOre;
            else if (y < 29 && ore > 0.986) id = B.IronOre;
            else if (y < 14 && ore > 0.9991) id = B.Crystal;
            else if (y < 12 && ore > 0.9987) id = B.Glowstone;
            else if (y < 32 && ore > 0.975 && ore < 0.979) id = B.Gravel;
          }
        } else if (y <= SEA_LEVEL) id = B.Water;
        if (biome === 'Tundra' && y === SEA_LEVEL && h < SEA_LEVEL) id = B.Ice;
        data[indexOf(x, y, z)] = id;
      }
    }

    // Only deterministic vegetation anchors are evaluated, including cells whose canopy crosses a border.
    const startX = cx * CHUNK_SIZE, startZ = cz * CHUNK_SIZE;
    const put = (x: number, y: number, z: number, id: number, replace = false) => {
      const lx = x - startX, lz = z - startZ;
      if (lx < 0 || lx >= CHUNK_SIZE || lz < 0 || lz >= CHUNK_SIZE || y < 1 || y >= WORLD_HEIGHT) return;
      const idx = indexOf(lx, y, lz);
      if (replace || data[idx] === B.Air || data[idx] === B.Leaves || data[idx] === B.BirchLeaves) data[idx] = id;
    };
    const minCellX = Math.floor((startX - 3) / 6), maxCellX = Math.floor((startX + CHUNK_SIZE + 2) / 6);
    const minCellZ = Math.floor((startZ - 3) / 6), maxCellZ = Math.floor((startZ + CHUNK_SIZE + 2) / 6);
    for (let cellX = minCellX; cellX <= maxCellX; cellX++) for (let cellZ = minCellZ; cellZ <= maxCellZ; cellZ++) {
      const wx = cellX * 6 + Math.floor(randomAt(cellX, cellZ, 1, this.seed + 1400) * 6);
      const wz = cellZ * 6 + Math.floor(randomAt(cellX, cellZ, 2, this.seed + 1400) * 6);
      const biome = this.biomeAt(wx, wz), h = this.heightAt(wx, wz);
      if (this.treeAt(wx, wz)) {
        const birch = biome === 'Meadow' || randomAt(wx, h, wz, this.seed) > 0.64;
        const log = birch ? B.BirchLog : B.OakLog, leaves = birch ? B.BirchLeaves : B.Leaves;
        const trunk = 4 + Math.floor(randomAt(wx, wz, h, this.seed + 51) * 3);
        for (let y = 1; y <= trunk; y++) put(wx, h + y, wz, log, true);
        for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) {
          const distance = Math.abs(dx) + Math.abs(dz) + Math.abs(dy) * 0.7;
          if (distance < 3.9 && !(dx === 0 && dz === 0 && dy < 1)) put(wx + dx, h + trunk + dy, wz + dz, leaves);
        }
        put(wx, h + trunk + 2, wz, leaves);
      } else if (biome === 'Desert' && h > SEA_LEVEL && randomAt(wx, wz, 17, this.seed + 42) < 0.38) {
        const cactus = 2 + Math.floor(randomAt(wx, wz, 18, this.seed) * 2);
        for (let y = 1; y <= cactus; y++) put(wx, h + y, wz, B.Cactus);
      }
    }

    const key = chunkKey(cx, cz);
    const saved = this.edits.get(key);
    if (saved) saved.forEach((id, index) => { if (index >= 0 && index < data.length) data[index] = id; });
    return { cx, cz, data, biomes, dirty: true, group: null, lastUsed: performance.now(), lights: [] };
  }

  ensureChunk(cx: number, cz: number) {
    const key = chunkKey(cx, cz);
    let chunk = this.chunks.get(key);
    if (!chunk) { chunk = this.generateChunk(cx, cz); this.chunks.set(key, chunk); this.meshQueue.add(key); }
    chunk.lastUsed = performance.now();
    return chunk;
  }

  getBlock(x: number, y: number, z: number, generate = true): number {
    x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
    if (y < 0) return B.Bedrock; if (y >= WORLD_HEIGHT) return B.Air;
    const cx = floorDiv(x, CHUNK_SIZE), cz = floorDiv(z, CHUNK_SIZE);
    const chunk = generate ? this.ensureChunk(cx, cz) : this.chunks.get(chunkKey(cx, cz));
    if (!chunk) return B.Air;
    return chunk.data[indexOf(mod(x, CHUNK_SIZE), y, mod(z, CHUNK_SIZE))];
  }

  getBiome(x: number, z: number): Biome {
    const cx = floorDiv(Math.floor(x), CHUNK_SIZE), cz = floorDiv(Math.floor(z), CHUNK_SIZE);
    const chunk = this.ensureChunk(cx, cz);
    return BIOMES[chunk.biomes[mod(Math.floor(x), CHUNK_SIZE) + mod(Math.floor(z), CHUNK_SIZE) * CHUNK_SIZE]];
  }

  setBlock(x: number, y: number, z: number, id: number, record = true) {
    x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
    if (y <= 0 || y >= WORLD_HEIGHT) return false;
    const cx = floorDiv(x, CHUNK_SIZE), cz = floorDiv(z, CHUNK_SIZE), key = chunkKey(cx, cz);
    const chunk = this.ensureChunk(cx, cz), lx = mod(x, CHUNK_SIZE), lz = mod(z, CHUNK_SIZE);
    const index = indexOf(lx, y, lz);
    if (chunk.data[index] === id) return false;
    chunk.data[index] = id; chunk.dirty = true; this.meshQueue.add(key);
    if (record) {
      let edits = this.edits.get(key); if (!edits) { edits = new Map(); this.edits.set(key, edits); }
      edits.set(index, id);
    }
    if (lx === 0) this.markDirty(cx - 1, cz); if (lx === CHUNK_SIZE - 1) this.markDirty(cx + 1, cz);
    if (lz === 0) this.markDirty(cx, cz - 1); if (lz === CHUNK_SIZE - 1) this.markDirty(cx, cz + 1);
    return true;
  }

  private markDirty(cx: number, cz: number) {
    const key = chunkKey(cx, cz), chunk = this.chunks.get(key);
    if (chunk) { chunk.dirty = true; this.meshQueue.add(key); }
  }

  private ao(x: number, y: number, z: number, normal: readonly number[], vertex: readonly number[]) {
    const axis = normal[0] !== 0 ? 0 : normal[1] !== 0 ? 1 : 2;
    const tangents = [0, 1, 2].filter(a => a !== axis);
    const base = [x + normal[0], y + normal[1], z + normal[2]];
    const offsets: number[][] = [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
    const sign = (a: number) => vertex[a] === 1 ? 1 : -1;
    offsets[0][tangents[0]] = sign(tangents[0]); offsets[1][tangents[1]] = sign(tangents[1]);
    offsets[2][tangents[0]] = sign(tangents[0]); offsets[2][tangents[1]] = sign(tangents[1]);
    const solid = (off: number[]) => {
      const id = this.getBlock(base[0] + off[0], base[1] + off[1], base[2] + off[2]);
      return BLOCKS[id]?.solid && !BLOCKS[id]?.translucent;
    };
    const s1 = solid(offsets[0]), s2 = solid(offsets[1]), corner = solid(offsets[2]);
    const level = s1 && s2 ? 0 : 3 - (Number(s1) + Number(s2) + Number(corner));
    return [0.53, 0.7, 0.85, 1][level];
  }

  private addFace(out: MeshArrays, id: number, x: number, y: number, z: number, face: typeof FACES[number], tint: [number, number, number], water = false) {
    const base = out.p.length / 3;
    const uv = water ? { u0: 0, v0: 0, u1: 1, v1: 1 } : tileUV(this.atlas.tiles, textureKey(id, face.kind as FaceKind));
    const uvs = [[uv.u0, uv.v0], [uv.u0, uv.v1], [uv.u1, uv.v1], [uv.u1, uv.v0]];
    for (let k = 0; k < 4; k++) {
      const v = face.v[k]; out.p.push(x + v[0], y + (water && face.n[1] === 1 ? -0.12 : 0) + v[1], z + v[2]);
      out.n.push(face.n[0], face.n[1], face.n[2]); out.uv.push(uvs[k][0], uvs[k][1]);
      const occlusion = water ? 1 : this.ao(x, y, z, face.n, v);
      const light = face.shade * occlusion;
      out.c.push(tint[0] * light, tint[1] * light, tint[2] * light);
    }
    out.i.push(base, base + 1, base + 2, base, base + 2, base + 3);
  }

  private makeGeometry(a: MeshArrays) {
    if (!a.p.length) return null;
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(a.p, 3));
    geometry.setAttribute('normal', new THREE.Float32BufferAttribute(a.n, 3));
    geometry.setAttribute('uv', new THREE.Float32BufferAttribute(a.uv, 2));
    geometry.setAttribute('color', new THREE.Float32BufferAttribute(a.c, 3));
    geometry.setIndex(a.i); geometry.computeBoundingSphere();
    return geometry;
  }

  rebuildChunk(chunk: Chunk) {
    if (chunk.group) {
      this.scene.remove(chunk.group);
      chunk.group.traverse(obj => { if (obj instanceof THREE.Mesh) obj.geometry.dispose(); });
    }
    const group = new THREE.Group(); group.name = `Chunk ${chunk.cx},${chunk.cz}`;
    const solid = arrays(), glow = arrays(), water = arrays(), lights: LightSource[] = [];
    const startX = chunk.cx * CHUNK_SIZE, startZ = chunk.cz * CHUNK_SIZE;
    for (let y = 0; y < WORLD_HEIGHT; y++) for (let z = 0; z < CHUNK_SIZE; z++) for (let x = 0; x < CHUNK_SIZE; x++) {
      const id = chunk.data[indexOf(x, y, z)]; if (id === B.Air) continue;
      const wx = startX + x, wz = startZ + z;
      if (BLOCKS[id]?.luminous) lights.push({ x: wx + 0.5, y: y + 0.5, z: wz + 0.5, id });
      const biome = BIOMES[chunk.biomes[x + z * CHUNK_SIZE]];
      let tint: [number, number, number] = [1, 1, 1];
      if (id === B.Grass || id === B.Leaves || id === B.BirchLeaves) tint = BIOME_TINTS[biome];
      const out = id === B.Water ? water : BLOCKS[id]?.luminous ? glow : solid;
      for (const face of FACES) {
        const neighbor = this.getBlock(wx + face.n[0], y + face.n[1], wz + face.n[2]);
        if (id === B.Water) {
          if (neighbor === B.Water || (BLOCKS[neighbor]?.solid && !BLOCKS[neighbor]?.translucent)) continue;
        } else {
          if (neighbor === id && BLOCKS[id]?.translucent) continue;
          if (neighbor !== B.Air && neighbor !== B.Water && !BLOCKS[neighbor]?.translucent) continue;
        }
        this.addFace(out, id, wx, y, wz, face, tint, id === B.Water);
      }
    }
    const solidGeo = this.makeGeometry(solid), glowGeo = this.makeGeometry(glow), waterGeo = this.makeGeometry(water);
    if (solidGeo) { const mesh = new THREE.Mesh(solidGeo, this.materials.solid); mesh.castShadow = true; mesh.receiveShadow = true; group.add(mesh); }
    if (glowGeo) { const mesh = new THREE.Mesh(glowGeo, this.materials.glow); mesh.receiveShadow = true; group.add(mesh); }
    if (waterGeo) { const mesh = new THREE.Mesh(waterGeo, this.materials.water); mesh.renderOrder = 2; group.add(mesh); }
    chunk.group = group; chunk.lights = lights; chunk.dirty = false; this.scene.add(group); this.meshQueue.delete(chunkKey(chunk.cx, chunk.cz));
  }

  updateStreaming(px: number, pz: number, meshBudget = 1, generateBudget = 2) {
    const pcx = floorDiv(Math.floor(px), CHUNK_SIZE), pcz = floorDiv(Math.floor(pz), CHUNK_SIZE);
    const wanted: { cx: number; cz: number; d: number }[] = [];
    for (let dz = -this.renderDistance; dz <= this.renderDistance; dz++) for (let dx = -this.renderDistance; dx <= this.renderDistance; dx++) {
      const d = dx * dx + dz * dz; if (d <= (this.renderDistance + 0.35) ** 2) wanted.push({ cx: pcx + dx, cz: pcz + dz, d });
    }
    wanted.sort((a, b) => a.d - b.d);
    let generated = 0;
    for (const pos of wanted) {
      const key = chunkKey(pos.cx, pos.cz);
      if (!this.chunks.has(key)) { this.ensureChunk(pos.cx, pos.cz); generated++; if (generated >= generateBudget) break; }
      else this.chunks.get(key)!.lastUsed = performance.now();
    }
    let meshed = 0;
    const queued = [...this.meshQueue].map(key => this.chunks.get(key)).filter(Boolean) as Chunk[];
    queued.sort((a, b) => ((a.cx - pcx) ** 2 + (a.cz - pcz) ** 2) - ((b.cx - pcx) ** 2 + (b.cz - pcz) ** 2));
    for (const chunk of queued) {
      if (Math.abs(chunk.cx - pcx) > this.renderDistance + 1 || Math.abs(chunk.cz - pcz) > this.renderDistance + 1) continue;
      this.rebuildChunk(chunk); if (++meshed >= meshBudget) break;
    }
    if (performance.now() - this.lastCull > 2000) {
      this.lastCull = performance.now();
      for (const [key, chunk] of this.chunks) {
        if (Math.abs(chunk.cx - pcx) > this.renderDistance + 2 || Math.abs(chunk.cz - pcz) > this.renderDistance + 2) {
          if (chunk.group) { this.scene.remove(chunk.group); chunk.group.traverse(o => { if (o instanceof THREE.Mesh) o.geometry.dispose(); }); }
          this.chunks.delete(key); this.meshQueue.delete(key);
        }
      }
    }
    const visible = wanted.filter(p => this.chunks.get(chunkKey(p.cx, p.cz))?.group).length;
    return { loaded: visible, total: wanted.length, queued: this.meshQueue.size };
  }

  prepareSpawn(x: number, z: number, radius = 1) {
    const cx = floorDiv(Math.floor(x), CHUNK_SIZE), cz = floorDiv(Math.floor(z), CHUNK_SIZE);
    for (let dz = -radius; dz <= radius; dz++) for (let dx = -radius; dx <= radius; dx++) this.ensureChunk(cx + dx, cz + dz);
    for (let dz = -radius; dz <= radius; dz++) for (let dx = -radius; dx <= radius; dx++) this.rebuildChunk(this.chunks.get(chunkKey(cx + dx, cz + dz))!);
  }

  findSurface(x: number, z: number) {
    for (let y = WORLD_HEIGHT - 1; y > 0; y--) {
      const id = this.getBlock(x, y, z);
      if (BLOCKS[id]?.solid && id !== B.Leaves && id !== B.BirchLeaves) return y + 1;
    }
    return SEA_LEVEL + 2;
  }

  raycast(origin: THREE.Vector3, direction: THREE.Vector3, maxDistance = 6): RayHit | null {
    const dir = direction.clone().normalize();
    let x = Math.floor(origin.x), y = Math.floor(origin.y), z = Math.floor(origin.z);
    const stepX = Math.sign(dir.x), stepY = Math.sign(dir.y), stepZ = Math.sign(dir.z);
    const deltaX = stepX === 0 ? Infinity : Math.abs(1 / dir.x), deltaY = stepY === 0 ? Infinity : Math.abs(1 / dir.y), deltaZ = stepZ === 0 ? Infinity : Math.abs(1 / dir.z);
    let maxX = stepX === 0 ? Infinity : ((stepX > 0 ? x + 1 - origin.x : origin.x - x) * deltaX);
    let maxY = stepY === 0 ? Infinity : ((stepY > 0 ? y + 1 - origin.y : origin.y - y) * deltaY);
    let maxZ = stepZ === 0 ? Infinity : ((stepZ > 0 ? z + 1 - origin.z : origin.z - z) * deltaZ);
    let distance = 0, nx = 0, ny = 0, nz = 0;
    for (let iterations = 0; iterations < 128 && distance <= maxDistance; iterations++) {
      const id = this.getBlock(x, y, z);
      if (id !== B.Air && id !== B.Water) return { x, y, z, nx, ny, nz, id, distance };
      if (maxX < maxY && maxX < maxZ) { x += stepX; distance = maxX; maxX += deltaX; nx = -stepX; ny = 0; nz = 0; }
      else if (maxY < maxZ) { y += stepY; distance = maxY; maxY += deltaY; nx = 0; ny = -stepY; nz = 0; }
      else { z += stepZ; distance = maxZ; maxZ += deltaZ; nx = 0; ny = 0; nz = -stepZ; }
    }
    return null;
  }

  getNearbyLights(position: THREE.Vector3, radius = 20) {
    const result: (LightSource & { distance: number })[] = [], radiusSq = radius * radius;
    for (const chunk of this.chunks.values()) for (const light of chunk.lights) {
      const distance = (light.x - position.x) ** 2 + (light.y - position.y) ** 2 + (light.z - position.z) ** 2;
      if (distance < radiusSq) result.push({ ...light, distance });
    }
    return result.sort((a, b) => a.distance - b.distance);
  }

  updateTime(time: number) {
    const shader = this.materials.water.userData.shader as { uniforms?: { waterTime?: { value: number } } } | undefined;
    if (shader?.uniforms?.waterTime) shader.uniforms.waterTime.value = time;
  }

  serializeEdits() {
    const result: Record<string, [number, number][]> = {};
    this.edits.forEach((map, key) => { result[key] = [...map.entries()]; });
    return result;
  }

  dispose() {
    for (const chunk of this.chunks.values()) if (chunk.group) chunk.group.traverse(o => { if (o instanceof THREE.Mesh) o.geometry.dispose(); });
    this.materials.solid.dispose(); this.materials.glow.dispose(); this.materials.water.dispose(); this.atlas.texture.dispose(); this.scene.clear(); this.chunks.clear();
  }
}
