import { Stack } from './blocks';

export type GameMode = 'survival' | 'creative';
export type SavedGame = {
  version: 1; id: string; name: string; seedLabel: string; seed: number; mode: GameMode;
  updatedAt: number; playTime: number; edits: Record<string, [number, number][]>;
  player?: { x: number; y: number; z: number; yaw: number; pitch: number };
  inventory: (Stack | null)[]; selected: number; health: number; hunger: number; air?: number; xp: number;
  hours: number; day: number; weather: string; achievements: string[]; bossDefeated: boolean;
};
export type WorldMeta = Pick<SavedGame, 'id' | 'name' | 'seedLabel' | 'mode' | 'updatedAt' | 'playTime'> & { level: number };

const WORLD_PREFIX = 'terrevale.world.';
const CATALOG_KEY = 'terrevale.catalog';

export function loadWorld(id: string): SavedGame | null {
  try {
    const raw = localStorage.getItem(WORLD_PREFIX + id); if (!raw) return null;
    const data = JSON.parse(raw) as SavedGame;
    if (data.version !== 1 || !Array.isArray(data.inventory) || typeof data.seed !== 'number') return null;
    return data;
  } catch { return null; }
}

export function saveWorld(data: SavedGame) {
  try {
    localStorage.setItem(WORLD_PREFIX + data.id, JSON.stringify(data));
    const catalog = listWorlds().filter(world => world.id !== data.id);
    const meta: WorldMeta = { id: data.id, name: data.name, seedLabel: data.seedLabel, mode: data.mode, updatedAt: data.updatedAt, playTime: data.playTime, level: Math.max(1, Math.floor(Math.sqrt(data.xp / 18)) + 1) };
    catalog.unshift(meta); localStorage.setItem(CATALOG_KEY, JSON.stringify(catalog.slice(0, 12)));
    return true;
  } catch { return false; }
}

export function listWorlds(): WorldMeta[] {
  try {
    const parsed = JSON.parse(localStorage.getItem(CATALOG_KEY) ?? '[]');
    return Array.isArray(parsed) ? parsed.filter(w => w && typeof w.id === 'string') : [];
  } catch { return []; }
}

export function deleteWorld(id: string) {
  try { localStorage.removeItem(WORLD_PREFIX + id); localStorage.setItem(CATALOG_KEY, JSON.stringify(listWorlds().filter(w => w.id !== id))); } catch { /* storage can be disabled */ }
}

export function makeWorldId() { return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`; }
