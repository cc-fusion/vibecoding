export const enum B {
  Air = 0, Grass = 1, Dirt = 2, Stone = 3, Sand = 4, OakLog = 5,
  Leaves = 6, Water = 7, Planks = 8, Cobblestone = 9, CoalOre = 10,
  IronOre = 11, Snow = 12, Ice = 13, Cactus = 14, Glass = 15,
  Bricks = 16, Glowstone = 17, CraftingTable = 18, Furnace = 19,
  Bedrock = 20, Gravel = 21, Clay = 22, BirchLog = 23, BirchLeaves = 24,
  Sandstone = 25, Crystal = 26,
}

export type ToolKind = 'pickaxe' | 'axe' | 'shovel' | 'sword';
export type BlockDef = {
  name: string;
  short: string;
  solid: boolean;
  liquid?: boolean;
  translucent?: boolean;
  luminous?: boolean;
  hardness: number;
  tool?: ToolKind;
  tier?: number;
  drop?: number;
  xp?: number;
  color: string;
};

const def = (name: string, short: string, color: string, hardness: number, extra: Partial<BlockDef> = {}): BlockDef => ({
  name, short, color, hardness, solid: true, ...extra,
});

export const BLOCKS: Record<number, BlockDef> = {
  [B.Air]: def('Air', 'Air', '#000000', 0, { solid: false, translucent: true }),
  [B.Grass]: def('Grass Block', 'Grass', '#6f9f45', 0.7, { tool: 'shovel', drop: B.Dirt, xp: 1 }),
  [B.Dirt]: def('Dirt', 'Dirt', '#805a3c', 0.6, { tool: 'shovel', xp: 1 }),
  [B.Stone]: def('Stone', 'Stone', '#858585', 1.7, { tool: 'pickaxe', tier: 1, drop: B.Cobblestone, xp: 1 }),
  [B.Sand]: def('Sand', 'Sand', '#d8c68b', 0.55, { tool: 'shovel', xp: 1 }),
  [B.OakLog]: def('Oak Log', 'Oak Log', '#765332', 1.4, { tool: 'axe', xp: 3 }),
  [B.Leaves]: def('Oak Leaves', 'Leaves', '#477d39', 0.25, { translucent: true, xp: 1 }),
  [B.Water]: def('Water', 'Water', '#397fc4', 999, { solid: false, liquid: true, translucent: true }),
  [B.Planks]: def('Oak Planks', 'Planks', '#b98c52', 1.2, { tool: 'axe', xp: 1 }),
  [B.Cobblestone]: def('Cobblestone', 'Cobble', '#777873', 1.9, { tool: 'pickaxe', tier: 1, xp: 1 }),
  [B.CoalOre]: def('Coal Ore', 'Coal Ore', '#4f504e', 2.3, { tool: 'pickaxe', tier: 1, drop: 111, xp: 7 }),
  [B.IronOre]: def('Iron Ore', 'Iron Ore', '#a88470', 3.1, { tool: 'pickaxe', tier: 2, drop: 112, xp: 12 }),
  [B.Snow]: def('Snow Block', 'Snow', '#e5f0f2', 0.35, { tool: 'shovel', xp: 1 }),
  [B.Ice]: def('Ice', 'Ice', '#9dcddd', 0.6, { translucent: true, tool: 'pickaxe', xp: 1 }),
  [B.Cactus]: def('Cactus', 'Cactus', '#3f783d', 0.5, { xp: 2 }),
  [B.Glass]: def('Glass', 'Glass', '#b9dfe1', 0.35, { translucent: true, xp: 1 }),
  [B.Bricks]: def('Bricks', 'Bricks', '#a05d48', 2, { tool: 'pickaxe', tier: 1, xp: 2 }),
  [B.Glowstone]: def('Sunstone', 'Sunstone', '#eac66c', 0.8, { luminous: true, xp: 8 }),
  [B.CraftingTable]: def('Crafting Table', 'Workbench', '#96643c', 1.4, { tool: 'axe', xp: 2 }),
  [B.Furnace]: def('Furnace', 'Furnace', '#686b69', 2.5, { tool: 'pickaxe', tier: 1, xp: 3 }),
  [B.Bedrock]: def('Bedrock', 'Bedrock', '#303130', Infinity, { xp: 0 }),
  [B.Gravel]: def('Gravel', 'Gravel', '#8a817c', 0.65, { tool: 'shovel', xp: 1 }),
  [B.Clay]: def('Clay', 'Clay', '#9aa4ac', 0.7, { tool: 'shovel', xp: 2 }),
  [B.BirchLog]: def('Birch Log', 'Birch Log', '#d2c9a6', 1.3, { tool: 'axe', xp: 3 }),
  [B.BirchLeaves]: def('Birch Leaves', 'Birch Leaf', '#6b963f', 0.25, { translucent: true, xp: 1 }),
  [B.Sandstone]: def('Sandstone', 'Sandstone', '#cdb77b', 1.2, { tool: 'pickaxe', tier: 1, xp: 1 }),
  [B.Crystal]: def('Echo Crystal', 'Crystal', '#7fd6cf', 3.5, { luminous: true, tool: 'pickaxe', tier: 3, drop: 113, xp: 25 }),
};

export const ITEMS: Record<number, { name: string; short: string; color: string; stack: number; tool?: ToolKind; tier?: number; damage?: number; food?: number; description?: string }> = {
  100: { name: 'Stick', short: 'Stick', color: '#9b7043', stack: 64 },
  101: { name: 'Wooden Pickaxe', short: 'Wood Pick', color: '#b98c52', stack: 1, tool: 'pickaxe', tier: 1, damage: 2 },
  102: { name: 'Stone Pickaxe', short: 'Stone Pick', color: '#8b8d88', stack: 1, tool: 'pickaxe', tier: 2, damage: 3 },
  103: { name: 'Iron Pickaxe', short: 'Iron Pick', color: '#d4d6cf', stack: 1, tool: 'pickaxe', tier: 3, damage: 4 },
  104: { name: 'Wooden Axe', short: 'Wood Axe', color: '#b98c52', stack: 1, tool: 'axe', tier: 1, damage: 3 },
  105: { name: 'Stone Axe', short: 'Stone Axe', color: '#8b8d88', stack: 1, tool: 'axe', tier: 2, damage: 4 },
  106: { name: 'Iron Axe', short: 'Iron Axe', color: '#d4d6cf', stack: 1, tool: 'axe', tier: 3, damage: 5 },
  107: { name: 'Wooden Sword', short: 'Wood Sword', color: '#b98c52', stack: 1, tool: 'sword', tier: 1, damage: 4 },
  108: { name: 'Stone Sword', short: 'Stone Sword', color: '#8b8d88', stack: 1, tool: 'sword', tier: 2, damage: 5 },
  109: { name: 'Iron Sword', short: 'Iron Sword', color: '#d4d6cf', stack: 1, tool: 'sword', tier: 3, damage: 7 },
  110: { name: 'Iron Ingot', short: 'Iron Ingot', color: '#d8d9d2', stack: 64 },
  111: { name: 'Coal', short: 'Coal', color: '#353735', stack: 64 },
  112: { name: 'Raw Iron', short: 'Raw Iron', color: '#b58c75', stack: 64 },
  113: { name: 'Echo Shard', short: 'Echo Shard', color: '#79d6ce', stack: 16 },
  114: { name: 'Guardian Core', short: 'Core', color: '#f0bf62', stack: 1, description: 'Use in an open area to challenge the Ancient Guardian.' },
  115: { name: 'Apple', short: 'Apple', color: '#c44f42', stack: 16, food: 5 },
  116: { name: 'Trail Ration', short: 'Ration', color: '#d6aa61', stack: 16, food: 9 },
  117: { name: 'Wooden Shovel', short: 'Wood Shovel', color: '#b98c52', stack: 1, tool: 'shovel', tier: 1, damage: 2 },
  118: { name: 'Stone Shovel', short: 'Stone Shovel', color: '#8b8d88', stack: 1, tool: 'shovel', tier: 2, damage: 3 },
  119: { name: 'Iron Shovel', short: 'Iron Shovel', color: '#d4d6cf', stack: 1, tool: 'shovel', tier: 3, damage: 4 },
  120: { name: 'Venison', short: 'Venison', color: '#a95f4f', stack: 16, food: 6 },
  121: { name: 'Boar Meat', short: 'Boar Meat', color: '#985345', stack: 16, food: 8 },
};

export const getItem = (id: number) => BLOCKS[id] ? { ...BLOCKS[id], stack: 64 } : ITEMS[id];
export const itemName = (id: number) => getItem(id)?.name ?? 'Unknown';
export const itemColor = (id: number) => getItem(id)?.color ?? '#ff00ff';
export const maxStack = (id: number) => getItem(id)?.stack ?? 64;

export type Stack = { id: number; count: number; durability?: number };
export type Recipe = {
  id: string; output: number; count: number; ingredients: { id: number; count: number }[];
  station?: 'table' | 'furnace'; level?: number; xp: number; category: 'Basics' | 'Tools' | 'Building' | 'Survival';
};

export const RECIPES: Recipe[] = [
  { id: 'planks', output: B.Planks, count: 4, ingredients: [{ id: B.OakLog, count: 1 }], xp: 2, category: 'Basics' },
  { id: 'birch-planks', output: B.Planks, count: 4, ingredients: [{ id: B.BirchLog, count: 1 }], xp: 2, category: 'Basics' },
  { id: 'sticks', output: 100, count: 4, ingredients: [{ id: B.Planks, count: 2 }], xp: 1, category: 'Basics' },
  { id: 'table', output: B.CraftingTable, count: 1, ingredients: [{ id: B.Planks, count: 4 }], xp: 4, category: 'Basics' },
  { id: 'wood-pick', output: 101, count: 1, ingredients: [{ id: B.Planks, count: 3 }, { id: 100, count: 2 }], station: 'table', xp: 5, category: 'Tools' },
  { id: 'wood-axe', output: 104, count: 1, ingredients: [{ id: B.Planks, count: 3 }, { id: 100, count: 2 }], station: 'table', xp: 5, category: 'Tools' },
  { id: 'wood-shovel', output: 117, count: 1, ingredients: [{ id: B.Planks, count: 1 }, { id: 100, count: 2 }], station: 'table', xp: 4, category: 'Tools' },
  { id: 'wood-sword', output: 107, count: 1, ingredients: [{ id: B.Planks, count: 2 }, { id: 100, count: 1 }], station: 'table', xp: 5, category: 'Tools' },
  { id: 'stone-pick', output: 102, count: 1, ingredients: [{ id: B.Cobblestone, count: 3 }, { id: 100, count: 2 }], station: 'table', level: 2, xp: 8, category: 'Tools' },
  { id: 'stone-axe', output: 105, count: 1, ingredients: [{ id: B.Cobblestone, count: 3 }, { id: 100, count: 2 }], station: 'table', level: 2, xp: 8, category: 'Tools' },
  { id: 'stone-shovel', output: 118, count: 1, ingredients: [{ id: B.Cobblestone, count: 1 }, { id: 100, count: 2 }], station: 'table', level: 2, xp: 6, category: 'Tools' },
  { id: 'stone-sword', output: 108, count: 1, ingredients: [{ id: B.Cobblestone, count: 2 }, { id: 100, count: 1 }], station: 'table', level: 2, xp: 8, category: 'Tools' },
  { id: 'furnace', output: B.Furnace, count: 1, ingredients: [{ id: B.Cobblestone, count: 8 }], station: 'table', level: 2, xp: 8, category: 'Basics' },
  { id: 'iron-pick', output: 103, count: 1, ingredients: [{ id: 110, count: 3 }, { id: 100, count: 2 }], station: 'table', level: 4, xp: 14, category: 'Tools' },
  { id: 'iron-axe', output: 106, count: 1, ingredients: [{ id: 110, count: 3 }, { id: 100, count: 2 }], station: 'table', level: 4, xp: 14, category: 'Tools' },
  { id: 'iron-shovel', output: 119, count: 1, ingredients: [{ id: 110, count: 1 }, { id: 100, count: 2 }], station: 'table', level: 4, xp: 12, category: 'Tools' },
  { id: 'iron-sword', output: 109, count: 1, ingredients: [{ id: 110, count: 2 }, { id: 100, count: 1 }], station: 'table', level: 4, xp: 14, category: 'Tools' },
  { id: 'smelt-iron', output: 110, count: 1, ingredients: [{ id: 112, count: 1 }, { id: 111, count: 1 }], station: 'furnace', level: 3, xp: 10, category: 'Survival' },
  { id: 'smelt-glass', output: B.Glass, count: 1, ingredients: [{ id: B.Sand, count: 1 }, { id: 111, count: 1 }], station: 'furnace', level: 2, xp: 3, category: 'Building' },
  { id: 'bricks', output: B.Bricks, count: 4, ingredients: [{ id: B.Clay, count: 4 }, { id: 111, count: 1 }], station: 'furnace', level: 2, xp: 6, category: 'Building' },
  { id: 'sandstone', output: B.Sandstone, count: 1, ingredients: [{ id: B.Sand, count: 4 }], xp: 2, category: 'Building' },
  { id: 'sunstone', output: B.Glowstone, count: 1, ingredients: [{ id: 113, count: 1 }, { id: 111, count: 2 }], station: 'table', level: 5, xp: 10, category: 'Building' },
  { id: 'ration', output: 116, count: 2, ingredients: [{ id: 115, count: 1 }, { id: 120, count: 1 }], level: 2, xp: 4, category: 'Survival' },
  { id: 'guardian-core', output: 114, count: 1, ingredients: [{ id: 113, count: 4 }, { id: 110, count: 2 }, { id: B.Glowstone, count: 1 }], station: 'table', level: 6, xp: 40, category: 'Survival' },
];

export const levelFromXp = (xp: number) => Math.max(1, Math.floor(Math.sqrt(xp / 18)) + 1);
export const xpForLevel = (level: number) => Math.pow(level - 1, 2) * 18;

export function miningTime(blockId: number, stack?: Stack | null) {
  const block = BLOCKS[blockId];
  if (!block || !Number.isFinite(block.hardness)) return Infinity;
  const item = stack ? ITEMS[stack.id] : undefined;
  let speed = 1;
  if (item?.tool && item.tool === block.tool) speed = 2.2 + (item.tier ?? 1) * 1.8;
  if (block.tier && (!item || item.tool !== block.tool || (item.tier ?? 0) < block.tier)) return Infinity;
  return Math.max(0.12, block.hardness / speed);
}
