import * as THREE from 'three';
import { B } from './blocks';
import { randomAt } from './noise';

export const TILE_SIZE = 32;
export const ATLAS_COLS = 8;
export const ATLAS_ROWS = 8;

export type FaceKind = 'top' | 'bottom' | 'side';

export function textureKey(id: number, face: FaceKind): string {
  if (id === B.Grass) return face === 'top' ? 'grass_top' : face === 'side' ? 'grass_side' : 'dirt';
  if (id === B.Snow) return face === 'top' ? 'snow' : face === 'side' ? 'snow_side' : 'dirt';
  if (id === B.OakLog || id === B.BirchLog) {
    const prefix = id === B.OakLog ? 'oak' : 'birch';
    return face === 'side' ? `${prefix}_bark` : `${prefix}_rings`;
  }
  if (id === B.CraftingTable) return face === 'top' ? 'work_top' : face === 'side' ? 'work_side' : 'planks';
  if (id === B.Furnace) return face === 'top' ? 'furnace_top' : face === 'side' ? 'furnace_side' : 'stone';
  if (id === B.Cobblestone) return 'cobble';
  if (id === B.CoalOre) return 'coal_ore';
  if (id === B.IronOre) return 'iron_ore';
  if (id === B.OakLog) return 'oak_bark';
  if (id === B.BirchLog) return 'birch_bark';
  const names: Record<number, string> = {
    [B.Dirt]: 'dirt', [B.Stone]: 'stone', [B.Sand]: 'sand', [B.Leaves]: 'leaves',
    [B.Water]: 'water', [B.Planks]: 'planks', [B.Ice]: 'ice', [B.Cactus]: 'cactus',
    [B.Glass]: 'glass', [B.Bricks]: 'bricks', [B.Glowstone]: 'sunstone', [B.Bedrock]: 'bedrock',
    [B.Gravel]: 'gravel', [B.Clay]: 'clay', [B.BirchLeaves]: 'birch_leaves',
    [B.Sandstone]: face === 'top' ? 'sandstone_top' : 'sandstone', [B.Crystal]: 'crystal',
  };
  return names[id] ?? 'stone';
}

const PALETTES: Record<string, string> = {
  grass_top: '#729b43', grass_side: '#805b3d', dirt: '#805b3d', stone: '#858781', sand: '#d9c68b',
  oak_bark: '#715034', oak_rings: '#b28a55', leaves: '#477b38', water: '#438ac1', planks: '#b68a52',
  cobble: '#777a75', coal_ore: '#858781', iron_ore: '#858781', snow: '#e6eff0', snow_side: '#805b3d',
  ice: '#9ccbd9', cactus: '#477c40', glass: '#c5e5e5', bricks: '#a15e49', sunstone: '#e6bd62',
  work_top: '#a57343', work_side: '#93633c', furnace_top: '#70736f', furnace_side: '#676a67',
  bedrock: '#353735', gravel: '#89817c', clay: '#9ca6ae', birch_bark: '#d2c9aa', birch_rings: '#d7caa5',
  birch_leaves: '#6a963f', sandstone: '#cbb47a', sandstone_top: '#d4c18b', crystal: '#72c9c5',
};

function shade(hex: string, amount: number) {
  const n = parseInt(hex.slice(1), 16);
  const r = Math.max(0, Math.min(255, (n >> 16) + amount));
  const g = Math.max(0, Math.min(255, ((n >> 8) & 255) + amount));
  const b = Math.max(0, Math.min(255, (n & 255) + amount));
  return `rgb(${r | 0},${g | 0},${b | 0})`;
}

function paintTile(ctx: CanvasRenderingContext2D, key: string, ox: number, oy: number) {
  const base = PALETTES[key] ?? '#ff00ff';
  const seed = [...key].reduce((a, c) => a + c.charCodeAt(0) * 17, 0);
  ctx.clearRect(ox, oy, TILE_SIZE, TILE_SIZE);
  const pixel = (x: number, y: number, color: string, alpha = 1) => {
    ctx.globalAlpha = alpha; ctx.fillStyle = color; ctx.fillRect(ox + x, oy + y, 1, 1); ctx.globalAlpha = 1;
  };

  if (key === 'glass') {
    for (let i = 0; i < TILE_SIZE; i++) {
      pixel(i, 0, '#d8f0ef'); pixel(i, TILE_SIZE - 1, '#8fbfc3'); pixel(0, i, '#d8f0ef'); pixel(TILE_SIZE - 1, i, '#8fbfc3');
    }
    for (let i = 3; i < 13; i++) pixel(i, i - 1, '#e9ffff', 0.75);
    pixel(2, 2, '#ffffff'); pixel(29, 29, '#6d9da2');
    return;
  }

  for (let y = 0; y < TILE_SIZE; y++) for (let x = 0; x < TILE_SIZE; x++) {
    const r = randomAt(x, y, seed, 71);
    let delta = (r - 0.5) * (key === 'snow' ? 15 : 28);
    if ((x + y) % 7 === 0) delta -= 4;
    pixel(x, y, shade(base, delta));
  }

  if (key === 'grass_side' || key === 'snow_side') {
    const top = key === 'snow_side' ? '#e5eff0' : '#709b43';
    for (let x = 0; x < TILE_SIZE; x++) {
      const depth = 5 + Math.floor(randomAt(x, seed, 2) * 5);
      for (let y = 0; y < depth; y++) pixel(x, y, shade(top, (randomAt(x, y, seed) - 0.5) * 25));
    }
  }
  if (key === 'oak_bark' || key === 'birch_bark') {
    for (let x = 1; x < TILE_SIZE; x += 4 + Math.floor(randomAt(x, seed) * 3)) {
      for (let y = 0; y < TILE_SIZE; y++) if (randomAt(x, y, seed) > 0.18) pixel(x, y, shade(base, key === 'birch_bark' ? -55 : -28));
    }
    if (key === 'birch_bark') for (let i = 0; i < 12; i++) {
      const x = Math.floor(randomAt(i, seed) * 28), y = Math.floor(randomAt(i, seed, 3) * 32);
      for (let k = 0; k < 3; k++) pixel(x + k, y, '#5d5b52');
    }
  }
  if (key === 'oak_rings' || key === 'birch_rings') {
    ctx.strokeStyle = shade(base, -35); ctx.lineWidth = 1;
    for (let r = 4; r < 16; r += 4) { ctx.beginPath(); ctx.arc(ox + 16, oy + 16, r, 0, Math.PI * 2); ctx.stroke(); }
    pixel(16, 16, shade(base, -45));
  }
  if (key === 'planks' || key === 'work_top') {
    for (let y = 0; y < TILE_SIZE; y += 8) for (let x = 0; x < TILE_SIZE; x++) pixel(x, y, shade(base, -38));
    for (let y = 0; y < TILE_SIZE; y += 8) {
      const seam = ((y / 8) % 2) * 16;
      for (let yy = y; yy < y + 8; yy++) pixel(seam, yy, shade(base, -30));
      pixel((seam + 3) % 32, y + 3, '#66513a'); pixel((seam + 12) % 32, y + 3, '#66513a');
    }
  }
  if (key === 'cobble' || key === 'bedrock' || key === 'gravel') {
    for (let i = 0; i < 24; i++) {
      const x = Math.floor(randomAt(i, seed, 9) * 30), y = Math.floor(randomAt(i, seed, 12) * 30);
      const w = 2 + Math.floor(randomAt(i, seed, 4) * 5);
      ctx.strokeStyle = shade(base, -35); ctx.strokeRect(ox + x, oy + y, w, 2 + (i % 4));
    }
  }
  if (key === 'coal_ore' || key === 'iron_ore') {
    const ore = key === 'coal_ore' ? '#303230' : '#b7866c';
    for (let i = 0; i < 9; i++) {
      const x = 2 + Math.floor(randomAt(i, seed, 19) * 26), y = 2 + Math.floor(randomAt(i, seed, 27) * 26);
      for (let yy = 0; yy < 3; yy++) for (let xx = 0; xx < 3; xx++) if (randomAt(xx + i, yy, seed) > 0.25) pixel(x + xx, y + yy, shade(ore, (randomAt(xx, yy, i) - 0.5) * 30));
    }
  }
  if (key === 'bricks') {
    for (let y = 0; y < TILE_SIZE; y += 8) {
      for (let x = 0; x < TILE_SIZE; x++) pixel(x, y, '#c2a18a');
      const offset = (y / 8) % 2 ? 8 : 0;
      for (let x = offset; x < TILE_SIZE; x += 16) for (let yy = y; yy < y + 8; yy++) pixel(x, yy, '#c2a18a');
    }
  }
  if (key === 'sandstone') for (let y = 5; y < 32; y += 9) for (let x = 0; x < 32; x++) if (randomAt(x, y, seed) > 0.2) pixel(x, y, shade(base, -22));
  if (key === 'cactus') for (let x = 3; x < 32; x += 7) for (let y = 0; y < 32; y++) pixel(x, y, shade(base, y % 6 === 0 ? 25 : -20));
  if (key === 'ice' || key === 'crystal') {
    ctx.strokeStyle = key === 'ice' ? '#d5f0f2' : '#b6ffef'; ctx.lineWidth = 1;
    for (let i = 0; i < 5; i++) {
      const x = randomAt(i, seed) * 32, y = randomAt(i, seed, 8) * 32;
      ctx.beginPath(); ctx.moveTo(ox + x, oy + y); ctx.lineTo(ox + (x + 9) % 32, oy + (y + 13) % 32); ctx.lineTo(ox + (x + 15) % 32, oy + (y + 9) % 32); ctx.stroke();
    }
  }
  if (key === 'sunstone') for (let i = 0; i < 22; i++) {
    const x = Math.floor(randomAt(i, seed, 22) * 32), y = Math.floor(randomAt(i, seed, 33) * 32);
    pixel(x, y, i % 2 ? '#fff1a3' : '#aa763c');
  }
  if (key === 'work_top') {
    ctx.strokeStyle = '#554330'; ctx.lineWidth = 2; ctx.strokeRect(ox + 4, oy + 4, 24, 24);
    ctx.beginPath(); ctx.moveTo(ox + 16, oy + 4); ctx.lineTo(ox + 16, oy + 28); ctx.moveTo(ox + 4, oy + 16); ctx.lineTo(ox + 28, oy + 16); ctx.stroke();
  }
  if (key === 'work_side') {
    ctx.fillStyle = '#4f4132'; ctx.fillRect(ox + 5, oy + 7, 22, 3); ctx.fillRect(ox + 7, oy + 18, 4, 11); ctx.fillRect(ox + 21, oy + 18, 4, 11);
  }
  if (key === 'furnace_side' || key === 'furnace_top') {
    ctx.fillStyle = '#343735'; ctx.fillRect(ox + 6, oy + 9, 20, 16); ctx.fillStyle = '#1f2422'; ctx.fillRect(ox + 9, oy + 12, 14, 10);
    ctx.fillStyle = '#969991'; ctx.fillRect(ox + 6, oy + 6, 20, 2);
  }
  if (key === 'leaves' || key === 'birch_leaves') {
    for (let i = 0; i < 20; i++) {
      const x = Math.floor(randomAt(i, seed, 18) * 32), y = Math.floor(randomAt(i, seed, 29) * 32);
      if (i % 5 === 0) ctx.clearRect(ox + x, oy + y, 1, 1); else pixel(x, y, shade(base, i % 2 ? 25 : -35));
    }
  }
}

export type Atlas = { texture: THREE.CanvasTexture; tiles: Map<string, number>; canvas: HTMLCanvasElement };

export function createAtlas(): Atlas {
  const keys = new Set<string>();
  for (let id = 1; id <= B.Crystal; id++) {
    if (id === B.Water) continue;
    keys.add(textureKey(id, 'top')); keys.add(textureKey(id, 'bottom')); keys.add(textureKey(id, 'side'));
  }
  const tiles = new Map<string, number>();
  [...keys].forEach((key, i) => tiles.set(key, i));
  const canvas = document.createElement('canvas'); canvas.width = ATLAS_COLS * TILE_SIZE; canvas.height = ATLAS_ROWS * TILE_SIZE;
  const ctx = canvas.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;
  tiles.forEach((index, key) => paintTile(ctx, key, (index % ATLAS_COLS) * TILE_SIZE, Math.floor(index / ATLAS_COLS) * TILE_SIZE));
  const texture = new THREE.CanvasTexture(canvas);
  texture.magFilter = THREE.NearestFilter; texture.minFilter = THREE.NearestMipmapLinearFilter;
  texture.colorSpace = THREE.SRGBColorSpace; texture.anisotropy = 4;
  return { texture, tiles, canvas };
}

export function tileUV(tiles: Map<string, number>, key: string) {
  const index = tiles.get(key) ?? 0;
  const col = index % ATLAS_COLS, row = Math.floor(index / ATLAS_COLS);
  const inset = 0.035;
  return {
    u0: (col + inset) / ATLAS_COLS, u1: (col + 1 - inset) / ATLAS_COLS,
    v0: 1 - (row + 1 - inset) / ATLAS_ROWS, v1: 1 - (row + inset) / ATLAS_ROWS,
  };
}

export function createVoxelMaterials(atlas: Atlas) {
  const solid = new THREE.MeshStandardMaterial({ map: atlas.texture, vertexColors: true, roughness: 0.92, metalness: 0, alphaTest: 0.42 });
  const glow = new THREE.MeshStandardMaterial({ map: atlas.texture, emissiveMap: atlas.texture, emissive: new THREE.Color('#ffffff'), emissiveIntensity: 0.38, vertexColors: true, roughness: 0.72 });
  const water = new THREE.MeshStandardMaterial({ color: '#3889c2', transparent: true, opacity: 0.64, roughness: 0.2, metalness: 0.05, depthWrite: false, side: THREE.DoubleSide });
  water.onBeforeCompile = shader => {
    shader.uniforms.waterTime = { value: 0 };
    shader.vertexShader = `uniform float waterTime;\n${shader.vertexShader}`.replace('#include <begin_vertex>', `#include <begin_vertex>\nfloat waterWave = sin(position.x * 1.4 + waterTime * 1.7) * cos(position.z * 1.2 + waterTime * 1.2) * 0.035;\ntransformed.y += waterWave * step(0.5, normal.y);`);
    water.userData.shader = shader;
  };
  return { solid, glow, water };
}
