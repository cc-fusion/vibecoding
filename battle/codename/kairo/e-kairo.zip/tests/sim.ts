/* Headless verification of the simulation core (no WebGL needed). */
import * as THREE from 'three';
import { WorldGen } from '../src/game/worldgen';
import { World } from '../src/game/world';
import { buildChunkMesh } from '../src/game/mesher';
import { moveEntity, raycastVoxel } from '../src/game/physics';
import { Inventory } from '../src/game/inventory';
import { matchRecipe, RECIPES, recipeIngredients } from '../src/game/recipes';
import { B, BLOCKS, ITEMS, breakTime, blockDrop, canHarvest, SMELTING } from '../src/game/blocks';
import { CX, CZ, WORLD_H, SEA_LEVEL, idx } from '../src/game/constants';

let failures = 0;
let checks = 0;
function ok(cond: boolean, label: string, extra = '') {
  checks++;
  if (!cond) { failures++; console.log(`  ✗ ${label} ${extra}`); }
  else console.log(`  ✓ ${label}${extra ? ' — ' + extra : ''}`);
}

console.log('\n== world generation ==');
const gen = new WorldGen(1337);
const t0 = Date.now();
const N = 24;
const biomeSeen = new Set<number>();
let minH = 999, maxH = -1, water = 0, ores = 0, trees = 0, caves = 0;
for (let i = 0; i < N; i++) {
  const cx = (i % 6) - 3, cz = Math.floor(i / 6) - 2;
  const r = gen.generateChunk(cx * 3, cz * 3);
  for (const b of r.biome) biomeSeen.add(b);
  for (const h of r.height) { minH = Math.min(minH, h); maxH = Math.max(maxH, h); }
  for (let k = 0; k < r.data.length; k++) {
    const id = r.data[k];
    if (id === B.WATER) water++;
    if (id === B.COAL_ORE || id === B.IRON_ORE || id === B.DIAMOND_ORE || id === B.GOLD_ORE) ores++;
    if (id === B.OAK_LOG || id === B.BIRCH_LOG) trees++;
  }
  for (let x = 0; x < CX; x++) for (let z = 0; z < CZ; z++) {
    const h = r.height[x + z * CX];
    for (let y = 5; y < h - 3; y++) if (r.data[idx(x, y, z)] === 0) caves++;
  }
}
const genMs = (Date.now() - t0) / N;
ok(biomeSeen.size >= 5, 'biome variety', `${biomeSeen.size} biomes: ${[...biomeSeen].join(',')}`);
ok(minH >= 4 && maxH < WORLD_H - 10, 'height range sane', `${minH}..${maxH}`);
ok(water > 0, 'oceans generate', `${water} water blocks`);
ok(ores > 40, 'ore veins generate', `${ores} ore blocks`);
ok(trees > 20, 'trees generate', `${trees} logs`);
ok(caves > 1000, 'caves carve out', `${caves} air pockets underground`);
ok(genMs < 40, 'chunk generation is fast', `${genMs.toFixed(1)} ms/chunk`);

const a = gen.generateChunk(2, 2), b2 = gen.generateChunk(2, 2);
let same = true;
for (let i = 0; i < a.data.length; i++) if (a.data[i] !== b2.data[i]) { same = false; break; }
ok(same, 'generation is deterministic');
const other = new WorldGen(999).generateChunk(2, 2);
let diff = 0;
for (let i = 0; i < a.data.length; i++) if (a.data[i] !== other.data[i]) diff++;
ok(diff > 1000, 'different seeds give different worlds', `${diff} blocks differ`);
const spawn = gen.findSpawn();
ok(spawn.y > SEA_LEVEL && spawn.y < WORLD_H, 'spawn is on dry land', `y=${spawn.y.toFixed(1)}`);

console.log('\n== meshing ==');
const world = new World(1337);
for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) world.ensure(dx, dz);
const t1 = Date.now();
let tris = 0, waterTris = 0, crossTris = 0, meshes = 0;
for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
  const c = world.get(dx, dz)!;
  const res = buildChunkMesh(c.data, world.neighbors(dx, dz), dx, dz, world.lightsNear(dx, dz), c.tint, c.topY);
  for (const key of ['solid', 'cross', 'water'] as const) {
    const m = res[key];
    if (!m) continue;
    meshes++;
    const verts = m.position.length / 3;
    if (key === 'solid') tris += m.index.length / 3;
    if (key === 'water') waterTris += m.index.length / 3;
    if (key === 'cross') crossTris += m.index.length / 3;
    let bad = 0, badIdx = 0, badUV = 0, badCol = 0;
    for (let i = 0; i < m.position.length; i++) if (!Number.isFinite(m.position[i])) bad++;
    for (let i = 0; i < m.index.length; i++) if (m.index[i] >= verts) badIdx++;
    for (let i = 0; i < m.uv.length; i++) if (m.uv[i] < -0.001 || m.uv[i] > 1.001) badUV++;
    if (m.color.length !== verts * 3) badCol++;
    if (m.light.length !== verts * 2) badCol++;
    ok(bad === 0 && badIdx === 0 && badUV === 0 && badCol === 0,
      `chunk ${dx},${dz} ${key} buffers valid`, `${verts} verts`);
  }
}
const meshMs = (Date.now() - t1) / 9;
ok(tris > 5000, 'solid geometry produced', `${tris} triangles over 9 chunks`);
ok(crossTris > 0 || waterTris > 0, 'transparent layers produced', `water ${waterTris}, cross ${crossTris}`);
ok(meshMs < 20, 'meshing is fast enough to stream', `${meshMs.toFixed(1)} ms/chunk`);

// torch lighting changes the mesh
const before = buildChunkMesh(world.get(0, 0)!.data, world.neighbors(0, 0), 0, 0, [], world.get(0, 0)!.tint, world.get(0, 0)!.topY);
const sy = world.surfaceY(0, 0);
world.setBlock(0, sy + 1, 0, B.TORCH);
const after = buildChunkMesh(world.get(0, 0)!.data, world.neighbors(0, 0), 0, 0, world.lightsNear(0, 0), world.get(0, 0)!.tint, world.get(0, 0)!.topY);
let litBefore = 0, litAfter = 0;
for (let i = 1; i < before.solid!.light.length; i += 2) litBefore += before.solid!.light[i];
for (let i = 1; i < after.solid!.light.length; i += 2) litAfter += after.solid!.light[i];
ok(litAfter > litBefore, 'placing a torch brightens nearby vertices', `${litBefore} -> ${litAfter}`);
ok(world.dirty.size >= 1, 'edits mark chunks dirty', `${world.dirty.size} dirty`);

console.log('\n== physics ==');
// use a column with no torch on it (torches are non-solid and raise surfaceY)
const pos = new THREE.Vector3(8.5, world.surfaceY(8, 8) + 6, 8.5);
const vel = new THREE.Vector3();
let grounded = false;
for (let i = 0; i < 240; i++) {
  vel.y -= 28 / 60;
  const r = moveEntity(world, pos, vel, 0.3, 1.8, 1 / 60);
  if (r.onGround) { grounded = true; break; }
}
const ground = world.surfaceY(8, 8);
ok(grounded, 'player lands on terrain');
ok(Math.abs(pos.y - (ground + 1)) < 0.1, 'player rests on the surface', `y=${pos.y.toFixed(3)} expected ${ground + 1}`);

// walking into a wall must not tunnel
world.setBlock(10, ground + 1, 8, B.STONE);
world.setBlock(10, ground + 2, 8, B.STONE);
const p2 = new THREE.Vector3(8.5, ground + 1, 8.5);
const v2 = new THREE.Vector3();
for (let i = 0; i < 120; i++) {
  v2.x = 8;
  v2.y -= 28 / 60;
  moveEntity(world, p2, v2, 0.3, 1.8, 1 / 60);
}
ok(p2.x < 9.75, 'horizontal collision stops the player at the wall', `x=${p2.x.toFixed(3)}`);

// jumping clears one block
const p3 = new THREE.Vector3(5.5, world.surfaceY(5, 5) + 1, 5.5);
const v3 = new THREE.Vector3(0, 8.7, 0);
let peak = p3.y;
for (let i = 0; i < 90; i++) {
  v3.y -= 28 / 60;
  moveEntity(world, p3, v3, 0.3, 1.8, 1 / 60);
  peak = Math.max(peak, p3.y);
}
ok(peak - (world.surfaceY(5, 5) + 1) > 1.0, 'jump height clears a full block', `${(peak - world.surfaceY(5, 5) - 1).toFixed(2)} blocks`);

// raycast hits the block we look at
const eye = new THREE.Vector3(0.5, ground + 3.5, 0.5);
const hit = raycastVoxel(world, eye, new THREE.Vector3(0, -1, 0), 8);
ok(!!hit && hit.ny === 1, 'downward raycast finds the top face', hit ? `block ${BLOCKS[hit.id].name} at y=${hit.y}` : 'miss');

console.log('\n== inventory + crafting ==');
const inv = new Inventory();
ok(inv.add(B.OAK_LOG, 10) === 0, 'add items');
ok(inv.count(B.OAK_LOG) === 10, 'count items');
inv.add(B.OAK_LOG, 100);
ok(inv.count(B.OAK_LOG) === 110, 'stacking across slots', `${inv.slots.filter(Boolean).length} slots used`);
ok(inv.remove(B.OAK_LOG, 105) && inv.count(B.OAK_LOG) === 5, 'remove items');
ok(!inv.remove(B.OAK_LOG, 999), 'cannot remove more than held');
const full = new Inventory();
for (let i = 0; i < 36; i++) full.slots[i] = { id: B.STONE, count: 64 };
ok(full.add(B.DIRT, 5) === 5, 'overflow is reported when full');

const grid = (arr: (number | null)[]) => arr.map((id) => (id == null ? null : { id, count: 1 }));
const planks = matchRecipe(grid([B.OAK_LOG, null, null, null]), 2);
ok(!!planks && planks.out.id === B.PLANKS && planks.out.count === 4, 'shapeless log -> planks');
const table = matchRecipe(grid([B.PLANKS, B.PLANKS, B.PLANKS, B.PLANKS]), 2);
ok(!!table && table.out.id === B.CRAFTING_TABLE, '2x2 planks -> crafting table');
const pick = matchRecipe(grid([B.COBBLE, B.COBBLE, B.COBBLE, null, 100, null, null, 100, null]), 3);
ok(!!pick && pick.out.id === 124, 'stone pickaxe pattern', pick ? ITEMS[pick.out.id].name : 'none');
const mirrored = matchRecipe(grid([B.COBBLE, B.COBBLE, null, 100, B.COBBLE, null, 100, null, null]), 3);
ok(!!mirrored && mirrored.out.id === 125, 'mirrored axe pattern matches');
const torch = matchRecipe(grid([101, null, 100, null]), 2);
ok(!!torch && torch.out.id === B.TORCH && torch.out.count === 4, 'coal + stick -> 4 torches');
const nope = matchRecipe(grid([B.DIRT, B.SAND, null, null]), 2);
ok(nope === null, 'invalid pattern yields no recipe');
let allRecipesValid = true;
for (const r of RECIPES) {
  for (const ing of recipeIngredients(r)) if (!ITEMS[ing.id]) { allRecipesValid = false; console.log('   bad ingredient', r.key, ing.id); }
  if (!ITEMS[r.out.id]) { allRecipesValid = false; console.log('   bad output', r.key); }
}
ok(allRecipesValid, `all ${RECIPES.length} recipes reference real items`);
ok(Object.keys(SMELTING).every((k) => ITEMS[SMELTING[Number(k)]]), 'all smelting outputs exist');

console.log('\n== mining rules ==');
ok(breakTime(B.STONE, undefined, false) > breakTime(B.STONE, 124, false), 'pickaxe speeds up stone');
ok(breakTime(B.STONE, 124, true) === 0, 'creative breaks instantly');
ok(!canHarvest(B.DIAMOND_ORE, 124), 'stone pick cannot harvest diamond');
ok(canHarvest(B.DIAMOND_ORE, 128), 'iron pick harvests diamond');
ok(blockDrop(B.STONE, 120, 0.5)?.id === B.COBBLE, 'stone drops cobblestone');
ok(blockDrop(B.DIAMOND_ORE, 124, 0.5) === null, 'wrong tool drops nothing');
ok(blockDrop(B.OAK_LEAVES, undefined, 0.01)?.id === 106, 'leaves can drop apples');
ok(breakTime(B.BEDROCK, 132, false) === Infinity, 'bedrock is unbreakable');

console.log('\n== persistence ==');
world.setBlock(3, 40, 3, B.GLOWSTONE);
world.setBlock(4, 40, 3, B.PLANKS);
const edits = world.serializeEdits();
const restored = new World(1337);
restored.loadEdits(edits);
restored.ensure(0, 0);
ok(restored.getBlock(3, 40, 3) === B.GLOWSTONE && restored.getBlock(4, 40, 3) === B.PLANKS, 'edits survive a save/load round trip');
ok(restored.get(0, 0)!.lights.size > 0, 'light index rebuilt after load');
const json = JSON.stringify(edits);
ok(json.length < 100000, 'save payload is compact', `${json.length} bytes for ${world.editCount} edits`);

console.log('\n== streaming stress ==');
const streamWorld = new World(4242);
const t2 = Date.now();
let count = 0;
for (let dx = -4; dx <= 4; dx++) for (let dz = -4; dz <= 4; dz++) {
  streamWorld.ensure(dx, dz);
  count++;
}
for (let dx = -3; dx <= 3; dx++) for (let dz = -3; dz <= 3; dz++) {
  const c = streamWorld.get(dx, dz)!;
  buildChunkMesh(c.data, streamWorld.neighbors(dx, dz), dx, dz, streamWorld.lightsNear(dx, dz), c.tint, c.topY);
}
const totalMs = Date.now() - t2;
ok(totalMs < 6000, `81 chunk gen + 49 meshes complete`, `${totalMs} ms total`);
ok(streamWorld.chunks.size === count, 'chunk map is consistent', `${streamWorld.chunks.size} chunks`);

// repeated edits + remeshes must not corrupt state
const c0 = streamWorld.get(0, 0)!;
for (let i = 0; i < 300; i++) {
  const x = i % 16, z = (i * 7) % 16, y = 50 + (i % 20);
  streamWorld.setBlock(x, y, z, i % 2 ? B.STONE : 0);
  if (i % 25 === 0) buildChunkMesh(c0.data, streamWorld.neighbors(0, 0), 0, 0, streamWorld.lightsNear(0, 0), c0.tint, c0.topY);
}
ok(true, '300 block edits + 12 remeshes without errors');

console.log(`\n${failures === 0 ? '✅' : '❌'} ${checks - failures}/${checks} checks passed\n`);
process.exit(failures === 0 ? 0 : 1);
