import { World } from '../src/game/world';
import { buildChunkMesh, meshTiming } from '../src/game/mesher';
const w = new World(1337);
for (let dx = -4; dx <= 4; dx++) for (let dz = -4; dz <= 4; dz++) w.ensure(dx, dz);
const t = Date.now();
for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) {
  const c = w.get(dx, dz)!;
  buildChunkMesh(c.data, w.neighbors(dx, dz), dx, dz, w.lightsNear(dx, dz), c.tint, c.topY);
}
const n = meshTiming.calls;
console.log('total ms/chunk', ((Date.now() - t) / n).toFixed(1));
console.log('fill', (meshTiming.fill / n).toFixed(2), 'sky', (meshTiming.sky / n).toFixed(2), 'torch', (meshTiming.torch / n).toFixed(2), 'faces', (meshTiming.faces / n).toFixed(2));
console.log('topY sample', w.get(0,0)!.topY);
