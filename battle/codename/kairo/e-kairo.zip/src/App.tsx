import { useEffect, useRef, useState } from 'react';
import { Engine } from './game/engine';
import { uiStore, initSettings } from './game/store';
import { engineRef, useUI } from './ui/common';
import { Hud } from './ui/Hud';
import { InventoryScreen } from './ui/Inventory';
import { TitleScreen, LoadingScreen, SettingsPanel, AchievementsPanel, PauseMenu, DeathScreen } from './ui/Screens';
import { TouchControls } from './ui/TouchControls';

const IS_TOUCH = typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches;

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const ui = useUI();
  const [error, setError] = useState<string | null>(null);
  const [booted, setBooted] = useState(false);

  useEffect(() => {
    initSettings();
    const canvas = canvasRef.current;
    if (!canvas) return;
    let engine: Engine | null = null;
    try {
      engine = new Engine(canvas, uiStore.get().settings);
      engineRef.current = engine;
      engine.startPreview();
      setBooted(true);
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : String(err));
    }
    const onUnload = () => engineRef.current?.save();
    window.addEventListener('beforeunload', onUnload);
    return () => {
      window.removeEventListener('beforeunload', onUnload);
      engine?.dispose();
      engineRef.current = null;
    };
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const s = uiStore.get();
      if (e.code !== 'Escape') return;
      if (s.screen !== 'game') {
        if (s.overlay) uiStore.set({ overlay: null });
        else if (s.screen === 'worlds' || s.screen === 'create') uiStore.set({ screen: 'title' });
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const inGame = ui.screen === 'game';
  const showInventory = inGame && (ui.overlay === 'inventory' || ui.overlay === 'crafting' || ui.overlay === 'furnace');
  const showPause = inGame && ui.overlay === 'pause';
  const showSettings = ui.overlay === 'settings';
  const showAchievements = ui.overlay === 'achievements';

  const closeToGame = () => {
    if (uiStore.get().screen === 'game') engineRef.current?.setOverlay(null);
    else uiStore.set({ overlay: null });
  };

  return (
    <div className="relative h-full w-full overflow-hidden bg-void">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />

      {!booted && !error && (
        <div className="absolute inset-0 grid place-items-center bg-void">
          <div className="font-display text-[12px] tracking-widest text-grass anim-pulse">BOOTING VOXEL ENGINE…</div>
        </div>
      )}

      {error && (
        <div className="absolute inset-0 grid place-items-center bg-void p-8">
          <div className="panel max-w-[520px] p-6">
            <h2 className="font-display text-[14px] text-redstone">WEBGL UNAVAILABLE</h2>
            <p className="mt-3 text-[13px] leading-relaxed text-parch/70">
              This game needs a WebGL2-capable browser with hardware acceleration enabled.
            </p>
            <pre className="mt-3 overflow-auto border-2 border-black/60 bg-black/50 p-3 text-[11px] text-parch/40">{error}</pre>
          </div>
        </div>
      )}

      {(ui.screen === 'title' || ui.screen === 'worlds' || ui.screen === 'create') && <TitleScreen />}
      {ui.screen === 'loading' && <LoadingScreen />}
      {inGame && <Hud />}
      {inGame && IS_TOUCH && <TouchControls />}
      {showInventory && <InventoryScreen />}
      {ui.screen === 'dead' && <DeathScreen />}

      {(showPause || showSettings || showAchievements) && (
        <div className="pointer-events-auto absolute inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-[3px]">
          {showSettings ? (
            <SettingsPanel
              onClose={() => {
                if (uiStore.get().screen === 'game') uiStore.set({ overlay: 'pause' });
                else uiStore.set({ overlay: null });
              }}
            />
          ) : showAchievements ? (
            <AchievementsPanel onClose={closeToGame} />
          ) : (
            <PauseMenu />
          )}
        </div>
      )}

      {/* click-to-lock prompt */}
      {inGame && !ui.overlay && !ui.pointerLocked && !IS_TOUCH && (
        <div
          className="pointer-events-auto absolute inset-0 z-20 grid place-items-center bg-black/45"
          onClick={() => engineRef.current?.lockPointer()}
        >
          <div className="panel anim-up px-8 py-6 text-center">
            <div className="font-display text-[14px] text-torch">CLICK TO PLAY</div>
            <div className="mt-2 text-[12px] text-parch/55">Mouse look will be captured. Press ESC to release.</div>
          </div>
        </div>
      )}
    </div>
  );
}
