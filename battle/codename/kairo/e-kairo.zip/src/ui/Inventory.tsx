import { useEffect, useMemo, useRef, useState } from 'react';
import { useUI, Slot, engineRef, Btn, ItemTooltip } from './common';
import { ITEMS, getItem, SMELTING, BLOCKS } from '../game/blocks';
import { RECIPES, recipeIngredients, recipeSize } from '../game/recipes';
import { itemIcon } from '../game/textures';

function CursorStack() {
  const ui = useUI();
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const move = (e: MouseEvent) => {
      if (ref.current) {
        ref.current.style.left = `${e.clientX}px`;
        ref.current.style.top = `${e.clientY}px`;
      }
    };
    window.addEventListener('mousemove', move);
    return () => window.removeEventListener('mousemove', move);
  }, []);
  if (!ui.inv.cursor) return null;
  return (
    <div ref={ref} className="pointer-events-none fixed z-[200] -translate-x-1/2 -translate-y-1/2" style={{ left: -100, top: -100 }}>
      <img src={itemIcon(ui.inv.cursor.id)} className="pixelated h-10 w-10 drop-shadow-[2px_3px_2px_rgba(0,0,0,0.7)]" alt="" />
      {ui.inv.cursor.count > 1 && (
        <span className="absolute -bottom-1 right-0 font-display text-[12px] text-white drop-shadow-[2px_2px_0_#000]">
          {ui.inv.cursor.count}
        </span>
      )}
    </div>
  );
}

function Avatar() {
  return (
    <svg viewBox="0 0 16 32" className="h-[104px] w-[52px] drop-shadow-[2px_3px_0_rgba(0,0,0,0.5)]">
      <rect x="4" y="2" width="8" height="8" fill="#d9a273" />
      <rect x="4" y="2" width="8" height="3" fill="#4a3524" />
      <rect x="5" y="5" width="2" height="2" fill="#20304a" />
      <rect x="9" y="5" width="2" height="2" fill="#20304a" />
      <rect x="6" y="8" width="4" height="1" fill="#a9744c" />
      <rect x="4" y="10" width="8" height="10" fill="#2f9c8f" />
      <rect x="1" y="10" width="3" height="9" fill="#d9a273" />
      <rect x="12" y="10" width="3" height="9" fill="#d9a273" />
      <rect x="4" y="20" width="3.5" height="10" fill="#3a4a8f" />
      <rect x="8.5" y="20" width="3.5" height="10" fill="#33417d" />
      <rect x="4" y="29" width="3.5" height="2" fill="#4a3524" />
      <rect x="8.5" y="29" width="3.5" height="2" fill="#4a3524" />
    </svg>
  );
}

function RecipeBook({ creative }: { creative: boolean }) {
  const ui = useUI();
  const [q, setQ] = useState('');
  const [tab, setTab] = useState<'all' | 'building' | 'tools' | 'misc' | 'blocks'>('all');
  const counts = useMemo(() => {
    const m = new Map<number, number>();
    for (const s of ui.inv.slots) if (s) m.set(s.id, (m.get(s.id) ?? 0) + s.count);
    return m;
  }, [ui.inv.slots]);

  const palette = useMemo(() => {
    if (!creative) return [];
    return ITEMS.filter((it) => it && it.name.toLowerCase().includes(q.toLowerCase()));
  }, [creative, q]);

  const recipes = useMemo(() => {
    return RECIPES.filter((r) => {
      if (tab !== 'all' && tab !== 'blocks' && r.category !== tab) return false;
      const name = getItem(r.out.id).name.toLowerCase();
      return name.includes(q.toLowerCase());
    }).map((r) => {
      const ings = recipeIngredients(r);
      const can = ings.every((i) => (counts.get(i.id) ?? 0) >= i.count);
      return { r, ings, can };
    }).sort((a, b) => Number(b.can) - Number(a.can));
  }, [q, tab, counts]);

  return (
    <div className="flex h-full w-[268px] flex-col gap-2">
      <div className="flex items-center gap-2">
        <input
          type="text"
          value={q}
          placeholder={creative ? 'Search items…' : 'Search recipes…'}
          className="w-full text-[12px]"
          onChange={(e) => setQ(e.target.value)}
        />
      </div>
      <div className="flex flex-wrap gap-1">
        {(creative ? (['blocks'] as const) : (['all', 'tools', 'building', 'misc'] as const)).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`border-2 px-2 py-1 font-display text-[9px] uppercase transition ${
              tab === t ? 'border-grass bg-grass/20 text-grass' : 'border-black/60 bg-black/30 text-parch/50 hover:text-parch'
            }`}
          >
            {t}
          </button>
        ))}
      </div>
      <div className="scroller flex-1 overflow-y-auto pr-1" style={{ maxHeight: 330 }}>
        {creative ? (
          <div className="grid grid-cols-6 gap-1">
            {palette.map((it) => (
              <div key={it.id} className="group relative">
                <Slot
                  stack={{ id: it.id, count: 1 }}
                  small
                  onClick={() => engineRef.current?.creativeGive(it.id, getItem(it.id).stack === 1 ? 1 : 64)}
                />
              </div>
            ))}
            {palette.length === 0 && <div className="col-span-6 py-6 text-center text-[12px] text-parch/40">No items found</div>}
          </div>
        ) : (
          <div className="flex flex-col gap-1">
            {recipes.map(({ r, ings, can }) => (
              <button
                key={r.key}
                onClick={(e) => engineRef.current?.quickCraft(r.key, e.shiftKey)}
                disabled={!can}
                className={`flex items-center gap-2 border-2 px-2 py-1.5 text-left transition ${
                  can ? 'border-black/60 bg-black/25 hover:border-grass/70 hover:bg-grass/10' : 'border-black/40 bg-black/15 opacity-45'
                }`}
              >
                <img src={itemIcon(r.out.id)} className="pixelated h-8 w-8" alt="" />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[12px] text-parch/90">
                    {getItem(r.out.id).name}
                    {r.out.count > 1 && <span className="text-parch/45"> ×{r.out.count}</span>}
                  </div>
                  <div className="flex items-center gap-1">
                    {ings.map((i) => (
                      <span key={i.id} className="flex items-center gap-[2px] text-[10px] text-parch/50">
                        <img src={itemIcon(i.id)} className="pixelated h-4 w-4" alt="" />
                        {i.count}
                      </span>
                    ))}
                    <span className="ml-auto font-display text-[8px] text-parch/30">{recipeSize(r)}×{recipeSize(r)}</span>
                  </div>
                </div>
              </button>
            ))}
            {recipes.length === 0 && <div className="py-6 text-center text-[12px] text-parch/40">No recipes found</div>}
          </div>
        )}
      </div>
      <div className="text-[10px] leading-snug text-parch/35">
        {creative ? 'Click to add a stack to your inventory.' : 'Click to craft · Shift-click to craft as many as possible.'}
      </div>
    </div>
  );
}

function FurnacePanel() {
  const ui = useUI();
  const f = ui.furnace;
  if (!f) return null;
  const cookPct = Math.min(100, (f.cook / 7) * 100);
  const burnPct = f.burnMax > 0 ? Math.max(0, (f.burn / f.burnMax) * 100) : 0;
  const preview = f.input ? SMELTING[f.input.id] : undefined;
  return (
    <div className="flex items-center justify-center gap-5 py-4">
      <div className="flex flex-col items-center gap-2">
        <Slot stack={f.input} onClick={(b, s) => engineRef.current?.clickFurnace('input', b, s)} label="IN" />
        <div className="relative h-7 w-6">
          <div className="absolute inset-0 opacity-30">🔥</div>
          <div className="absolute bottom-0 left-0 right-0 overflow-hidden" style={{ height: `${burnPct}%` }}>
            <div className="h-7 w-6 text-center text-[18px] leading-7">🔥</div>
          </div>
        </div>
        <Slot stack={f.fuel} onClick={(b, s) => engineRef.current?.clickFurnace('fuel', b, s)} label="FUEL" />
      </div>
      <div className="flex flex-col items-center gap-1">
        <div className="relative h-4 w-24 border-2 border-black/70 bg-black/50">
          <div className="h-full bg-gradient-to-r from-torch to-gold transition-[width] duration-150" style={{ width: `${cookPct}%` }} />
        </div>
        <span className="font-display text-[9px] text-parch/40">SMELTING</span>
        {preview != null && (
          <img src={itemIcon(preview)} className="pixelated mt-1 h-6 w-6 opacity-40" alt="" />
        )}
      </div>
      <Slot stack={f.output} onClick={(b, s) => engineRef.current?.clickFurnace('output', b, s)} label="OUT" />
    </div>
  );
}

export function InventoryScreen() {
  const ui = useUI();
  const e = engineRef.current;
  const crafting = ui.overlay === 'crafting';
  const furnace = ui.overlay === 'furnace';
  const creative = ui.mode === 'creative';
  const size = crafting ? 3 : 2;
  if (!e) return null;

  const craftIndex = (x: number, y: number) => y * 3 + x;

  return (
    <div className="pointer-events-auto absolute inset-0 z-40 flex items-center justify-center bg-black/62 backdrop-blur-[3px]">
      <div className="anim-up panel flex max-h-[94vh] gap-5 overflow-hidden p-5">
        <div className="flex flex-col">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-display text-[15px] tracking-wide text-torch">
              {furnace ? 'FURNACE' : crafting ? 'CRAFTING TABLE' : 'INVENTORY'}
            </h2>
            <button className="font-display text-[12px] text-parch/50 hover:text-redstone" onClick={() => e.setOverlay(null)}>
              ✕
            </button>
          </div>

          {furnace ? (
            <FurnacePanel />
          ) : (
            <div className="mb-4 flex items-center gap-5">
              {!crafting && (
                <div className="flex h-[124px] w-[92px] items-center justify-center border-2 border-black/60 bg-black/35">
                  <Avatar />
                </div>
              )}
              <div className="flex items-center gap-3">
                <div className="grid gap-1" style={{ gridTemplateColumns: `repeat(${size}, auto)` }}>
                  {Array.from({ length: size * size }, (_, i) => {
                    const x = i % size, y = Math.floor(i / size);
                    const idx = craftIndex(x, y);
                    return (
                      <Slot
                        key={i}
                        stack={ui.inv.craft[idx]}
                        onClick={(b, s) => e.clickSlot('craft', idx, b, s)}
                      />
                    );
                  })}
                </div>
                <div className="font-display text-[20px] text-parch/40">➜</div>
                <div className="relative">
                  <Slot stack={ui.inv.result} onClick={(b, s) => e.clickSlot('result', 0, b, s)} />
                  {ui.inv.result && (
                    <div className="absolute -inset-1 -z-10 animate-pulse rounded-sm bg-grass/25 blur-[6px]" />
                  )}
                </div>
              </div>
            </div>
          )}

          <div className="mb-2 font-display text-[10px] text-parch/40">STORAGE</div>
          <div className="grid grid-cols-9 gap-1">
            {ui.inv.slots.slice(9).map((s, i) => (
              <Slot key={i} stack={s} onClick={(b, sh) => e.clickSlot('inv', i + 9, b, sh)} />
            ))}
          </div>
          <div className="mt-3 grid grid-cols-9 gap-1">
            {ui.inv.slots.slice(0, 9).map((s, i) => (
              <Slot key={i} stack={s} active={i === ui.inv.selected} onClick={(b, sh) => e.clickSlot('inv', i, b, sh)} />
            ))}
          </div>
          <div className="mt-3 flex items-center justify-between text-[10px] text-parch/35">
            <span>Left-click move · Right-click split · Shift-click quick move</span>
            <span className="font-display">E / ESC to close</span>
          </div>
        </div>

        <div className="w-[1px] bg-black/50" />
        <RecipeBook creative={creative && !furnace} />
      </div>
      <CursorStack />
    </div>
  );
}

export function CursorOnly() {
  return <CursorStack />;
}

export const inventoryHelpers = { BLOCKS, ItemTooltip, Btn };
