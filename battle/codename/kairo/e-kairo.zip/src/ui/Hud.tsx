import { useEffect, useState } from 'react';
import { useHud, useUI, Slot, engineRef } from './common';
import { itemIcon } from '../game/textures';
import { getItem } from '../game/blocks';

const HEART = ['0110110', '1111111', '1111111', '0111110', '0011100', '0001000'];

function PixelIcon({ map, color, half, empty }: { map: string[]; color: string; half?: boolean; empty?: boolean }) {
  const w = map[0].length, h = map.length;
  return (
    <svg width={w * 2.2} height={h * 2.2} viewBox={`0 0 ${w} ${h}`} className="drop-shadow-[1px_1px_0_rgba(0,0,0,0.9)]">
      {map.map((row, y) =>
        row.split('').map((c, x) => {
          if (c !== '1') return null;
          const dim = empty || (half && x >= w / 2);
          return <rect key={`${x}-${y}`} x={x} y={y} width="1" height="1" fill={dim ? '#2b1113' : color} />;
        }),
      )}
      {!empty && <rect x={1} y={1} width="1" height="1" fill="rgba(255,255,255,0.55)" />}
    </svg>
  );
}

const FOOD = ['0011100', '0111110', '1111111', '0111110', '0011100', '0011000'];

function Bar({ value, max, color, icon }: { value: number; max: number; color: string; icon: string[] }) {
  const n = 10;
  return (
    <div className="flex gap-[2px]">
      {Array.from({ length: n }, (_, i) => {
        const v = value / max * n - i;
        return <PixelIcon key={i} map={icon} color={color} half={v > 0 && v < 1} empty={v <= 0} />;
      })}
    </div>
  );
}

function Clock({ time, day }: { time: number; day: number }) {
  const angle = time * 360 - 90;
  const isDay = time < 0.5;
  const hours = Math.floor(((time * 24) + 6) % 24);
  const mins = Math.floor((((time * 24) + 6) % 1) * 60);
  return (
    <div className="glass flex items-center gap-3 rounded-sm px-3 py-2">
      <div className="relative h-9 w-9 overflow-hidden rounded-full border-2 border-black/70"
        style={{ background: isDay ? 'linear-gradient(180deg,#7fc4f2,#2f74d0)' : 'linear-gradient(180deg,#1a2242,#070b18)' }}>
        <div className="absolute inset-0" style={{ transform: `rotate(${angle}deg)` }}>
          <div className="absolute left-1/2 top-[2px] h-3 w-3 -translate-x-1/2 rounded-full"
            style={{ background: isDay ? '#ffd85e' : '#e8eeff', boxShadow: `0 0 8px ${isDay ? '#ffb545' : '#9fb6ff'}` }} />
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-[38%] bg-black/45" />
      </div>
      <div className="leading-tight">
        <div className="font-display text-[11px] text-torch">DAY {day}</div>
        <div className="text-[11px] tabular-nums text-parch/70">
          {String(hours).padStart(2, '0')}:{String(mins).padStart(2, '0')}
        </div>
      </div>
    </div>
  );
}

export function Hud() {
  const hud = useHud();
  const ui = useUI();
  const [muted, setMuted] = useState(false);
  const [showHint, setShowHint] = useState(true);
  const [hurtKey, setHurtKey] = useState(0);

  useEffect(() => {
    const t = setTimeout(() => setShowHint(false), 22000);
    return () => clearTimeout(t);
  }, []);
  useEffect(() => { if (hud.hurt) setHurtKey(hud.hurt); }, [hud.hurt]);

  const nameVisible = performance.now() - hud.selectedAt < 1800;
  const creative = ui.mode === 'creative';
  const xpNeed = 7 + hud.level * 3;

  return (
    <div className="pointer-events-none absolute inset-0 z-30 select-none">
      {/* atmosphere overlays */}
      <div className="absolute inset-0 vignette" />
      {hud.underwater && (
        <div className="absolute inset-0" style={{ background: 'linear-gradient(180deg, rgba(20,90,150,0.42), rgba(8,45,90,0.55))' }} />
      )}
      {hurtKey > 0 && (
        <div key={hurtKey} className="hurt-flash absolute inset-0"
          style={{ background: 'radial-gradient(ellipse at center, rgba(180,20,20,0.15) 30%, rgba(150,10,10,0.75) 100%)' }} />
      )}
      {hud.health <= 6 && !creative && (
        <div className="absolute inset-0 anim-pulse"
          style={{ background: 'radial-gradient(ellipse at center, transparent 45%, rgba(140,10,10,0.5) 100%)' }} />
      )}

      {/* crosshair */}
      {!ui.overlay && (
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className="relative h-6 w-6" style={{ mixBlendMode: 'difference' }}>
            <div className="absolute left-1/2 top-0 h-6 w-[2px] -translate-x-1/2 bg-white/90" />
            <div className="absolute top-1/2 left-0 h-[2px] w-6 -translate-y-1/2 bg-white/90" />
          </div>
          {hud.breaking > 0 && (
            <div className="absolute left-1/2 top-8 h-[5px] w-16 -translate-x-1/2 border border-black/70 bg-black/50">
              <div className="h-full bg-torch transition-[width] duration-75" style={{ width: `${Math.min(100, hud.breaking * 100)}%` }} />
            </div>
          )}
        </div>
      )}

      {/* top left status */}
      <div className="absolute left-4 top-4 flex flex-col gap-2">
        <Clock time={hud.time} day={hud.day} />
        <div className="glass flex items-center gap-2 rounded-sm px-3 py-1.5 text-[11px]">
          <span className="h-2 w-2 rounded-full" style={{ background: hud.weather === 'Clear' ? '#6cc24a' : hud.weather === 'Snow' ? '#cfe8ff' : '#4fa3f7' }} />
          <span className="text-parch/80">{hud.biome}</span>
          <span className="text-parch/35">·</span>
          <span className="text-parch/60">{hud.weather}</span>
        </div>
        {ui.settings.showDebug && (
          <div className="panel-dark max-w-[260px] px-3 py-2 font-display text-[10px] leading-relaxed text-grass/90">
            <div>FPS {hud.fps} · CHUNKS {hud.chunks}</div>
            <div>TRIS {hud.tris.toLocaleString()}</div>
            <div>XYZ {hud.x.toFixed(1)} / {hud.y.toFixed(1)} / {hud.z.toFixed(1)}</div>
            <div>CHUNK {Math.floor(hud.x / 16)} , {Math.floor(hud.z / 16)}</div>
            <div>MOBS {hud.mobCount} · {hud.weather}</div>
            <div>TARGET {hud.target ?? '—'}</div>
            <div className="text-parch/40">{creative ? 'CREATIVE' : 'SURVIVAL'}{hud.flying ? ' · FLYING' : ''}</div>
          </div>
        )}
      </div>

      {/* top right controls */}
      <div className="pointer-events-auto absolute right-4 top-4 flex items-center gap-2">
        <button
          className="glass flex h-10 items-center gap-2 rounded-sm px-3 font-display text-[10px] text-parch/80 transition hover:text-torch"
          onClick={() => {
            const e = engineRef.current;
            if (!e) return;
            const next = !muted;
            setMuted(next);
            e.audio.setMuted(next);
          }}
          title="Mute all audio"
        >
          <span style={{ color: muted ? '#e0483d' : '#6cc24a' }}>{muted ? '🔇' : '🔊'}</span>
          {muted ? 'MUTED' : 'SOUND'}
        </button>
        <button
          className="glass flex h-10 items-center rounded-sm px-3 font-display text-[10px] text-parch/80 transition hover:text-torch"
          onClick={() => engineRef.current?.setOverlay('achievements')}
        >
          ★ {ui.achievements.filter((a) => a.done).length}/{ui.achievements.length}
        </button>
        <button
          className="glass flex h-10 items-center rounded-sm px-3 font-display text-[10px] text-parch/80 transition hover:text-torch"
          onClick={() => engineRef.current?.setOverlay('pause')}
        >
          ESC
        </button>
      </div>

      {/* toasts */}
      <div className="absolute right-4 top-20 flex w-[290px] flex-col gap-2">
        {ui.toasts.map((t) => (
          <div key={t.id} className="anim-toast panel-dark flex items-center gap-3 px-3 py-2">
            {t.icon != null && <img src={itemIcon(t.icon)} className="pixelated h-8 w-8" alt="" />}
            <div className="min-w-0">
              <div className="font-display text-[11px]" style={{ color: t.kind === 'achievement' ? '#f5c542' : t.kind === 'warn' ? '#e0483d' : '#8fdc63' }}>
                {t.kind === 'achievement' ? '★ ' : ''}{t.title}
              </div>
              {t.body && <div className="truncate text-[11px] text-parch/60">{t.body}</div>}
            </div>
          </div>
        ))}
      </div>

      {/* bottom center: stats + hotbar */}
      <div className="absolute bottom-4 left-1/2 flex -translate-x-1/2 flex-col items-center gap-1.5">
        {nameVisible && hud.selectedName && (
          <div className="mb-1 font-display text-[12px] text-parch drop-shadow-[0_2px_0_rgba(0,0,0,0.9)]">
            {hud.selectedName}
          </div>
        )}
        {!creative && (
          <div className="flex w-[512px] items-end justify-between px-1">
            <div className="flex flex-col gap-1">
              {hud.air < 10 && (
                <div className="flex gap-[2px]">
                  {Array.from({ length: 10 }, (_, i) => (
                    <div key={i} className="h-3 w-3 rounded-full border border-black/70"
                      style={{ background: i < Math.ceil(hud.air) ? '#7fd8ff' : 'transparent', opacity: i < Math.ceil(hud.air) ? 1 : 0.25 }} />
                  ))}
                </div>
              )}
              <Bar value={hud.health} max={20} color="#e0483d" icon={HEART} />
            </div>
            <div className="flex flex-col items-end gap-1">
              <Bar value={hud.hunger} max={20} color="#c98f45" icon={FOOD} />
            </div>
          </div>
        )}
        {!creative && (
          <div className="relative h-[10px] w-[512px] border-2 border-black/80 bg-black/60">
            <div className="h-full bg-gradient-to-r from-grass-deep to-grass transition-[width] duration-200"
              style={{ width: `${Math.min(100, (hud.xp / xpNeed) * 100)}%` }} />
            {hud.level > 0 && (
              <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 font-display text-[11px] text-grass drop-shadow-[1px_1px_0_#000]">
                {hud.level}
              </span>
            )}
          </div>
        )}
        <div className="pointer-events-auto flex gap-[3px] border-2 border-black/70 bg-black/35 p-[3px]">
          {ui.inv.slots.slice(0, 9).map((s, i) => (
            <Slot key={i} stack={s} hotbar active={i === ui.inv.selected} onClick={() => engineRef.current?.selectSlot(i)} />
          ))}
        </div>
      </div>

      {/* control hints */}
      {showHint && !ui.overlay && (
        <div className="absolute bottom-4 left-4 max-w-[240px] panel-dark px-3 py-2 text-[11px] leading-relaxed text-parch/60">
          <div className="mb-1 font-display text-[10px] text-torch">CONTROLS</div>
          <div><b className="text-parch/85">WASD</b> move · <b className="text-parch/85">Space</b> jump</div>
          <div><b className="text-parch/85">Shift</b> sprint · <b className="text-parch/85">C</b> sneak</div>
          <div><b className="text-parch/85">LMB</b> mine · <b className="text-parch/85">RMB</b> place/use</div>
          <div><b className="text-parch/85">E</b> inventory · <b className="text-parch/85">Q</b> drop</div>
          <div><b className="text-parch/85">1-9</b> hotbar · <b className="text-parch/85">F3</b> debug</div>
          {creative && <div className="text-grass">Double-tap Space to fly</div>}
        </div>
      )}

      {/* target label */}
      {hud.target && !ui.overlay && (
        <div className="absolute left-1/2 top-[calc(50%+38px)] -translate-x-1/2 font-display text-[10px] text-parch/45">
          {hud.target}
        </div>
      )}

      {/* creative badge */}
      {creative && (
        <div className="absolute bottom-4 right-4 panel-dark px-3 py-2 font-display text-[10px] text-diamond">
          CREATIVE {hud.flying ? '· FLIGHT' : ''}
        </div>
      )}

      {/* item under cursor label for hotbar */}
      <div className="hidden">{getItem(0).name}</div>
    </div>
  );
}
