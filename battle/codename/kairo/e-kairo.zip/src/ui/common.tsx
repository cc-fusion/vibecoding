import { useSyncExternalStore } from 'react';
import { uiStore, hudStore } from '../game/store';
import { getItem } from '../game/blocks';
import { itemIcon } from '../game/textures';
import type { Stack } from '../game/inventory';
import type { Engine } from '../game/engine';

export const engineRef: { current: Engine | null } = { current: null };

export const useUI = () => useSyncExternalStore(uiStore.subscribe, uiStore.get);
export const useHud = () => useSyncExternalStore(hudStore.subscribe, hudStore.get);

export const RARITY_COLOR: Record<string, string> = {
  common: '#efe6d8',
  uncommon: '#f5c542',
  rare: '#4fa3f7',
  epic: '#4fe3d6',
};

export function ItemTooltip({ id, count }: { id: number; count?: number }) {
  const it = getItem(id);
  return (
    <div className="tooltip">
      <div className="font-display text-[11px]" style={{ color: RARITY_COLOR[it.rarity ?? 'common'] }}>
        {it.name}
      </div>
      {it.tool && (
        <div className="mt-1 text-[10px] text-parch/60">
          {it.tool.kind} · tier {it.tool.tier} · {it.tool.damage} dmg
        </div>
      )}
      {it.food != null && <div className="mt-1 text-[10px] text-grass">+{it.food} hunger</div>}
      {it.fuel != null && <div className="mt-1 text-[10px] text-torch">fuel {it.fuel}s</div>}
      {count != null && count > 1 && <div className="mt-1 text-[10px] text-parch/45">x{count}</div>}
    </div>
  );
}

export function Slot({
  stack,
  onClick,
  active,
  small,
  hotbar,
  label,
  disabled,
}: {
  stack: Stack | null;
  onClick?: (button: number, shift: boolean) => void;
  active?: boolean;
  small?: boolean;
  hotbar?: boolean;
  label?: string;
  disabled?: boolean;
}) {
  const cls = hotbar ? 'slot hotbar-slot' : small ? 'slot slot-sm' : 'slot';
  return (
    <div
      className={`${cls} ${active ? 'active' : ''} group`}
      onMouseDown={(e) => {
        e.preventDefault();
        if (!disabled) onClick?.(e.button, e.shiftKey);
      }}
      onContextMenu={(e) => e.preventDefault()}
    >
      {stack ? (
        <>
          <img className="pixelated" src={itemIcon(stack.id)} alt={getItem(stack.id).name} draggable={false} />
          {stack.count > 1 && <span className="count">{stack.count}</span>}
          <div className="hidden group-hover:block">
            <ItemTooltip id={stack.id} count={stack.count} />
          </div>
        </>
      ) : label ? (
        <span className="font-display text-[9px] text-parch/25">{label}</span>
      ) : null}
    </div>
  );
}

export function Panel({ children, className = '', title }: { children: React.ReactNode; className?: string; title?: string }) {
  return (
    <div className={`panel ${className}`}>
      {title && (
        <div className="border-b-2 border-black/60 px-4 py-2 font-display text-[12px] tracking-wider text-torch">
          {title}
        </div>
      )}
      {children}
    </div>
  );
}

export function Btn({
  children,
  onClick,
  variant = 'default',
  className = '',
  disabled,
  title,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'default' | 'primary' | 'danger' | 'ghost';
  className?: string;
  disabled?: boolean;
  title?: string;
}) {
  const v = variant === 'primary' ? 'btn-primary' : variant === 'danger' ? 'btn-danger' : variant === 'ghost' ? 'btn-ghost' : '';
  return (
    <button className={`btn ${v} ${className}`} onClick={onClick} disabled={disabled} title={title}>
      {children}
    </button>
  );
}

export function Toggle({ value, onChange, label }: { value: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      className="flex w-full items-center justify-between gap-4 border-2 border-black/70 bg-black/30 px-3 py-2 text-left transition hover:bg-black/10"
      onClick={() => onChange(!value)}
    >
      <span className="text-[13px] text-parch/85">{label}</span>
      <span
        className="relative h-6 w-11 border-2 border-black/80"
        style={{ background: value ? 'linear-gradient(180deg,#74cf50,#3d8a2b)' : 'linear-gradient(180deg,#3a352f,#221f1b)' }}
      >
        <span
          className="absolute top-[1px] h-[16px] w-[16px] bg-parch shadow-[0_0_6px_rgba(0,0,0,0.6)] transition-all"
          style={{ left: value ? '22px' : '2px' }}
        />
      </span>
    </button>
  );
}

export function Slider({
  value, min, max, step = 1, onChange, label, format,
}: {
  value: number; min: number; max: number; step?: number;
  onChange: (v: number) => void; label: string; format?: (v: number) => string;
}) {
  return (
    <label className="block">
      <div className="mb-1 flex items-center justify-between text-[12px]">
        <span className="text-parch/80">{label}</span>
        <span className="font-display text-[11px] text-grass">{format ? format(value) : value}</span>
      </div>
      <input
        type="range"
        className="w-full"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
      />
    </label>
  );
}
