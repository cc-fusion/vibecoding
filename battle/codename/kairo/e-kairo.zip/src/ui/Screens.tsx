import { useEffect, useMemo, useState } from 'react';
import { useUI, useHud, engineRef, Btn, Panel, Slider, Toggle } from './common';
import { listWorlds, createWorldMeta, deleteWorld, saveSize, type WorldMeta } from '../game/save';
import { hashString } from '../game/noise';
import { uiStore, persistSettings } from '../game/store';
import { itemIcon } from '../game/textures';

const TIPS = [
  'Punch a tree to gather wood — everything starts there.',
  'Craft a crafting table for the 3×3 grid, then a pickaxe.',
  'Torches keep the dark away. Coal + stick makes four.',
  'Diamonds hide below Y=15. Bring iron tools.',
  'Sneak with C to avoid walking off ledges.',
  'A furnace turns raw ore into ingots. Feed it coal.',
  'Zombies burn at sunrise — survive the night.',
  'Water breaks your fall. Aim for the ocean.',
];

function Logo({ small }: { small?: boolean }) {
  return (
    <div className="select-none">
      <h1 className={`logo-3d ${small ? 'text-[30px]' : 'text-[58px]'} leading-none`}>VOXELCRAFT</h1>
      <div className="mt-2 flex items-center gap-3">
        <span className="h-[2px] w-10 bg-grass/70" />
        <p className="font-display text-[10px] tracking-[0.32em] text-parch/60">INFINITE BLOCK SANDBOX</p>
      </div>
    </div>
  );
}

function WorldCard({ w, onPlay, onDelete }: { w: WorldMeta; onPlay: () => void; onDelete: () => void }) {
  const size = saveSize(w.id);
  return (
    <div className="group flex items-center gap-3 border-2 border-black/60 bg-black/30 p-3 transition hover:border-grass/60 hover:bg-grass/5">
      <div className="grid h-12 w-12 shrink-0 place-items-center border-2 border-black/70 bg-gradient-to-br from-grass-deep/50 to-black/60">
        <img src={itemIcon(w.mode === 'creative' ? 29 : 6)} className="pixelated h-9 w-9" alt="" />
      </div>
      <div className="min-w-0 flex-1">
        <div className="truncate font-display text-[12px] text-parch">{w.name}</div>
        <div className="mt-1 flex flex-wrap gap-x-3 text-[10px] text-parch/45">
          <span className="uppercase text-grass/80">{w.mode}</span>
          <span>Day {w.day}</span>
          <span>Seed {w.seed}</span>
          <span>{(size / 1024).toFixed(0)} KB</span>
        </div>
      </div>
      <div className="flex shrink-0 gap-2">
        <Btn variant="primary" onClick={onPlay} className="!px-3 !py-2 !text-[11px]">PLAY</Btn>
        <Btn variant="danger" onClick={onDelete} className="!px-3 !py-2 !text-[11px]" title="Delete world">✕</Btn>
      </div>
    </div>
  );
}

export function TitleScreen() {
  const ui = useUI();
  const [worlds, setWorlds] = useState<WorldMeta[]>(() => listWorlds());
  const [name, setName] = useState('My World');
  const [seedText, setSeedText] = useState('');
  const [mode, setMode] = useState<'survival' | 'creative'>('survival');
  const [tip] = useState(() => TIPS[Math.floor(Math.random() * TIPS.length)]);

  useEffect(() => { setWorlds(listWorlds()); }, [ui.screen]);

  const play = (w: WorldMeta) => engineRef.current?.loadGame(w);
  const create = () => {
    const seed = seedText.trim() === ''
      ? Math.floor(Math.random() * 4294967295)
      : /^-?\d+$/.test(seedText.trim())
        ? parseInt(seedText.trim(), 10) >>> 0
        : hashString(seedText.trim());
    const w = createWorldMeta(name, seed, mode);
    engineRef.current?.loadGame(w);
  };

  return (
    <div className="pointer-events-auto absolute inset-0 z-30 overflow-hidden">
      <div className="absolute inset-0" style={{ background: 'linear-gradient(105deg, rgba(6,10,8,0.92) 0%, rgba(8,12,10,0.72) 42%, rgba(6,10,14,0.25) 75%, rgba(6,10,14,0.55) 100%)' }} />
      <div className="absolute inset-0 vignette" />
      <div className="absolute inset-0 scanlines opacity-30" />

      {ui.screen === 'title' && (
        <div className="relative flex h-full items-center">
          <div className="anim-up ml-[7vw] max-w-[440px]">
            <Logo />
            <p className="mt-6 max-w-[380px] text-[13px] leading-relaxed text-parch/60">
              Carve into a procedurally generated world of forests, deserts, tundras and caverns.
              Mine it, craft it, build it — then hold the line when the sun goes down.
            </p>
            <div className="mt-8 flex w-[300px] flex-col gap-2.5">
              {worlds.length > 0 && (
                <Btn variant="primary" onClick={() => play(worlds[0])} className="!py-3.5">
                  ▶ CONTINUE — {worlds[0].name.toUpperCase().slice(0, 18)}
                </Btn>
              )}
              <Btn variant={worlds.length ? 'default' : 'primary'} onClick={() => uiStore.set({ screen: 'create' })} className="!py-3.5">
                ✦ CREATE NEW WORLD
              </Btn>
              <Btn onClick={() => uiStore.set({ screen: 'worlds' })}>🗂 SAVED WORLDS ({worlds.length})</Btn>
              <Btn variant="ghost" onClick={() => uiStore.set({ overlay: 'settings' })}>⚙ SETTINGS</Btn>
            </div>
            <div className="mt-8 flex items-center gap-2 text-[11px] text-parch/40">
              <span className="inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-grass" />
              {tip}
            </div>
          </div>

          <div className="anim-up ml-auto mr-[6vw] hidden w-[300px] flex-col gap-3 lg:flex" style={{ animationDelay: '160ms' }}>
            <Panel title="WHAT'S INSIDE">
              <div className="flex flex-col gap-2.5 p-4 text-[12px] text-parch/70">
                {[
                  ['🌍', '10 biomes · caves · ores · ruins'],
                  ['⛏️', 'Mining, tool tiers & durability-free play'],
                  ['🧪', 'Crafting grid, recipe book & furnace'],
                  ['🐖', 'Pigs, sheep and night-time zombies'],
                  ['🌦️', 'Day/night cycle, rain, snow & thunder'],
                  ['💾', 'Auto-saving worlds in your browser'],
                ].map(([icon, text]) => (
                  <div key={text} className="flex items-start gap-2.5">
                    <span className="text-[14px] leading-5">{icon}</span>
                    <span className="leading-5">{text}</span>
                  </div>
                ))}
              </div>
            </Panel>
            <div className="glass px-4 py-3 text-[11px] leading-relaxed text-parch/50">
              Everything you see — terrain, textures, creatures and sound — is generated in code at runtime.
              No asset downloads.
            </div>
          </div>

          <div className="absolute bottom-4 left-[7vw] font-display text-[9px] tracking-widest text-parch/25">
            BUILT WITH WEBGL · REACT · PROCEDURAL EVERYTHING
          </div>
        </div>
      )}

      {ui.screen === 'worlds' && (
        <div className="relative flex h-full items-center justify-center">
          <Panel className="anim-up w-[620px] max-w-[92vw]" title="SAVED WORLDS">
            <div className="scroller flex max-h-[52vh] flex-col gap-2 overflow-y-auto p-4">
              {worlds.length === 0 && (
                <div className="py-12 text-center text-[13px] text-parch/40">
                  No worlds yet. Create one to start digging.
                </div>
              )}
              {worlds.map((w) => (
                <WorldCard
                  key={w.id}
                  w={w}
                  onPlay={() => play(w)}
                  onDelete={() => { deleteWorld(w.id); setWorlds(listWorlds()); }}
                />
              ))}
            </div>
            <div className="flex justify-between gap-2 border-t-2 border-black/50 p-4">
              <Btn onClick={() => uiStore.set({ screen: 'title' })}>← BACK</Btn>
              <Btn variant="primary" onClick={() => uiStore.set({ screen: 'create' })}>+ NEW WORLD</Btn>
            </div>
          </Panel>
        </div>
      )}

      {ui.screen === 'create' && (
        <div className="relative flex h-full items-center justify-center">
          <Panel className="anim-up w-[520px] max-w-[92vw]" title="CREATE NEW WORLD">
            <div className="flex flex-col gap-5 p-5">
              <label className="block">
                <div className="mb-1.5 font-display text-[10px] text-parch/60">WORLD NAME</div>
                <input type="text" className="w-full" value={name} maxLength={28} onChange={(e) => setName(e.target.value)} />
              </label>
              <label className="block">
                <div className="mb-1.5 font-display text-[10px] text-parch/60">SEED (blank = random)</div>
                <input type="text" className="w-full" value={seedText} placeholder="e.g. 1337 or 'emerald valley'" onChange={(e) => setSeedText(e.target.value)} />
              </label>
              <div>
                <div className="mb-1.5 font-display text-[10px] text-parch/60">GAME MODE</div>
                <div className="grid grid-cols-2 gap-2">
                  {(['survival', 'creative'] as const).map((m) => (
                    <button
                      key={m}
                      onClick={() => setMode(m)}
                      className={`border-2 p-3 text-left transition ${mode === m ? 'border-grass bg-grass/15' : 'border-black/60 bg-black/30 hover:bg-black/10'}`}
                    >
                      <div className="font-display text-[11px] text-parch">{m.toUpperCase()}</div>
                      <div className="mt-1 text-[11px] leading-snug text-parch/50">
                        {m === 'survival' ? 'Health, hunger, mobs and tool progression.' : 'Infinite blocks, instant mining, free flight.'}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex justify-between gap-2 border-t-2 border-black/50 p-4">
              <Btn onClick={() => uiStore.set({ screen: 'title' })}>← BACK</Btn>
              <Btn variant="primary" onClick={create}>CREATE & PLAY ▶</Btn>
            </div>
          </Panel>
        </div>
      )}
    </div>
  );
}

export function LoadingScreen() {
  const ui = useUI();
  const [tip] = useState(() => TIPS[Math.floor(Math.random() * TIPS.length)]);
  return (
    <div className="pointer-events-auto absolute inset-0 z-40 flex flex-col items-center justify-center bg-[#07090a]">
      <div className="absolute inset-0 opacity-40" style={{ background: 'radial-gradient(circle at 50% 40%, rgba(60,140,60,0.22), transparent 60%)' }} />
      <div className="relative flex flex-col items-center">
        <Logo small />
        <div className="mt-8 h-4 w-[380px] max-w-[80vw] border-2 border-black bg-black/70 p-[2px]">
          <div className="loading-bar h-full transition-[width] duration-200" style={{ width: `${Math.max(4, ui.loading * 100)}%` }} />
        </div>
        <div className="mt-3 font-display text-[10px] tracking-widest text-parch/50">
          {ui.loadingLabel.toUpperCase()} — {Math.round(ui.loading * 100)}%
        </div>
        <div className="mt-8 max-w-[380px] text-center text-[12px] text-parch/40">{tip}</div>
      </div>
    </div>
  );
}

export function SettingsPanel({ onClose }: { onClose: () => void }) {
  const ui = useUI();
  const s = ui.settings;
  const set = (patch: Partial<typeof s>) => {
    engineRef.current?.updateSettings(patch);
    persistSettings({ ...s, ...patch });
  };
  return (
    <Panel className="anim-up w-[560px] max-w-[94vw]" title="SETTINGS">
      <div className="scroller max-h-[62vh] overflow-y-auto p-5">
        <div className="grid grid-cols-2 gap-x-6 gap-y-4">
          <Slider label="Render distance" value={s.renderDistance} min={3} max={12} onChange={(v) => set({ renderDistance: v })} format={(v) => `${v} chunks`} />
          <Slider label="Field of view" value={s.fov} min={60} max={105} onChange={(v) => set({ fov: v })} format={(v) => `${v}°`} />
          <Slider label="Mouse sensitivity" value={s.sensitivity} min={0.25} max={2.5} step={0.05} onChange={(v) => set({ sensitivity: v })} format={(v) => `${v.toFixed(2)}×`} />
          <Slider label="Volume" value={s.volume} min={0} max={1} step={0.05} onChange={(v) => set({ volume: v })} format={(v) => `${Math.round(v * 100)}%`} />
        </div>
        <div className="mt-5 grid grid-cols-2 gap-2">
          <Toggle label="Music" value={s.music} onChange={(v) => set({ music: v })} />
          <Toggle label="Particles" value={s.particles} onChange={(v) => set({ particles: v })} />
          <Toggle label="Clouds" value={s.clouds} onChange={(v) => set({ clouds: v })} />
          <Toggle label="Auto-jump" value={s.autoJump} onChange={(v) => set({ autoJump: v })} />
          <Toggle label="View bobbing" value={s.viewBob} onChange={(v) => set({ viewBob: v })} />
          <Toggle label="Invert mouse Y" value={s.invertY} onChange={(v) => set({ invertY: v })} />
          <Toggle label="Debug overlay (F3)" value={s.showDebug} onChange={(v) => set({ showDebug: v })} />
        </div>
        <div className="mt-5 border-2 border-black/50 bg-black/25 p-3 text-[11px] leading-relaxed text-parch/45">
          Lower the render distance if the frame rate dips. Chunk meshes are built on the fly with a
          per-frame time budget, so streaming stays smooth while you move.
        </div>
      </div>
      <div className="flex justify-end border-t-2 border-black/50 p-4">
        <Btn variant="primary" onClick={onClose}>DONE</Btn>
      </div>
    </Panel>
  );
}

export function AchievementsPanel({ onClose }: { onClose: () => void }) {
  const ui = useUI();
  const done = ui.achievements.filter((a) => a.done).length;
  return (
    <Panel className="anim-up w-[560px] max-w-[94vw]" title={`ADVANCEMENTS — ${done}/${ui.achievements.length}`}>
      <div className="scroller grid max-h-[60vh] grid-cols-2 gap-2 overflow-y-auto p-4">
        {ui.achievements.map((a) => (
          <div key={a.id} className={`flex items-center gap-3 border-2 p-2.5 transition ${a.done ? 'border-gold/50 bg-gold/10' : 'border-black/50 bg-black/25 opacity-55'}`}>
            <img src={itemIcon(a.icon)} className={`pixelated h-9 w-9 ${a.done ? '' : 'grayscale'}`} alt="" />
            <div className="min-w-0">
              <div className="font-display text-[10px]" style={{ color: a.done ? '#f5c542' : '#efe6d8' }}>{a.name}</div>
              <div className="text-[11px] leading-snug text-parch/50">{a.desc}</div>
            </div>
          </div>
        ))}
      </div>
      <div className="flex justify-end border-t-2 border-black/50 p-4">
        <Btn variant="primary" onClick={onClose}>CLOSE</Btn>
      </div>
    </Panel>
  );
}

export function PauseMenu() {
  const ui = useUI();
  const hud = useHud();
  const e = engineRef.current;
  const [saved, setSaved] = useState(false);
  const mins = Math.floor((e?.playTime ?? 0) / 60);
  return (
    <Panel className="anim-up w-[420px] max-w-[92vw]" title="GAME PAUSED">
      <div className="p-5">
        <div className="mb-4 grid grid-cols-3 gap-2 text-center">
          {[
            ['DAY', String(hud.day)],
            ['MINED', String(e?.stats.mined ?? 0)],
            ['PLACED', String(e?.stats.placed ?? 0)],
          ].map(([k, v]) => (
            <div key={k} className="border-2 border-black/50 bg-black/30 py-2">
              <div className="font-display text-[16px] text-grass">{v}</div>
              <div className="font-display text-[8px] tracking-widest text-parch/40">{k}</div>
            </div>
          ))}
        </div>
        <div className="flex flex-col gap-2">
          <Btn variant="primary" onClick={() => e?.setOverlay(null)}>▶ RESUME</Btn>
          <Btn onClick={() => uiStore.set({ overlay: 'settings' })}>⚙ SETTINGS</Btn>
          <Btn onClick={() => uiStore.set({ overlay: 'achievements' })}>★ ADVANCEMENTS</Btn>
          <Btn onClick={() => { e?.save(); setSaved(true); setTimeout(() => setSaved(false), 1800); }}>
            {saved ? '✓ WORLD SAVED' : '💾 SAVE WORLD'}
          </Btn>
          <Btn variant="danger" onClick={() => e?.quitToTitle()}>⏻ SAVE & QUIT</Btn>
        </div>
        <div className="mt-4 text-center text-[10px] text-parch/35">
          {ui.worldName} · {mins} min played · autosaves every 30s
        </div>
      </div>
    </Panel>
  );
}

export function DeathScreen() {
  const hud = useHud();
  const e = engineRef.current;
  const cause = useMemo(() => (hud.y < 0 ? 'the void' : 'the wilds'), [hud.y]);
  return (
    <div className="pointer-events-auto absolute inset-0 z-50 flex flex-col items-center justify-center"
      style={{ background: 'radial-gradient(ellipse at center, rgba(120,10,10,0.55), rgba(20,0,0,0.9))' }}>
      <div className="anim-up flex flex-col items-center">
        <h1 className="font-display text-[46px] text-redstone drop-shadow-[0_5px_0_rgba(0,0,0,0.8)]">YOU DIED</h1>
        <p className="mt-2 text-[13px] text-parch/60">You were lost to {cause} on day {hud.day}.</p>
        <div className="mt-8 flex gap-3">
          <Btn variant="primary" onClick={() => e?.respawn()}>⟲ RESPAWN</Btn>
          <Btn variant="danger" onClick={() => e?.quitToTitle()}>TITLE SCREEN</Btn>
        </div>
        <p className="mt-6 text-[11px] text-parch/35">Your inventory is kept. Half of your loose XP is lost.</p>
      </div>
    </div>
  );
}
