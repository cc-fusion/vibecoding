import { useEffect, useRef, useState } from 'react';
import { engineRef, useUI } from './common';

const DEAD = 0.18;

export function TouchControls() {
  const ui = useUI();
  const padRef = useRef<HTMLDivElement>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0, active: false });
  const [sprint, setSprint] = useState(false);
  const moveId = useRef<number | null>(null);
  const lookId = useRef<number | null>(null);
  const lookLast = useRef({ x: 0, y: 0 });
  const origin = useRef({ x: 0, y: 0 });

  useEffect(() => {
    return () => {
      const e = engineRef.current;
      if (e) { e.keys.clear(); e.mouse.left = false; }
    };
  }, []);

  const applyMove = (dx: number, dy: number) => {
    const e = engineRef.current;
    if (!e) return;
    const keys = e.keys;
    keys.delete('KeyW'); keys.delete('KeyS'); keys.delete('KeyA'); keys.delete('KeyD');
    if (dy < -DEAD) keys.add('KeyW');
    if (dy > DEAD) keys.add('KeyS');
    if (dx < -DEAD) keys.add('KeyA');
    if (dx > DEAD) keys.add('KeyD');
  };

  const onDown = (ev: React.PointerEvent) => {
    const e = engineRef.current;
    if (!e) return;
    const rect = (ev.currentTarget as HTMLElement).getBoundingClientRect();
    const x = ev.clientX - rect.left;
    if (x < rect.width * 0.42 && moveId.current === null) {
      moveId.current = ev.pointerId;
      origin.current = { x: ev.clientX, y: ev.clientY };
      setKnob({ x: 0, y: 0, active: true });
    } else if (lookId.current === null) {
      lookId.current = ev.pointerId;
      lookLast.current = { x: ev.clientX, y: ev.clientY };
    }
    (ev.currentTarget as HTMLElement).setPointerCapture(ev.pointerId);
  };

  const onMove = (ev: React.PointerEvent) => {
    const e = engineRef.current;
    if (!e) return;
    if (ev.pointerId === moveId.current) {
      const dx = ev.clientX - origin.current.x;
      const dy = ev.clientY - origin.current.y;
      const max = 52;
      const len = Math.hypot(dx, dy) || 1;
      const cl = Math.min(len, max);
      const nx = (dx / len) * cl, ny = (dy / len) * cl;
      setKnob({ x: nx, y: ny, active: true });
      applyMove(nx / max, ny / max);
    } else if (ev.pointerId === lookId.current) {
      const dx = ev.clientX - lookLast.current.x;
      const dy = ev.clientY - lookLast.current.y;
      lookLast.current = { x: ev.clientX, y: ev.clientY };
      const s = e.settings.sensitivity * 0.005;
      e.player.yaw -= dx * s;
      e.player.pitch -= dy * s * (e.settings.invertY ? -1 : 1);
      const lim = Math.PI / 2 - 0.001;
      e.player.pitch = Math.max(-lim, Math.min(lim, e.player.pitch));
    }
  };

  const onUp = (ev: React.PointerEvent) => {
    if (ev.pointerId === moveId.current) {
      moveId.current = null;
      setKnob({ x: 0, y: 0, active: false });
      applyMove(0, 0);
    }
    if (ev.pointerId === lookId.current) lookId.current = null;
  };

  const hold = (fn: (down: boolean) => void) => ({
    onPointerDown: (ev: React.PointerEvent) => { ev.stopPropagation(); ev.preventDefault(); fn(true); },
    onPointerUp: (ev: React.PointerEvent) => { ev.stopPropagation(); fn(false); },
    onPointerLeave: () => fn(false),
    onPointerCancel: () => fn(false),
  });

  if (ui.screen !== 'game' || ui.overlay) return null;
  const creative = ui.mode === 'creative';

  return (
    <div className="pointer-events-none absolute inset-0 z-20 select-none">
      <div
        ref={padRef}
        className="pointer-events-auto absolute inset-0 touch-none"
        onPointerDown={onDown}
        onPointerMove={onMove}
        onPointerUp={onUp}
        onPointerCancel={onUp}
      />
      {/* joystick */}
      <div className="absolute bottom-[104px] left-6 h-[124px] w-[124px] rounded-full border-2 border-white/15 bg-black/25"
        style={{ opacity: knob.active ? 0.95 : 0.45 }}>
        <div className="absolute left-1/2 top-1/2 h-12 w-12 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-black/60 bg-gradient-to-b from-grass to-grass-deep"
          style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }} />
      </div>

      {/* action cluster */}
      <div className="pointer-events-auto absolute bottom-[100px] right-5 flex flex-col items-end gap-2">
        <div className="flex gap-2">
          <button className="h-12 w-12 rounded-full border-2 border-black/60 bg-black/45 font-display text-[9px] text-parch/80 active:bg-grass/40"
            onClick={() => engineRef.current?.setOverlay('inventory')}>BAG</button>
          {creative && (
            <button className="h-12 w-12 rounded-full border-2 border-black/60 bg-black/45 font-display text-[9px] text-diamond active:bg-diamond/30"
              onClick={() => { const e = engineRef.current; if (e) e.player.flying = !e.player.flying; }}>FLY</button>
          )}
          <button className={`h-12 w-12 rounded-full border-2 border-black/60 font-display text-[9px] active:bg-grass/40 ${sprint ? 'bg-grass/40 text-parch' : 'bg-black/45 text-parch/80'}`}
            onClick={() => {
              const e = engineRef.current;
              if (!e) return;
              const next = !sprint;
              setSprint(next);
              if (next) e.keys.add('ShiftLeft'); else e.keys.delete('ShiftLeft');
            }}>RUN</button>
        </div>
        <div className="flex items-end gap-2">
          <button className="h-16 w-16 rounded-full border-2 border-black/60 bg-black/50 font-display text-[10px] text-torch active:bg-torch/40"
            {...hold((d) => { const e = engineRef.current; if (!e) return; if (d) { e.mouse.right = true; e.useItem(); } else { e.mouse.right = false; e.eatTimer = 0; } })}>
            USE
          </button>
          <button className="h-20 w-20 rounded-full border-2 border-black/60 bg-black/50 font-display text-[11px] text-redstone active:bg-redstone/40"
            {...hold((d) => { const e = engineRef.current; if (!e) return; e.mouse.left = d; if (d) e.tryAttack(); else e.breakProgress = 0; })}>
            MINE
          </button>
          <button className="h-16 w-16 rounded-full border-2 border-black/60 bg-black/50 font-display text-[10px] text-grass active:bg-grass/40"
            {...hold((d) => { const e = engineRef.current; if (!e) return; if (d) e.keys.add('Space'); else e.keys.delete('Space'); })}>
            JUMP
          </button>
        </div>
      </div>
      <div className="absolute bottom-[236px] left-6 font-display text-[8px] tracking-widest text-parch/30">
        DRAG LEFT TO MOVE · DRAG RIGHT TO LOOK
      </div>
    </div>
  );
}
