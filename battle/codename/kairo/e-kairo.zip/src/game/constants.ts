export const CX = 16;
export const CZ = 16;
export const WORLD_H = 96;
export const SEA_LEVEL = 32;
export const CHUNK_VOL = CX * CZ * WORLD_H;

export const idx = (x: number, y: number, z: number) => x + CX * (z + CZ * y);
export const chunkKey = (cx: number, cz: number) => `${cx},${cz}`;

export const BIOMES = [
  'Ocean', 'Beach', 'Plains', 'Forest', 'Desert', 'Savanna', 'Taiga', 'Snowy Tundra', 'Mountains', 'Swamp',
] as const;
export type BiomeId = number;

export const BIOME_INFO: { name: string; grass: number; foliage: number; sky: number }[] = [
  { name: 'Ocean', grass: 0x8fd35a, foliage: 0x74c04a, sky: 0x7fb6ef },
  { name: 'Beach', grass: 0x9fd36a, foliage: 0x86c94f, sky: 0x86c5f2 },
  { name: 'Plains', grass: 0x93d55c, foliage: 0x77c247, sky: 0x82c4f5 },
  { name: 'Forest', grass: 0x79c94a, foliage: 0x59ab3a, sky: 0x7cbdf0 },
  { name: 'Desert', grass: 0xc9d16a, foliage: 0xb0bd52, sky: 0x9fd0f0 },
  { name: 'Savanna', grass: 0xc2c85a, foliage: 0xa8b048, sky: 0x93c8ee },
  { name: 'Taiga', grass: 0x7fc389, foliage: 0x5f9e6b, sky: 0x88bfe8 },
  { name: 'Snowy Tundra', grass: 0x9fd8c0, foliage: 0x7fbfa8, sky: 0x9ec9ec },
  { name: 'Mountains', grass: 0x8cc98a, foliage: 0x6faa72, sky: 0x8ec3ef },
  { name: 'Swamp', grass: 0x6faa52, foliage: 0x5c8f3c, sky: 0x7faec2 },
];
