import { Noise, hash2, mulberry32 } from './noise';
import { B, BLOCKS } from './blocks';
import { CX, CZ, WORLD_H, SEA_LEVEL, idx } from './constants';

const PAD = 3;
const EW = CX + PAD * 2; // expanded width for decoration overlap

export interface GenResult {
  data: Uint8Array;
  height: Uint8Array; // top solid+water height per column
  biome: Uint8Array;
}

export class WorldGen {
  private n: Noise;
  private n2: Noise;
  private nc: Noise;
  readonly seed: number;

  constructor(seed: number) {
    this.seed = seed >>> 0;
    this.n = new Noise(this.seed);
    this.n2 = new Noise(this.seed ^ 0x9e3779b9);
    this.nc = new Noise((this.seed + 7777) >>> 0);
  }

  climate(x: number, z: number) {
    const temp = this.n2.fbm2(x * 0.0016, z * 0.0016, 3) * 0.5 + 0.5;
    const humid = this.n2.fbm2(x * 0.0021 + 400, z * 0.0021 - 250, 3) * 0.5 + 0.5;
    return { temp, humid };
  }

  heightAt(x: number, z: number, temp: number, humid: number): number {
    const cont = this.n.fbm2(x * 0.0013, z * 0.0013, 4);
    const hills = this.n.fbm2(x * 0.0072, z * 0.0072, 4);
    const detail = this.n.noise2(x * 0.031, z * 0.031);
    let m = this.n.fbm2(x * 0.0019 + 900, z * 0.0019 - 700, 3);
    m = Math.max(0, m - 0.12);
    const mountain = Math.pow(m * 1.9, 2.1) * (0.55 + 0.45 * (1 - humid));
    let h = 36 + cont * 17 + hills * 5.5 + detail * 1.2 + mountain * 46;
    // flatten ocean floors and beaches a little
    if (h < SEA_LEVEL - 1) h = SEA_LEVEL - 1 - (SEA_LEVEL - 1 - h) * 0.75;
    if (temp > 0.72 && humid < 0.4) h += 1.5; // dunes
    return Math.max(4, Math.min(WORLD_H - 12, Math.round(h)));
  }

  biomeFor(h: number, temp: number, humid: number): number {
    if (h < SEA_LEVEL - 1) return 0; // ocean
    if (h <= SEA_LEVEL + 1) return 1; // beach
    if (h > 62) return temp < 0.35 ? 8 : 8;
    if (temp < 0.24) return 7;
    if (temp < 0.4) return humid > 0.45 ? 6 : 2;
    if (temp > 0.72) return humid < 0.34 ? 4 : humid < 0.55 ? 5 : 3;
    if (humid > 0.72 && h < SEA_LEVEL + 5) return 9;
    if (humid > 0.52) return 3;
    return 2;
  }

  generateChunk(cx: number, cz: number): GenResult {
    const data = new Uint8Array(CX * CZ * WORLD_H);
    const height = new Uint8Array(CX * CZ);
    const biome = new Uint8Array(CX * CZ);
    const hs = new Int16Array(EW * EW);
    const bs = new Uint8Array(EW * EW);
    const ox = cx * CX, oz = cz * CZ;

    for (let z = 0; z < EW; z++) {
      for (let x = 0; x < EW; x++) {
        const wx = ox + x - PAD, wz = oz + z - PAD;
        const { temp, humid } = this.climate(wx, wz);
        const h = this.heightAt(wx, wz, temp, humid);
        hs[x + z * EW] = h;
        bs[x + z * EW] = this.biomeFor(h, temp, humid);
      }
    }

    const rnd = mulberry32((hash2(cx, cz, this.seed) * 4294967296) >>> 0);

    for (let z = 0; z < CZ; z++) {
      for (let x = 0; x < CX; x++) {
        const wx = ox + x, wz = oz + z;
        const h = hs[x + PAD + (z + PAD) * EW];
        const bio = bs[x + PAD + (z + PAD) * EW];
        biome[x + z * CX] = bio;
        const desert = bio === 4;
        const snowy = bio === 7;
        const rocky = bio === 8 && h > 66;

        for (let y = 0; y <= Math.max(h, SEA_LEVEL); y++) {
          let id: number = B.AIR;
          if (y === 0 || (y < 3 && hash2(wx * 3 + y, wz * 5, this.seed) < 0.55)) id = B.BEDROCK;
          else if (y <= h) {
            const depth = h - y;
            if (depth === 0) {
              if (h < SEA_LEVEL) id = bio === 9 ? B.CLAY : h < SEA_LEVEL - 4 ? B.GRAVEL : B.SAND;
              else if (desert) id = B.SAND;
              else if (snowy) id = B.SNOW_GRASS;
              else if (rocky) id = B.STONE;
              else if (bio === 1) id = B.SAND;
              else id = B.GRASS;
            } else if (depth < 4) {
              id = desert ? B.SANDSTONE : bio === 1 ? B.SAND : rocky ? B.STONE : B.DIRT;
              if (h < SEA_LEVEL && depth < 3) id = bio === 9 ? B.CLAY : B.SAND;
            } else id = B.STONE;

            // caves
            if (id !== B.BEDROCK && y > 1 && y < h - 1) {
              const n1 = this.nc.noise3(wx * 0.026, y * 0.042, wz * 0.026);
              const n2 = this.nc.noise3(wx * 0.026 + 120, y * 0.042, wz * 0.026 - 90);
              const widen = y < 24 ? 0.028 : 0;
              const tunnel = Math.abs(n1) < 0.118 + widen && Math.abs(n2) < 0.118 + widen;
              let cavern = false;
              if (y < 34) {
                const c = this.nc.noise3(wx * 0.015, y * 0.03, wz * 0.015);
                cavern = c > 0.44 - (34 - y) * 0.005;
              }
              if (tunnel || cavern) id = y <= 7 ? B.LAVA : B.AIR;
            }
          }
          if (id === B.AIR && y <= SEA_LEVEL) {
            id = B.WATER;
            if (snowy && y === SEA_LEVEL) id = B.ICE;
          }
          if (id !== B.AIR) data[idx(x, y, z)] = id;
        }
        let top = h;
        while (top > 0 && data[idx(x, top, z)] === B.AIR) top--;
        height[x + z * CX] = top;
      }
    }

    // ---- ore veins (deterministic per chunk) ----
    const vein = (block: number, tries: number, minY: number, maxY: number, size: number) => {
      for (let i = 0; i < tries; i++) {
        const vx = (rnd() * CX) | 0, vz = (rnd() * CZ) | 0;
        const vy = minY + ((rnd() * (maxY - minY)) | 0);
        let px = vx, py = vy, pz = vz;
        const n = size + ((rnd() * size) | 0);
        for (let s = 0; s < n; s++) {
          if (px >= 0 && px < CX && pz >= 0 && pz < CZ && py > 0 && py < WORLD_H) {
            const k = idx(px, py, pz);
            if (data[k] === B.STONE) data[k] = block;
          }
          px += ((rnd() * 3) | 0) - 1;
          py += ((rnd() * 3) | 0) - 1;
          pz += ((rnd() * 3) | 0) - 1;
        }
      }
    };
    vein(B.COAL_ORE, 14, 8, 68, 5);
    vein(B.IRON_ORE, 10, 4, 48, 4);
    vein(B.GOLD_ORE, 3, 3, 26, 3);
    vein(B.DIAMOND_ORE, 2, 2, 15, 3);
    vein(B.GRAVEL, 4, 10, 60, 6);
    vein(B.DIRT, 5, 12, 60, 6);

    // ---- decoration (trees / plants / ruins) ----
    const set = (wx: number, wy: number, wz: number, id: number, replace = false) => {
      const lx = wx - ox, lz = wz - oz;
      if (lx < 0 || lx >= CX || lz < 0 || lz >= CZ || wy < 0 || wy >= WORLD_H) return;
      const k = idx(lx, wy, lz);
      if (!replace && data[k] !== B.AIR && data[k] !== B.WATER && !BLOCKS[data[k]].cross) return;
      data[k] = id;
    };
    const surfaceAt = (x: number, z: number) => {
      const h = hs[x + PAD + (z + PAD) * EW];
      return h;
    };

    for (let z = -PAD; z < CZ + PAD; z++) {
      for (let x = -PAD; x < CX + PAD; x++) {
        const wx = ox + x, wz = oz + z;
        const bio = bs[x + PAD + (z + PAD) * EW];
        const h = surfaceAt(x, z);
        if (h < SEA_LEVEL) continue;
        const r = hash2(wx, wz, this.seed ^ 0x51ab);
        const treeChance =
          bio === 3 ? 0.055 : bio === 6 ? 0.05 : bio === 5 ? 0.012 : bio === 2 ? 0.006 :
          bio === 9 ? 0.03 : bio === 8 ? 0.008 : bio === 7 ? 0.012 : 0;
        if (r < treeChance) {
          const birch = bio === 3 ? hash2(wx, wz, 99) < 0.35 : bio === 2 || bio === 9 ? hash2(wx, wz, 99) < 0.5 : false;
          const log = birch ? B.BIRCH_LOG : B.OAK_LOG;
          const leaf = birch ? B.BIRCH_LEAVES : B.OAK_LEAVES;
          const th = 4 + ((hash2(wx, wz, 7) * 3) | 0);
          for (let i = 1; i <= th; i++) set(wx, h + i, wz, log, true);
          const topY = h + th;
          for (let dy = -2; dy <= 1; dy++) {
            const rad = dy <= -1 ? 2 : dy === 0 ? 2 : 1;
            for (let dx = -rad; dx <= rad; dx++)
              for (let dz = -rad; dz <= rad; dz++) {
                if (Math.abs(dx) === rad && Math.abs(dz) === rad && (dy >= 0 || hash2(wx + dx, wz + dz, 3) < 0.5)) continue;
                if (dx === 0 && dz === 0 && dy <= 0) continue;
                set(wx + dx, topY + dy, wz + dz, leaf);
              }
          }
          set(wx, topY + 1, wz, leaf);
          continue;
        }
        // ground cover
        const g = hash2(wx, wz, this.seed ^ 0x77c1);
        if (bio === 4) {
          if (g < 0.012) {
            const ch = 2 + ((hash2(wx, wz, 21) * 2) | 0);
            for (let i = 1; i <= ch; i++) set(wx, h + i, wz, B.CACTUS, true);
          } else if (g < 0.03) set(wx, h + 1, wz, B.DEAD_BUSH);
        } else if (bio === 7) {
          if (g < 0.01) set(wx, h + 1, wz, B.DEAD_BUSH);
        } else if (bio !== 1 && bio !== 8) {
          if (g < 0.16) set(wx, h + 1, wz, B.TALL_GRASS);
          else if (g < 0.185) set(wx, h + 1, wz, B.POPPY);
          else if (g < 0.21) set(wx, h + 1, wz, B.DANDELION);
        }
      }
    }

    // boulders + rare ruins
    const rr = mulberry32((hash2(cx, cz, this.seed ^ 0xbeef) * 4294967296) >>> 0);
    if (rr() < 0.22) {
      const bx = 2 + ((rr() * (CX - 4)) | 0), bz = 2 + ((rr() * (CZ - 4)) | 0);
      const h = hs[bx + PAD + (bz + PAD) * EW];
      if (h > SEA_LEVEL) {
        const rad = 1 + rr() * 1.4;
        for (let dx = -2; dx <= 2; dx++)
          for (let dy = -1; dy <= 2; dy++)
            for (let dz = -2; dz <= 2; dz++) {
              if (Math.hypot(dx, dy * 1.3, dz) <= rad) set(ox + bx + dx, h + dy, oz + bz + dz, rr() < 0.3 ? B.MOSSY_COBBLE : B.COBBLE, true);
            }
      }
    }
    if (rr() < 0.035) {
      const bx = 3 + ((rr() * (CX - 7)) | 0), bz = 3 + ((rr() * (CZ - 7)) | 0);
      const h = hs[bx + PAD + (bz + PAD) * EW];
      if (h > SEA_LEVEL + 1) {
        for (let dx = 0; dx < 5; dx++)
          for (let dz = 0; dz < 5; dz++) {
            set(ox + bx + dx, h, oz + bz + dz, rr() < 0.4 ? B.MOSSY_COBBLE : B.STONE_BRICKS, true);
            const edge = dx === 0 || dz === 0 || dx === 4 || dz === 4;
            if (edge) {
              const wallH = 1 + ((rr() * 3) | 0);
              for (let dy = 1; dy <= wallH; dy++) set(ox + bx + dx, h + dy, oz + bz + dz, rr() < 0.35 ? B.MOSSY_COBBLE : B.STONE_BRICKS, true);
            }
          }
        set(ox + bx + 2, h + 1, oz + bz + 2, B.CRAFTING_TABLE, true);
        set(ox + bx + 1, h + 1, oz + bz + 1, B.TORCH, true);
      }
    }

    return { data, height, biome };
  }

  findSpawn(): { x: number; y: number; z: number } {
    for (let r = 0; r < 220; r += 4) {
      for (let a = 0; a < 12; a++) {
        const ang = (a / 12) * Math.PI * 2;
        const x = Math.round(Math.cos(ang) * r);
        const z = Math.round(Math.sin(ang) * r);
        const { temp, humid } = this.climate(x, z);
        const h = this.heightAt(x, z, temp, humid);
        const bio = this.biomeFor(h, temp, humid);
        if (h > SEA_LEVEL + 2 && h < 58 && bio !== 0 && bio !== 8) return { x: x + 0.5, y: h + 2.2, z: z + 0.5 };
      }
    }
    return { x: 0.5, y: 60, z: 0.5 };
  }
}
