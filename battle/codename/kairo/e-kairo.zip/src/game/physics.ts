import * as THREE from 'three';
import { BLOCKS } from './blocks';
import type { World } from './world';

export interface MoveResult {
  onGround: boolean;
  hitX: boolean;
  hitZ: boolean;
  hitY: boolean;
  ceiling: boolean;
}

const EPS = 1e-3;

/** Axis-separated AABB sweep against the voxel grid. pos is the entity's feet centre. */
export function moveEntity(
  world: World,
  pos: THREE.Vector3,
  vel: THREE.Vector3,
  halfW: number,
  height: number,
  dt: number,
): MoveResult {
  const res: MoveResult = { onGround: false, hitX: false, hitZ: false, hitY: false, ceiling: false };
  const total = new THREE.Vector3(vel.x * dt, vel.y * dt, vel.z * dt);
  const steps = Math.max(1, Math.ceil(Math.max(Math.abs(total.x), Math.abs(total.y), Math.abs(total.z)) / 0.35));
  const step = total.clone().divideScalar(steps);

  const solidAt = (x: number, y: number, z: number) => BLOCKS[world.getBlockSolid(Math.floor(x), Math.floor(y), Math.floor(z))].solid;

  for (let s = 0; s < steps; s++) {
    // X
    if (step.x !== 0) {
      pos.x += step.x;
      const y0 = Math.floor(pos.y + EPS), y1 = Math.floor(pos.y + height - EPS);
      const z0 = Math.floor(pos.z - halfW + EPS), z1 = Math.floor(pos.z + halfW - EPS);
      const bx = Math.floor(pos.x + (step.x > 0 ? halfW : -halfW));
      let hit = false;
      for (let y = y0; y <= y1 && !hit; y++)
        for (let z = z0; z <= z1 && !hit; z++) if (solidAt(bx, y, z)) hit = true;
      if (hit) {
        pos.x = step.x > 0 ? bx - halfW - EPS : bx + 1 + halfW + EPS;
        vel.x = 0;
        res.hitX = true;
        step.x = 0;
      }
    }
    // Z
    if (step.z !== 0) {
      pos.z += step.z;
      const y0 = Math.floor(pos.y + EPS), y1 = Math.floor(pos.y + height - EPS);
      const x0 = Math.floor(pos.x - halfW + EPS), x1 = Math.floor(pos.x + halfW - EPS);
      const bz = Math.floor(pos.z + (step.z > 0 ? halfW : -halfW));
      let hit = false;
      for (let y = y0; y <= y1 && !hit; y++)
        for (let x = x0; x <= x1 && !hit; x++) if (solidAt(x, y, bz)) hit = true;
      if (hit) {
        pos.z = step.z > 0 ? bz - halfW - EPS : bz + 1 + halfW + EPS;
        vel.z = 0;
        res.hitZ = true;
        step.z = 0;
      }
    }
    // Y
    if (step.y !== 0) {
      pos.y += step.y;
      const x0 = Math.floor(pos.x - halfW + EPS), x1 = Math.floor(pos.x + halfW - EPS);
      const z0 = Math.floor(pos.z - halfW + EPS), z1 = Math.floor(pos.z + halfW - EPS);
      const by = Math.floor(step.y > 0 ? pos.y + height : pos.y);
      let hit = false;
      for (let x = x0; x <= x1 && !hit; x++)
        for (let z = z0; z <= z1 && !hit; z++) if (solidAt(x, by, z)) hit = true;
      if (hit) {
        if (step.y > 0) {
          pos.y = by - height - EPS;
          res.ceiling = true;
        } else {
          pos.y = by + 1 + EPS;
          res.onGround = true;
        }
        vel.y = 0;
        res.hitY = true;
        step.y = 0;
      }
    }
  }
  if (!res.onGround) {
    const y = Math.floor(pos.y - 0.02);
    const x0 = Math.floor(pos.x - halfW + EPS), x1 = Math.floor(pos.x + halfW - EPS);
    const z0 = Math.floor(pos.z - halfW + EPS), z1 = Math.floor(pos.z + halfW - EPS);
    outer: for (let x = x0; x <= x1; x++)
      for (let z = z0; z <= z1; z++)
        if (solidAt(x, y, z)) { res.onGround = true; break outer; }
  }
  return res;
}

export interface RayHit {
  x: number; y: number; z: number;
  nx: number; ny: number; nz: number;
  id: number;
  dist: number;
}

/** Amanatides & Woo voxel traversal. */
export function raycastVoxel(
  world: World,
  origin: THREE.Vector3,
  dir: THREE.Vector3,
  maxDist: number,
  hitLiquid = false,
): RayHit | null {
  let x = Math.floor(origin.x), y = Math.floor(origin.y), z = Math.floor(origin.z);
  const stepX = dir.x > 0 ? 1 : -1, stepY = dir.y > 0 ? 1 : -1, stepZ = dir.z > 0 ? 1 : -1;
  const tDeltaX = Math.abs(1 / (dir.x || 1e-9));
  const tDeltaY = Math.abs(1 / (dir.y || 1e-9));
  const tDeltaZ = Math.abs(1 / (dir.z || 1e-9));
  const fx = origin.x - x, fy = origin.y - y, fz = origin.z - z;
  let tMaxX = tDeltaX * (dir.x > 0 ? 1 - fx : fx);
  let tMaxY = tDeltaY * (dir.y > 0 ? 1 - fy : fy);
  let tMaxZ = tDeltaZ * (dir.z > 0 ? 1 - fz : fz);
  let nx = 0, ny = 0, nz = 0;
  let t = 0;
  for (let i = 0; i < 256; i++) {
    const id = world.getBlock(x, y, z);
    if (id !== 0) {
      const b = BLOCKS[id];
      if (b.solid || b.cross || (hitLiquid && b.liquid)) {
        return { x, y, z, nx, ny, nz, id, dist: t };
      }
    }
    if (tMaxX < tMaxY && tMaxX < tMaxZ) {
      x += stepX; t = tMaxX; tMaxX += tDeltaX; nx = -stepX; ny = 0; nz = 0;
    } else if (tMaxY < tMaxZ) {
      y += stepY; t = tMaxY; tMaxY += tDeltaY; nx = 0; ny = -stepY; nz = 0;
    } else {
      z += stepZ; t = tMaxZ; tMaxZ += tDeltaZ; nx = 0; ny = 0; nz = -stepZ;
    }
    if (t > maxDist) break;
    if (y < -1 || y > 200) break;
  }
  return null;
}

/** Ray vs axis aligned box, returns distance or null. */
export function rayBox(
  origin: THREE.Vector3, dir: THREE.Vector3,
  min: THREE.Vector3, max: THREE.Vector3, maxDist: number,
): number | null {
  let tmin = 0, tmax = maxDist;
  for (const ax of ['x', 'y', 'z'] as const) {
    const d = dir[ax];
    const o = origin[ax];
    if (Math.abs(d) < 1e-8) {
      if (o < min[ax] || o > max[ax]) return null;
    } else {
      let t1 = (min[ax] - o) / d;
      let t2 = (max[ax] - o) / d;
      if (t1 > t2) { const tmp = t1; t1 = t2; t2 = tmp; }
      tmin = Math.max(tmin, t1);
      tmax = Math.min(tmax, t2);
      if (tmin > tmax) return null;
    }
  }
  return tmin;
}
