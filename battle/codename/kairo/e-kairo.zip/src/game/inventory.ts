import { getItem } from './blocks';

export interface Stack { id: number; count: number }

export const HOTBAR = 9;
export const MAIN = 27;
export const TOTAL = HOTBAR + MAIN;

export class Inventory {
  slots: (Stack | null)[] = new Array(TOTAL).fill(null);
  craft: (Stack | null)[] = new Array(9).fill(null);
  cursor: Stack | null = null;
  selected = 0;

  get held(): Stack | null {
    return this.slots[this.selected];
  }

  clone(): Inventory {
    const i = new Inventory();
    i.slots = this.slots.map((s) => (s ? { ...s } : null));
    i.craft = this.craft.map((s) => (s ? { ...s } : null));
    i.selected = this.selected;
    return i;
  }

  count(id: number): number {
    let n = 0;
    for (const s of this.slots) if (s && s.id === id) n += s.count;
    return n;
  }

  /** Adds items, hotbar first. Returns the amount that did not fit. */
  add(id: number, count = 1): number {
    const max = getItem(id).stack;
    let left = count;
    for (let i = 0; i < TOTAL && left > 0; i++) {
      const s = this.slots[i];
      if (s && s.id === id && s.count < max) {
        const take = Math.min(max - s.count, left);
        s.count += take;
        left -= take;
      }
    }
    for (let i = 0; i < TOTAL && left > 0; i++) {
      if (!this.slots[i]) {
        const take = Math.min(max, left);
        this.slots[i] = { id, count: take };
        left -= take;
      }
    }
    return left;
  }

  remove(id: number, count = 1): boolean {
    if (this.count(id) < count) return false;
    let left = count;
    for (let i = TOTAL - 1; i >= 0 && left > 0; i--) {
      const s = this.slots[i];
      if (s && s.id === id) {
        const take = Math.min(s.count, left);
        s.count -= take;
        left -= take;
        if (s.count <= 0) this.slots[i] = null;
      }
    }
    return true;
  }

  consumeHeld(n = 1) {
    const s = this.slots[this.selected];
    if (!s) return;
    s.count -= n;
    if (s.count <= 0) this.slots[this.selected] = null;
  }

  firstEmpty(): number {
    return this.slots.findIndex((s) => s === null);
  }

  serialize() {
    return { slots: this.slots, craft: this.craft, selected: this.selected };
  }

  load(d: { slots?: (Stack | null)[]; selected?: number }) {
    if (d.slots) for (let i = 0; i < TOTAL; i++) this.slots[i] = d.slots[i] ?? null;
    if (d.selected != null) this.selected = Math.max(0, Math.min(HOTBAR - 1, d.selected));
  }

  /** Return crafting grid contents to the main inventory (on closing a table). */
  returnCraft() {
    for (let i = 0; i < 9; i++) {
      const s = this.craft[i];
      if (s) {
        const left = this.add(s.id, s.count);
        this.craft[i] = left > 0 ? { id: s.id, count: left } : null;
      }
    }
    if (this.cursor) {
      const left = this.add(this.cursor.id, this.cursor.count);
      this.cursor = left > 0 ? { id: this.cursor.id, count: left } : null;
    }
  }
}
