import { WorldGen } from './worldgen';
import { B, BLOCKS } from './blocks';
import { CX, CZ, WORLD_H, CHUNK_VOL, idx, chunkKey } from './constants';
import { BIOME_INFO } from './constants';
import type { NeighborData, LightSource } from './mesher';

export interface FurnaceState {
  input: { id: number; count: number } | null;
  fuel: { id: number; count: number } | null;
  output: { id: number; count: number } | null;
  burn: number;
  burnMax: number;
  cook: number;
}

export class Chunk {
  data: Uint8Array;
  height: Uint8Array;
  biome: Uint8Array;
  tint: Uint32Array;
  topY = 0;
  lights = new Set<number>();
  dirty = true;
  meshes: unknown = null;
  constructor(
    readonly cx: number,
    readonly cz: number,
    data: Uint8Array,
    height: Uint8Array,
    biome: Uint8Array,
  ) {
    this.data = data;
    this.height = height;
    this.biome = biome;
    this.tint = new Uint32Array(CX * CZ);
    for (let i = 0; i < CX * CZ; i++) this.tint[i] = BIOME_INFO[biome[i]].grass;
    this.recompute();
  }

  recompute() {
    let top = 0;
    this.lights.clear();
    for (let y = WORLD_H - 1; y >= 0; y--) {
      const row = y * CX * CZ;
      for (let i = 0; i < CX * CZ; i++) {
        const id = this.data[row + i];
        if (id === 0) continue;
        if (y > top) top = y;
        // lava is emissive but far too common to flood-fill: it glows locally in the mesher
        if (BLOCKS[id].light && id !== B.LAVA) this.lights.add(row + i);
      }
    }
    this.topY = Math.min(WORLD_H - 1, top + 1);
  }

  updateColumn(x: number, z: number) {
    let y = WORLD_H - 1;
    while (y > 0 && this.data[idx(x, y, z)] === 0) y--;
    this.height[x + z * CX] = y;
  }
}

export type EditMap = Map<string, Map<number, number>>;

export class World {
  chunks = new Map<string, Chunk>();
  gen: WorldGen;
  edits: EditMap = new Map();
  furnaces = new Map<string, FurnaceState>();
  dirty = new Set<string>();

  constructor(readonly seed: number) {
    this.gen = new WorldGen(seed);
  }

  get(cx: number, cz: number): Chunk | undefined {
    return this.chunks.get(chunkKey(cx, cz));
  }

  ensure(cx: number, cz: number): Chunk {
    const key = chunkKey(cx, cz);
    let c = this.chunks.get(key);
    if (c) return c;
    const res = this.gen.generateChunk(cx, cz);
    c = new Chunk(cx, cz, res.data, res.height, res.biome);
    const ed = this.edits.get(key);
    if (ed) {
      for (const [i, id] of ed) {
        c.data[i] = id;
        const y = Math.floor(i / (CX * CZ));
        const rem = i - y * CX * CZ;
        const z = Math.floor(rem / CX);
        const x = rem - z * CX;
        c.updateColumn(x, z);
      }
      c.recompute();
    }
    this.chunks.set(key, c);
    return c;
  }

  has(cx: number, cz: number) {
    return this.chunks.has(chunkKey(cx, cz));
  }

  getBlock(x: number, y: number, z: number): number {
    if (y < 0 || y >= WORLD_H) return 0;
    const cx = Math.floor(x / CX), cz = Math.floor(z / CZ);
    const c = this.chunks.get(chunkKey(cx, cz));
    if (!c) return 0;
    return c.data[idx(x - cx * CX, y, z - cz * CZ)];
  }

  /** Like getBlock but unloaded chunks read as solid so the player never falls out of the world. */
  getBlockSolid(x: number, y: number, z: number): number {
    if (y < 0) return B.BEDROCK;
    if (y >= WORLD_H) return 0;
    const cx = Math.floor(x / CX), cz = Math.floor(z / CZ);
    const c = this.chunks.get(chunkKey(cx, cz));
    if (!c) return B.STONE;
    return c.data[idx(x - cx * CX, y, z - cz * CZ)];
  }

  biomeAt(x: number, z: number): number {
    const cx = Math.floor(x / CX), cz = Math.floor(z / CZ);
    const c = this.chunks.get(chunkKey(cx, cz));
    if (!c) return 2;
    return c.biome[(x - cx * CX) + (z - cz * CZ) * CX];
  }

  surfaceY(x: number, z: number): number {
    const cx = Math.floor(x / CX), cz = Math.floor(z / CZ);
    const c = this.chunks.get(chunkKey(cx, cz));
    if (!c) return this.gen.heightAt(x, z, 0.5, 0.5);
    return c.height[(x - cx * CX) + (z - cz * CZ) * CX];
  }

  setBlock(x: number, y: number, z: number, id: number, record = true): boolean {
    if (y < 0 || y >= WORLD_H) return false;
    const cx = Math.floor(x / CX), cz = Math.floor(z / CZ);
    const c = this.chunks.get(chunkKey(cx, cz));
    if (!c) return false;
    const lx = x - cx * CX, lz = z - cz * CZ;
    const i = idx(lx, y, lz);
    const prev = c.data[i];
    if (prev === id) return false;
    c.data[i] = id;
    c.updateColumn(lx, lz);
    if (BLOCKS[id].light && id !== B.LAVA) c.lights.add(i);
    else c.lights.delete(i);
    if (y + 1 > c.topY) c.topY = Math.min(WORLD_H - 1, y + 2);
    if (record) {
      const key = chunkKey(cx, cz);
      let ed = this.edits.get(key);
      if (!ed) this.edits.set(key, (ed = new Map()));
      ed.set(i, id);
    }
    if (prev === B.FURNACE && id !== B.FURNACE) this.furnaces.delete(`${x},${y},${z}`);

    const radius = Math.max(BLOCKS[id].light ?? 0, BLOCKS[prev].light ?? 0);
    if (radius > 0) {
      for (let dx = -1; dx <= 1; dx++)
        for (let dz = -1; dz <= 1; dz++) this.markDirty(cx + dx, cz + dz);
    } else {
      this.markDirty(cx, cz);
      if (lx <= 1) this.markDirty(cx - 1, cz);
      if (lx >= CX - 2) this.markDirty(cx + 1, cz);
      if (lz <= 1) this.markDirty(cx, cz - 1);
      if (lz >= CZ - 2) this.markDirty(cx, cz + 1);
    }
    return true;
  }

  markDirty(cx: number, cz: number) {
    const k = chunkKey(cx, cz);
    const c = this.chunks.get(k);
    if (c) {
      c.dirty = true;
      this.dirty.add(k);
    }
  }

  neighbors(cx: number, cz: number): NeighborData {
    const g = (dx: number, dz: number) => this.chunks.get(chunkKey(cx + dx, cz + dz))?.data ?? null;
    return {
      east: g(1, 0), west: g(-1, 0), south: g(0, 1), north: g(0, -1),
      se: g(1, 1), sw: g(1, -1), ne: g(-1, 1), nw: g(-1, -1),
    };
  }

  neighborsReady(cx: number, cz: number): boolean {
    return (
      this.has(cx + 1, cz) && this.has(cx - 1, cz) && this.has(cx, cz + 1) && this.has(cx, cz - 1)
    );
  }

  lightsNear(cx: number, cz: number): LightSource[] {
    const out: LightSource[] = [];
    for (let dx = -1; dx <= 1; dx++) {
      for (let dz = -1; dz <= 1; dz++) {
        const c = this.chunks.get(chunkKey(cx + dx, cz + dz));
        if (!c || c.lights.size === 0) continue;
        for (const i of c.lights) {
          const y = Math.floor(i / (CX * CZ));
          const rem = i - y * CX * CZ;
          const z = Math.floor(rem / CX);
          const x = rem - z * CX;
          const id = c.data[i];
          const lvl = BLOCKS[id].light;
          if (!lvl) continue;
          out.push({ x: c.cx * CX + x + 0.5, y: y + 0.5, z: c.cz * CZ + z + 0.5, level: lvl });
        }
      }
    }
    return out;
  }

  unload(cx: number, cz: number) {
    this.chunks.delete(chunkKey(cx, cz));
  }

  serializeEdits(): Record<string, number[]> {
    const out: Record<string, number[]> = {};
    for (const [k, m] of this.edits) {
      const arr: number[] = [];
      for (const [i, id] of m) arr.push(i, id);
      out[k] = arr;
    }
    return out;
  }

  loadEdits(data: Record<string, number[]>) {
    this.edits.clear();
    for (const k of Object.keys(data)) {
      const arr = data[k];
      const m = new Map<number, number>();
      for (let i = 0; i < arr.length; i += 2) m.set(arr[i], arr[i + 1]);
      this.edits.set(k, m);
    }
  }

  get editCount() {
    let n = 0;
    for (const m of this.edits.values()) n += m.size;
    return n;
  }
}

export const chunkVolume = CHUNK_VOL;
