/** Voxel chunk mesher: face culling, ambient occlusion, smooth sky + block light. */
import { BLOCKS } from './blocks';
import { CX, CZ, WORLD_H, idx } from './constants';
import { tileUV } from './textures';

export interface MeshData {
  position: Float32Array;
  uv: Float32Array;
  color: Uint8Array;
  light: Uint8Array;
  index: Uint32Array;
  count: number;
}
export interface MeshResult {
  solid: MeshData | null;
  cross: MeshData | null;
  water: MeshData | null;
}

const PX = CX + 2;
const PZ = CZ + 2;
const PY = WORLD_H + 2;
const pidx = (x: number, y: number, z: number) => x + 1 + PX * (z + 1 + PZ * (y + 1));
const PVOL = PX * PZ * PY;

const padded = new Uint8Array(PVOL);
const skyArr = new Uint8Array(PVOL);
const torchArr = new Uint8Array(PVOL);
const queue = new Int32Array(PVOL * 3);

class Builder {
  pos = new Float32Array(1 << 15);
  uv = new Float32Array(1 << 14);
  col = new Uint8Array(1 << 15);
  lit = new Uint8Array(1 << 14);
  idx = new Uint32Array(1 << 15);
  vn = 0;
  inn = 0;

  reset() { this.vn = 0; this.inn = 0; }

  private grow() {
    const p = new Float32Array(this.pos.length * 2); p.set(this.pos); this.pos = p;
    const u = new Float32Array(this.uv.length * 2); u.set(this.uv); this.uv = u;
    const c = new Uint8Array(this.col.length * 2); c.set(this.col); this.col = c;
    const l = new Uint8Array(this.lit.length * 2); l.set(this.lit); this.lit = l;
    const i = new Uint32Array(this.idx.length * 2); i.set(this.idx); this.idx = i;
  }

  /** one vertex: position, uv, rgb tint (0-255), sky/torch (0-255) */
  vert(x: number, y: number, z: number, u: number, v: number, r: number, g: number, b: number, l0: number, l1: number) {
    const n = this.vn;
    if ((n + 1) * 3 > this.pos.length) this.grow();
    const p = n * 3, q = n * 2;
    this.pos[p] = x; this.pos[p + 1] = y; this.pos[p + 2] = z;
    this.uv[q] = u; this.uv[q + 1] = v;
    this.col[p] = r; this.col[p + 1] = g; this.col[p + 2] = b;
    this.lit[q] = l0; this.lit[q + 1] = l1;
    this.vn = n + 1;
  }

  quad(base: number, flip: boolean) {
    if (this.inn + 6 > this.idx.length) this.grow();
    const i = this.inn;
    if (flip) {
      this.idx[i] = base; this.idx[i + 1] = base + 1; this.idx[i + 2] = base + 2;
      this.idx[i + 3] = base; this.idx[i + 4] = base + 2; this.idx[i + 5] = base + 3;
    } else {
      this.idx[i] = base + 1; this.idx[i + 1] = base + 2; this.idx[i + 2] = base + 3;
      this.idx[i + 3] = base + 1; this.idx[i + 4] = base + 3; this.idx[i + 5] = base;
    }
    this.inn = i + 6;
  }
}
const solidB = new Builder();
const crossB = new Builder();
const waterB = new Builder();

const FACES = [
  { n: [1, 0, 0], v: [[1, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]], shade: 0.74, t: [1, 2] },
  { n: [-1, 0, 0], v: [[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]], shade: 0.74, t: [1, 2] },
  { n: [0, 1, 0], v: [[0, 1, 1], [1, 1, 1], [1, 1, 0], [0, 1, 0]], shade: 1.0, t: [0, 2] },
  { n: [0, -1, 0], v: [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]], shade: 0.5, t: [0, 2] },
  { n: [0, 0, 1], v: [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]], shade: 0.88, t: [0, 1] },
  { n: [0, 0, -1], v: [[1, 0, 0], [0, 0, 0], [0, 1, 0], [1, 1, 0]], shade: 0.88, t: [0, 1] },
];
const AO_LEVELS = [0.44, 0.64, 0.83, 1.0];

export interface LightSource { x: number; y: number; z: number; level: number }

export interface NeighborData {
  east: Uint8Array | null;
  west: Uint8Array | null;
  south: Uint8Array | null;
  north: Uint8Array | null;
  se: Uint8Array | null;
  sw: Uint8Array | null;
  ne: Uint8Array | null;
  nw: Uint8Array | null;
}

function finish(b: Builder): MeshData | null {
  if (b.inn === 0) return null;
  return {
    position: b.pos.slice(0, b.vn * 3),
    uv: b.uv.slice(0, b.vn * 2),
    color: b.col.slice(0, b.vn * 3),
    light: b.lit.slice(0, b.vn * 2),
    index: b.idx.slice(0, b.inn),
    count: b.inn,
  };
}

function fillPadded(data: Uint8Array, nb: NeighborData) {
  padded.fill(0);
  for (let y = 0; y < WORLD_H; y++) {
    for (let z = 0; z < CZ; z++) {
      const src = idx(0, y, z);
      padded.set(data.subarray(src, src + CX), pidx(0, y, z));
    }
  }
  for (let y = 0; y < WORLD_H; y++) {
    if (nb.east) for (let z = 0; z < CZ; z++) padded[pidx(CX, y, z)] = nb.east[idx(0, y, z)];
    if (nb.west) for (let z = 0; z < CZ; z++) padded[pidx(-1, y, z)] = nb.west[idx(CX - 1, y, z)];
    if (nb.south) for (let x = 0; x < CX; x++) padded[pidx(x, y, CZ)] = nb.south[idx(x, y, 0)];
    if (nb.north) for (let x = 0; x < CX; x++) padded[pidx(x, y, -1)] = nb.north[idx(x, y, CZ - 1)];
    if (nb.se) padded[pidx(CX, y, CZ)] = nb.se[idx(0, y, 0)];
    if (nb.sw) padded[pidx(CX, y, -1)] = nb.sw[idx(0, y, CZ - 1)];
    if (nb.ne) padded[pidx(-1, y, CZ)] = nb.ne[idx(CX - 1, y, 0)];
    if (nb.nw) padded[pidx(-1, y, -1)] = nb.nw[idx(CX - 1, y, CZ - 1)];
  }
}

/** Vertical sunlight + horizontal flood so cave mouths and overhangs shade softly. */
function computeSky(limitY: number) {
  skyArr.fill(0);
  const top = Math.min(WORLD_H, limitY + 1);
  let qh = 0, qt = 0;
  for (let z = -1; z <= CZ; z++) {
    for (let x = -1; x <= CX; x++) {
      let light = 15;
      for (let y = WORLD_H; y >= -1; y--) {
        const id = padded[pidx(x, y, z)];
        const b = BLOCKS[id];
        if (b.opaque) light = 0;
        else if (id !== 0 && (b.liquid || b.cutout)) light = Math.max(0, light - (b.liquid ? 2 : 1));
        const p = pidx(x, y, z);
        skyArr[p] = light;
        if (light === 15 && y <= top) queue[qt++] = p;
      }
    }
  }
  while (qh < qt) {
    const p = queue[qh++];
    const level = skyArr[p];
    if (level <= 1) continue;
    const y = Math.floor(p / (PX * PZ)) - 1;
    const rem = p - (y + 1) * PX * PZ;
    const z = Math.floor(rem / PX) - 1;
    const x = rem - (z + 1) * PX - 1;
    for (let f = 0; f < 6; f++) {
      const n = FACES[f].n;
      const nx2 = x + n[0], ny2 = y + n[1], nz2 = z + n[2];
      if (nx2 < -1 || nx2 > CX || nz2 < -1 || nz2 > CZ || ny2 < -1 || ny2 > top) continue;
      const np = pidx(nx2, ny2, nz2);
      if (BLOCKS[padded[np]].opaque) continue;
      const atten = BLOCKS[padded[np]].liquid ? 3 : 1;
      const nl = level - atten;
      if (nl > skyArr[np]) {
        skyArr[np] = nl;
        if (qt < queue.length) queue[qt++] = np;
      }
    }
  }
}

/** Torch / glowstone / lava lighting with a cheap line-of-sight test. */
function computeTorch(cx: number, cz: number, lights: LightSource[], limitY: number) {
  torchArr.fill(0);
  const ox = cx * CX, oz = cz * CZ;
  for (let li = 0; li < lights.length; li++) {
    const L = lights[li];
    const lx = L.x - ox, ly = L.y, lz = L.z - oz;
    const rad = L.level;
    const x0 = Math.max(-1, Math.floor(lx - rad)), x1 = Math.min(CX, Math.ceil(lx + rad));
    const z0 = Math.max(-1, Math.floor(lz - rad)), z1 = Math.min(CZ, Math.ceil(lz + rad));
    const y0 = Math.max(-1, Math.floor(ly - rad)), y1 = Math.min(Math.min(WORLD_H, limitY + 2), Math.ceil(ly + rad));
    for (let y = y0; y <= y1; y++) {
      for (let z = z0; z <= z1; z++) {
        for (let x = x0; x <= x1; x++) {
          const d = Math.sqrt((x - lx) * (x - lx) + (y - ly) * (y - ly) + (z - lz) * (z - lz));
          if (d > rad) continue;
          let v = Math.round(L.level * (1 - d / rad) * (1 - d / rad) * 1.35);
          if (v <= 0) continue;
          const p = pidx(x, y, z);
          if (v <= torchArr[p]) continue;
          if (d > 1.5) {
            let blocked = 0;
            for (let s = 1; s <= 3; s++) {
              const t = s / 4;
              const sx = Math.round(lx + (x - lx) * t);
              const sy = Math.round(ly + (y - ly) * t);
              const sz = Math.round(lz + (z - lz) * t);
              if (sx < -1 || sx > CX || sz < -1 || sz > CZ || sy < -1 || sy > WORLD_H) continue;
              if (BLOCKS[padded[pidx(sx, sy, sz)]].opaque) blocked++;
            }
            if (blocked) v = Math.round(v * (blocked >= 2 ? 0.12 : 0.4));
          }
          if (v > torchArr[p]) torchArr[p] = Math.min(15, v);
        }
      }
    }
  }
}

const AO_SOLID = new Uint8Array(64);
for (let i = 0; i < 64; i++) {
  const b = BLOCKS[i];
  AO_SOLID[i] = b && (b.opaque || (b.cutout && !b.cross && !b.liquid)) ? 1 : 0;
}

/** Constant AO sample offsets per face/vertex, relative to the face-adjacent cell. */
const AO_OFF: number[][][][] = FACES.map((F) =>
  F.v.map((v) => {
    const ta = F.t[0], tb = F.t[1];
    const s1 = v[ta] === 1 ? 1 : -1;
    const s2 = v[tb] === 1 ? 1 : -1;
    const o1 = [0, 0, 0]; o1[ta] = s1;
    const o2 = [0, 0, 0]; o2[tb] = s2;
    const o3 = [0, 0, 0]; o3[ta] = s1; o3[tb] = s2;
    return [o1, o2, o3];
  }),
);

/** Flat UV table: blockId * 24 + face * 4 */
const BLOCK_UV = new Float32Array(64 * 24);
for (let i = 0; i < 64; i++) {
  const b = BLOCKS[i];
  if (!b) continue;
  for (let f = 0; f < 6; f++) {
    const r = tileUV(b.tiles[f]);
    BLOCK_UV[i * 24 + f * 4] = r[0];
    BLOCK_UV[i * 24 + f * 4 + 1] = r[1];
    BLOCK_UV[i * 24 + f * 4 + 2] = r[2];
    BLOCK_UV[i * 24 + f * 4 + 3] = r[3];
  }
}

export const meshTiming = { fill: 0, sky: 0, torch: 0, faces: 0, calls: 0 };

export function buildChunkMesh(
  data: Uint8Array,
  nb: NeighborData,
  cx: number,
  cz: number,
  lights: LightSource[],
  grassTint: Uint32Array,
  topY: number,
): MeshResult {
  const T0 = performance.now();
  fillPadded(data, nb);
  const limitY = Math.min(WORLD_H - 1, topY + 1);
  const T1 = performance.now();
  computeSky(limitY);
  const T2 = performance.now();
  computeTorch(cx, cz, lights, limitY);
  const T3 = performance.now();
  meshTiming.fill += T1 - T0;
  meshTiming.sky += T2 - T1;
  meshTiming.torch += T3 - T2;
  meshTiming.calls++;

  solidB.reset();
  crossB.reset();
  waterB.reset();
  const solid = solidB, cross = crossB, water = waterB;
  const ao = [0, 0, 0, 0];
  const sv = [0, 0, 0, 0];
  const tv = [0, 0, 0, 0];

  for (let y = 0; y <= limitY; y++) {
    for (let z = 0; z < CZ; z++) {
      for (let x = 0; x < CX; x++) {
        const id = data[idx(x, y, z)];
        if (id === 0) continue;
        const b = BLOCKS[id];
        const tint = grassTint[x + z * CX];
        const here = pidx(x, y, z);

        if (b.cross) {
          const isTorch = b.light != null && b.light > 0;
          const inset = isTorch ? 0.32 : 0.12;
          const hgt = isTorch ? 0.72 : 1;
          const [u0, v0, du, dv] = tileUV(b.tiles[0]);
          const skyV = isTorch ? 0 : skyArr[here] / 15;
          const torchV = isTorch ? 1 : Math.max(torchArr[here] / 15, 0.05);
          const tr = b.tint != null ? ((tint >> 16) & 255) / 255 : 1;
          const tg = b.tint != null ? ((tint >> 8) & 255) / 255 : 1;
          const tb = b.tint != null ? (tint & 255) / 255 : 1;
          const quads = [
            [[inset, 0, inset], [1 - inset, 0, 1 - inset], [1 - inset, hgt, 1 - inset], [inset, hgt, inset]],
            [[1 - inset, 0, inset], [inset, 0, 1 - inset], [inset, hgt, 1 - inset], [1 - inset, hgt, inset]],
          ];
          const cr255 = (tr * 255) | 0, cg255 = (tg * 255) | 0, cb255 = (tb * 255) | 0;
          const sl = (skyV * 255) | 0, tl = (torchV * 255) | 0;
          for (const q of quads) {
            const base = cross.vn;
            cross.vert(x + q[0][0], y + q[0][1], z + q[0][2], u0, v0, cr255, cg255, cb255, sl, tl);
            cross.vert(x + q[1][0], y + q[1][1], z + q[1][2], u0 + du, v0, cr255, cg255, cb255, sl, tl);
            cross.vert(x + q[2][0], y + q[2][1], z + q[2][2], u0 + du, v0 + dv, cr255, cg255, cb255, sl, tl);
            cross.vert(x + q[3][0], y + q[3][1], z + q[3][2], u0, v0 + dv, cr255, cg255, cb255, sl, tl);
            cross.quad(base, true);
          }
          continue;
        }

        const isWater = id === 14;
        const target = isWater ? water : solid;
        const lowerTop = isWater && padded[pidx(x, y + 1, z)] !== 14;

        for (let f = 0; f < 6; f++) {
          const F = FACES[f];
          const nx = x + F.n[0], ny = y + F.n[1], nz = z + F.n[2];
          if (ny < 0 || ny > WORLD_H) continue;
          const np = pidx(nx, ny, nz);
          const nid = padded[np];
          const nbb = BLOCKS[nid];
          if (nbb.opaque) continue;
          if (nid === id && (b.cutout || b.liquid)) continue;
          if (b.liquid && nbb.liquid) continue;
          if (isWater && f === 3) continue;

          let skyBase = skyArr[np], torchBase = torchArr[np];
          if (AO_SOLID[nid]) { skyBase = skyArr[here]; torchBase = torchArr[here]; }
          if (nid === 40 || padded[here] === 40) torchBase = Math.max(torchBase, 13);
          const offs = AO_OFF[f];
          for (let i = 0; i < 4; i++) {
            const of = offs[i];
            const x1 = nx + of[0][0], y1 = ny + of[0][1], z1 = nz + of[0][2];
            const x2 = nx + of[1][0], y2 = ny + of[1][1], z2 = nz + of[1][2];
            const x3 = nx + of[2][0], y3 = ny + of[2][1], z3 = nz + of[2][2];
            const p1 = (x1 >= -1 && x1 <= CX && z1 >= -1 && z1 <= CZ && y1 >= -1 && y1 <= WORLD_H) ? pidx(x1, y1, z1) : -1;
            const p2 = (x2 >= -1 && x2 <= CX && z2 >= -1 && z2 <= CZ && y2 >= -1 && y2 <= WORLD_H) ? pidx(x2, y2, z2) : -1;
            const p3 = (x3 >= -1 && x3 <= CX && z3 >= -1 && z3 <= CZ && y3 >= -1 && y3 <= WORLD_H) ? pidx(x3, y3, z3) : -1;
            const c1 = p1 >= 0 ? AO_SOLID[padded[p1]] : 0;
            const c2 = p2 >= 0 ? AO_SOLID[padded[p2]] : 0;
            const c3 = p3 >= 0 ? AO_SOLID[padded[p3]] : 0;
            ao[i] = c1 && c2 ? 0 : 3 - (c1 + c2 + c3);
            let ss = skyBase, ts = torchBase, cnt = 1;
            if (p1 >= 0 && !c1) { ss += skyArr[p1]; ts += padded[p1] === 40 ? 13 : torchArr[p1]; cnt++; }
            if (p2 >= 0 && !c2) { ss += skyArr[p2]; ts += padded[p2] === 40 ? 13 : torchArr[p2]; cnt++; }
            if (p3 >= 0 && !c3) { ss += skyArr[p3]; ts += padded[p3] === 40 ? 13 : torchArr[p3]; cnt++; }
            sv[i] = ss / cnt / 15;
            tv[i] = ts / cnt / 15;
          }

          const useTint = b.tint != null && (!b.tintFaces || b.tintFaces.indexOf(f) >= 0);
          const baseCol = useTint ? (b.id === 6 ? tint : b.tint ?? 0xffffff) : 0xffffff;
          const cr = ((baseCol >> 16) & 255) / 255;
          const cg = ((baseCol >> 8) & 255) / 255;
          const cb = (baseCol & 255) / 255;
          const uvo = id * 24 + f * 4;
          const u0 = BLOCK_UV[uvo], v0 = BLOCK_UV[uvo + 1], du = BLOCK_UV[uvo + 2], dv = BLOCK_UV[uvo + 3];
          const base = target.vn;
          const emissive = b.light != null && b.light >= 15;
          const torchFloor = b.light ? 0.9 : 0;
          for (let i = 0; i < 4; i++) {
            const v = F.v[i];
            const vy = lowerTop && v[1] === 1 ? 0.875 : v[1];
            const sh = emissive ? 1 : F.shade * AO_LEVELS[ao[i]];
            target.vert(
              x + v[0], y + vy, z + v[2],
              i === 0 || i === 3 ? u0 : u0 + du,
              i < 2 ? v0 : v0 + dv,
              (cr * sh * 255) | 0, (cg * sh * 255) | 0, (cb * sh * 255) | 0,
              ((emissive ? 1 : sv[i]) * 255) | 0,
              ((emissive ? 1 : Math.max(tv[i], torchFloor)) * 255) | 0,
            );
          }
          target.quad(base, ao[0] + ao[2] > ao[1] + ao[3]);
        }
      }
    }
  }

  meshTiming.faces += performance.now() - T3;
  return { solid: finish(solid), cross: finish(cross), water: finish(water) };
}
