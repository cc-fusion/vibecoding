/** Procedural 16x16 pixel-art atlas. No external image assets are used anywhere. */
import { mulberry32 } from './noise';
import { BLOCKS, ITEMS, getItem } from './blocks';

export const TILE = 16;
export const PAD = 4;
export const CELL = TILE + PAD * 2; // 24
export const GRID = 10;
export const ATLAS_SIZE = CELL * GRID; // 240

type Ctx = CanvasRenderingContext2D;
type Painter = (c: Ctx, r: () => number) => void;

const tileCanvases = new Map<string, HTMLCanvasElement>();
export const tileIndex = new Map<string, number>();
export const uvRects = new Map<string, [number, number, number, number]>();
let atlasCanvas: HTMLCanvasElement | null = null;

function hex(h: number): [number, number, number] {
  return [(h >> 16) & 255, (h >> 8) & 255, h & 255];
}
function shade(h: number, d: number): string {
  const [r, g, b] = hex(h);
  const cl = (v: number) => Math.max(0, Math.min(255, Math.round(v)));
  return `rgb(${cl(r + d)},${cl(g + d)},${cl(b + d)})`;
}
function px(c: Ctx, x: number, y: number, color: string) {
  c.fillStyle = color;
  c.fillRect(x, y, 1, 1);
}
function rect(c: Ctx, x: number, y: number, w: number, h: number, color: string) {
  c.fillStyle = color;
  c.fillRect(x, y, w, h);
}
function noisy(c: Ctx, r: () => number, base: number, amp: number, x0 = 0, y0 = 0, w = 16, h = 16) {
  for (let y = y0; y < y0 + h; y++)
    for (let x = x0; x < x0 + w; x++) px(c, x, y, shade(base, (r() - 0.5) * 2 * amp));
}
function specks(c: Ctx, r: () => number, color: number, count: number, amp = 0) {
  for (let i = 0; i < count; i++) {
    const x = (r() * 16) | 0, y = (r() * 16) | 0;
    px(c, x, y, shade(color, (r() - 0.5) * amp));
  }
}
function ascii(c: Ctx, rows: string[], colors: Record<string, string>) {
  for (let y = 0; y < rows.length; y++)
    for (let x = 0; x < rows[y].length; x++) {
      const ch = rows[y][x];
      if (colors[ch]) px(c, x, y, colors[ch]);
    }
}
/** irregular ore blobs */
function oreBlobs(c: Ctx, r: () => number, color: number, hi: number) {
  const spots = 4 + ((r() * 3) | 0);
  for (let i = 0; i < spots; i++) {
    const cx = 2 + r() * 12, cy = 2 + r() * 12, rad = 1.3 + r() * 1.5;
    for (let y = 0; y < 16; y++)
      for (let x = 0; x < 16; x++) {
        const d = Math.hypot(x + 0.5 - cx, y + 0.5 - cy);
        if (d < rad) px(c, x, y, shade(color, d < rad * 0.55 ? 18 : -14));
      }
    px(c, Math.round(cx - 1), Math.round(cy - 1), shade(hi, 20));
  }
}
function plankTile(c: Ctx, r: () => number, base: number) {
  noisy(c, r, base, 10);
  for (let y = 0; y < 16; y++) {
    if (y % 4 === 3) rect(c, 0, y, 16, 1, shade(base, -42));
    else if (y % 4 === 0) rect(c, 0, y, 16, 1, shade(base, 14));
    for (let i = 0; i < 3; i++) {
      const x = (r() * 16) | 0;
      px(c, x, y, shade(base, -18 - r() * 12));
    }
  }
  for (let b = 0; b < 4; b++) {
    const x = ((b * 5 + 3) % 16) | 0;
    rect(c, x, b * 4, 1, 3, shade(base, -30));
  }
}
function logSide(c: Ctx, r: () => number, base: number, dark: number) {
  noisy(c, r, base, 8);
  for (let x = 0; x < 16; x++) {
    const v = Math.sin(x * 1.7) * 0.5 + r() * 0.5;
    if (v > 0.55) rect(c, x, 0, 1, 16, shade(dark, (r() - 0.5) * 12));
    if (v < 0.15) rect(c, x, 0, 1, 16, shade(base, 14));
  }
  for (let i = 0; i < 10; i++) {
    const x = (r() * 16) | 0, y = (r() * 16) | 0;
    rect(c, x, y, 1, 1 + ((r() * 3) | 0), shade(dark, -10));
  }
}
function logTop(c: Ctx, r: () => number, base: number, ring: number) {
  noisy(c, r, base, 8);
  for (let y = 0; y < 16; y++)
    for (let x = 0; x < 16; x++) {
      const d = Math.hypot(x - 7.5, y - 7.5);
      const s = Math.sin(d * 2.1) * 0.5 + 0.5;
      if (s > 0.6) px(c, x, y, shade(ring, (r() - 0.5) * 10));
      if (d > 7.2) px(c, x, y, shade(base, -40));
    }
  px(c, 8, 8, shade(ring, -30));
}
function leafTile(c: Ctx, r: () => number, gray: number) {
  c.clearRect(0, 0, 16, 16);
  for (let y = 0; y < 16; y++)
    for (let x = 0; x < 16; x++) {
      const n = r();
      if (n < 0.14) continue; // holes
      const v = gray + (n - 0.5) * 70;
      px(c, x, y, shade(0xffffff, v - 255));
    }
  for (let i = 0; i < 14; i++) {
    const x = (r() * 15) | 0, y = (r() * 15) | 0;
    px(c, x, y, `rgba(0,0,0,0.28)`);
    px(c, x + 1, y + 1, `rgba(255,255,255,0.16)`);
  }
}
function crossPlant(c: Ctx, r: () => number, color: number, kind: 'grass' | 'flower' | 'bush' | 'sapling', petal = 0xe0403a) {
  c.clearRect(0, 0, 16, 16);
  if (kind === 'grass') {
    for (let i = 0; i < 9; i++) {
      const x = 1 + ((r() * 14) | 0);
      const h = 5 + ((r() * 8) | 0);
      for (let y = 0; y < h; y++) {
        const xx = x + Math.round(Math.sin(y * 0.4 + i) * 1.2);
        px(c, xx, 15 - y, shade(color, -40 + (y / h) * 70 + (r() - 0.5) * 20));
      }
    }
  } else if (kind === 'flower') {
    for (let y = 0; y < 8; y++) px(c, 8 + (y > 4 ? 0 : 0), 15 - y, shade(0x4f8f36, -10 + y * 3));
    px(c, 6, 10, shade(0x4f8f36, 10));
    px(c, 7, 10, shade(0x4f8f36, 0));
    px(c, 10, 12, shade(0x4f8f36, 10));
    px(c, 9, 12, shade(0x4f8f36, 0));
    const petals = [[7, 4], [8, 4], [9, 4], [6, 5], [7, 5], [8, 5], [9, 5], [10, 5], [6, 6], [7, 6], [8, 6], [9, 6], [10, 6], [7, 7], [8, 7], [9, 7]];
    for (const [x, y] of petals) px(c, x, y, shade(petal, (r() - 0.5) * 30));
    px(c, 8, 5, shade(0xffe066, 0));
    px(c, 8, 6, shade(0xffcc33, 0));
  } else if (kind === 'bush') {
    for (let i = 0; i < 7; i++) {
      const x = 3 + ((r() * 10) | 0);
      const h = 4 + ((r() * 7) | 0);
      for (let y = 0; y < h; y++) px(c, x + ((y * 0.3) | 0) * (i % 2 ? 1 : -1), 15 - y, shade(color, (r() - 0.5) * 30));
    }
  } else {
    rect(c, 7, 9, 2, 7, shade(0x6b4a2a, 0));
    for (let y = 0; y < 8; y++)
      for (let x = 0; x < 16; x++) {
        const d = Math.hypot(x - 7.5, (y - 5) * 1.2);
        if (d < 4.4 && r() > 0.22) px(c, x, y, shade(color, (r() - 0.5) * 60));
      }
  }
}

const P: Record<string, Painter> = {
  stone: (c, r) => { noisy(c, r, 0x8b8b91, 16); specks(c, r, 0x6f6f76, 26, 20); specks(c, r, 0xa3a3a8, 14, 10); },
  bedrock: (c, r) => {
    noisy(c, r, 0x4a4a52, 26);
    for (let i = 0; i < 22; i++) {
      const x = (r() * 14) | 0, y = (r() * 14) | 0, s = 2 + ((r() * 2) | 0);
      rect(c, x, y, s, s, shade(0x2c2c33, (r() - 0.5) * 40));
    }
  },
  cobble: (c, r) => {
    noisy(c, r, 0x5d5d64, 8);
    const stones = [[0, 0, 7, 5], [8, 0, 8, 4], [0, 6, 4, 5], [5, 5, 6, 6], [12, 5, 4, 7], [0, 12, 7, 4], [8, 12, 8, 4], [11, 0, 5, 4]];
    for (const [x, y, w, h] of stones) {
      const base = 0x8b8b92 + (((r() * 24) | 0) << 16) * 0;
      noisy(c, r, base, 18, x, y, w, h);
      rect(c, x, y + h - 1, w, 1, shade(0x4a4a50, 0));
      rect(c, x, y, w, 1, shade(0xa8a8ae, 0));
    }
  },
  mossy_cobble: (c, r) => {
    P.cobble(c, r);
    for (let y = 0; y < 16; y++)
      for (let x = 0; x < 16; x++) if (r() < 0.42) px(c, x, y, shade(0x5d8f42, (r() - 0.5) * 40));
  },
  dirt: (c, r) => { noisy(c, r, 0x8a6242, 20); specks(c, r, 0x6b4a30, 24, 20); specks(c, r, 0xa07a54, 12, 14); },
  grass_top: (c, r) => {
    noisy(c, r, 0xb8b8b8, 22);
    for (let i = 0; i < 40; i++) {
      const x = (r() * 16) | 0, y = (r() * 16) | 0;
      px(c, x, y, shade(0xd8d8d8, (r() - 0.5) * 20));
      px(c, x, (y + 1) % 16, shade(0x909090, 0));
    }
  },
  grass_side: (c, r) => {
    noisy(c, r, 0x8a6242, 20);
    specks(c, r, 0x6b4a30, 18, 16);
    for (let x = 0; x < 16; x++) {
      const h = 3 + ((r() * 3) | 0);
      for (let y = 0; y < h; y++) px(c, x, y, shade(0x6faa3c, (r() - 0.5) * 34 - y * 4));
      px(c, x, h, shade(0x568a2e, (r() - 0.5) * 20));
    }
  },
  grass_snow_side: (c, r) => {
    noisy(c, r, 0x8a6242, 20);
    for (let x = 0; x < 16; x++) {
      const h = 3 + ((r() * 3) | 0);
      for (let y = 0; y < h; y++) px(c, x, y, shade(0xf2f7ff, (r() - 0.5) * 14));
    }
  },
  sand: (c, r) => { noisy(c, r, 0xe0d29a, 14); specks(c, r, 0xc9b87e, 26, 12); },
  sandstone_top: (c, r) => { noisy(c, r, 0xdfd29c, 10); specks(c, r, 0xc6b682, 20, 10); },
  sandstone_side: (c, r) => {
    noisy(c, r, 0xdfd29c, 8);
    rect(c, 0, 0, 16, 3, shade(0xe8dcab, 0));
    rect(c, 0, 3, 16, 1, shade(0xbfae78, 0));
    rect(c, 0, 12, 16, 1, shade(0xbfae78, 0));
    for (let i = 0; i < 24; i++) px(c, (r() * 16) | 0, 4 + ((r() * 8) | 0), shade(0xcfc08a, (r() - 0.5) * 20));
  },
  gravel: (c, r) => {
    noisy(c, r, 0x8a8580, 22);
    for (let i = 0; i < 26; i++) {
      const x = (r() * 15) | 0, y = (r() * 15) | 0;
      rect(c, x, y, 2, 2, shade(0x6e6a66, (r() - 0.5) * 50));
      px(c, x, y, shade(0xa8a49e, (r() - 0.5) * 30));
    }
  },
  clay: (c, r) => { noisy(c, r, 0xa3a8b4, 12); specks(c, r, 0x8f95a3, 20, 10); },
  snow: (c, r) => { noisy(c, r, 0xf4f8ff, 8); specks(c, r, 0xdde8f7, 16, 8); },
  ice: (c, r) => {
    noisy(c, r, 0x9dc9f2, 12);
    for (let i = 0; i < 7; i++) {
      let x = (r() * 16) | 0, y = (r() * 16) | 0;
      for (let s = 0; s < 7; s++) {
        px(c, x, y, shade(0xd6ecff, 0));
        x = (x + (r() < 0.5 ? 1 : 0)) % 16;
        y = (y + 1) % 16;
      }
    }
  },
  water: (c, r) => {
    noisy(c, r, 0x2f6fd0, 12);
    for (let i = 0; i < 22; i++) {
      const x = (r() * 16) | 0, y = (r() * 16) | 0;
      rect(c, x, y, 2 + ((r() * 3) | 0), 1, shade(0x5b9ceb, (r() - 0.5) * 20));
    }
  },
  lava: (c, r) => {
    noisy(c, r, 0xe8631a, 26);
    for (let i = 0; i < 20; i++) {
      const x = (r() * 16) | 0, y = (r() * 16) | 0;
      rect(c, x, y, 2 + ((r() * 3) | 0), 2, shade(0xffc23d, (r() - 0.5) * 40));
    }
    specks(c, r, 0x7a2a06, 14, 20);
  },
  oak_log_side: (c, r) => logSide(c, r, 0x6d5233, 0x4e3a24),
  oak_log_top: (c, r) => logTop(c, r, 0x9c7a4c, 0x7a5c37),
  birch_log_side: (c, r) => {
    logSide(c, r, 0xd8d3c4, 0xb9b3a2);
    for (let i = 0; i < 6; i++) {
      const y = (r() * 15) | 0, x = (r() * 12) | 0;
      rect(c, x, y, 2 + ((r() * 3) | 0), 1, shade(0x3a3630, (r() - 0.5) * 20));
    }
  },
  birch_log_top: (c, r) => logTop(c, r, 0xd6ceb4, 0xb3a98c),
  oak_leaves: (c, r) => leafTile(c, r, 190),
  birch_leaves: (c, r) => leafTile(c, r, 215),
  planks: (c, r) => plankTile(c, r, 0xb0854f),
  birch_planks: (c, r) => plankTile(c, r, 0xd7c48d),
  crafting_top: (c, r) => {
    plankTile(c, r, 0x9c7442);
    rect(c, 0, 0, 16, 1, shade(0x5c4326, 0));
    rect(c, 0, 0, 1, 16, shade(0x5c4326, 0));
    for (let i = 0; i < 3; i++) {
      rect(c, 1 + i * 5, 1, 1, 14, shade(0x6b4f2e, 0));
      rect(c, 1, 1 + i * 5, 14, 1, shade(0x6b4f2e, 0));
    }
    rect(c, 11, 11, 4, 4, shade(0x8a6a3e, 0));
  },
  crafting_side: (c, r) => {
    plankTile(c, r, 0x9c7442);
    rect(c, 0, 0, 16, 4, shade(0x7a5a34, 0));
    rect(c, 2, 6, 5, 5, shade(0x5c4326, 0));
    rect(c, 9, 6, 5, 5, shade(0x5c4326, 0));
    rect(c, 3, 7, 3, 3, shade(0xb0854f, 0));
    rect(c, 10, 7, 3, 3, shade(0xb0854f, 0));
  },
  furnace_top: (c, r) => { noisy(c, r, 0x77777d, 14); rect(c, 3, 3, 10, 10, shade(0x5c5c62, 0)); rect(c, 4, 4, 8, 8, shade(0x6e6e74, 0)); },
  furnace_side: (c, r) => { noisy(c, r, 0x77777d, 14); rect(c, 0, 0, 16, 1, shade(0x9a9aa0, 0)); rect(c, 0, 15, 16, 1, shade(0x55555b, 0)); specks(c, r, 0x5f5f65, 20, 16); },
  furnace_front: (c, r) => {
    noisy(c, r, 0x77777d, 14);
    rect(c, 3, 6, 10, 8, shade(0x2e2e33, 0));
    rect(c, 4, 7, 8, 6, shade(0x1c1c20, 0));
    rect(c, 4, 11, 8, 2, shade(0x55555b, 0));
    rect(c, 3, 2, 10, 3, shade(0x8d8d94, 0));
    for (let i = 0; i < 4; i++) rect(c, 4 + i * 2, 3, 1, 1, shade(0x55555b, 0));
  },
  glass: (c, r) => {
    c.clearRect(0, 0, 16, 16);
    rect(c, 0, 0, 16, 1, 'rgba(226,242,255,0.85)');
    rect(c, 0, 15, 16, 1, 'rgba(190,215,240,0.85)');
    rect(c, 0, 0, 1, 16, 'rgba(226,242,255,0.85)');
    rect(c, 15, 0, 1, 16, 'rgba(190,215,240,0.85)');
    for (let i = 0; i < 6; i++) px(c, 2 + ((r() * 11) | 0), 2 + ((r() * 11) | 0), 'rgba(255,255,255,0.55)');
    rect(c, 3, 3, 4, 1, 'rgba(255,255,255,0.4)');
    rect(c, 3, 4, 1, 3, 'rgba(255,255,255,0.28)');
  },
  coal_ore: (c, r) => { P.stone(c, r); oreBlobs(c, r, 0x2b2b30, 0x4a4a52); },
  iron_ore: (c, r) => { P.stone(c, r); oreBlobs(c, r, 0xc08a63, 0xe0b48c); },
  gold_ore: (c, r) => { P.stone(c, r); oreBlobs(c, r, 0xe0b12c, 0xffe27a); },
  diamond_ore: (c, r) => { P.stone(c, r); oreBlobs(c, r, 0x3fdcd0, 0xb6fff8); },
  glowstone: (c, r) => {
    noisy(c, r, 0xb98a3e, 18);
    for (let i = 0; i < 16; i++) {
      const x = (r() * 14) | 0, y = (r() * 14) | 0;
      rect(c, x, y, 2, 2, shade(0xffe27a, (r() - 0.5) * 30));
    }
  },
  bricks: (c, r) => {
    noisy(c, r, 0xa8503c, 10);
    for (let y = 0; y < 16; y += 4) {
      rect(c, 0, y, 16, 1, shade(0xc9c2b6, 0));
      const off = (y / 4) % 2 === 0 ? 0 : 4;
      for (let x = off; x < 16; x += 8) rect(c, x, y, 1, 4, shade(0xc9c2b6, 0));
    }
    for (let i = 0; i < 30; i++) px(c, (r() * 16) | 0, (r() * 16) | 0, shade(0x93412f, (r() - 0.5) * 20));
  },
  stone_bricks: (c, r) => {
    noisy(c, r, 0x8b8b91, 12);
    for (let y = 0; y < 16; y += 8) {
      rect(c, 0, y, 16, 1, shade(0x5f5f66, 0));
      const off = (y / 8) % 2 === 0 ? 0 : 8;
      for (let x = off; x < 16; x += 16) rect(c, x, y, 1, 8, shade(0x5f5f66, 0));
      rect(c, (off + 8) % 16, y, 1, 8, shade(0x5f5f66, 0));
    }
    specks(c, r, 0x74747a, 26, 14);
  },
  obsidian: (c, r) => {
    noisy(c, r, 0x1a1426, 12);
    for (let i = 0; i < 14; i++) {
      const x = (r() * 15) | 0, y = (r() * 15) | 0;
      rect(c, x, y, 1 + ((r() * 2) | 0), 1, shade(0x513a80, (r() - 0.5) * 40));
    }
    specks(c, r, 0x6f4fa8, 8, 20);
  },
  cactus_side: (c, r) => {
    noisy(c, r, 0x3f7a34, 12);
    rect(c, 0, 0, 1, 16, shade(0x2c5a25, 0));
    rect(c, 15, 0, 1, 16, shade(0x2c5a25, 0));
    rect(c, 2, 0, 1, 16, shade(0x549944, 0));
    for (let y = 1; y < 16; y += 3) { px(c, 6, y, shade(0xdfe8c0, 0)); px(c, 11, y + 1, shade(0xdfe8c0, 0)); }
  },
  cactus_top: (c, r) => { noisy(c, r, 0x4c8c3c, 10); rect(c, 5, 5, 6, 6, shade(0x6aa84f, 0)); rect(c, 7, 7, 2, 2, shade(0x376b2c, 0)); },
  tall_grass: (c, r) => crossPlant(c, r, 0xbdbdbd, 'grass'),
  poppy: (c, r) => crossPlant(c, r, 0x4f8f36, 'flower', 0xd83a34),
  dandelion: (c, r) => crossPlant(c, r, 0x4f8f36, 'flower', 0xf5d33f),
  dead_bush: (c, r) => crossPlant(c, r, 0x8a6a3a, 'bush'),
  sapling: (c, r) => crossPlant(c, r, 0x59a03c, 'sapling'),
  torch: (c, r) => {
    c.clearRect(0, 0, 16, 16);
    rect(c, 7, 8, 2, 8, shade(0x7a5a34, 0));
    rect(c, 7, 8, 1, 8, shade(0x9c7442, 0));
    rect(c, 6, 5, 4, 3, shade(0xffcf4d, 0));
    rect(c, 7, 4, 2, 2, shade(0xfff3b0, 0));
    px(c, 6, 7, shade(0xff9c2a, 0));
    px(c, 9, 7, shade(0xff9c2a, 0));
    px(c, 7, 3, 'rgba(255,240,180,0.5)');
    void r;
  },
  wool: (c, r) => {
    noisy(c, r, 0xeceff2, 10);
    for (let i = 0; i < 40; i++) {
      const x = (r() * 16) | 0, y = (r() * 16) | 0;
      px(c, x, y, shade(0xdadfe4, (r() - 0.5) * 16));
    }
  },
  /* ---- items ---- */
  stick: (c) => {
    for (let i = 0; i < 10; i++) { rect(c, 4 + i, 12 - i, 2, 2, shade(0x8a6a3e, i % 2 ? 0 : -18)); }
  },
  coal: (c, r) => {
    const pts = [[6, 4], [9, 5], [5, 7], [8, 8], [10, 8], [6, 10], [9, 11], [7, 6], [8, 6], [7, 9], [10, 6]];
    for (const [x, y] of pts) rect(c, x - 1, y - 1, 3, 3, shade(0x26262b, (r() - 0.5) * 22));
    px(c, 6, 5, shade(0x50505a, 0)); px(c, 9, 8, shade(0x45454e, 0));
  },
  iron_ingot: (c) => {
    rect(c, 4, 6, 8, 5, shade(0xd8d8dc, 0));
    rect(c, 3, 8, 10, 3, shade(0xc2c2c8, 0));
    rect(c, 4, 6, 8, 1, shade(0xf2f2f6, 0));
    rect(c, 3, 10, 10, 1, shade(0x9a9aa2, 0));
  },
  gold_ingot: (c) => {
    rect(c, 4, 6, 8, 5, shade(0xf2c53d, 0));
    rect(c, 3, 8, 10, 3, shade(0xdba828, 0));
    rect(c, 4, 6, 8, 1, shade(0xffe98a, 0));
    rect(c, 3, 10, 10, 1, shade(0xa87c14, 0));
  },
  diamond: (c) => {
    const rows = ['....dddd....', '...dLLLLd...', '..dLWWLLd...', '.dLWLLLLLd..', '..dLLLLLd...', '...dLLLd....', '....dLd.....', '.....d......'];
    const colors: Record<string, string> = { d: '#1c8f88', L: '#4fe3d6', W: '#d4fffb' };
    for (let y = 0; y < rows.length; y++)
      for (let x = 0; x < rows[y].length; x++) {
        const ch = rows[y][x];
        if (colors[ch]) px(c, x + 2, y + 4, colors[ch]);
      }
  },
  apple: (c, r) => {
    for (let y = 0; y < 16; y++)
      for (let x = 0; x < 16; x++) {
        const d = Math.hypot((x - 7.5) / 4.6, (y - 9.5) / 4.4);
        if (d < 1) px(c, x, y, shade(0xd8352f, (1 - d) * 26 + (r() - 0.5) * 12));
      }
    rect(c, 7, 3, 1, 3, shade(0x6b4a2a, 0));
    rect(c, 8, 3, 3, 2, shade(0x4f9c3a, 0));
    px(c, 5, 7, 'rgba(255,255,255,0.55)');
    px(c, 6, 6, 'rgba(255,255,255,0.35)');
  },
  pork_raw: (c, r) => {
    for (let y = 5; y < 13; y++)
      for (let x = 3; x < 13; x++) {
        const d = Math.hypot((x - 8) / 5, (y - 9) / 4);
        if (d < 1) px(c, x, y, shade(0xf09a9a, (r() - 0.5) * 26));
      }
    rect(c, 4, 6, 8, 1, shade(0xffc9c9, 0));
    rect(c, 5, 11, 6, 1, shade(0xc97070, 0));
    rect(c, 7, 3, 2, 3, shade(0xf2ead8, 0));
  },
  pork_cooked: (c, r) => {
    for (let y = 5; y < 13; y++)
      for (let x = 3; x < 13; x++) {
        const d = Math.hypot((x - 8) / 5, (y - 9) / 4);
        if (d < 1) px(c, x, y, shade(0xc98040, (r() - 0.5) * 30));
      }
    rect(c, 4, 6, 8, 1, shade(0xe8a860, 0));
    rect(c, 5, 11, 6, 1, shade(0x8f5322, 0));
    rect(c, 7, 3, 2, 3, shade(0xf2ead8, 0));
  },
  mutton_raw: (c, r) => {
    for (let y = 4; y < 13; y++)
      for (let x = 4; x < 13; x++) {
        const d = Math.hypot((x - 8) / 4.4, (y - 8.5) / 4.6);
        if (d < 1) px(c, x, y, shade(0xe07070, (r() - 0.5) * 26));
      }
    rect(c, 6, 12, 4, 3, shade(0xf2ead8, 0));
  },
  mutton_cooked: (c, r) => {
    for (let y = 4; y < 13; y++)
      for (let x = 4; x < 13; x++) {
        const d = Math.hypot((x - 8) / 4.4, (y - 8.5) / 4.6);
        if (d < 1) px(c, x, y, shade(0xa9622f, (r() - 0.5) * 30));
      }
    rect(c, 6, 12, 4, 3, shade(0xf2ead8, 0));
  },
  brick_item: (c, r) => { rect(c, 3, 6, 10, 5, shade(0xa8503c, 0)); rect(c, 3, 6, 10, 1, shade(0xc46a52, 0)); rect(c, 3, 10, 10, 1, shade(0x7d3628, 0)); void r; },
  seeds: (c, r) => { for (let i = 0; i < 7; i++) { const x = 3 + ((r() * 10) | 0), y = 5 + ((r() * 7) | 0); rect(c, x, y, 2, 2, shade(0x7fa83c, (r() - 0.5) * 30)); } },
  bread: (c, r) => {
    for (let y = 5; y < 12; y++)
      for (let x = 2; x < 14; x++) {
        const d = Math.hypot((x - 8) / 6, (y - 8.5) / 3.4);
        if (d < 1) px(c, x, y, shade(0xc98f45, (r() - 0.5) * 24));
      }
    for (let i = 0; i < 3; i++) rect(c, 4 + i * 3, 6, 1, 3, shade(0x8a5a24, 0));
  },
};

const TOOL_SHAPES: Record<string, string[]> = {
  pickaxe: [
    '................', '......HHHHH.....', '.....HHhhhHH....', '....HH..S.hHH...',
    '....H..Ss..hH...', '.......Ss...H...', '......Ss........', '.....Ss.........',
    '....Ss..........', '...Ss...........', '..Ss............', '.Ss.............',
    'Ss..............', '................', '................', '................',
  ],
  axe: [
    '................', '......HHHH......', '.....HHhhhH.....', '.....HHh.hhH....',
    '.....HHhSshH....', '......HHSsH.....', '.......HSs......', '......Ss........',
    '.....Ss.........', '....Ss..........', '...Ss...........', '..Ss............',
    '.Ss.............', 'Ss..............', '................', '................',
  ],
  shovel: [
    '................', '.......HH.......', '......HHHH......', '......HhhH......',
    '......HhhH......', '.......SS.......', '.......Ss.......', '......Ss........',
    '.....Ss.........', '....Ss..........', '...Ss...........', '..Ss............',
    '.Ss.............', 'Ss..............', '................', '................',
  ],
  sword: [
    '................', '..........HH....', '.........HHh....', '........HHh.....',
    '.......HHh......', '......HHh.......', '.....HHh........', '....HHh.........',
    '..G.Hh..........', '.GGGh...........', '.GGSS...........', '..GSs...........',
    '.Ss.............', 'Ss..............', '................', '................',
  ],
};
const TOOL_COLORS: Record<string, [string, string]> = {
  wood: ['#b0854f', '#7d5c33'],
  stone: ['#8b8b91', '#5f5f66'],
  iron: ['#dcdce2', '#9a9aa2'],
  diamond: ['#4fe3d6', '#1f9e94'],
};
for (const mat of Object.keys(TOOL_COLORS)) {
  for (const kind of Object.keys(TOOL_SHAPES)) {
    P[`${mat}_${kind}`] = (c) => {
      const [h, hh] = TOOL_COLORS[mat];
      ascii(c, TOOL_SHAPES[kind], { H: h, h: hh, S: '#9c7442', s: '#6b4f2e', G: '#c9a227' });
    };
  }
}

/* crack overlay stages */
for (let s = 0; s < 10; s++) {
  P[`crack_${s}`] = (c) => {
    c.clearRect(0, 0, 16, 16);
    const r = mulberry32(1337);
    const branches: [number, number][][] = [];
    for (let b = 0; b < 6; b++) {
      let x = 8, y = 8;
      const path: [number, number][] = [];
      const dx = r() < 0.5 ? -1 : 1, dy = r() < 0.5 ? -1 : 1;
      for (let i = 0; i < 9; i++) {
        x += r() < 0.7 ? dx : 0;
        y += r() < 0.7 ? dy : 0;
        if (x < 0 || x > 15 || y < 0 || y > 15) break;
        path.push([x, y]);
      }
      branches.push(path);
    }
    const amount = (s + 1) / 10;
    for (const path of branches) {
      const n = Math.ceil(path.length * amount);
      for (let i = 0; i < n; i++) {
        const [x, y] = path[i];
        px(c, x, y, `rgba(0,0,0,${0.35 + amount * 0.4})`);
      }
    }
  };
}

function makeTile(name: string, index: number): HTMLCanvasElement {
  const cv = document.createElement('canvas');
  cv.width = TILE;
  cv.height = TILE;
  const c = cv.getContext('2d')!;
  c.imageSmoothingEnabled = false;
  const painter = P[name];
  const r = mulberry32(index * 7919 + 13);
  if (painter) painter(c, r);
  else noisy(c, r, 0xff00ff, 40);
  return cv;
}

/** Tile order is fixed at module load so UVs are valid even before the atlas is painted. */
const TILE_NAMES: string[] = (() => {
  const names = new Set<string>(['stone']);
  for (const b of BLOCKS) if (b) for (const t of b.tiles) names.add(t);
  for (const it of ITEMS) if (it) names.add(it.tile);
  for (let i = 0; i < 10; i++) names.add(`crack_${i}`);
  const list = Array.from(names).slice(0, GRID * GRID);
  list.forEach((name, i) => {
    tileIndex.set(name, i);
    const cx = (i % GRID) * CELL, cy = ((i / GRID) | 0) * CELL;
    uvRects.set(name, [
      (cx + PAD) / ATLAS_SIZE,
      1 - (cy + PAD + TILE) / ATLAS_SIZE,
      TILE / ATLAS_SIZE,
      TILE / ATLAS_SIZE,
    ]);
  });
  return list;
})();

export function buildAtlas(): { canvas: HTMLCanvasElement; uv: Map<string, [number, number, number, number]> } {
  if (atlasCanvas) return { canvas: atlasCanvas, uv: uvRects };
  const list = TILE_NAMES;

  const cv = document.createElement('canvas');
  cv.width = ATLAS_SIZE;
  cv.height = ATLAS_SIZE;
  const ctx = cv.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;
  list.forEach((name, i) => {
    if (i >= GRID * GRID) return;
    const tile = makeTile(name, i);
    tileCanvases.set(name, tile);
    tileIndex.set(name, i);
    const cx = (i % GRID) * CELL, cy = ((i / GRID) | 0) * CELL;
    // padded border (clamped edge replicate) prevents mip bleeding
    ctx.drawImage(tile, 0, 0, TILE, 1, cx + PAD, cy, TILE, PAD);
    ctx.drawImage(tile, 0, TILE - 1, TILE, 1, cx + PAD, cy + PAD + TILE, TILE, PAD);
    ctx.drawImage(tile, 0, 0, 1, TILE, cx, cy + PAD, PAD, TILE);
    ctx.drawImage(tile, TILE - 1, 0, 1, TILE, cx + PAD + TILE, cy + PAD, PAD, TILE);
    ctx.drawImage(tile, 0, 0, 1, 1, cx, cy, PAD, PAD);
    ctx.drawImage(tile, TILE - 1, 0, 1, 1, cx + PAD + TILE, cy, PAD, PAD);
    ctx.drawImage(tile, 0, TILE - 1, 1, 1, cx, cy + PAD + TILE, PAD, PAD);
    ctx.drawImage(tile, TILE - 1, TILE - 1, 1, 1, cx + PAD + TILE, cy + PAD + TILE, PAD, PAD);
    ctx.drawImage(tile, cx + PAD, cy + PAD);
    const u0 = (cx + PAD) / ATLAS_SIZE;
    const v0 = 1 - (cy + PAD + TILE) / ATLAS_SIZE;
    uvRects.set(name, [u0, v0, TILE / ATLAS_SIZE, TILE / ATLAS_SIZE]);
  });
  atlasCanvas = cv;
  return { canvas: cv, uv: uvRects };
}

export function tileUV(name: string): [number, number, number, number] {
  return uvRects.get(name) ?? uvRects.get('stone')!;
}

/* ------------------------------------------------- inventory icon rendering */
const iconCache = new Map<number, string>();

function tintCanvas(src: HTMLCanvasElement, color: number): HTMLCanvasElement {
  const cv = document.createElement('canvas');
  cv.width = TILE;
  cv.height = TILE;
  const c = cv.getContext('2d')!;
  c.drawImage(src, 0, 0);
  c.globalCompositeOperation = 'multiply';
  c.fillStyle = `#${color.toString(16).padStart(6, '0')}`;
  c.fillRect(0, 0, TILE, TILE);
  c.globalCompositeOperation = 'destination-in';
  c.drawImage(src, 0, 0);
  return cv;
}

/** Isometric cube icon for blocks, flat sprite for items. */
export function itemIcon(id: number): string {
  const cached = iconCache.get(id);
  if (cached) return cached;
  if (!atlasCanvas) buildAtlas();
  const S = 64;
  const cv = document.createElement('canvas');
  cv.width = S;
  cv.height = S;
  const c = cv.getContext('2d')!;
  c.imageSmoothingEnabled = false;
  const it = getItem(id);
  const block = it.block != null ? BLOCKS[it.block] : null;

  if (block && !block.cross) {
    const topName = block.tiles[2], sideName = block.tiles[4], rightName = block.tiles[0];
    let top = tileCanvases.get(topName)!, left = tileCanvases.get(sideName)!, right = tileCanvases.get(rightName)!;
    if (block.tint) {
      const faces = block.tintFaces;
      if (!faces || faces.includes(2)) top = tintCanvas(top, block.tint);
      if (!faces || faces.includes(4)) left = tintCanvas(left, block.tint);
      if (!faces || faces.includes(0)) right = tintCanvas(right, block.tint);
    }
    const w = 26, h = 15;
    const cx = S / 2, cy = 12;
    // top face
    c.save();
    c.setTransform(w / 16, h / 16, -w / 16, h / 16, cx, cy);
    c.drawImage(top, 0, 0);
    c.restore();
    // left face
    c.save();
    c.setTransform(w / 16, h / 16, 0, 26 / 16, cx - w, cy + h);
    c.drawImage(left, 0, 0);
    c.fillStyle = 'rgba(0,0,0,0.28)';
    c.fillRect(0, 0, 16, 16);
    c.restore();
    // right face
    c.save();
    c.setTransform(w / 16, -h / 16, 0, 26 / 16, cx, cy + 2 * h);
    c.drawImage(right, 0, 0);
    c.fillStyle = 'rgba(0,0,0,0.45)';
    c.fillRect(0, 0, 16, 16);
    c.restore();
  } else {
    let cvi = tileCanvases.get(it.tile);
    if (!cvi) cvi = tileCanvases.get('stone')!;
    if (block?.tint) cvi = tintCanvas(cvi, block.tint);
    c.drawImage(cvi, 4, 4, 56, 56);
  }
  const url = cv.toDataURL();
  iconCache.set(id, url);
  return url;
}

const avgCache = new Map<string, [number, number, number]>();

/** Average tile colour in linear space, used for break particles. */
export function tileAverage(name: string, tint?: number): [number, number, number] {
  const key = `${name}:${tint ?? 0}`;
  const hit = avgCache.get(key);
  if (hit) return hit;
  const cv = tileCanvases.get(name);
  let r = 0.5, g = 0.5, b = 0.5;
  if (cv) {
    const c = cv.getContext('2d')!;
    const d = c.getImageData(0, 0, TILE, TILE).data;
    let sr = 0, sg = 0, sb = 0, n = 0;
    for (let i = 0; i < d.length; i += 4) {
      if (d[i + 3] < 40) continue;
      sr += d[i]; sg += d[i + 1]; sb += d[i + 2]; n++;
    }
    if (n > 0) { r = sr / n / 255; g = sg / n / 255; b = sb / n / 255; }
  }
  if (tint != null) {
    r *= ((tint >> 16) & 255) / 255;
    g *= ((tint >> 8) & 255) / 255;
    b *= (tint & 255) / 255;
  }
  const out: [number, number, number] = [Math.pow(r, 2.2), Math.pow(g, 2.2), Math.pow(b, 2.2)];
  avgCache.set(key, out);
  return out;
}

export function crackTextureStage(stage: number): [number, number] {
  const i = tileIndex.get(`crack_${Math.max(0, Math.min(9, stage))}`) ?? 0;
  return [(i % GRID) * CELL / ATLAS_SIZE, 1 - (((i / GRID) | 0) * CELL + CELL) / ATLAS_SIZE];
}
