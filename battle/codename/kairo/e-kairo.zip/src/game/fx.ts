import * as THREE from 'three';
import { BLOCKS } from './blocks';
import { tileAverage } from './textures';
import type { World } from './world';

const MAX = 1400;

const VERT = /* glsl */ `
attribute float psize;
attribute float palpha;
attribute vec3 pcolor;
varying vec3 vC;
varying float vA;
varying float vD;
void main() {
  vC = pcolor;
  vA = palpha;
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  vD = -mv.z;
  gl_PointSize = psize * (420.0 / max(1.0, -mv.z));
  gl_Position = projectionMatrix * mv;
}
`;
const FRAG = /* glsl */ `
uniform vec3 fogColor;
uniform float fogNear;
uniform float fogFar;
varying vec3 vC;
varying float vA;
varying float vD;
void main() {
  vec2 d = gl_PointCoord - 0.5;
  if (max(abs(d.x), abs(d.y)) > 0.5) discard;
  float f = smoothstep(fogNear, fogFar, vD);
  vec3 col = mix(vC, fogColor, f);
  float edge = 1.0 - smoothstep(0.36, 0.5, max(abs(d.x), abs(d.y)));
  gl_FragColor = vec4(col * (0.78 + 0.22 * edge), vA);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}
`;

export type ParticleKind = 'block' | 'spark' | 'smoke' | 'splash' | 'damage' | 'leaf';

export class Particles {
  points: THREE.Points;
  private pos = new Float32Array(MAX * 3);
  private vel = new Float32Array(MAX * 3);
  private col = new Float32Array(MAX * 3);
  private size = new Float32Array(MAX);
  private alpha = new Float32Array(MAX);
  private life = new Float32Array(MAX);
  private maxLife = new Float32Array(MAX);
  private grav = new Float32Array(MAX);
  private drag = new Float32Array(MAX);
  private cursor = 0;
  private geo: THREE.BufferGeometry;
  enabled = true;

  constructor(fog: { fogColor: { value: THREE.Color }; fogNear: { value: number }; fogFar: { value: number } }) {
    this.geo = new THREE.BufferGeometry();
    this.geo.setAttribute('position', new THREE.BufferAttribute(this.pos, 3));
    this.geo.setAttribute('pcolor', new THREE.BufferAttribute(this.col, 3));
    this.geo.setAttribute('psize', new THREE.BufferAttribute(this.size, 1));
    this.geo.setAttribute('palpha', new THREE.BufferAttribute(this.alpha, 1));
    this.geo.setDrawRange(0, 0);
    this.points = new THREE.Points(
      this.geo,
      new THREE.ShaderMaterial({
        uniforms: { fogColor: fog.fogColor, fogNear: fog.fogNear, fogFar: fog.fogFar },
        vertexShader: VERT,
        fragmentShader: FRAG,
        transparent: true,
        depthWrite: false,
      }),
    );
    this.points.frustumCulled = false;
    this.points.renderOrder = 5;
  }

  private emit(
    x: number, y: number, z: number,
    vx: number, vy: number, vz: number,
    r: number, g: number, b: number,
    size: number, life: number, gravity: number, drag: number,
  ) {
    const i = this.cursor;
    this.cursor = (this.cursor + 1) % MAX;
    const o = i * 3;
    this.pos[o] = x; this.pos[o + 1] = y; this.pos[o + 2] = z;
    this.vel[o] = vx; this.vel[o + 1] = vy; this.vel[o + 2] = vz;
    this.col[o] = r; this.col[o + 1] = g; this.col[o + 2] = b;
    this.size[i] = size;
    this.life[i] = life;
    this.maxLife[i] = life;
    this.alpha[i] = 1;
    this.grav[i] = gravity;
    this.drag[i] = drag;
  }

  blockBreak(x: number, y: number, z: number, id: number, light = 1) {
    if (!this.enabled) return;
    const b = BLOCKS[id];
    const [r, g, bb] = tileAverage(b.tiles[2], b.tint);
    for (let i = 0; i < 16; i++) {
      const j = 0.7 + Math.random() * 0.6;
      this.emit(
        x + 0.15 + Math.random() * 0.7, y + 0.15 + Math.random() * 0.7, z + 0.15 + Math.random() * 0.7,
        (Math.random() - 0.5) * 3.2, 1.4 + Math.random() * 3.2, (Math.random() - 0.5) * 3.2,
        r * j * light, g * j * light, bb * j * light,
        0.09 + Math.random() * 0.06, 0.7 + Math.random() * 0.5, 16, 0.6,
      );
    }
  }

  blockHit(x: number, y: number, z: number, id: number, nx: number, ny: number, nz: number, light = 1) {
    if (!this.enabled) return;
    const b = BLOCKS[id];
    const [r, g, bb] = tileAverage(b.tiles[2], b.tint);
    for (let i = 0; i < 3; i++) {
      const j = 0.75 + Math.random() * 0.5;
      this.emit(
        x + 0.5 + nx * 0.55 + (Math.random() - 0.5) * 0.5,
        y + 0.5 + ny * 0.55 + (Math.random() - 0.5) * 0.5,
        z + 0.5 + nz * 0.55 + (Math.random() - 0.5) * 0.5,
        nx * 1.4 + (Math.random() - 0.5), ny * 1.4 + Math.random() * 1.6, nz * 1.4 + (Math.random() - 0.5),
        r * j * light, g * j * light, bb * j * light,
        0.07, 0.45, 14, 0.7,
      );
    }
  }

  placePuff(x: number, y: number, z: number, id: number) {
    if (!this.enabled) return;
    const [r, g, b] = tileAverage(BLOCKS[id].tiles[2], BLOCKS[id].tint);
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      this.emit(x + 0.5 + Math.cos(a) * 0.5, y + 0.2 + Math.random() * 0.6, z + 0.5 + Math.sin(a) * 0.5,
        Math.cos(a) * 1.1, 0.7, Math.sin(a) * 1.1, r, g, b, 0.08, 0.35, 4, 1.6);
    }
  }

  splash(x: number, y: number, z: number, amount = 18) {
    if (!this.enabled) return;
    for (let i = 0; i < amount; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = Math.random() * 2.4;
      this.emit(x, y, z, Math.cos(a) * s, 2 + Math.random() * 3.4, Math.sin(a) * s,
        0.45, 0.68, 0.95, 0.08 + Math.random() * 0.05, 0.6 + Math.random() * 0.4, 15, 0.4);
    }
  }

  flame(x: number, y: number, z: number) {
    if (!this.enabled || Math.random() > 0.4) return;
    this.emit(x + (Math.random() - 0.5) * 0.12, y, z + (Math.random() - 0.5) * 0.12,
      (Math.random() - 0.5) * 0.12, 0.35 + Math.random() * 0.2, (Math.random() - 0.5) * 0.12,
      1, 0.65 + Math.random() * 0.3, 0.22, 0.055, 0.55, -0.4, 0.9);
  }

  smoke(x: number, y: number, z: number, dark = false) {
    if (!this.enabled) return;
    const v = dark ? 0.18 : 0.55;
    this.emit(x + (Math.random() - 0.5) * 0.3, y, z + (Math.random() - 0.5) * 0.3,
      (Math.random() - 0.5) * 0.2, 0.5 + Math.random() * 0.4, (Math.random() - 0.5) * 0.2,
      v, v, v, 0.12, 1.1, -0.2, 0.9);
  }

  damage(x: number, y: number, z: number, hostile = false) {
    if (!this.enabled) return;
    for (let i = 0; i < 8; i++) {
      this.emit(x + (Math.random() - 0.5) * 0.5, y + Math.random() * 0.8, z + (Math.random() - 0.5) * 0.5,
        (Math.random() - 0.5) * 2.4, 1 + Math.random() * 2, (Math.random() - 0.5) * 2.4,
        hostile ? 0.45 : 0.85, hostile ? 0.75 : 0.12, hostile ? 0.3 : 0.12,
        0.1, 0.5, 10, 0.7);
    }
  }

  update(dt: number, world: World) {
    let live = 0;
    for (let i = 0; i < MAX; i++) {
      if (this.life[i] <= 0) { this.alpha[i] = 0; continue; }
      this.life[i] -= dt;
      const o = i * 3;
      this.vel[o + 1] -= this.grav[i] * dt;
      const d = Math.max(0, 1 - this.drag[i] * dt);
      this.vel[o] *= d; this.vel[o + 2] *= d;
      const nx = this.pos[o] + this.vel[o] * dt;
      const ny = this.pos[o + 1] + this.vel[o + 1] * dt;
      const nz = this.pos[o + 2] + this.vel[o + 2] * dt;
      if (this.grav[i] > 0 && BLOCKS[world.getBlockSolid(Math.floor(nx), Math.floor(ny), Math.floor(nz))].solid) {
        this.vel[o] *= 0.4; this.vel[o + 2] *= 0.4;
        this.vel[o + 1] = Math.abs(this.vel[o + 1]) * 0.22;
        this.life[i] = Math.min(this.life[i], 0.25);
      } else {
        this.pos[o] = nx; this.pos[o + 1] = ny; this.pos[o + 2] = nz;
      }
      const t = Math.max(0, this.life[i] / this.maxLife[i]);
      this.alpha[i] = t > 0.7 ? 1 : t / 0.7;
      live = Math.max(live, i + 1);
    }
    this.geo.setDrawRange(0, live);
    (this.geo.getAttribute('position') as THREE.BufferAttribute).needsUpdate = true;
    (this.geo.getAttribute('pcolor') as THREE.BufferAttribute).needsUpdate = true;
    (this.geo.getAttribute('psize') as THREE.BufferAttribute).needsUpdate = true;
    (this.geo.getAttribute('palpha') as THREE.BufferAttribute).needsUpdate = true;
  }

  dispose() {
    this.geo.dispose();
    (this.points.material as THREE.Material).dispose();
  }
}
