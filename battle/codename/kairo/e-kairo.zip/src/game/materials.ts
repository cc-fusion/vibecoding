import * as THREE from 'three';
import { ATLAS_SIZE } from './textures';

export interface TerrainUniforms {
  map: { value: THREE.Texture };
  uSun: { value: THREE.Color };
  uAmbient: { value: THREE.Color };
  uTorch: { value: THREE.Color };
  fogColor: { value: THREE.Color };
  fogNear: { value: number };
  fogFar: { value: number };
  uTime: { value: number };
  uWave: { value: number };
}

const VERT = /* glsl */ `
attribute vec3 tint;
attribute vec2 lume;
varying vec3 vTint;
varying vec2 vLume;
varying vec2 vUv;
varying float vDepth;
varying vec3 vWorld;
uniform float uTime;
uniform float uWave;
void main() {
  vUv = uv;
  vTint = tint;
  vLume = lume;
  vec3 p = position;
  if (uWave > 0.5) {
    vec3 w = (modelMatrix * vec4(position, 1.0)).xyz;
    p.y += sin(w.x * 0.7 + uTime * 1.6) * 0.035 + sin(w.z * 0.9 + uTime * 2.1) * 0.03;
  }
  vec4 world = modelMatrix * vec4(p, 1.0);
  vWorld = world.xyz;
  vec4 mv = viewMatrix * world;
  vDepth = -mv.z;
  gl_Position = projectionMatrix * mv;
}
`;

const FRAG = /* glsl */ `
uniform sampler2D map;
uniform vec3 uSun;
uniform vec3 uAmbient;
uniform vec3 uTorch;
uniform vec3 fogColor;
uniform float fogNear;
uniform float fogFar;
uniform float uTime;
uniform float uAlpha;
uniform float uWave;
varying vec3 vTint;
varying vec2 vLume;
varying vec2 vUv;
varying float vDepth;
varying vec3 vWorld;
void main() {
  vec2 uv2 = vUv;
  if (uWave > 0.5) {
    uv2 += vec2(sin(uTime * 0.35 + vWorld.z * 0.2), cos(uTime * 0.29 + vWorld.x * 0.2)) * 0.006;
  }
  vec4 tex = texture2D(map, uv2);
  if (tex.a < 0.35) discard;
  vec3 base = tex.rgb * vTint;
  vec3 light = uAmbient + uSun * vLume.x;
  vec3 col = base * light + base * uTorch * vLume.y;
  if (uWave > 0.5) {
    float shimmer = sin(vWorld.x * 2.1 + uTime * 1.7) * sin(vWorld.z * 1.7 - uTime * 1.3);
    col += vec3(0.10, 0.16, 0.22) * max(0.0, shimmer) * vLume.x;
    col = mix(col, col * 1.15 + vec3(0.02, 0.05, 0.08), 0.35);
  }
  float f = smoothstep(fogNear, fogFar, vDepth);
  col = mix(col, fogColor, f);
  gl_FragColor = vec4(col, uAlpha * tex.a);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}
`;

export function makeAtlasTexture(canvas: HTMLCanvasElement): THREE.Texture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.generateMipmaps = true;
  tex.anisotropy = 4;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.needsUpdate = true;
  void ATLAS_SIZE;
  return tex;
}

export function sharedUniforms(tex: THREE.Texture): TerrainUniforms {
  return {
    map: { value: tex },
    uSun: { value: new THREE.Color(1, 0.97, 0.9) },
    uAmbient: { value: new THREE.Color(0.34, 0.38, 0.46) },
    uTorch: { value: new THREE.Color(1.05, 0.66, 0.3) },
    fogColor: { value: new THREE.Color(0.6, 0.75, 0.92) },
    fogNear: { value: 40 },
    fogFar: { value: 110 },
    uTime: { value: 0 },
    uWave: { value: 0 },
  };
}

export function terrainMaterial(u: TerrainUniforms, kind: 'solid' | 'cross' | 'water') {
  const uniforms: Record<string, THREE.IUniform> = {
    map: u.map, uSun: u.uSun, uAmbient: u.uAmbient, uTorch: u.uTorch,
    fogColor: u.fogColor, fogNear: u.fogNear, fogFar: u.fogFar, uTime: u.uTime,
    uWave: { value: kind === 'water' ? 1 : 0 },
    uAlpha: { value: kind === 'water' ? 0.76 : 1 },
  };
  return new THREE.ShaderMaterial({
    uniforms,
    vertexShader: VERT,
    fragmentShader: FRAG,
    side: kind === 'solid' ? THREE.FrontSide : THREE.DoubleSide,
    transparent: kind === 'water',
    depthWrite: kind !== 'water',
    fog: false,
  });
}

/** Selection wireframe + breaking overlay. */
export function makeHighlight() {
  const geo = new THREE.BoxGeometry(1.002, 1.002, 1.002);
  const edges = new THREE.EdgesGeometry(geo);
  const line = new THREE.LineSegments(
    edges,
    new THREE.LineBasicMaterial({ color: 0x0a0a0a, transparent: true, opacity: 0.55, depthTest: true }),
  );
  line.renderOrder = 3;
  line.visible = false;
  return line;
}

export function makeBreakMesh(tex: THREE.Texture) {
  const mat = new THREE.MeshBasicMaterial({
    map: tex,
    transparent: true,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -2,
    polygonOffsetUnits: -2,
    blending: THREE.NormalBlending,
  });
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(1.004, 1.004, 1.004), mat);
  mesh.visible = false;
  mesh.renderOrder = 4;
  return mesh;
}
