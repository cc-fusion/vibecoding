import * as THREE from 'three';
import { B, BLOCKS, getItem } from './blocks';
import { tileUV } from './textures';
import { moveEntity } from './physics';
import type { World } from './world';
import type { Stack } from './inventory';
import type { Particles } from './fx';
import type { GameAudio } from './audio';

/* ------------------------------------------------------------- item drops */

const geoCache = new Map<number, THREE.BufferGeometry>();
const CUBE_FACES = [
  { n: [1, 0, 0], v: [[1, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]], f: 0 },
  { n: [-1, 0, 0], v: [[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]], f: 1 },
  { n: [0, 1, 0], v: [[0, 1, 1], [1, 1, 1], [1, 1, 0], [0, 1, 0]], f: 2 },
  { n: [0, -1, 0], v: [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]], f: 3 },
  { n: [0, 0, 1], v: [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]], f: 4 },
  { n: [0, 0, -1], v: [[1, 0, 0], [0, 0, 0], [0, 1, 0], [1, 1, 0]], f: 5 },
];

export function itemGeometry(id: number): { geo: THREE.BufferGeometry; flat: boolean } {
  const cached = geoCache.get(id);
  const item = getItem(id);
  const block = item.block != null ? BLOCKS[item.block] : null;
  const flat = !block || !!block.cross;
  if (cached) return { geo: cached, flat };
  const pos: number[] = [], uv: number[] = [], tint: number[] = [], lume: number[] = [], index: number[] = [];
  const push = (x: number, y: number, z: number, u: number, v: number, r: number, g: number, b: number) => {
    pos.push(x, y, z); uv.push(u, v); tint.push(r * 255, g * 255, b * 255); lume.push(230, 60);
  };
  if (!flat && block) {
    const s = 0.3;
    for (const F of CUBE_FACES) {
      const [u0, v0, du, dv] = tileUV(block.tiles[F.f]);
      const useTint = block.tint != null && (!block.tintFaces || block.tintFaces.includes(F.f));
      const c = useTint ? block.tint! : 0xffffff;
      const r = ((c >> 16) & 255) / 255, g = ((c >> 8) & 255) / 255, b = (c & 255) / 255;
      const base = pos.length / 3;
      const uvs = [[u0, v0], [u0 + du, v0], [u0 + du, v0 + dv], [u0, v0 + dv]];
      for (let i = 0; i < 4; i++) {
        const v = F.v[i];
        push((v[0] - 0.5) * s, (v[1] - 0.5) * s, (v[2] - 0.5) * s, uvs[i][0], uvs[i][1], r, g, b);
      }
      index.push(base, base + 1, base + 2, base, base + 2, base + 3);
    }
  } else {
    const [u0, v0, du, dv] = tileUV(item.tile);
    const s = 0.34;
    const c = block?.tint ?? 0xffffff;
    const r = ((c >> 16) & 255) / 255, g = ((c >> 8) & 255) / 255, b = (c & 255) / 255;
    push(-s / 2, -s / 2, 0, u0, v0, r, g, b);
    push(s / 2, -s / 2, 0, u0 + du, v0, r, g, b);
    push(s / 2, s / 2, 0, u0 + du, v0 + dv, r, g, b);
    push(-s / 2, s / 2, 0, u0, v0 + dv, r, g, b);
    index.push(0, 1, 2, 0, 2, 3);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  geo.setAttribute('tint', new THREE.Uint8BufferAttribute(tint, 3, true));
  geo.setAttribute('lume', new THREE.Uint8BufferAttribute(lume, 2, true));
  geo.setIndex(index);
  geo.computeVertexNormals();
  geoCache.set(id, geo);
  return { geo, flat };
}

interface Drop {
  mesh: THREE.Mesh;
  stack: Stack;
  vel: THREE.Vector3;
  age: number;
  bob: number;
  onGround: boolean;
}

export class DropManager {
  group = new THREE.Group();
  drops: Drop[] = [];
  constructor(
    private solidMat: THREE.Material,
    private flatMat: THREE.Material,
    private audio: GameAudio,
  ) {}

  spawn(world: World, x: number, y: number, z: number, stack: Stack, toss?: THREE.Vector3) {
    if (stack.count <= 0) return;
    // merge with a nearby identical drop
    for (const d of this.drops) {
      if (d.stack.id === stack.id && d.stack.count + stack.count <= getItem(stack.id).stack) {
        if (d.mesh.position.distanceToSquared(new THREE.Vector3(x, y, z)) < 1.2) {
          d.stack.count += stack.count;
          return;
        }
      }
    }
    const { geo, flat } = itemGeometry(stack.id);
    const mesh = new THREE.Mesh(geo, flat ? this.flatMat : this.solidMat);
    mesh.position.set(x, y, z);
    this.group.add(mesh);
    const vel = toss
      ? toss.clone()
      : new THREE.Vector3((Math.random() - 0.5) * 1.6, 2.2 + Math.random(), (Math.random() - 0.5) * 1.6);
    this.drops.push({ mesh, stack: { ...stack }, vel, age: 0, bob: Math.random() * 6.28, onGround: false });
    void world;
  }

  update(dt: number, world: World, playerPos: THREE.Vector3, pickup: (s: Stack) => number, creative: boolean) {
    for (let i = this.drops.length - 1; i >= 0; i--) {
      const d = this.drops[i];
      d.age += dt;
      d.vel.y -= 22 * dt;
      const r = moveEntity(world, d.mesh.position, d.vel, 0.14, 0.28, dt);
      if (r.onGround) {
        d.vel.x *= 0.72;
        d.vel.z *= 0.72;
        d.onGround = true;
      }
      const inWater = BLOCKS[world.getBlock(Math.floor(d.mesh.position.x), Math.floor(d.mesh.position.y), Math.floor(d.mesh.position.z))].liquid;
      if (inWater) { d.vel.y = Math.min(d.vel.y + 30 * dt, 1.4); d.vel.multiplyScalar(0.92); }
      d.mesh.rotation.y += dt * 1.6;
      d.mesh.position.y += Math.sin(d.age * 2.4 + d.bob) * 0.0016;

      const dist = d.mesh.position.distanceTo(playerPos);
      if (d.age > 0.45 && dist < 2.0) {
        const dir = new THREE.Vector3().subVectors(playerPos, d.mesh.position).normalize();
        d.vel.addScaledVector(dir, dt * 26);
        if (dist < 0.95) {
          const left = pickup(d.stack);
          if (left === 0) {
            this.audio.pickup();
            this.group.remove(d.mesh);
            this.drops.splice(i, 1);
            continue;
          }
          d.stack.count = left;
        }
      }
      if (d.age > 300 || d.mesh.position.y < -8) {
        this.group.remove(d.mesh);
        this.drops.splice(i, 1);
      }
    }
    void creative;
  }

  clear() {
    for (const d of this.drops) this.group.remove(d.mesh);
    this.drops.length = 0;
  }
}

/* -------------------------------------------------------------------- mobs */

export type MobKind = 'pig' | 'sheep' | 'zombie';

interface MobSpec {
  health: number;
  speed: number;
  halfW: number;
  height: number;
  hostile: boolean;
  damage: number;
  xp: number;
}
const SPECS: Record<MobKind, MobSpec> = {
  pig: { health: 10, speed: 1.35, halfW: 0.42, height: 0.9, hostile: false, damage: 0, xp: 2 },
  sheep: { health: 10, speed: 1.25, halfW: 0.44, height: 1.2, hostile: false, damage: 0, xp: 2 },
  zombie: { health: 20, speed: 2.35, halfW: 0.32, height: 1.85, hostile: true, damage: 3, xp: 6 },
};

function box(w: number, h: number, d: number, color: number, x: number, y: number, z: number) {
  const m = new THREE.Mesh(
    new THREE.BoxGeometry(w, h, d),
    new THREE.MeshLambertMaterial({ color }),
  );
  m.position.set(x, y, z);
  return m;
}

export interface Mob {
  kind: MobKind;
  group: THREE.Group;
  parts: { legs: THREE.Object3D[]; head: THREE.Object3D; arms: THREE.Object3D[]; body: THREE.Object3D };
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  yaw: number;
  health: number;
  spec: MobSpec;
  state: 'idle' | 'wander' | 'chase' | 'flee';
  timer: number;
  walk: number;
  onGround: boolean;
  hurtT: number;
  attackCd: number;
  soundCd: number;
  burn: number;
  dead: boolean;
}

export class MobManager {
  group = new THREE.Group();
  mobs: Mob[] = [];
  spawnTimer = 3;
  onKill: ((m: Mob) => void) | null = null;

  constructor(
    private world: World,
    private particles: Particles,
    private audio: GameAudio,
    private drops: DropManager,
  ) {}

  private build(kind: MobKind): Mob['parts'] & { group: THREE.Group } {
    const g = new THREE.Group();
    const legs: THREE.Object3D[] = [];
    const arms: THREE.Object3D[] = [];
    let head: THREE.Object3D, body: THREE.Object3D;
    if (kind === 'pig' || kind === 'sheep') {
      const isPig = kind === 'pig';
      const bodyCol = isPig ? 0xe59a9a : 0xeef1f2;
      const headCol = isPig ? 0xe8a3a3 : 0xd8c3ad;
      const legCol = isPig ? 0xd08686 : 0x6b5b4c;
      body = box(0.78, 0.68, 1.15, bodyCol, 0, isPig ? 0.6 : 0.82, 0);
      head = box(0.5, 0.5, 0.48, headCol, 0, isPig ? 0.68 : 0.98, 0.72);
      const snout = box(0.26, 0.2, 0.12, isPig ? 0xd07575 : 0xc0a58c, 0, isPig ? 0.6 : 0.92, 0.98);
      const eyeL = box(0.09, 0.09, 0.04, 0x1a1a20, 0.16, isPig ? 0.78 : 1.08, 0.96);
      const eyeR = box(0.09, 0.09, 0.04, 0x1a1a20, -0.16, isPig ? 0.78 : 1.08, 0.96);
      g.add(body, head, snout, eyeL, eyeR);
      if (!isPig) {
        const wool = box(0.86, 0.74, 1.2, 0xf7f9fa, 0, 0.86, -0.02);
        g.add(wool);
        body = wool;
      }
      const lh = isPig ? 0.34 : 0.5;
      for (const [dx, dz] of [[0.26, 0.4], [-0.26, 0.4], [0.26, -0.4], [-0.26, -0.4]]) {
        const pivot = new THREE.Group();
        pivot.position.set(dx, lh, dz);
        const leg = box(0.22, lh, 0.22, legCol, 0, -lh / 2, 0);
        pivot.add(leg);
        g.add(pivot);
        legs.push(pivot);
      }
    } else {
      body = box(0.55, 0.72, 0.3, 0x2f6f5e, 0, 1.12, 0);
      head = box(0.5, 0.5, 0.5, 0x529b52, 0, 1.72, 0);
      const eyeL = box(0.11, 0.09, 0.04, 0x14261a, 0.13, 1.78, 0.26);
      const eyeR = box(0.11, 0.09, 0.04, 0x14261a, -0.13, 1.78, 0.26);
      g.add(body, head, eyeL, eyeR);
      for (const dx of [0.38, -0.38]) {
        const pivot = new THREE.Group();
        pivot.position.set(dx, 1.4, 0);
        const arm = box(0.2, 0.66, 0.2, 0x529b52, 0, -0.33, 0);
        pivot.add(arm);
        pivot.rotation.x = -1.45;
        g.add(pivot);
        arms.push(pivot);
      }
      for (const dx of [0.14, -0.14]) {
        const pivot = new THREE.Group();
        pivot.position.set(dx, 0.76, 0);
        const leg = box(0.22, 0.76, 0.22, 0x35407a, 0, -0.38, 0);
        pivot.add(leg);
        g.add(pivot);
        legs.push(pivot);
      }
    }
    g.traverse((o) => { o.frustumCulled = true; });
    return { group: g, legs, head, arms, body };
  }

  spawn(kind: MobKind, x: number, y: number, z: number) {
    const built = this.build(kind);
    const spec = SPECS[kind];
    const mob: Mob = {
      kind,
      group: built.group,
      parts: { legs: built.legs, head: built.head, arms: built.arms, body: built.body },
      pos: new THREE.Vector3(x, y, z),
      vel: new THREE.Vector3(),
      yaw: Math.random() * Math.PI * 2,
      health: spec.health,
      spec,
      state: 'idle',
      timer: Math.random() * 3,
      walk: 0,
      onGround: false,
      hurtT: 0,
      attackCd: 0,
      soundCd: Math.random() * 12,
      burn: 0,
      dead: false,
    };
    built.group.position.copy(mob.pos);
    this.group.add(built.group);
    this.mobs.push(mob);
    return mob;
  }

  hurt(mob: Mob, dmg: number, knock: THREE.Vector3, playerCaused: boolean) {
    mob.health -= dmg;
    mob.hurtT = 0.32;
    mob.vel.add(knock);
    mob.vel.y = Math.max(mob.vel.y, 3.4);
    this.particles.damage(mob.pos.x, mob.pos.y + mob.spec.height * 0.5, mob.pos.z, mob.kind === 'zombie');
    this.audio.mob(mob.kind);
    if (!mob.spec.hostile) { mob.state = 'flee'; mob.timer = 5; }
    else if (playerCaused) { mob.state = 'chase'; mob.timer = 12; }
    if (mob.health <= 0 && !mob.dead) {
      mob.dead = true;
      this.kill(mob);
    }
  }

  private kill(mob: Mob) {
    const loot: Stack[] = [];
    if (mob.kind === 'pig') loot.push({ id: 107, count: 1 + Math.floor(Math.random() * 2) });
    if (mob.kind === 'sheep') {
      loot.push({ id: 109, count: 1 + Math.floor(Math.random() * 2) });
      loot.push({ id: B.WOOL, count: 1 });
    }
    if (mob.kind === 'zombie' && Math.random() < 0.22) loot.push({ id: 103, count: 1 });
    for (const s of loot) this.drops.spawn(this.world, mob.pos.x, mob.pos.y + 0.4, mob.pos.z, s);
    this.particles.damage(mob.pos.x, mob.pos.y + 0.5, mob.pos.z, mob.kind === 'zombie');
    this.onKill?.(mob);
    this.remove(mob);
  }

  remove(mob: Mob) {
    const i = this.mobs.indexOf(mob);
    if (i >= 0) this.mobs.splice(i, 1);
    this.group.remove(mob.group);
    mob.group.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.geometry) m.geometry.dispose();
      if (m.material) (m.material as THREE.Material).dispose();
    });
  }

  update(
    dt: number,
    playerPos: THREE.Vector3,
    daylight: number,
    attackPlayer: (dmg: number, from: THREE.Vector3) => void,
    difficulty: number,
  ) {
    for (let i = this.mobs.length - 1; i >= 0; i--) {
      const m = this.mobs[i];
      const dist = m.pos.distanceTo(playerPos);
      if (dist > 78) { this.remove(m); continue; }
      m.timer -= dt;
      m.attackCd -= dt;
      m.soundCd -= dt;
      m.hurtT = Math.max(0, m.hurtT - dt);

      const hostileActive = m.spec.hostile && difficulty > 0;
      if (hostileActive && dist < 20 && m.state !== 'flee') {
        m.state = 'chase';
        m.timer = 3;
      } else if (m.state === 'chase' && dist > 26) m.state = 'wander';

      if (m.timer <= 0) {
        if (m.state === 'flee') m.state = 'wander';
        if (m.state !== 'chase') {
          m.state = Math.random() < 0.45 ? 'idle' : 'wander';
          m.yaw = Math.random() * Math.PI * 2;
          m.timer = 2 + Math.random() * 4;
        }
      }

      let speed = 0;
      if (m.state === 'wander') speed = m.spec.speed;
      else if (m.state === 'flee') speed = m.spec.speed * 1.9;
      else if (m.state === 'chase') {
        speed = m.spec.speed;
        m.yaw = Math.atan2(playerPos.x - m.pos.x, playerPos.z - m.pos.z);
        if (dist < 1.5 && m.attackCd <= 0 && Math.abs(playerPos.y - m.pos.y) < 2) {
          m.attackCd = 1.1;
          attackPlayer(m.spec.damage, m.pos);
        }
      }

      const fx = Math.sin(m.yaw), fz = Math.cos(m.yaw);
      const accel = m.onGround ? 14 : 4;
      m.vel.x += (fx * speed - m.vel.x) * Math.min(1, accel * dt);
      m.vel.z += (fz * speed - m.vel.z) * Math.min(1, accel * dt);
      m.vel.y -= 24 * dt;

      const feet = BLOCKS[this.world.getBlock(Math.floor(m.pos.x), Math.floor(m.pos.y), Math.floor(m.pos.z))];
      if (feet.liquid) {
        m.vel.y = Math.min(m.vel.y + 34 * dt, 2.6);
        m.vel.x *= 0.9; m.vel.z *= 0.9;
      }

      const res = moveEntity(this.world, m.pos, m.vel, m.spec.halfW, m.spec.height, dt);
      m.onGround = res.onGround;
      if ((res.hitX || res.hitZ) && m.onGround && speed > 0) m.vel.y = 7.2;
      if (m.pos.y < -6) { this.remove(m); continue; }

      // zombies burn in daylight
      if (m.kind === 'zombie') {
        const exposed = this.world.surfaceY(Math.floor(m.pos.x), Math.floor(m.pos.z)) <= m.pos.y + 0.5;
        if (daylight > 0.62 && exposed && !feet.liquid) {
          m.burn += dt;
          if (Math.random() < dt * 12) this.particles.flame(m.pos.x + (Math.random() - 0.5) * 0.5, m.pos.y + Math.random() * 1.6, m.pos.z + (Math.random() - 0.5) * 0.5);
          if (m.burn > 1) {
            m.burn = 0;
            m.health -= 2;
            m.hurtT = 0.2;
            if (m.health <= 0) { this.kill(m); continue; }
          }
        } else m.burn = 0;
      }

      if (m.soundCd <= 0 && dist < 26) {
        m.soundCd = 8 + Math.random() * 14;
        this.audio.mob(m.kind);
      }

      // animation
      const hs = Math.hypot(m.vel.x, m.vel.z);
      m.walk += dt * hs * 4.2;
      const swing = Math.sin(m.walk) * Math.min(0.8, hs * 0.35);
      m.parts.legs.forEach((leg, li) => {
        leg.rotation.x = swing * (li % 2 === 0 ? 1 : -1) * (li < 2 ? 1 : -1);
      });
      m.parts.arms.forEach((arm, ai) => {
        arm.rotation.x = -1.45 + Math.sin(m.walk * 0.6 + ai) * 0.12;
      });
      if (m.kind !== 'zombie') m.parts.head.rotation.x = Math.sin(m.walk * 0.5) * 0.08;
      m.group.position.copy(m.pos);
      m.group.rotation.y = m.yaw;
      const flash = m.hurtT > 0 ? 1 : 0;
      m.group.traverse((o) => {
        const mesh = o as THREE.Mesh;
        const mat = mesh.material as THREE.MeshLambertMaterial | undefined;
        if (mat && mat.emissive) mat.emissive.setRGB(flash * 0.6, 0, 0);
      });
    }
  }

  trySpawn(playerPos: THREE.Vector3, daylight: number, cap: number) {
    if (this.mobs.length >= cap) return;
    const hostileCount = this.mobs.filter((m) => m.spec.hostile).length;
    const passiveCount = this.mobs.length - hostileCount;
    const wantHostile = daylight < 0.35 && hostileCount < 7;
    const angle = Math.random() * Math.PI * 2;
    const r = 22 + Math.random() * 22;
    const x = Math.floor(playerPos.x + Math.cos(angle) * r);
    const z = Math.floor(playerPos.z + Math.sin(angle) * r);
    if (!this.world.has(Math.floor(x / 16), Math.floor(z / 16))) return;
    const sy = this.world.surfaceY(x, z);
    if (sy <= 32) return;
    const ground = this.world.getBlock(x, sy, z);
    if (!BLOCKS[ground].solid) return;
    if (this.world.getBlock(x, sy + 1, z) !== 0 || this.world.getBlock(x, sy + 2, z) !== 0) return;
    if (wantHostile) {
      this.spawn('zombie', x + 0.5, sy + 1, z + 0.5);
    } else if (passiveCount < 9 && (ground === B.GRASS || ground === B.SNOW_GRASS)) {
      this.spawn(Math.random() < 0.5 ? 'pig' : 'sheep', x + 0.5, sy + 1, z + 0.5);
    }
  }

  clear() {
    for (let i = this.mobs.length - 1; i >= 0; i--) this.remove(this.mobs[i]);
  }
}
