import * as THREE from 'three';
import { B, BLOCKS, getItem, breakTime, blockDrop, SMELTING } from './blocks';
import { CX, CZ, WORLD_H, SEA_LEVEL, chunkKey, BIOME_INFO } from './constants';
import { World } from './world';
import { buildChunkMesh, type MeshData } from './mesher';
import { buildAtlas, itemIcon, uvRects } from './textures';
import { makeAtlasTexture, sharedUniforms, terrainMaterial, makeHighlight, makeBreakMesh, type TerrainUniforms } from './materials';
import { Sky, Weather, type WeatherKind } from './sky';
import { Particles } from './fx';
import { DropManager, MobManager, itemGeometry, type Mob } from './entities';
import { GameAudio } from './audio';
import { Inventory, type Stack } from './inventory';
import { matchRecipe, RECIPES, recipeIngredients, recipeSize } from './recipes';
import { moveEntity, raycastVoxel, rayBox, type RayHit } from './physics';
import { uiStore, hudStore, pushToast, type Settings, type Overlay } from './store';
import { hashString } from './noise';
import { loadWorld, saveWorld, touchWorld, type WorldMeta, type SaveData } from './save';

const DAY_LENGTH = 720; // seconds for a full day/night cycle

interface ChunkMeshes {
  solid: THREE.Mesh | null;
  cross: THREE.Mesh | null;
  water: THREE.Mesh | null;
}

export interface PlayerState {
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  yaw: number;
  pitch: number;
  onGround: boolean;
  flying: boolean;
  sprinting: boolean;
  crouching: boolean;
  inWater: boolean;
  headInWater: boolean;
  health: number;
  hunger: number;
  air: number;
  xp: number;
  level: number;
  fallStart: number;
  exhaustion: number;
  regenTimer: number;
  hurtTimer: number;
  dead: boolean;
}

export class Engine {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  handScene = new THREE.Scene();
  handCamera: THREE.PerspectiveCamera;
  world: World;
  meta: WorldMeta | null = null;
  inv = new Inventory();
  audio = new GameAudio();
  uniforms: TerrainUniforms;
  matSolid: THREE.ShaderMaterial;
  matCross: THREE.ShaderMaterial;
  matWater: THREE.ShaderMaterial;
  sky = new Sky();
  weather = new Weather();
  particles: Particles;
  drops: DropManager;
  mobs: MobManager;
  highlight = makeHighlight();
  breakMesh: THREE.Mesh;
  sunLight: THREE.DirectionalLight;
  hemiLight: THREE.HemisphereLight;
  handLight: THREE.DirectionalLight;
  handMesh: THREE.Mesh | null = null;
  handItemId = -1;
  handSwing = 0;

  meshes = new Map<string, ChunkMeshes>();
  player: PlayerState;
  spawn = new THREE.Vector3(0, 60, 0);
  settings: Settings;
  mode: 'survival' | 'creative' = 'survival';
  time = 0.12;
  day = 1;
  playTime = 0;
  running = false;
  preview = true;
  previewAngle = 0;
  loadingTotal = 1;
  loadingDone = 0;
  target: RayHit | null = null;
  targetMob: Mob | null = null;
  breakProgress = 0;
  breakKey = '';
  attackCd = 0;
  useCd = 0;
  eatTimer = 0;
  keys = new Set<string>();
  mouse = { left: false, right: false };
  stats: Record<string, number> = {};
  achievements = new Set<string>();
  weatherTimer = 120;
  flash = 0;
  bob = 0;
  private lastChunk = { x: 1e9, z: 1e9 };
  private genQueue: [number, number][] = [];
  private meshQueue: [number, number][] = [];
  private raf = 0;
  private clock = new THREE.Clock();
  private hudAcc = 0;
  private saveAcc = 0;
  private fpsAcc = 0;
  private fpsFrames = 0;
  private fps = 60;
  private disposed = false;
  private crackUVBase: Float32Array;
  private tmpV = new THREE.Vector3();
  private fogBase = new THREE.Color();
  private lastStep = 0;
  private canvas: HTMLCanvasElement;
  private listeners: (() => void)[] = [];
  private mobSpawnAcc = 0;
  private furnaceTick = 0;

  constructor(canvas: HTMLCanvasElement, settings: Settings) {
    this.canvas = canvas;
    this.settings = settings;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
    this.renderer.setSize(window.innerWidth, window.innerHeight, false);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.06;
    this.renderer.autoClear = false;
    this.renderer.setClearColor(0x8fc0ee, 1);

    this.camera = new THREE.PerspectiveCamera(settings.fov, window.innerWidth / window.innerHeight, 0.08, 1200);
    this.camera.rotation.order = 'YXZ';
    this.handCamera = new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.01, 10);

    const { canvas: atlas } = buildAtlas();
    const tex = makeAtlasTexture(atlas);
    this.uniforms = sharedUniforms(tex);
    this.matSolid = terrainMaterial(this.uniforms, 'solid');
    this.matCross = terrainMaterial(this.uniforms, 'cross');
    this.matWater = terrainMaterial(this.uniforms, 'water');

    this.scene.add(this.sky.mesh, this.sky.clouds, this.weather.group, this.highlight, this.breakMesh0());
    this.breakMesh = makeBreakMesh(tex);
    this.scene.add(this.breakMesh);
    const box = this.breakMesh.geometry as THREE.BoxGeometry;
    this.crackUVBase = Float32Array.from((box.getAttribute('uv') as THREE.BufferAttribute).array as Float32Array);

    this.particles = new Particles(this.uniforms);
    this.scene.add(this.particles.points);
    this.drops = new DropManager(this.matSolid, this.matCross, this.audio);
    this.scene.add(this.drops.group);

    this.hemiLight = new THREE.HemisphereLight(0xbcd8f5, 0x4a4436, 1.1);
    this.sunLight = new THREE.DirectionalLight(0xfff2d8, 1.3);
    this.sunLight.position.set(60, 100, 30);
    this.scene.add(this.hemiLight, this.sunLight);

    this.handLight = new THREE.DirectionalLight(0xffffff, 1.5);
    this.handLight.position.set(0.4, 1, 0.8);
    this.handScene.add(this.handLight, new THREE.AmbientLight(0xffffff, 0.7));

    this.world = new World(1337);
    this.mobs = new MobManager(this.world, this.particles, this.audio, this.drops);
    this.scene.add(this.mobs.group);
    this.mobs.onKill = (m) => this.onMobKill(m);

    this.player = {
      pos: new THREE.Vector3(0, 70, 0),
      vel: new THREE.Vector3(),
      yaw: 0, pitch: 0,
      onGround: false, flying: false, sprinting: false, crouching: false,
      inWater: false, headInWater: false,
      health: 20, hunger: 20, air: 10, xp: 0, level: 0,
      fallStart: 70, exhaustion: 0, regenTimer: 0, hurtTimer: 0, dead: false,
    };

    this.bindEvents();
    this.running = true;
    this.clock.start();
    this.loop();
  }

  private breakMesh0() {
    return new THREE.Object3D();
  }

  /* ------------------------------------------------------------ lifecycle */

  private bindEvents() {
    const onResize = () => {
      const w = window.innerWidth, h = window.innerHeight;
      this.renderer.setSize(w, h, false);
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.handCamera.aspect = w / h;
      this.handCamera.updateProjectionMatrix();
    };
    window.addEventListener('resize', onResize);
    this.listeners.push(() => window.removeEventListener('resize', onResize));

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'F3') { e.preventDefault(); this.updateSettings({ showDebug: !this.settings.showDebug }); return; }
      if (e.repeat) return;
      const ui = uiStore.get();
      if (ui.screen !== 'game') return;
      if (e.code === 'Escape') {
        e.preventDefault();
        this.setOverlay(ui.overlay ? null : 'pause');
        return;
      }
      if (e.code === 'KeyE') {
        e.preventDefault();
        const o = ui.overlay;
        this.setOverlay(o === 'inventory' || o === 'crafting' || o === 'furnace' ? null : 'inventory');
        return;
      }
      if (ui.overlay) return;
      this.keys.add(e.code);
      if (e.code.startsWith('Digit')) {
        const n = parseInt(e.code.slice(5), 10);
        if (n >= 1 && n <= 9) this.selectSlot(n - 1);
      }
      if (e.code === 'KeyQ') this.dropHeld();
      if (e.code === 'KeyF' && this.mode === 'creative') this.player.flying = !this.player.flying;
      if (e.code === 'Space') {
        const now = performance.now();
        if (this.mode === 'creative' && now - this.lastSpace < 280) {
          this.player.flying = !this.player.flying;
          this.player.vel.y = 0;
        }
        this.lastSpace = now;
      }
      if (e.code === 'Tab') e.preventDefault();
    };
    const onKeyUp = (e: KeyboardEvent) => this.keys.delete(e.code);
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    this.listeners.push(() => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
    });

    const onMouseMove = (e: MouseEvent) => {
      if (document.pointerLockElement !== this.canvas) return;
      const s = this.settings.sensitivity * 0.0022;
      this.player.yaw -= e.movementX * s;
      this.player.pitch -= e.movementY * s * (this.settings.invertY ? -1 : 1);
      const lim = Math.PI / 2 - 0.001;
      this.player.pitch = Math.max(-lim, Math.min(lim, this.player.pitch));
    };
    const onMouseDown = (e: MouseEvent) => {
      if (uiStore.get().screen !== 'game' || uiStore.get().overlay) return;
      if (document.pointerLockElement !== this.canvas) { this.lockPointer(); return; }
      if (e.button === 0) { this.mouse.left = true; this.tryAttack(); }
      if (e.button === 2) { this.mouse.right = true; this.useItem(); }
      if (e.button === 1) { e.preventDefault(); this.pickBlock(); }
    };
    const onMouseUp = (e: MouseEvent) => {
      if (e.button === 0) { this.mouse.left = false; this.breakProgress = 0; }
      if (e.button === 2) { this.mouse.right = false; this.eatTimer = 0; }
    };
    const onWheel = (e: WheelEvent) => {
      if (uiStore.get().screen !== 'game' || uiStore.get().overlay) return;
      const dir = e.deltaY > 0 ? 1 : -1;
      this.selectSlot((this.inv.selected + dir + 9) % 9);
    };
    const onContext = (e: Event) => e.preventDefault();
    const onLockChange = () => {
      const locked = document.pointerLockElement === this.canvas;
      uiStore.set({ pointerLocked: locked });
      if (!locked) {
        this.keys.clear();
        this.mouse.left = false;
        this.mouse.right = false;
        const ui = uiStore.get();
        if (ui.screen === 'game' && !ui.overlay) this.setOverlay('pause');
      }
    };
    document.addEventListener('mousemove', onMouseMove);
    this.canvas.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);
    this.canvas.addEventListener('wheel', onWheel, { passive: true });
    this.canvas.addEventListener('contextmenu', onContext);
    document.addEventListener('pointerlockchange', onLockChange);
    this.listeners.push(() => {
      document.removeEventListener('mousemove', onMouseMove);
      this.canvas.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mouseup', onMouseUp);
      this.canvas.removeEventListener('wheel', onWheel);
      this.canvas.removeEventListener('contextmenu', onContext);
      document.removeEventListener('pointerlockchange', onLockChange);
    });
    const onBlur = () => { this.keys.clear(); this.mouse.left = false; this.mouse.right = false; };
    window.addEventListener('blur', onBlur);
    this.listeners.push(() => window.removeEventListener('blur', onBlur));
  }

  private lastSpace = 0;

  lockPointer() {
    const el = this.canvas;
    const p = el.requestPointerLock() as unknown as Promise<void> | undefined;
    if (p && typeof p.catch === 'function') p.catch(() => undefined);
  }

  dispose() {
    this.disposed = true;
    this.running = false;
    cancelAnimationFrame(this.raf);
    for (const off of this.listeners) off();
    this.listeners = [];
    this.clearMeshes();
    this.sky.dispose();
    this.weather.dispose();
    this.particles.dispose();
    this.audio.dispose();
    this.renderer.dispose();
  }

  /* --------------------------------------------------------- world loading */

  resetWorld(world: World) {
    this.clearMeshes();
    this.mobs.clear();
    this.drops.clear();
    this.world = world;
    (this.mobs as unknown as { world: World }).world = world;
    this.lastChunk = { x: 1e9, z: 1e9 };
    this.genQueue = [];
    this.meshQueue = [];
  }

  startPreview(seed = 20260214) {
    this.preview = true;
    const w = new World(seed);
    this.resetWorld(w);
    const sp = w.gen.findSpawn();
    this.spawn.set(sp.x, sp.y, sp.z);
    this.player.pos.copy(this.spawn);
    this.time = 0.16;
    this.mode = 'creative';
    uiStore.set({ screen: 'title', overlay: null });
    this.ensureArea(Math.floor(sp.x / CX), Math.floor(sp.z / CZ), 3, 400);
  }

  loadGame(meta: WorldMeta) {
    this.preview = false;
    this.meta = meta;
    this.mode = meta.mode;
    const world = new World(meta.seed);
    const save = loadWorld(meta.id);
    this.achievements.clear();
    this.stats = {};
    this.inv = new Inventory();
    this.time = 0.12;
    this.day = 1;
    this.playTime = 0;
    if (save) {
      world.loadEdits(save.edits ?? {});
      this.time = save.time ?? 0.12;
      this.day = save.day ?? 1;
      this.playTime = save.playTime ?? 0;
      this.inv.load(save.inv ?? { slots: [] });
      this.player.health = save.player?.health ?? 20;
      this.player.hunger = save.player?.hunger ?? 20;
      this.player.xp = save.player?.xp ?? 0;
      this.player.level = save.player?.level ?? 0;
      this.player.flying = save.player?.flying ?? false;
      this.player.yaw = save.player?.yaw ?? 0;
      this.player.pitch = save.player?.pitch ?? 0;
      for (const a of save.achievements ?? []) this.achievements.add(a);
      this.stats = save.stats ?? {};
      if (save.furnaces) for (const [k, v] of save.furnaces) world.furnaces.set(k, v);
      if (save.weather) { this.weather.set(save.weather.kind as WeatherKind); this.weatherTimer = save.weather.timer; }
      this.spawn.set(save.spawn?.x ?? 0, save.spawn?.y ?? 60, save.spawn?.z ?? 0);
    } else {
      const sp = world.gen.findSpawn();
      this.spawn.set(sp.x, sp.y, sp.z);
      if (meta.mode === 'survival') {
        this.inv.add(B.CRAFTING_TABLE, 0);
      }
    }
    this.resetWorld(world);
    if (save?.player) this.player.pos.set(save.player.x, save.player.y, save.player.z);
    else this.player.pos.copy(this.spawn);
    this.player.vel.set(0, 0, 0);
    this.player.dead = false;
    this.player.air = 10;
    this.player.hurtTimer = 0;
    this.weather.set(this.weather.kind);
    uiStore.set({
      screen: 'loading', overlay: null, loading: 0, loadingLabel: 'Generating terrain',
      mode: meta.mode, worldName: meta.name,
      achievements: uiStore.get().achievements.map((a) => ({ ...a, done: this.achievements.has(a.id) })),
    });
    const pcx = Math.floor(this.player.pos.x / CX), pcz = Math.floor(this.player.pos.z / CZ);
    const r = 2;
    this.loadingTotal = (r * 2 + 3) * (r * 2 + 3);
    this.loadingDone = 0;
    this.ensureArea(pcx, pcz, r + 1, 900);
    this.settlePlayer();
    this.syncInv();
    this.audio.init();
    this.audio.setVolume(this.settings.volume);
    this.audio.setMusic(this.settings.music);
  }

  private settlePlayer() {
    const p = this.player.pos;
    const x = Math.floor(p.x), z = Math.floor(p.z);
    let y = Math.min(WORLD_H - 3, Math.max(2, Math.floor(p.y)));
    for (let i = 0; i < WORLD_H; i++) {
      const a = this.world.getBlockSolid(x, y, z);
      const b = this.world.getBlockSolid(x, y + 1, z);
      if (BLOCKS[a].solid || BLOCKS[b].solid) y++;
      else break;
      if (y >= WORLD_H - 2) break;
    }
    p.y = y + 0.05;
    this.player.fallStart = p.y;
  }

  /** Synchronous generation used for the initial area / preview. */
  ensureArea(cx: number, cz: number, r: number, budgetMs: number) {
    const t0 = performance.now();
    for (let dx = -r; dx <= r; dx++)
      for (let dz = -r; dz <= r; dz++) {
        this.world.ensure(cx + dx, cz + dz);
        if (performance.now() - t0 > budgetMs) return;
      }
  }

  save(): boolean {
    if (!this.meta || this.preview) return false;
    const p = this.player;
    const data: SaveData = {
      edits: this.world.serializeEdits(),
      player: {
        x: p.pos.x, y: p.pos.y, z: p.pos.z, yaw: p.yaw, pitch: p.pitch,
        health: p.health, hunger: p.hunger, xp: p.xp, level: p.level, flying: p.flying,
      },
      inv: { slots: this.inv.slots, selected: this.inv.selected },
      time: this.time,
      day: this.day,
      weather: { kind: this.weather.kind, timer: this.weatherTimer },
      furnaces: Array.from(this.world.furnaces.entries()),
      achievements: Array.from(this.achievements),
      stats: this.stats,
      spawn: { x: this.spawn.x, y: this.spawn.y, z: this.spawn.z },
    };
    const ok = saveWorld(this.meta.id, data);
    this.meta = touchWorld(this.meta, { day: this.day, playTime: this.playTime });
    if (ok) uiStore.set({ saved: Date.now() });
    else pushToast({ title: 'Save failed', body: 'Browser storage is full.', kind: 'warn' });
    return ok;
  }

  quitToTitle() {
    this.save();
    if (document.pointerLockElement) document.exitPointerLock();
    this.startPreview(this.meta?.seed ?? 20260214);
  }

  /* -------------------------------------------------------------- meshing */

  private makeMesh(data: MeshData, mat: THREE.Material, cx: number, cz: number, order: number) {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(data.position, 3));
    geo.setAttribute('uv', new THREE.BufferAttribute(data.uv, 2));
    geo.setAttribute('tint', new THREE.BufferAttribute(data.color, 3, true));
    geo.setAttribute('lume', new THREE.BufferAttribute(data.light, 2, true));
    geo.setIndex(new THREE.BufferAttribute(data.index, 1));
    geo.computeBoundingSphere();
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(cx * CX, 0, cz * CZ);
    mesh.renderOrder = order;
    mesh.matrixAutoUpdate = false;
    mesh.updateMatrix();
    this.scene.add(mesh);
    return mesh;
  }

  private disposeMeshes(m: ChunkMeshes) {
    for (const key of ['solid', 'cross', 'water'] as const) {
      const mesh = m[key];
      if (mesh) {
        this.scene.remove(mesh);
        mesh.geometry.dispose();
      }
    }
  }

  private clearMeshes() {
    for (const m of this.meshes.values()) this.disposeMeshes(m);
    this.meshes.clear();
  }

  meshChunk(cx: number, cz: number) {
    const chunk = this.world.get(cx, cz);
    if (!chunk) return;
    const key = chunkKey(cx, cz);
    const old = this.meshes.get(key);
    if (old) this.disposeMeshes(old);
    const res = buildChunkMesh(
      chunk.data,
      this.world.neighbors(cx, cz),
      cx, cz,
      this.world.lightsNear(cx, cz),
      chunk.tint,
      chunk.topY,
    );
    const m: ChunkMeshes = {
      solid: res.solid ? this.makeMesh(res.solid, this.matSolid, cx, cz, 0) : null,
      cross: res.cross ? this.makeMesh(res.cross, this.matCross, cx, cz, 1) : null,
      water: res.water ? this.makeMesh(res.water, this.matWater, cx, cz, 2) : null,
    };
    this.meshes.set(key, m);
    chunk.dirty = false;
    this.world.dirty.delete(key);
  }

  private rebuildQueues(pcx: number, pcz: number) {
    const R = this.settings.renderDistance;
    const gen: [number, number][] = [];
    const mesh: [number, number][] = [];
    for (let dx = -R - 1; dx <= R + 1; dx++) {
      for (let dz = -R - 1; dz <= R + 1; dz++) {
        const d2 = dx * dx + dz * dz;
        if (d2 > (R + 1.5) * (R + 1.5)) continue;
        const cx = pcx + dx, cz = pcz + dz;
        if (!this.world.has(cx, cz)) gen.push([cx, cz]);
        if (d2 <= (R + 0.5) * (R + 0.5)) mesh.push([cx, cz]);
      }
    }
    gen.sort((a, b) => ((a[0] - pcx) ** 2 + (a[1] - pcz) ** 2) - ((b[0] - pcx) ** 2 + (b[1] - pcz) ** 2));
    mesh.sort((a, b) => ((a[0] - pcx) ** 2 + (a[1] - pcz) ** 2) - ((b[0] - pcx) ** 2 + (b[1] - pcz) ** 2));
    this.genQueue = gen;
    this.meshQueue = mesh;
    // unload distant chunks
    const limit = (R + 3) * (R + 3);
    for (const [key, c] of Array.from(this.world.chunks.entries())) {
      const d2 = (c.cx - pcx) ** 2 + (c.cz - pcz) ** 2;
      if (d2 > limit) {
        const m = this.meshes.get(key);
        if (m) { this.disposeMeshes(m); this.meshes.delete(key); }
        this.world.chunks.delete(key);
      }
    }
  }

  streamChunks(budgetMs: number) {
    const pcx = Math.floor(this.player.pos.x / CX);
    const pcz = Math.floor(this.player.pos.z / CZ);
    if (pcx !== this.lastChunk.x || pcz !== this.lastChunk.z) {
      this.lastChunk = { x: pcx, z: pcz };
      this.rebuildQueues(pcx, pcz);
    }
    const t0 = performance.now();
    let generated = 0;
    while (this.genQueue.length && performance.now() - t0 < budgetMs) {
      const [cx, cz] = this.genQueue.shift()!;
      if (!this.world.has(cx, cz)) {
        this.world.ensure(cx, cz);
        generated++;
        // neighbours may now be meshable
        for (const [dx, dz] of [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1]]) {
          const k = chunkKey(cx + dx, cz + dz);
          if (this.world.has(cx + dx, cz + dz) && !this.meshes.has(k)) this.meshQueue.push([cx + dx, cz + dz]);
        }
      }
    }
    // dirty chunks first (player edits)
    if (this.world.dirty.size) {
      for (const key of Array.from(this.world.dirty)) {
        const c = this.world.chunks.get(key);
        if (!c) { this.world.dirty.delete(key); continue; }
        if (this.world.neighborsReady(c.cx, c.cz)) {
          this.meshChunk(c.cx, c.cz);
          if (performance.now() - t0 > budgetMs + 6) break;
        }
      }
    }
    let meshed = 0;
    while (this.meshQueue.length && performance.now() - t0 < budgetMs + (generated ? 0 : 3)) {
      const [cx, cz] = this.meshQueue.shift()!;
      const key = chunkKey(cx, cz);
      if (this.meshes.has(key) || !this.world.has(cx, cz)) continue;
      if (!this.world.neighborsReady(cx, cz)) {
        this.world.ensure(cx + 1, cz); this.world.ensure(cx - 1, cz);
        this.world.ensure(cx, cz + 1); this.world.ensure(cx, cz - 1);
      }
      this.meshChunk(cx, cz);
      meshed++;
    }
    if (uiStore.get().screen === 'loading') {
      this.loadingDone = this.meshes.size;
      const pct = Math.min(1, this.loadingDone / this.loadingTotal);
      uiStore.set({ loading: pct, loadingLabel: pct < 0.6 ? 'Generating terrain' : 'Building chunk meshes' });
      if (pct >= 1 || (this.genQueue.length === 0 && this.meshQueue.length === 0)) {
        uiStore.set({ screen: 'game', loading: 1 });
        this.settlePlayer();
        this.lockPointer();
      }
    }
    return { generated, meshed };
  }

  updateSettings(patch: Partial<Settings>) {
    this.settings = { ...this.settings, ...patch };
    uiStore.set({ settings: this.settings });
    if (patch.fov != null) {
      this.camera.fov = patch.fov;
      this.camera.updateProjectionMatrix();
    }
    if (patch.volume != null) this.audio.setVolume(patch.volume);
    if (patch.music != null) this.audio.setMusic(patch.music);
    if (patch.particles != null) this.particles.enabled = patch.particles;
    if (patch.clouds != null) this.sky.clouds.visible = patch.clouds;
    if (patch.renderDistance != null) this.lastChunk = { x: 1e9, z: 1e9 };
  }

  /* ---------------------------------------------------------- ui plumbing */

  setOverlay(o: Overlay) {
    if (o === null) {
      this.inv.returnCraft();
      uiStore.set({ overlay: null, furnaceKey: null, furnace: null });
      this.syncInv();
      this.lockPointer();
    } else {
      uiStore.set({ overlay: o });
      this.keys.clear();
      this.mouse.left = false;
      this.mouse.right = false;
      this.breakProgress = 0;
      if (document.pointerLockElement) document.exitPointerLock();
      if (o === 'furnace') this.syncFurnace();
      this.syncInv();
    }
  }

  toggleOverlay(o: Overlay) {
    this.setOverlay(uiStore.get().overlay === o ? null : o);
  }

  selectSlot(n: number) {
    if (n === this.inv.selected) return;
    this.inv.selected = n;
    this.syncInv();
    const s = this.inv.slots[n];
    hudStore.set({ selectedName: s ? getItem(s.id).name : '', selectedAt: performance.now() });
  }

  syncInv() {
    const size = uiStore.get().overlay === 'crafting' ? 3 : 2;
    const grid = this.craftGrid(size);
    const r = matchRecipe(grid, size);
    uiStore.set({
      inv: {
        slots: this.inv.slots.map((s) => (s ? { ...s } : null)),
        craft: this.inv.craft.map((s) => (s ? { ...s } : null)),
        cursor: this.inv.cursor ? { ...this.inv.cursor } : null,
        selected: this.inv.selected,
        result: r ? { ...r.out } : null,
      },
    });
  }

  craftGrid(size: number): (Stack | null)[] {
    if (size === 3) return this.inv.craft;
    const out: (Stack | null)[] = [];
    for (let y = 0; y < 2; y++) for (let x = 0; x < 2; x++) out.push(this.inv.craft[y * 3 + x]);
    return out;
  }

  /** UI slot click: kind = inv | craft | result, button 0 = left, 2 = right. */
  clickSlot(kind: 'inv' | 'craft' | 'result', index: number, button: number, shift: boolean) {
    const inv = this.inv;
    const size = uiStore.get().overlay === 'crafting' ? 3 : 2;
    if (kind === 'result') {
      const grid = this.craftGrid(size);
      const r = matchRecipe(grid, size);
      if (!r) return;
      const max = getItem(r.out.id).stack;
      if (shift) {
        let guard = 0;
        while (guard++ < 64) {
          const g2 = this.craftGrid(size);
          const r2 = matchRecipe(g2, size);
          if (!r2) break;
          if (inv.add(r2.out.id, r2.out.count) > 0) break;
          this.consumeCraft(size);
          this.onCraft(r2.out.id);
        }
      } else {
        if (inv.cursor && (inv.cursor.id !== r.out.id || inv.cursor.count + r.out.count > max)) return;
        if (inv.cursor) inv.cursor.count += r.out.count;
        else inv.cursor = { ...r.out };
        this.consumeCraft(size);
        this.onCraft(r.out.id);
      }
      this.audio.craft();
      this.syncInv();
      return;
    }
    const arr = kind === 'inv' ? inv.slots : inv.craft;
    const cur = arr[index];
    if (shift && cur) {
      if (kind === 'inv') {
        // move between hotbar and main inventory
        const start = index < 9 ? 9 : 0;
        const end = index < 9 ? 36 : 9;
        let left = cur.count;
        const max = getItem(cur.id).stack;
        for (let i = start; i < end && left > 0; i++) {
          const s = arr[i];
          if (s && s.id === cur.id && s.count < max) {
            const take = Math.min(max - s.count, left);
            s.count += take; left -= take;
          }
        }
        for (let i = start; i < end && left > 0; i++) {
          if (!arr[i]) { arr[i] = { id: cur.id, count: left }; left = 0; }
        }
        if (left <= 0) arr[index] = null;
        else cur.count = left;
      } else {
        const left = inv.add(cur.id, cur.count);
        arr[index] = left > 0 ? { id: cur.id, count: left } : null;
      }
      this.syncInv();
      return;
    }
    if (button === 2) {
      if (!inv.cursor && cur) {
        const half = Math.ceil(cur.count / 2);
        inv.cursor = { id: cur.id, count: half };
        cur.count -= half;
        if (cur.count <= 0) arr[index] = null;
      } else if (inv.cursor) {
        const max = getItem(inv.cursor.id).stack;
        if (!cur) {
          arr[index] = { id: inv.cursor.id, count: 1 };
          inv.cursor.count--;
        } else if (cur.id === inv.cursor.id && cur.count < max) {
          cur.count++;
          inv.cursor.count--;
        }
        if (inv.cursor.count <= 0) inv.cursor = null;
      }
    } else {
      if (!inv.cursor) {
        if (cur) { inv.cursor = cur; arr[index] = null; }
      } else if (!cur) {
        arr[index] = inv.cursor;
        inv.cursor = null;
      } else if (cur.id === inv.cursor.id) {
        const max = getItem(cur.id).stack;
        const take = Math.min(max - cur.count, inv.cursor.count);
        cur.count += take;
        inv.cursor.count -= take;
        if (inv.cursor.count <= 0) inv.cursor = null;
      } else {
        arr[index] = inv.cursor;
        inv.cursor = cur;
      }
    }
    this.syncInv();
  }

  private consumeCraft(size: number) {
    if (size === 3) {
      for (let i = 0; i < 9; i++) {
        const s = this.inv.craft[i];
        if (s) { s.count--; if (s.count <= 0) this.inv.craft[i] = null; }
      }
    } else {
      for (const i of [0, 1, 3, 4]) {
        const s = this.inv.craft[i];
        if (s) { s.count--; if (s.count <= 0) this.inv.craft[i] = null; }
      }
    }
  }

  /** Recipe-book quick craft straight from the inventory. */
  quickCraft(recipeKey: string, all: boolean) {
    const r = RECIPES.find((x) => x.key === recipeKey);
    if (!r) return;
    const ings = recipeIngredients(r);
    let made = 0;
    const limit = all ? 64 : 1;
    while (made < limit) {
      if (!ings.every((i) => this.inv.count(i.id) >= i.count)) break;
      for (const i of ings) this.inv.remove(i.id, i.count);
      if (this.inv.add(r.out.id, r.out.count) > 0) {
        this.drops.spawn(this.world, this.player.pos.x, this.player.pos.y + 1, this.player.pos.z, r.out);
      }
      made++;
      this.onCraft(r.out.id);
    }
    if (made > 0) this.audio.craft();
    this.syncInv();
  }

  creativeGive(id: number, count = 64) {
    if (this.mode !== 'creative') return;
    this.inv.add(id, count);
    this.syncInv();
  }

  private onCraft(id: number) {
    if (id === B.CRAFTING_TABLE) this.unlock('planks');
    if (id >= 120 && id < 136) this.unlock('pick');
    if (id === B.FURNACE) this.unlock('furnace');
    this.stats.crafted = (this.stats.crafted ?? 0) + 1;
  }

  /* --------------------------------------------------------- interactions */

  dropHeld() {
    const s = this.inv.held;
    if (!s) return;
    const dir = this.lookDir();
    const pos = this.eyePos().addScaledVector(dir, 0.6);
    this.drops.spawn(this.world, pos.x, pos.y, pos.z, { id: s.id, count: 1 }, dir.clone().multiplyScalar(6).setY(2.4));
    this.inv.consumeHeld(1);
    this.syncInv();
  }

  pickBlock() {
    if (!this.target) return;
    const id = this.target.id;
    if (this.mode === 'creative') {
      const existing = this.inv.slots.findIndex((s, i) => i < 9 && s?.id === id);
      if (existing >= 0) this.selectSlot(existing);
      else {
        this.inv.slots[this.inv.selected] = { id, count: 64 };
        this.syncInv();
      }
    } else {
      const i = this.inv.slots.findIndex((s, idx) => idx < 9 && s?.id === id);
      if (i >= 0) this.selectSlot(i);
    }
  }

  eyePos() {
    return new THREE.Vector3(this.player.pos.x, this.player.pos.y + (this.player.crouching ? 1.42 : 1.62), this.player.pos.z);
  }

  lookDir() {
    const v = new THREE.Vector3(0, 0, -1);
    v.applyEuler(new THREE.Euler(this.player.pitch, this.player.yaw, 0, 'YXZ'));
    return v;
  }

  tryAttack() {
    this.handSwing = 1;
    if (this.targetMob && this.attackCd <= 0) {
      const held = this.inv.held;
      const tool = held ? getItem(held.id).tool : undefined;
      const dmg = tool ? tool.damage : 1;
      const dir = new THREE.Vector3(this.targetMob.pos.x - this.player.pos.x, 0, this.targetMob.pos.z - this.player.pos.z).normalize().multiplyScalar(5.5);
      this.mobs.hurt(this.targetMob, dmg, dir, true);
      this.attackCd = 0.42;
      this.audio.hit();
      this.player.exhaustion += 0.1;
      return;
    }
    if (this.mode === 'creative' && this.target && this.attackCd <= 0) {
      this.doBreak(this.target.x, this.target.y, this.target.z);
      this.attackCd = 0.16;
    }
  }

  useItem() {
    this.handSwing = 1;
    if (this.useCd > 0) return;
    const t = this.target;
    if (t && !this.player.crouching) {
      if (t.id === B.CRAFTING_TABLE) { this.useCd = 0.3; this.setOverlay('crafting'); return; }
      if (t.id === B.FURNACE) {
        const key = `${t.x},${t.y},${t.z}`;
        if (!this.world.furnaces.has(key)) {
          this.world.furnaces.set(key, { input: null, fuel: null, output: null, burn: 0, burnMax: 0, cook: 0 });
        }
        uiStore.set({ furnaceKey: key });
        this.useCd = 0.3;
        this.setOverlay('furnace');
        return;
      }
    }
    const held = this.inv.held;
    if (!held) return;
    const item = getItem(held.id);
    if (item.food != null) {
      if (this.player.hunger < 20) this.eatTimer = 0.001;
      return;
    }
    if (item.block == null) return;
    if (!t) return;
    const bx = t.x + t.nx, by = t.y + t.ny, bz = t.z + t.nz;
    this.placeBlock(bx, by, bz, item.block);
  }

  placeBlock(x: number, y: number, z: number, id: number) {
    if (y < 0 || y >= WORLD_H) return;
    const existing = this.world.getBlock(x, y, z);
    const eb = BLOCKS[existing];
    if (existing !== 0 && !eb.liquid && !eb.cross) return;
    const def = BLOCKS[id];
    if (def.cross) {
      const below = this.world.getBlock(x, y - 1, z);
      if (!BLOCKS[below].solid) return;
    }
    if (def.solid) {
      const p = this.player.pos;
      const halfW = 0.32;
      const h = this.player.crouching ? 1.5 : 1.8;
      if (p.x + halfW > x && p.x - halfW < x + 1 && p.y + h > y && p.y < y + 1 && p.z + halfW > z && p.z - halfW < z + 1) return;
      for (const m of this.mobs.mobs) {
        if (m.pos.x + m.spec.halfW > x && m.pos.x - m.spec.halfW < x + 1 &&
            m.pos.y + m.spec.height > y && m.pos.y < y + 1 &&
            m.pos.z + m.spec.halfW > z && m.pos.z - m.spec.halfW < z + 1) return;
      }
    }
    if (!this.world.setBlock(x, y, z, id)) return;
    // water meeting lava
    if (id === B.WATER || id === B.LAVA) {
      for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
        const n = this.world.getBlock(x + dx, y + dy, z + dz);
        if ((id === B.WATER && n === B.LAVA) || (id === B.LAVA && n === B.WATER)) {
          this.world.setBlock(x + dx, y + dy, z + dz, B.OBSIDIAN);
          this.particles.smoke(x + dx + 0.5, y + dy + 1, z + dz + 0.5, true);
        }
      }
    }
    if (this.mode === 'survival') this.inv.consumeHeld(1);
    this.audio.place(def.sound);
    this.particles.placePuff(x, y, z, id);
    this.handSwing = 1;
    this.useCd = 0.18;
    this.stats.placed = (this.stats.placed ?? 0) + 1;
    if (this.stats.placed >= 100) this.unlock('builder');
    this.syncInv();
  }

  doBreak(x: number, y: number, z: number) {
    const id = this.world.getBlock(x, y, z);
    if (id === 0 || BLOCKS[id].hardness === Infinity) return;
    const held = this.inv.held?.id;
    this.world.setBlock(x, y, z, 0);
    const above = this.world.getBlock(x, y + 1, z);
    if (BLOCKS[above].cross) {
      if (this.mode === 'survival') {
        const d2 = blockDrop(above, held, Math.random());
        if (d2) this.drops.spawn(this.world, x + 0.5, y + 1.2, z + 0.5, d2);
      }
      this.world.setBlock(x, y + 1, z, 0);
    }
    this.particles.blockBreak(x, y, z, id);
    this.audio.breakBlock(BLOCKS[id].sound);
    if (this.mode === 'survival') {
      const drop = blockDrop(id, held, Math.random());
      if (drop) this.drops.spawn(this.world, x + 0.5, y + 0.4, z + 0.5, drop);
      this.player.exhaustion += 0.05;
      if (id === B.COAL_ORE) this.addXp(1);
      if (id === B.DIAMOND_ORE) { this.addXp(5); this.unlock('diamond'); }
      if (id === B.IRON_ORE || id === B.GOLD_ORE) this.addXp(1);
      if (id === B.OAK_LOG || id === B.BIRCH_LOG) this.unlock('wood');
      if (id === B.STONE && y < 40) this.unlock('stone');
    } else if (id === B.OAK_LOG || id === B.BIRCH_LOG) this.unlock('wood');
    this.stats.mined = (this.stats.mined ?? 0) + 1;
    this.breakProgress = 0;
    this.breakKey = '';
    this.handSwing = 1;
  }

  addXp(n: number) {
    this.player.xp += n;
    let need = 7 + this.player.level * 3;
    while (this.player.xp >= need) {
      this.player.xp -= need;
      this.player.level++;
      need = 7 + this.player.level * 3;
      this.audio.achievement();
    }
  }

  unlock(id: string) {
    if (this.achievements.has(id)) return;
    const a = uiStore.get().achievements.find((x) => x.id === id);
    if (!a) return;
    this.achievements.add(id);
    uiStore.set({ achievements: uiStore.get().achievements.map((x) => (x.id === id ? { ...x, done: true } : x)) });
    pushToast({ title: a.name, body: a.desc, icon: a.icon, kind: 'achievement' });
    this.audio.achievement();
  }

  onMobKill(m: Mob) {
    this.addXp(m.spec.xp);
    if (m.spec.hostile) this.unlock('hunter');
    this.stats.kills = (this.stats.kills ?? 0) + 1;
  }

  /* ------------------------------------------------------------- furnace */

  syncFurnace() {
    const key = uiStore.get().furnaceKey;
    if (!key) return;
    const f = this.world.furnaces.get(key);
    if (!f) return;
    uiStore.set({ furnace: { ...f, input: f.input ? { ...f.input } : null, fuel: f.fuel ? { ...f.fuel } : null, output: f.output ? { ...f.output } : null } });
  }

  clickFurnace(slot: 'input' | 'fuel' | 'output', button: number, shift: boolean) {
    const key = uiStore.get().furnaceKey;
    if (!key) return;
    const f = this.world.furnaces.get(key);
    if (!f) return;
    const inv = this.inv;
    const cur = f[slot];
    if (slot === 'output') {
      if (!cur) return;
      if (inv.cursor && inv.cursor.id !== cur.id) return;
      const max = getItem(cur.id).stack;
      if (shift) {
        const left = inv.add(cur.id, cur.count);
        f.output = left > 0 ? { id: cur.id, count: left } : null;
      } else if (!inv.cursor) { inv.cursor = cur; f.output = null; }
      else if (inv.cursor.count + cur.count <= max) { inv.cursor.count += cur.count; f.output = null; }
      if (cur.id === 103) this.unlock('iron');
    } else if (button === 2 && inv.cursor) {
      if (!cur) { f[slot] = { id: inv.cursor.id, count: 1 }; inv.cursor.count--; }
      else if (cur.id === inv.cursor.id && cur.count < getItem(cur.id).stack) { cur.count++; inv.cursor.count--; }
      if (inv.cursor.count <= 0) inv.cursor = null;
    } else if (button === 2 && !inv.cursor && cur) {
      const half = Math.ceil(cur.count / 2);
      inv.cursor = { id: cur.id, count: half };
      cur.count -= half;
      if (cur.count <= 0) f[slot] = null;
    } else {
      if (!inv.cursor) { if (cur) { inv.cursor = cur; f[slot] = null; } }
      else if (!cur) { f[slot] = inv.cursor; inv.cursor = null; }
      else if (cur.id === inv.cursor.id) {
        const max = getItem(cur.id).stack;
        const take = Math.min(max - cur.count, inv.cursor.count);
        cur.count += take; inv.cursor.count -= take;
        if (inv.cursor.count <= 0) inv.cursor = null;
      } else { f[slot] = inv.cursor; inv.cursor = cur; }
    }
    this.syncFurnace();
    this.syncInv();
  }

  private tickFurnaces(dt: number) {
    for (const [key, f] of this.world.furnaces) {
      const result = f.input ? SMELTING[f.input.id] : undefined;
      const canOut = result != null && (!f.output || (f.output.id === result && f.output.count < getItem(result).stack));
      if (f.burn <= 0 && canOut && f.fuel) {
        const secs = getItem(f.fuel.id).fuel;
        if (secs) {
          f.burn = secs;
          f.burnMax = secs;
          f.fuel.count--;
          if (f.fuel.count <= 0) f.fuel = null;
        }
      }
      if (f.burn > 0) {
        f.burn = Math.max(0, f.burn - dt);
        if (canOut) {
          f.cook += dt;
          if (f.cook >= 7) {
            f.cook = 0;
            const outId = result!;
            if (f.output) f.output.count++;
            else f.output = { id: outId, count: 1 };
            if (f.input) { f.input.count--; if (f.input.count <= 0) f.input = null; }
            if (outId === 103) this.unlock('iron');
          }
        } else f.cook = Math.max(0, f.cook - dt * 2);
        if (Math.random() < dt * 3) {
          const [x, y, z] = key.split(',').map(Number);
          if (this.player.pos.distanceToSquared(new THREE.Vector3(x, y, z)) < 900) {
            this.particles.smoke(x + 0.5, y + 1.05, z + 0.5);
          }
        }
      } else f.cook = Math.max(0, f.cook - dt * 2);
    }
    this.furnaceTick += dt;
    if (this.furnaceTick > 0.15) {
      this.furnaceTick = 0;
      if (uiStore.get().overlay === 'furnace') this.syncFurnace();
    }
  }

  respawn() {
    const p = this.player;
    p.health = 20;
    p.hunger = 20;
    p.air = 10;
    p.dead = false;
    p.vel.set(0, 0, 0);
    p.pos.copy(this.spawn);
    p.xp = Math.floor(p.xp * 0.5);
    this.world.ensure(Math.floor(p.pos.x / CX), Math.floor(p.pos.z / CZ));
    this.settlePlayer();
    uiStore.set({ screen: 'game', overlay: null });
    this.lockPointer();
  }

  hurtPlayer(dmg: number, from?: THREE.Vector3) {
    const p = this.player;
    if (p.dead || this.mode === 'creative' || p.hurtTimer > 0) return;
    p.health = Math.max(0, p.health - dmg);
    p.hurtTimer = 0.5;
    this.audio.hurt();
    hudStore.set({ hurt: performance.now() });
    if (from) {
      const dir = new THREE.Vector3(p.pos.x - from.x, 0, p.pos.z - from.z).normalize().multiplyScalar(4.5);
      p.vel.x += dir.x; p.vel.z += dir.z;
      p.vel.y = Math.max(p.vel.y, 3.6);
    }
    if (p.health <= 0) {
      p.dead = true;
      uiStore.set({ screen: 'dead', overlay: null });
      if (document.pointerLockElement) document.exitPointerLock();
      this.save();
    }
  }

  /* ------------------------------------------------------------- physics */

  private digTimer = 0;
  private stepDist = 0;
  private armMesh: THREE.Mesh | null = null;
  private weatherFlashTimer = 12;
  private lavaTimer = 0;

  updatePlayer(dt: number) {
    const p = this.player;
    const ui = uiStore.get();
    if (ui.screen !== 'game' || p.dead) return;
    if (dt <= 0) return;
    const active = !ui.overlay;
    const k = this.keys;

    const feet = BLOCKS[this.world.getBlock(Math.floor(p.pos.x), Math.floor(p.pos.y + 0.1), Math.floor(p.pos.z))];
    const head = BLOCKS[this.world.getBlock(Math.floor(p.pos.x), Math.floor(p.pos.y + 1.6), Math.floor(p.pos.z))];
    const wasInWater = p.inWater;
    p.inWater = !!feet.liquid;
    p.headInWater = !!head.liquid;
    if (p.inWater && !wasInWater && p.vel.y < -6) {
      this.audio.splash();
      this.particles.splash(p.pos.x, p.pos.y + 0.3, p.pos.z);
    }

    p.crouching = active && (k.has('KeyC') || k.has('ControlLeft')) && !p.flying;
    p.sprinting = active && k.has('ShiftLeft') && !p.crouching;

    let ix = 0, iz = 0;
    if (active) {
      if (k.has('KeyW') || k.has('ArrowUp')) iz += 1;
      if (k.has('KeyS') || k.has('ArrowDown')) iz -= 1;
      if (k.has('KeyA') || k.has('ArrowLeft')) ix -= 1;
      if (k.has('KeyD') || k.has('ArrowRight')) ix += 1;
    }
    const len = Math.hypot(ix, iz);
    if (len > 0) { ix /= len; iz /= len; }
    const sy = Math.sin(p.yaw), cy = Math.cos(p.yaw);
    const fwdX = -sy, fwdZ = -cy, rightX = cy, rightZ = -sy;

    let speed = p.flying ? (p.sprinting ? 22 : 10.5) : p.crouching ? 1.9 : p.sprinting ? 6.1 : 4.4;
    if (p.inWater && !p.flying) speed *= 0.62;
    if (!p.onGround && !p.flying && !p.inWater) speed *= 0.94;

    const wishX = (fwdX * iz + rightX * ix) * speed;
    const wishZ = (fwdZ * iz + rightZ * ix) * speed;
    const accel = p.flying ? 10 : p.onGround ? 13 : p.inWater ? 5 : 3.2;
    const a = Math.min(1, accel * dt);
    p.vel.x += (wishX - p.vel.x) * a;
    p.vel.z += (wishZ - p.vel.z) * a;

    const jump = active && k.has('Space');
    if (p.flying) {
      let vy = 0;
      if (jump) vy += 9;
      if (k.has('KeyC') || k.has('ControlLeft')) vy -= 9;
      p.vel.y += (vy - p.vel.y) * Math.min(1, 12 * dt);
    } else if (p.inWater) {
      p.vel.y -= 9 * dt;
      if (jump) p.vel.y = Math.min(p.vel.y + 24 * dt, 3.6);
      p.vel.y = Math.max(p.vel.y, -3.4);
      p.vel.x *= 1 - 1.4 * dt;
      p.vel.z *= 1 - 1.4 * dt;
    } else {
      p.vel.y -= 28 * dt;
      if (p.vel.y < -58) p.vel.y = -58;
      if (jump && p.onGround) {
        p.vel.y = 8.7;
        p.onGround = false;
        p.exhaustion += p.sprinting ? 0.2 : 0.05;
        this.audio.jump();
      }
    }

    const prevX = p.pos.x, prevZ = p.pos.z;
    const height = p.crouching ? 1.5 : 1.8;
    const wasGround = p.onGround;
    const res = moveEntity(this.world, p.pos, p.vel, 0.3, height, dt);
    p.onGround = res.onGround;

    if (this.settings.autoJump && (res.hitX || res.hitZ) && p.onGround && len > 0 && !p.flying) {
      const fx2 = Math.floor(p.pos.x + (fwdX * iz + rightX * ix) * 0.7);
      const fz2 = Math.floor(p.pos.z + (fwdZ * iz + rightZ * ix) * 0.7);
      const fy = Math.floor(p.pos.y);
      if (BLOCKS[this.world.getBlockSolid(fx2, fy, fz2)].solid &&
          !BLOCKS[this.world.getBlockSolid(fx2, fy + 1, fz2)].solid &&
          !BLOCKS[this.world.getBlockSolid(fx2, fy + 2, fz2)].solid) {
        p.vel.y = 8.2;
      }
    }
    if (p.crouching && wasGround && !p.onGround && !p.inWater) {
      p.pos.x = prevX;
      p.pos.z = prevZ;
      p.vel.x = 0; p.vel.z = 0;
      p.pos.y = Math.floor(p.pos.y) + 0.001;
      p.onGround = true;
    }

    // fall damage
    if (p.onGround && !wasGround) {
      const fall = p.fallStart - p.pos.y;
      if (fall > 3.2 && !p.inWater) {
        const dmg = Math.floor(fall - 3);
        if (dmg > 0) this.hurtPlayer(dmg);
        this.audio.land();
      } else if (fall > 0.6) this.audio.land();
      p.fallStart = p.pos.y;
    }
    if (p.onGround || p.inWater || p.flying) p.fallStart = p.pos.y;
    else if (p.pos.y > p.fallStart) p.fallStart = p.pos.y;

    // footsteps
    const hs = Math.hypot(p.vel.x, p.vel.z);
    if (p.onGround && hs > 0.6) {
      this.stepDist += hs * dt;
      if (this.stepDist > (p.sprinting ? 1.9 : 2.4)) {
        this.stepDist = 0;
        const below = this.world.getBlock(Math.floor(p.pos.x), Math.floor(p.pos.y - 0.2), Math.floor(p.pos.z));
        if (below) this.audio.step(BLOCKS[below].sound);
      }
      this.bob += hs * dt * 1.6;
    }
    void this.lastStep;

    // environment damage
    if (feet.id === B.LAVA || head.id === B.LAVA) {
      this.lavaTimer += dt;
      if (this.lavaTimer > 0.5) { this.lavaTimer = 0; this.hurtPlayer(4); }
      if (Math.random() < dt * 8) this.particles.flame(p.pos.x, p.pos.y + 0.4, p.pos.z);
    } else this.lavaTimer = 0;
    for (const [dx, dz] of [[0.35, 0], [-0.35, 0], [0, 0.35], [0, -0.35]]) {
      if (this.world.getBlock(Math.floor(p.pos.x + dx), Math.floor(p.pos.y + 0.5), Math.floor(p.pos.z + dz)) === B.CACTUS) {
        this.hurtPlayer(1);
        break;
      }
    }

    // breath
    if (p.headInWater) {
      p.air -= dt * 0.7;
      if (p.air <= 0) { p.air = 0; this.hurtPlayer(2); }
      if (Math.random() < dt * 2) this.particles.splash(p.pos.x, p.pos.y + 1.5, p.pos.z, 1);
    } else p.air = Math.min(10, p.air + dt * 4);

    // hunger + regeneration
    if (this.mode === 'survival') {
      p.exhaustion += dt * (p.sprinting && hs > 1 ? 0.09 : hs > 0.5 ? 0.022 : 0.008);
      if (p.exhaustion >= 4) {
        p.exhaustion -= 4;
        p.hunger = Math.max(0, p.hunger - 1);
      }
      p.regenTimer += dt;
      if (p.regenTimer > 3.5) {
        p.regenTimer = 0;
        if (p.hunger >= 17 && p.health < 20) { p.health = Math.min(20, p.health + 1); p.exhaustion += 0.6; }
        else if (p.hunger <= 0) this.hurtPlayer(1);
      }
    }
    p.hurtTimer = Math.max(0, p.hurtTimer - dt);
    if (p.pos.y < -4) this.hurtPlayer(20);
    if (p.pos.y < 12) this.unlock('deep');
    if (p.pos.y > 80) this.unlock('sky');
  }

  private eat(dt: number) {
    if (this.eatTimer <= 0) return;
    const held = this.inv.held;
    const item = held ? getItem(held.id) : null;
    if (!item || item.food == null || !this.mouse.right) { this.eatTimer = 0; return; }
    this.eatTimer += dt;
    this.handSwing = Math.max(this.handSwing, 0.35 + Math.sin(this.eatTimer * 22) * 0.25);
    if (Math.random() < dt * 12) {
      this.particles.blockHit(this.player.pos.x, this.player.pos.y + 1.4, this.player.pos.z, B.SAPLING, 0, 0, 0);
    }
    if (this.eatTimer > 1.3) {
      this.eatTimer = 0;
      this.player.hunger = Math.min(20, this.player.hunger + item.food);
      this.inv.consumeHeld(1);
      this.audio.pickup();
      this.syncInv();
    }
  }

  /* --------------------------------------------------------- environment */

  updateEnvironment(dt: number) {
    const ang = this.time * Math.PI * 2;
    const sunDir = new THREE.Vector3(Math.cos(ang), Math.sin(ang), 0.26).normalize();
    const elev = sunDir.y;
    const smooth = (e0: number, e1: number, x: number) => {
      const t = Math.max(0, Math.min(1, (x - e0) / (e1 - e0)));
      return t * t * (3 - 2 * t);
    };
    const day = smooth(-0.14, 0.24, elev);
    const sunset = Math.max(0, 1 - Math.abs(elev) / 0.3);
    const overcast = this.weather.intensity;
    const night = 1 - day;

    const c = (hex: number) => new THREE.Color(hex).convertSRGBToLinear();
    const zenith = c(0x050a1c).lerp(c(0x2f74d0), day).lerp(c(0x35406e), sunset * 0.5);
    const horizon = c(0x121c33).lerp(c(0xa9d6f5), day).lerp(c(0xff8f45), sunset * 0.75);
    const sunCol = c(0x415a99).lerp(c(0xfff2d0), day).lerp(c(0xff9a52), sunset * 0.8);
    const gray = c(0x7f8894);
    zenith.lerp(gray, overcast * 0.55 * day);
    horizon.lerp(gray, overcast * 0.6 * day);

    const su = this.sky.uniforms;
    (su.uZenith.value as THREE.Color).copy(zenith);
    (su.uHorizon.value as THREE.Color).copy(horizon);
    (su.uGround.value as THREE.Color).copy(horizon).multiplyScalar(0.42);
    (su.uSunColor.value as THREE.Color).copy(sunCol);
    (su.uSunDir.value as THREE.Vector3).copy(sunDir);
    su.uNight.value = night * (1 - overcast * 0.7);
    su.uFlash.value = this.flash;

    const amb = c(0x0b1024).lerp(c(0x6d7d99), day).lerp(c(0x5a5f6b), overcast * 0.5 * day);
    const sun = c(0x0a1030).lerp(c(0xd9d2c0), day).lerp(c(0x8a8f99), overcast * 0.6 * day);
    this.uniforms.uAmbient.value.copy(amb).multiplyScalar(0.72);
    this.uniforms.uSun.value.copy(sun).multiplyScalar(0.95 * (1 - overcast * 0.45));
    if (this.flash > 0) {
      this.uniforms.uAmbient.value.addScalar(this.flash * 0.8);
      this.uniforms.uSun.value.addScalar(this.flash * 0.6);
    }
    this.uniforms.uTime.value = this.playTime + performance.now() * 0.00002;

    const rd = this.settings.renderDistance * CX;
    this.fogBase.copy(horizon).lerp(zenith, 0.25);
    if (this.player.headInWater && !this.preview) {
      const wc = c(0x1d5f96).multiplyScalar(0.35 + day * 0.75);
      this.uniforms.fogColor.value.copy(wc);
      this.uniforms.fogNear.value = 0.4;
      this.uniforms.fogFar.value = 16;
    } else {
      this.uniforms.fogColor.value.copy(this.fogBase);
      this.uniforms.fogNear.value = rd * (0.52 - overcast * 0.14);
      this.uniforms.fogFar.value = rd * (0.98 - overcast * 0.2);
    }
    this.renderer.setClearColor(this.uniforms.fogColor.value, 1);

    this.sunLight.position.copy(sunDir).multiplyScalar(120).add(this.camera.position);
    this.sunLight.target.position.copy(this.camera.position);
    this.sunLight.target.updateMatrixWorld();
    this.sunLight.color.copy(sunCol);
    this.sunLight.intensity = 0.25 + day * 1.15;
    this.hemiLight.intensity = 0.25 + day * 0.85;
    this.hemiLight.color.copy(horizon);
    this.handLight.intensity = 0.5 + day * 1.3;
    (this.handScene.children[1] as THREE.AmbientLight).intensity = 0.35 + day * 0.6 + Math.min(0.5, this.torchNear() * 0.5);

    this.sky.update(this.camera.position, this.playTime, overcast);
    this.sky.clouds.visible = this.settings.clouds;
    this.flash = Math.max(0, this.flash - dt * 3.2);

    const wind = Math.min(1, Math.max(0, (this.player.pos.y - 45) / 40)) * 0.6 + overcast * 0.4;
    this.audio.setAmbience(this.preview ? 0.3 : wind, this.weather.kind === 'snow' ? overcast * 0.2 : overcast);
    return day;
  }

  private torchNear(): number {
    const held = this.inv.held;
    if (held && BLOCKS[held.id]?.light) return 1;
    return 0;
  }

  updateWeather(dt: number) {
    this.weatherTimer -= dt;
    if (this.weatherTimer <= 0) {
      const biome = this.world.biomeAt(Math.floor(this.player.pos.x), Math.floor(this.player.pos.z));
      const cold = biome === 7 || biome === 6;
      const r = Math.random();
      if (this.weather.kind !== 'clear') {
        this.weather.set('clear');
        this.weatherTimer = 150 + Math.random() * 260;
      } else if (r < 0.34) {
        this.weather.set(cold ? 'snow' : r < 0.1 ? 'storm' : 'rain');
        this.weatherTimer = 60 + Math.random() * 110;
        pushToast({
          title: cold ? 'Snow begins to fall' : r < 0.1 ? 'A storm rolls in' : 'Rain begins to fall',
          kind: 'info',
        });
      } else {
        this.weatherTimer = 120 + Math.random() * 200;
      }
    }
    if (this.weather.kind === 'storm') {
      this.weatherFlashTimer -= dt;
      if (this.weatherFlashTimer <= 0) {
        this.weatherFlashTimer = 9 + Math.random() * 18;
        this.flash = 1;
        window.setTimeout(() => this.audio.thunder(), 400 + Math.random() * 1400);
      }
    }
  }

  /* ---------------------------------------------------------- interaction */

  updateTargeting() {
    const ui = uiStore.get();
    if (ui.overlay || this.preview || ui.screen !== 'game') {
      this.target = null;
      this.targetMob = null;
      this.highlight.visible = false;
      this.breakMesh.visible = false;
      return;
    }
    const eye = this.eyePos();
    const dir = this.lookDir();
    const reach = this.mode === 'creative' ? 6.5 : 4.7;
    const hit = raycastVoxel(this.world, eye, dir, reach);
    this.target = hit;
    let best: Mob | null = null;
    let bestD = hit ? hit.dist : reach;
    const min = new THREE.Vector3(), max = new THREE.Vector3();
    for (const m of this.mobs.mobs) {
      min.set(m.pos.x - m.spec.halfW, m.pos.y, m.pos.z - m.spec.halfW);
      max.set(m.pos.x + m.spec.halfW, m.pos.y + m.spec.height, m.pos.z + m.spec.halfW);
      const d = rayBox(eye, dir, min, max, reach);
      if (d != null && d < bestD) { bestD = d; best = m; }
    }
    this.targetMob = best;
    if (hit && !best) {
      this.highlight.visible = true;
      this.highlight.position.set(hit.x + 0.5, hit.y + 0.5, hit.z + 0.5);
    } else {
      this.highlight.visible = false;
    }
  }

  updateBreaking(dt: number) {
    const ui = uiStore.get();
    if (ui.overlay || !this.mouse.left || !this.target || this.targetMob || this.mode === 'creative') {
      this.breakProgress = 0;
      this.breakMesh.visible = false;
      return;
    }
    const t = this.target;
    const key = `${t.x},${t.y},${t.z}`;
    if (key !== this.breakKey) { this.breakKey = key; this.breakProgress = 0; }
    const time = breakTime(t.id, this.inv.held?.id, false);
    if (!isFinite(time)) { this.breakMesh.visible = false; return; }
    this.breakProgress += dt / time;
    this.handSwing = Math.max(this.handSwing, 0.55 + Math.sin(performance.now() * 0.018) * 0.35);
    this.digTimer -= dt;
    if (this.digTimer <= 0) {
      this.digTimer = 0.22;
      this.audio.dig(BLOCKS[t.id].sound);
      this.particles.blockHit(t.x, t.y, t.z, t.id, t.nx, t.ny, t.nz);
    }
    if (this.breakProgress >= 1) {
      this.doBreak(t.x, t.y, t.z);
      this.breakMesh.visible = false;
      return;
    }
    const stage = Math.max(0, Math.min(9, Math.floor(this.breakProgress * 10)));
    this.setCrackStage(stage);
    this.breakMesh.visible = true;
    this.breakMesh.position.set(t.x + 0.5, t.y + 0.5, t.z + 0.5);
  }

  private crackStage = -1;
  private setCrackStage(stage: number) {
    if (stage === this.crackStage) return;
    this.crackStage = stage;
    const rect = uvRects.get(`crack_${stage}`);
    if (!rect) return;
    const geo = this.breakMesh.geometry as THREE.BoxGeometry;
    const attr = geo.getAttribute('uv') as THREE.BufferAttribute;
    const arr = attr.array as Float32Array;
    for (let i = 0; i < arr.length; i += 2) {
      arr[i] = rect[0] + this.crackUVBase[i] * rect[2];
      arr[i + 1] = rect[1] + this.crackUVBase[i + 1] * rect[3];
    }
    attr.needsUpdate = true;
  }

  /* ------------------------------------------------------------- visuals */

  updateCamera(dt: number) {
    const p = this.player;
    const eyeH = p.crouching ? 1.42 : 1.62;
    const speed = Math.hypot(p.vel.x, p.vel.z);
    const bobAmt = this.settings.viewBob && p.onGround ? Math.min(1, speed / 5) : 0;
    const by = Math.sin(this.bob * 2) * 0.045 * bobAmt;
    const bx = Math.cos(this.bob) * 0.035 * bobAmt;
    this.camera.position.set(p.pos.x + bx, p.pos.y + eyeH + by, p.pos.z);
    this.camera.rotation.set(p.pitch, p.yaw, Math.cos(this.bob) * 0.008 * bobAmt);
    const targetFov = this.settings.fov + (p.sprinting && speed > 3 ? 6 : 0) + (p.headInWater ? -6 : 0);
    if (Math.abs(this.camera.fov - targetFov) > 0.05) {
      this.camera.fov += (targetFov - this.camera.fov) * Math.min(1, dt * 8);
      this.camera.updateProjectionMatrix();
    }
  }

  updateHand(dt: number) {
    const id = this.inv.held?.id ?? -1;
    if (id !== this.handItemId) {
      this.handItemId = id;
      if (this.handMesh) { this.handScene.remove(this.handMesh); this.handMesh = null; }
      if (this.armMesh) { this.handScene.remove(this.armMesh); this.armMesh = null; }
      if (id >= 0) {
        const { geo, flat } = itemGeometry(id);
        this.handMesh = new THREE.Mesh(geo, flat ? this.matCross : this.matSolid);
        this.handMesh.scale.setScalar(flat ? 1.5 : 1.25);
        this.handScene.add(this.handMesh);
      } else {
        this.armMesh = new THREE.Mesh(
          new THREE.BoxGeometry(0.17, 0.44, 0.17),
          new THREE.MeshLambertMaterial({ color: 0xd9a273 }),
        );
        this.handScene.add(this.armMesh);
      }
    }
    this.handSwing = Math.max(0, this.handSwing - dt * 3.4);
    const s = Math.sin(this.handSwing * Math.PI);
    const speed = Math.min(1, Math.hypot(this.player.vel.x, this.player.vel.z) / 5);
    const bobX = Math.cos(this.bob) * 0.02 * speed;
    const bobY = Math.abs(Math.sin(this.bob * 2)) * 0.02 * speed;
    if (this.handMesh) {
      const flat = !!BLOCKS[id]?.cross || getItem(id).block == null;
      this.handMesh.position.set(0.42 + bobX - s * 0.12, -0.4 + bobY - s * 0.16, -0.62 + s * 0.12);
      this.handMesh.rotation.set(
        flat ? 0.2 - s * 0.9 : 0.12 - s * 0.8,
        flat ? -0.5 : -0.62 + s * 0.4,
        flat ? 0.35 : 0.08,
      );
    }
    if (this.armMesh) {
      this.armMesh.position.set(0.4 + bobX - s * 0.1, -0.46 + bobY - s * 0.12, -0.55 + s * 0.14);
      this.armMesh.rotation.set(-0.35 - s * 1.1, 0.2, 0.18);
    }
  }

  /* ----------------------------------------------------------------- hud */

  syncHud(day: number) {
    const p = this.player;
    const biome = this.world.biomeAt(Math.floor(p.pos.x), Math.floor(p.pos.z));
    let tris = 0;
    for (const m of this.meshes.values()) {
      for (const key of ['solid', 'cross', 'water'] as const) {
        const mesh = m[key];
        if (mesh) tris += (mesh.geometry.getIndex()?.count ?? 0) / 3;
      }
    }
    hudStore.set({
      health: p.health, hunger: p.hunger, air: p.air, xp: p.xp, level: p.level,
      x: p.pos.x, y: p.pos.y, z: p.pos.z,
      biome: BIOME_INFO[biome].name,
      time: this.time, day: this.day,
      fps: Math.round(this.fps), chunks: this.meshes.size, tris: Math.round(tris),
      target: this.target ? BLOCKS[this.target.id].name : this.targetMob ? this.targetMob.kind : null,
      breaking: this.breakProgress,
      weather: this.weather.kind === 'clear' ? 'Clear' : this.weather.kind === 'storm' ? 'Thunderstorm' : this.weather.kind === 'rain' ? 'Rain' : 'Snow',
      underwater: p.headInWater,
      flying: p.flying, sprinting: p.sprinting,
      mobCount: this.mobs.mobs.length,
    });
    void day;
  }

  render() {
    this.renderer.clear();
    this.renderer.render(this.scene, this.camera);
    if (!this.preview && uiStore.get().screen === 'game') {
      this.renderer.clearDepth();
      this.renderer.render(this.handScene, this.handCamera);
    }
  }

  loop = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const raw = this.clock.getDelta();
    const dt = Math.min(0.05, raw);
    const ui = uiStore.get();
    this.fpsAcc += raw;
    this.fpsFrames++;
    if (this.fpsAcc > 0.5) {
      this.fps = this.fpsFrames / this.fpsAcc;
      this.fpsAcc = 0;
      this.fpsFrames = 0;
    }

    if (this.preview) {
      this.time = (this.time + dt * 0.006) % 1;
      this.playTime += dt;
      this.streamChunks(5);
      this.previewAngle += dt * 0.028;
      const r = 30;
      this.camera.position.set(
        this.spawn.x + Math.cos(this.previewAngle) * r,
        this.spawn.y + 13 + Math.sin(this.previewAngle * 0.7) * 3,
        this.spawn.z + Math.sin(this.previewAngle) * r,
      );
      this.camera.lookAt(this.spawn.x, this.spawn.y + 1, this.spawn.z);
      this.updateEnvironment(dt);
      this.particles.update(dt, this.world);
      this.render();
      return;
    }

    const paused = ui.overlay === 'pause' || ui.overlay === 'settings' || ui.screen === 'dead';
    const sim = paused ? 0 : dt;
    const loading = ui.screen === 'loading';

    if (!loading) {
      this.time += sim / DAY_LENGTH;
      if (this.time >= 1) {
        this.time -= 1;
        this.day++;
        this.unlock('night');
      }
      this.playTime += sim;
      this.updatePlayer(sim);
      this.eat(sim);
    }
    this.streamChunks(loading ? 16 : 5);
    const day = this.updateEnvironment(dt);
    if (!loading) {
      this.updateWeather(sim);
      this.updateTargeting();
      this.updateBreaking(sim);
      this.attackCd = Math.max(0, this.attackCd - dt);
      this.useCd = Math.max(0, this.useCd - dt);
      if (this.mouse.left && this.mode === 'creative' && this.target && !this.targetMob && this.attackCd <= 0) {
        this.doBreak(this.target.x, this.target.y, this.target.z);
        this.attackCd = 0.18;
      }
      if (this.mouse.right && this.useCd <= 0 && !ui.overlay) {
        const held = this.inv.held;
        if (held && getItem(held.id).block != null) this.useItem();
      }
      this.mobSpawnAcc += sim;
      if (this.mobSpawnAcc > 2.2) {
        this.mobSpawnAcc = 0;
        this.mobs.trySpawn(this.player.pos, day, this.mode === 'creative' ? 10 : 16);
      }
      this.mobs.update(sim, this.player.pos, day, (dmg, from) => this.hurtPlayer(dmg, from), 1);
      this.drops.update(sim, this.world, this.tmpV.copy(this.player.pos).setY(this.player.pos.y + 0.9), (s) => {
        const left = this.inv.add(s.id, s.count);
        if (left !== s.count) this.syncInv();
        return left;
      }, this.mode === 'creative');
      this.tickFurnaces(sim);
      this.updateCamera(dt);
      this.updateHand(dt);
      this.saveAcc += dt;
      if (this.saveAcc > 30) { this.saveAcc = 0; this.save(); }
    }
    this.particles.update(sim, this.world);
    this.weather.update(sim, this.camera.position, this.world, this.playTime);
    // torch ambience (only nearby emitters, driven by the chunk light index)
    if (this.settings.particles && !paused) {
      const pcx = Math.floor(this.player.pos.x / CX), pcz = Math.floor(this.player.pos.z / CZ);
      const lights = this.world.lightsNear(pcx, pcz);
      for (const L of lights) {
        const dx = L.x - this.player.pos.x, dy = L.y - this.player.pos.y, dz = L.z - this.player.pos.z;
        if (dx * dx + dy * dy + dz * dz > 196) continue;
        if (this.world.getBlock(Math.floor(L.x), Math.floor(L.y), Math.floor(L.z)) === B.TORCH) {
          this.particles.flame(L.x, L.y + 0.18, L.z);
        }
      }
    }
    this.hudAcc += dt;
    if (this.hudAcc > 0.1) { this.hudAcc = 0; this.syncHud(day); }
    this.render();
  };
}

export const engineHelpers = { hashString, getItem, breakTime, blockDrop, SMELTING, matchRecipe, RECIPES, recipeIngredients, recipeSize, itemIcon, uvRects, itemGeometry, moveEntity, raycastVoxel, rayBox, BIOME_INFO, SEA_LEVEL, hudStore, DAY_LENGTH };
