import type { Stack } from './inventory';
import type { FurnaceState } from './world';

export interface WorldMeta {
  id: string;
  name: string;
  seed: number;
  mode: 'survival' | 'creative';
  created: number;
  lastPlayed: number;
  playTime: number;
  day: number;
}

export interface SaveData {
  edits: Record<string, number[]>;
  player: {
    x: number; y: number; z: number; yaw: number; pitch: number;
    health: number; hunger: number; xp: number; level: number; flying: boolean;
  };
  inv: { slots: (Stack | null)[]; selected: number };
  time: number;
  day: number;
  weather: { kind: string; timer: number };
  furnaces: [string, FurnaceState][];
  achievements: string[];
  stats: Record<string, number>;
  spawn: { x: number; y: number; z: number };
  playTime?: number;
}

const INDEX = 'voxelcraft:worlds';
const KEY = (id: string) => `voxelcraft:world:${id}`;

export function listWorlds(): WorldMeta[] {
  try {
    const raw = localStorage.getItem(INDEX);
    if (!raw) return [];
    const arr = JSON.parse(raw) as WorldMeta[];
    return arr.sort((a, b) => b.lastPlayed - a.lastPlayed);
  } catch {
    return [];
  }
}

function writeIndex(list: WorldMeta[]) {
  try { localStorage.setItem(INDEX, JSON.stringify(list)); } catch { /* quota */ }
}

export function createWorldMeta(name: string, seed: number, mode: 'survival' | 'creative'): WorldMeta {
  const meta: WorldMeta = {
    id: `w${Date.now().toString(36)}${Math.floor(Math.random() * 1e4).toString(36)}`,
    name: name.trim() || 'New World',
    seed: seed >>> 0,
    mode,
    created: Date.now(),
    lastPlayed: Date.now(),
    playTime: 0,
    day: 1,
  };
  const list = listWorlds();
  list.unshift(meta);
  writeIndex(list);
  return meta;
}

export function touchWorld(meta: WorldMeta, patch: Partial<WorldMeta> = {}) {
  const list = listWorlds();
  const i = list.findIndex((w) => w.id === meta.id);
  const next = { ...meta, ...patch, lastPlayed: Date.now() };
  if (i >= 0) list[i] = next;
  else list.unshift(next);
  writeIndex(list);
  return next;
}

export function deleteWorld(id: string) {
  writeIndex(listWorlds().filter((w) => w.id !== id));
  try { localStorage.removeItem(KEY(id)); } catch { /* ignore */ }
}

export function saveWorld(id: string, data: SaveData): boolean {
  try {
    localStorage.setItem(KEY(id), JSON.stringify(data));
    return true;
  } catch {
    return false;
  }
}

export function loadWorld(id: string): SaveData | null {
  try {
    const raw = localStorage.getItem(KEY(id));
    if (!raw) return null;
    return JSON.parse(raw) as SaveData;
  } catch {
    return null;
  }
}

export function saveSize(id: string): number {
  try { return (localStorage.getItem(KEY(id)) ?? '').length; } catch { return 0; }
}
