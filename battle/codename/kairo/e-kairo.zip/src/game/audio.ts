/** Fully synthesised audio: no sample files, everything is generated with WebAudio. */
import type { SoundKind } from './blocks';

export class GameAudio {
  ctx: AudioContext | null = null;
  private master!: GainNode;
  private sfx!: GainNode;
  private musicBus!: GainNode;
  private ambBus!: GainNode;
  private noiseBuf!: AudioBuffer;
  private verb!: ConvolverNode;
  private windGain: GainNode | null = null;
  private rainGain: GainNode | null = null;
  private musicTimer: number | null = null;
  private started = false;
  volume = 0.7;
  musicOn = true;
  muted = false;

  init() {
    if (this.started) return;
    const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return;
    try {
      this.ctx = new Ctor();
    } catch {
      return;
    }
    const ctx = this.ctx;
    this.started = true;
    this.master = ctx.createGain();
    this.master.gain.value = this.volume;
    this.master.connect(ctx.destination);

    this.sfx = ctx.createGain();
    this.sfx.gain.value = 0.9;
    this.sfx.connect(this.master);
    this.musicBus = ctx.createGain();
    this.musicBus.gain.value = this.musicOn ? 0.34 : 0;
    this.ambBus = ctx.createGain();
    this.ambBus.gain.value = 0.5;
    this.ambBus.connect(this.master);

    // reverb
    this.verb = ctx.createConvolver();
    const len = ctx.sampleRate * 2.2;
    const imp = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const d = imp.getChannelData(ch);
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.6);
    }
    this.verb.buffer = imp;
    const verbGain = ctx.createGain();
    verbGain.gain.value = 0.5;
    this.verb.connect(verbGain);
    verbGain.connect(this.master);
    this.musicBus.connect(this.master);
    this.musicBus.connect(this.verb);

    // noise source buffer
    const nlen = ctx.sampleRate * 2;
    this.noiseBuf = ctx.createBuffer(1, nlen, ctx.sampleRate);
    const nd = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < nlen; i++) nd[i] = Math.random() * 2 - 1;

    this.startAmbience();
    this.scheduleMusic();
  }

  resume() {
    if (this.ctx && this.ctx.state === 'suspended') void this.ctx.resume();
  }

  setVolume(v: number) {
    this.volume = v;
    if (this.master) this.master.gain.value = this.muted ? 0 : v;
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master) this.master.gain.value = m ? 0 : this.volume;
  }

  setMusic(on: boolean) {
    this.musicOn = on;
    if (this.musicBus) this.musicBus.gain.setTargetAtTime(on ? 0.34 : 0, this.ctx!.currentTime, 0.4);
  }

  private noise(dur: number, filterType: BiquadFilterType, freq: number, gain: number, q = 1, decay = 1) {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    const f = ctx.createBiquadFilter();
    f.type = filterType;
    f.frequency.value = freq;
    f.Q.value = q;
    const g = ctx.createGain();
    const t = ctx.currentTime;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, gain), t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur * decay);
    src.connect(f); f.connect(g); g.connect(this.sfx);
    src.start(t);
    src.stop(t + dur + 0.05);
  }

  private tone(freq: number, dur: number, type: OscillatorType, gain: number, slideTo?: number, delay = 0) {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const t = ctx.currentTime + delay;
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(this.sfx);
    o.start(t);
    o.stop(t + dur + 0.03);
  }

  step(kind: SoundKind) {
    const map: Record<SoundKind, [BiquadFilterType, number, number]> = {
      grass: ['bandpass', 900, 0.1],
      dirt: ['lowpass', 500, 0.13],
      stone: ['bandpass', 1500, 0.09],
      wood: ['bandpass', 700, 0.11],
      sand: ['highpass', 2200, 0.07],
      glass: ['highpass', 3000, 0.06],
      cloth: ['lowpass', 900, 0.07],
      liquid: ['lowpass', 700, 0.09],
    };
    const [f, freq, g] = map[kind] ?? map.stone;
    this.noise(0.11, f, freq * (0.85 + Math.random() * 0.3), g, 1.2);
  }

  dig(kind: SoundKind) {
    const freq = kind === 'stone' ? 1300 : kind === 'wood' ? 620 : kind === 'glass' ? 2600 : 750;
    this.noise(0.09, 'bandpass', freq * (0.8 + Math.random() * 0.4), 0.07, 1.4);
  }

  breakBlock(kind: SoundKind) {
    const freq = kind === 'stone' ? 1100 : kind === 'wood' ? 520 : kind === 'glass' ? 3200 : 640;
    this.noise(0.3, 'bandpass', freq, 0.24, 0.9);
    this.noise(0.22, 'lowpass', freq * 0.4, 0.16, 1);
    if (kind === 'glass') this.tone(2400, 0.18, 'triangle', 0.08, 1400);
  }

  place(kind: SoundKind) {
    this.noise(0.14, 'lowpass', kind === 'stone' ? 900 : 620, 0.2, 1);
    this.tone(kind === 'wood' ? 180 : 140, 0.08, 'square', 0.045);
  }

  hurt() {
    this.tone(320, 0.24, 'sawtooth', 0.14, 110);
    this.noise(0.16, 'lowpass', 800, 0.12);
  }

  jump() { this.noise(0.07, 'highpass', 1200, 0.035); }
  land() { this.noise(0.14, 'lowpass', 420, 0.14); }

  splash() {
    this.noise(0.45, 'lowpass', 1400, 0.2, 0.7);
    this.tone(600, 0.2, 'sine', 0.05, 240);
  }

  pickup() {
    this.tone(720, 0.07, 'triangle', 0.07);
    this.tone(1080, 0.09, 'triangle', 0.055, undefined, 0.05);
  }

  craft() {
    this.tone(420, 0.1, 'square', 0.05);
    this.tone(630, 0.12, 'square', 0.045, undefined, 0.07);
    this.tone(840, 0.16, 'triangle', 0.05, undefined, 0.14);
  }

  achievement() {
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((n, i) => this.tone(n, 0.5, 'triangle', 0.07, undefined, i * 0.11));
  }

  hit() {
    this.noise(0.12, 'bandpass', 420, 0.18, 1.2);
    this.tone(180, 0.1, 'square', 0.06, 90);
  }

  thunder() {
    this.noise(1.9, 'lowpass', 260, 0.5, 0.6, 1);
    this.noise(1.2, 'lowpass', 90, 0.42, 0.6, 1);
  }

  mob(kind: 'pig' | 'sheep' | 'zombie') {
    if (!this.ctx) return;
    if (kind === 'pig') {
      this.tone(320, 0.13, 'sawtooth', 0.055, 190);
      this.noise(0.12, 'bandpass', 700, 0.05, 3);
    } else if (kind === 'sheep') {
      const ctx = this.ctx;
      const o = ctx.createOscillator();
      o.type = 'sawtooth';
      const t = ctx.currentTime;
      o.frequency.setValueAtTime(420, t);
      const lfo = ctx.createOscillator();
      lfo.frequency.value = 17;
      const lg = ctx.createGain();
      lg.gain.value = 28;
      lfo.connect(lg); lg.connect(o.frequency);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.06, t + 0.05);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.55);
      const f = ctx.createBiquadFilter();
      f.type = 'bandpass'; f.frequency.value = 900; f.Q.value = 2;
      o.connect(f); f.connect(g); g.connect(this.sfx);
      o.start(t); lfo.start(t);
      o.stop(t + 0.6); lfo.stop(t + 0.6);
    } else {
      this.tone(120, 0.6, 'sawtooth', 0.075, 68);
      this.noise(0.55, 'lowpass', 420, 0.07, 0.8);
    }
  }

  private startAmbience() {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const mk = (type: BiquadFilterType, freq: number, q: number) => {
      const src = ctx.createBufferSource();
      src.buffer = this.noiseBuf;
      src.loop = true;
      const f = ctx.createBiquadFilter();
      f.type = type; f.frequency.value = freq; f.Q.value = q;
      const g = ctx.createGain();
      g.gain.value = 0;
      src.connect(f); f.connect(g); g.connect(this.ambBus);
      src.start();
      return g;
    };
    this.windGain = mk('lowpass', 420, 0.7);
    this.rainGain = mk('highpass', 1100, 0.5);
  }

  setAmbience(wind: number, rain: number) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.windGain?.gain.setTargetAtTime(wind * 0.1, t, 1.2);
    this.rainGain?.gain.setTargetAtTime(rain * 0.16, t, 1.0);
  }

  private scheduleMusic() {
    if (this.musicTimer != null) return;
    const scale = [0, 2, 4, 7, 9, 12, 14, 16, 19];
    const roots = [220, 174.61, 196, 146.83];
    let bar = 0;
    const play = () => {
      if (!this.ctx || !this.musicOn || this.muted) {
        this.musicTimer = window.setTimeout(play, 4000);
        return;
      }
      const ctx = this.ctx;
      const root = roots[bar % roots.length];
      bar++;
      const t0 = ctx.currentTime + 0.05;
      const chord = [0, 4, 7];
      chord.forEach((c, i) => {
        const o = ctx.createOscillator();
        o.type = 'sine';
        o.frequency.value = root * Math.pow(2, c / 12) * 0.5;
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.0001, t0);
        g.gain.linearRampToValueAtTime(0.05, t0 + 1.6 + i * 0.2);
        g.gain.linearRampToValueAtTime(0.0001, t0 + 7.5);
        o.connect(g); g.connect(this.musicBus);
        o.start(t0); o.stop(t0 + 8);
      });
      const notes = 3 + Math.floor(Math.random() * 3);
      for (let i = 0; i < notes; i++) {
        const when = t0 + 0.4 + Math.random() * 5.4;
        const semi = scale[Math.floor(Math.random() * scale.length)];
        const o = ctx.createOscillator();
        o.type = 'triangle';
        o.frequency.value = root * Math.pow(2, semi / 12);
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.0001, when);
        g.gain.exponentialRampToValueAtTime(0.075, when + 0.06);
        g.gain.exponentialRampToValueAtTime(0.0001, when + 2.4);
        o.connect(g); g.connect(this.musicBus);
        o.start(when); o.stop(when + 2.6);
      }
      this.musicTimer = window.setTimeout(play, 7600);
    };
    this.musicTimer = window.setTimeout(play, 1200);
  }

  dispose() {
    if (this.musicTimer != null) clearTimeout(this.musicTimer);
    this.musicTimer = null;
    if (this.ctx) void this.ctx.close();
    this.ctx = null;
    this.started = false;
  }
}
