import * as THREE from 'three';
import { mulberry32 } from './noise';
import type { World } from './world';

const SKY_VERT = /* glsl */ `
varying vec3 vDir;
void main() {
  vDir = normalize(position);
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`;

const SKY_FRAG = /* glsl */ `
uniform vec3 uZenith;
uniform vec3 uHorizon;
uniform vec3 uGround;
uniform vec3 uSunColor;
uniform vec3 uSunDir;
uniform float uNight;
uniform float uTime;
uniform float uFlash;
varying vec3 vDir;

float hash13(vec3 p) {
  p = fract(p * 0.1031);
  p += dot(p, p.yzx + 33.33);
  return fract((p.x + p.y) * p.z);
}

void main() {
  vec3 d = normalize(vDir);
  float up = max(d.y, 0.0);
  vec3 col = mix(uHorizon, uZenith, pow(up, 0.62));
  if (d.y < 0.0) col = mix(uHorizon, uGround, min(1.0, -d.y * 2.6));

  float sd = max(dot(d, uSunDir), 0.0);
  col += uSunColor * pow(sd, 900.0) * 3.2;
  col += uSunColor * pow(sd, 12.0) * 0.30 * (1.0 - uNight);
  col += uSunColor * pow(sd, 3.0) * 0.09 * (1.0 - uNight);

  float md = max(dot(d, -uSunDir), 0.0);
  col += vec3(0.95, 0.96, 1.0) * pow(md, 2600.0) * 3.0 * uNight;
  col += vec3(0.35, 0.45, 0.75) * pow(md, 60.0) * 0.16 * uNight;

  vec3 cell = floor(d * 220.0);
  float h = hash13(cell);
  float twinkle = 0.65 + 0.35 * sin(uTime * 2.2 + h * 60.0);
  float star = smoothstep(0.9965, 0.9995, h) * uNight * up * twinkle;
  col += vec3(star) * 1.4;

  col += vec3(0.75, 0.8, 1.0) * uFlash;
  gl_FragColor = vec4(col, 1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}
`;

function cloudTexture(): THREE.Texture {
  const S = 128;
  const cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const c = cv.getContext('2d')!;
  const img = c.createImageData(S, S);
  const rnd = mulberry32(90210);
  const grid = 16;
  const vals = new Float32Array(grid * grid);
  for (let i = 0; i < vals.length; i++) vals[i] = rnd();
  const smooth = (x: number, y: number, scale: number) => {
    const gx = (x / S) * scale, gy = (y / S) * scale;
    const x0 = Math.floor(gx) % grid, y0 = Math.floor(gy) % grid;
    const x1 = (x0 + 1) % grid, y1 = (y0 + 1) % grid;
    const fx = gx - Math.floor(gx), fy = gy - Math.floor(gy);
    const sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy);
    const a = vals[x0 + y0 * grid], b = vals[x1 + y0 * grid];
    const cc = vals[x0 + y1 * grid], d = vals[x1 + y1 * grid];
    return (a + (b - a) * sx) * (1 - sy) + (cc + (d - cc) * sx) * sy;
  };
  for (let y = 0; y < S; y++)
    for (let x = 0; x < S; x++) {
      const n = smooth(x, y, 4) * 0.6 + smooth(x, y, 8) * 0.3 + smooth(x, y, 16) * 0.1;
      const a = n > 0.56 ? Math.min(1, (n - 0.56) * 6) : 0;
      const i = (x + y * S) * 4;
      img.data[i] = img.data[i + 1] = img.data[i + 2] = 255;
      img.data[i + 3] = Math.round(a * 235);
    }
  c.putImageData(img, 0, 0);
  const tex = new THREE.CanvasTexture(cv);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.repeat.set(6, 6);
  return tex;
}

export class Sky {
  mesh: THREE.Mesh;
  clouds: THREE.Mesh;
  uniforms: Record<string, THREE.IUniform>;
  private cloudTex: THREE.Texture;

  constructor() {
    this.uniforms = {
      uZenith: { value: new THREE.Color(0x2f74d0) },
      uHorizon: { value: new THREE.Color(0xa9d6f5) },
      uGround: { value: new THREE.Color(0x2a3340) },
      uSunColor: { value: new THREE.Color(0xfff2d0) },
      uSunDir: { value: new THREE.Vector3(0, 1, 0) },
      uNight: { value: 0 },
      uTime: { value: 0 },
      uFlash: { value: 0 },
    };
    this.mesh = new THREE.Mesh(
      new THREE.SphereGeometry(500, 32, 20),
      new THREE.ShaderMaterial({
        uniforms: this.uniforms,
        vertexShader: SKY_VERT,
        fragmentShader: SKY_FRAG,
        side: THREE.BackSide,
        depthWrite: false,
        fog: false,
      }),
    );
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = -100;

    this.cloudTex = cloudTexture();
    this.clouds = new THREE.Mesh(
      new THREE.PlaneGeometry(1400, 1400),
      new THREE.MeshBasicMaterial({
        map: this.cloudTex,
        transparent: true,
        depthWrite: false,
        opacity: 0.85,
        side: THREE.DoubleSide,
        fog: false,
      }),
    );
    this.clouds.rotation.x = -Math.PI / 2;
    this.clouds.position.y = 122;
    this.clouds.renderOrder = -90;
    this.clouds.frustumCulled = false;
  }

  update(camPos: THREE.Vector3, t: number, overcast: number) {
    this.mesh.position.copy(camPos);
    this.clouds.position.x = camPos.x;
    this.clouds.position.z = camPos.z;
    this.uniforms.uTime.value = t;
    const m = this.clouds.material as THREE.MeshBasicMaterial;
    m.opacity = 0.62 + overcast * 0.35;
    this.cloudTex.offset.x = (t * 0.0035) % 1;
    this.cloudTex.offset.y = (t * 0.0012) % 1;
  }

  dispose() {
    this.mesh.geometry.dispose();
    (this.mesh.material as THREE.Material).dispose();
    this.clouds.geometry.dispose();
    this.cloudTex.dispose();
  }
}

export type WeatherKind = 'clear' | 'rain' | 'storm' | 'snow';

export class Weather {
  group = new THREE.Group();
  kind: WeatherKind = 'clear';
  intensity = 0;
  private rain: THREE.LineSegments;
  private snow: THREE.Points;
  private rainPos: Float32Array;
  private snowPos: Float32Array;
  private rainVel: Float32Array;
  private snowPhase: Float32Array;
  private readonly RAIN_N = 2600;
  private readonly SNOW_N = 1800;
  private rnd = mulberry32(4242);

  constructor() {
    this.rainPos = new Float32Array(this.RAIN_N * 6);
    this.rainVel = new Float32Array(this.RAIN_N);
    for (let i = 0; i < this.RAIN_N; i++) {
      this.resetDrop(i, 0, 60, 0, true);
      this.rainVel[i] = 26 + this.rnd() * 14;
    }
    const rg = new THREE.BufferGeometry();
    rg.setAttribute('position', new THREE.BufferAttribute(this.rainPos, 3));
    this.rain = new THREE.LineSegments(
      rg,
      new THREE.LineBasicMaterial({ color: 0xa8c8ee, transparent: true, opacity: 0.42, fog: true }),
    );
    this.rain.frustumCulled = false;
    this.rain.visible = false;

    this.snowPos = new Float32Array(this.SNOW_N * 3);
    this.snowPhase = new Float32Array(this.SNOW_N);
    for (let i = 0; i < this.SNOW_N; i++) {
      this.snowPos[i * 3] = (this.rnd() - 0.5) * 70;
      this.snowPos[i * 3 + 1] = this.rnd() * 40;
      this.snowPos[i * 3 + 2] = (this.rnd() - 0.5) * 70;
      this.snowPhase[i] = this.rnd() * 6.28;
    }
    const sg = new THREE.BufferGeometry();
    sg.setAttribute('position', new THREE.BufferAttribute(this.snowPos, 3));
    this.snow = new THREE.Points(
      sg,
      new THREE.PointsMaterial({
        color: 0xffffff, size: 0.16, transparent: true, opacity: 0.9,
        sizeAttenuation: true, depthWrite: false, fog: true,
      }),
    );
    this.snow.frustumCulled = false;
    this.snow.visible = false;
    this.group.add(this.rain, this.snow);
  }

  private resetDrop(i: number, px: number, py: number, pz: number, init = false) {
    const x = px + (this.rnd() - 0.5) * 64;
    const z = pz + (this.rnd() - 0.5) * 64;
    const y = py + (init ? this.rnd() * 40 - 12 : 22 + this.rnd() * 12);
    const o = i * 6;
    this.rainPos[o] = x; this.rainPos[o + 1] = y; this.rainPos[o + 2] = z;
    this.rainPos[o + 3] = x + 0.04; this.rainPos[o + 4] = y - 0.75; this.rainPos[o + 5] = z;
  }

  set(kind: WeatherKind) {
    this.kind = kind;
    this.rain.visible = kind === 'rain' || kind === 'storm';
    this.snow.visible = kind === 'snow';
  }

  update(dt: number, p: THREE.Vector3, world: World, t: number) {
    const target = this.kind === 'clear' ? 0 : this.kind === 'storm' ? 1 : 0.72;
    this.intensity += (target - this.intensity) * Math.min(1, dt * 0.7);
    if (this.kind === 'clear' && this.intensity < 0.01) return;
    const surface = world.surfaceY(Math.floor(p.x), Math.floor(p.z));
    const deep = p.y < surface - 8;
    this.rain.visible = (this.kind === 'rain' || this.kind === 'storm') && !deep;
    this.snow.visible = this.kind === 'snow' && !deep;
    if (deep) return;

    if (this.rain.visible) {
      const n = Math.floor(this.RAIN_N * Math.max(0.25, this.intensity));
      const geo = this.rain.geometry;
      geo.setDrawRange(0, n * 2);
      for (let i = 0; i < n; i++) {
        const o = i * 6;
        const dy = this.rainVel[i] * dt;
        this.rainPos[o + 1] -= dy;
        this.rainPos[o + 4] -= dy;
        const ground = world.surfaceY(Math.floor(this.rainPos[o]), Math.floor(this.rainPos[o + 2]));
        if (this.rainPos[o + 1] < ground + 0.2 || Math.abs(this.rainPos[o] - p.x) > 34 || Math.abs(this.rainPos[o + 2] - p.z) > 34) {
          this.resetDrop(i, p.x, p.y, p.z);
        }
      }
      (geo.getAttribute('position') as THREE.BufferAttribute).needsUpdate = true;
      (this.rain.material as THREE.LineBasicMaterial).opacity = 0.18 + this.intensity * 0.3;
    }
    if (this.snow.visible) {
      const geo = this.snow.geometry;
      for (let i = 0; i < this.SNOW_N; i++) {
        const o = i * 3;
        this.snowPos[o + 1] -= dt * (1.4 + (i % 5) * 0.2);
        this.snowPos[o] += Math.sin(t * 0.7 + this.snowPhase[i]) * dt * 0.8;
        this.snowPos[o + 2] += Math.cos(t * 0.5 + this.snowPhase[i]) * dt * 0.6;
        const ground = world.surfaceY(Math.floor(this.snowPos[o]), Math.floor(this.snowPos[o + 2]));
        if (this.snowPos[o + 1] < ground + 0.2 || Math.abs(this.snowPos[o] - p.x) > 36 || Math.abs(this.snowPos[o + 2] - p.z) > 36) {
          this.snowPos[o] = p.x + (this.rnd() - 0.5) * 64;
          this.snowPos[o + 1] = p.y + 18 + this.rnd() * 12;
          this.snowPos[o + 2] = p.z + (this.rnd() - 0.5) * 64;
        }
      }
      (geo.getAttribute('position') as THREE.BufferAttribute).needsUpdate = true;
    }
  }

  dispose() {
    this.rain.geometry.dispose();
    (this.rain.material as THREE.Material).dispose();
    this.snow.geometry.dispose();
    (this.snow.material as THREE.Material).dispose();
  }
}
