import { B } from './blocks';
import type { Stack } from './inventory';

export interface Recipe {
  key: string;
  out: Stack;
  pattern?: string[];
  map?: Record<string, number>;
  shapeless?: number[];
  category: 'building' | 'tools' | 'misc';
}

const R: Recipe[] = [];
const shaped = (key: string, out: Stack, pattern: string[], map: Record<string, number>, category: Recipe['category'] = 'misc') =>
  R.push({ key, out, pattern, map, category });
const shapeless = (key: string, out: Stack, ids: number[], category: Recipe['category'] = 'misc') =>
  R.push({ key, out, shapeless: ids, category });

shapeless('oak_planks', { id: B.PLANKS, count: 4 }, [B.OAK_LOG], 'building');
shapeless('birch_planks', { id: B.BIRCH_PLANKS, count: 4 }, [B.BIRCH_LOG], 'building');
shaped('stick', { id: 100, count: 4 }, ['P', 'P'], { P: B.PLANKS });
shaped('stick_birch', { id: 100, count: 4 }, ['P', 'P'], { P: B.BIRCH_PLANKS });
shaped('crafting_table', { id: B.CRAFTING_TABLE, count: 1 }, ['PP', 'PP'], { P: B.PLANKS }, 'building');
shaped('furnace', { id: B.FURNACE, count: 1 }, ['CCC', 'C C', 'CCC'], { C: B.COBBLE }, 'building');
shaped('torch', { id: B.TORCH, count: 4 }, ['C', 'S'], { C: 101, S: 100 });
shaped('torch_charcoal', { id: B.TORCH, count: 4 }, ['C', 'S'], { C: 102, S: 100 });
shaped('stone_bricks', { id: B.STONE_BRICKS, count: 4 }, ['SS', 'SS'], { S: B.STONE }, 'building');
shaped('bricks', { id: B.BRICKS, count: 1 }, ['BB', 'BB'], { B: 111 }, 'building');
shaped('sandstone', { id: B.SANDSTONE, count: 1 }, ['SS', 'SS'], { S: B.SAND }, 'building');
shaped('bread', { id: 113, count: 1 }, ['SSS'], { S: 112 });
shapeless('mossy', { id: B.MOSSY_COBBLE, count: 1 }, [B.COBBLE, B.TALL_GRASS], 'building');
shaped('wool_from_grass', { id: B.WOOL, count: 1 }, ['SS', 'SS'], { S: B.TALL_GRASS }, 'building');
shaped('glass_pane_alt', { id: B.GLASS, count: 1 }, ['GG', 'GG'], { G: B.ICE }, 'building');

const MATS: [number, string][] = [
  [B.PLANKS, 'wooden'],
  [B.COBBLE, 'stone'],
  [103, 'iron'],
  [105, 'diamond'],
];
MATS.forEach(([mat, name], tier) => {
  const base = 120 + tier * 4;
  shaped(`${name}_pickaxe`, { id: base, count: 1 }, ['MMM', ' S ', ' S '], { M: mat, S: 100 }, 'tools');
  shaped(`${name}_axe`, { id: base + 1, count: 1 }, ['MM', 'MS', ' S'], { M: mat, S: 100 }, 'tools');
  shaped(`${name}_shovel`, { id: base + 2, count: 1 }, ['M', 'S', 'S'], { M: mat, S: 100 }, 'tools');
  shaped(`${name}_sword`, { id: base + 3, count: 1 }, ['M', 'M', 'S'], { M: mat, S: 100 }, 'tools');
});

export const RECIPES = R;

export function recipeIngredients(r: Recipe): { id: number; count: number }[] {
  const tally = new Map<number, number>();
  if (r.shapeless) {
    for (const id of r.shapeless) tally.set(id, (tally.get(id) ?? 0) + 1);
  } else if (r.pattern && r.map) {
    for (const row of r.pattern)
      for (const ch of row) {
        const id = r.map[ch];
        if (id != null) tally.set(id, (tally.get(id) ?? 0) + 1);
      }
  }
  return Array.from(tally, ([id, count]) => ({ id, count }));
}

export function recipeSize(r: Recipe): number {
  if (!r.pattern) return 2;
  const h = r.pattern.length;
  const w = Math.max(...r.pattern.map((p) => p.length));
  return Math.max(w, h) <= 2 ? 2 : 3;
}

/** grid is a size*size array of stacks. */
export function matchRecipe(grid: (Stack | null)[], size: number): Recipe | null {
  const ids: number[] = [];
  let minx = size, miny = size, maxx = -1, maxy = -1;
  for (let y = 0; y < size; y++)
    for (let x = 0; x < size; x++) {
      const s = grid[y * size + x];
      if (s) {
        ids.push(s.id);
        if (x < minx) minx = x;
        if (y < miny) miny = y;
        if (x > maxx) maxx = x;
        if (y > maxy) maxy = y;
      }
    }
  if (maxx < 0) return null;
  const w = maxx - minx + 1, h = maxy - miny + 1;

  for (const r of RECIPES) {
    if (r.shapeless) {
      if (r.shapeless.length !== ids.length) continue;
      const need = [...r.shapeless].sort((a, b) => a - b);
      const have = [...ids].sort((a, b) => a - b);
      if (need.every((v, i) => v === have[i])) return r;
      continue;
    }
    if (!r.pattern || !r.map) continue;
    const ph = r.pattern.length;
    const pw = Math.max(...r.pattern.map((p) => p.length));
    if (pw !== w || ph !== h) continue;
    for (const mirror of [false, true]) {
      let ok = true;
      for (let y = 0; y < h && ok; y++)
        for (let x = 0; x < w && ok; x++) {
          const ch = r.pattern[y][mirror ? w - 1 - x : x] ?? ' ';
          const want = ch === ' ' ? null : r.map[ch];
          const got = grid[(miny + y) * size + (minx + x)];
          if ((want ?? null) !== (got ? got.id : null)) ok = false;
        }
      if (ok) return r;
    }
  }
  return null;
}
