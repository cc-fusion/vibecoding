import type { Stack } from './inventory';

export interface Settings {
  renderDistance: number;
  fov: number;
  sensitivity: number;
  volume: number;
  music: boolean;
  particles: boolean;
  autoJump: boolean;
  showDebug: boolean;
  clouds: boolean;
  invertY: boolean;
  viewBob: boolean;
}

export const DEFAULT_SETTINGS: Settings = {
  renderDistance: 6,
  fov: 74,
  sensitivity: 1,
  volume: 0.7,
  music: true,
  particles: true,
  autoJump: true,
  showDebug: false,
  clouds: true,
  invertY: false,
  viewBob: true,
};

export interface Toast {
  id: number;
  title: string;
  body?: string;
  icon?: number;
  kind: 'info' | 'achievement' | 'warn';
}

export interface Achievement {
  id: string;
  name: string;
  desc: string;
  icon: number;
  done: boolean;
}

export interface InvSnapshot {
  slots: (Stack | null)[];
  craft: (Stack | null)[];
  cursor: Stack | null;
  selected: number;
  result: Stack | null;
}

export type Screen = 'title' | 'worlds' | 'create' | 'loading' | 'game' | 'dead';
export type Overlay = null | 'pause' | 'inventory' | 'crafting' | 'furnace' | 'settings' | 'achievements';

export interface UIState {
  screen: Screen;
  overlay: Overlay;
  loading: number;
  loadingLabel: string;
  settings: Settings;
  toasts: Toast[];
  achievements: Achievement[];
  inv: InvSnapshot;
  mode: 'survival' | 'creative';
  worldName: string;
  furnaceKey: string | null;
  furnace: { input: Stack | null; fuel: Stack | null; output: Stack | null; burn: number; burnMax: number; cook: number } | null;
  hint: string;
  saved: number;
  pointerLocked: boolean;
}

export interface HudState {
  health: number;
  hunger: number;
  air: number;
  xp: number;
  level: number;
  x: number;
  y: number;
  z: number;
  biome: string;
  time: number;
  day: number;
  fps: number;
  chunks: number;
  tris: number;
  target: string | null;
  breaking: number;
  weather: string;
  underwater: boolean;
  hurt: number;
  flying: boolean;
  sprinting: boolean;
  mobCount: number;
  selectedName: string;
  selectedAt: number;
}

export function createStore<T extends object>(initial: T) {
  let state = initial;
  const subs = new Set<() => void>();
  return {
    get: () => state,
    set(patch: Partial<T> | ((s: T) => Partial<T>)) {
      const p = typeof patch === 'function' ? patch(state) : patch;
      let changed = false;
      for (const k of Object.keys(p) as (keyof T)[]) {
        if (state[k] !== p[k]) { changed = true; break; }
      }
      if (!changed) return;
      state = { ...state, ...p };
      subs.forEach((f) => f());
    },
    subscribe(f: () => void) {
      subs.add(f);
      return () => subs.delete(f);
    },
  };
}

export const ACHIEVEMENTS: Achievement[] = [
  { id: 'wood', name: 'Timber!', desc: 'Punch a tree and collect a log', icon: 15, done: false },
  { id: 'planks', name: 'Workbench', desc: 'Craft a crafting table', icon: 21, done: false },
  { id: 'pick', name: 'Stone Age', desc: 'Craft your first pickaxe', icon: 120, done: false },
  { id: 'stone', name: 'Rock Bottom', desc: 'Mine stone underground', icon: 3, done: false },
  { id: 'furnace', name: 'Hot Topic', desc: 'Build a furnace', icon: 22, done: false },
  { id: 'iron', name: 'Iron Age', desc: 'Smelt an iron ingot', icon: 103, done: false },
  { id: 'diamond', name: 'Diamonds!', desc: 'Find and mine a diamond', icon: 105, done: false },
  { id: 'night', name: 'Night Watch', desc: 'Survive your first night', icon: 28, done: false },
  { id: 'hunter', name: 'Hunter', desc: 'Defeat a hostile creature', icon: 123, done: false },
  { id: 'deep', name: 'Deep Diver', desc: 'Descend below Y=12', icon: 39, done: false },
  { id: 'sky', name: 'Sky High', desc: 'Climb above Y=80', icon: 11, done: false },
  { id: 'builder', name: 'Architect', desc: 'Place 100 blocks', icon: 30, done: false },
];

const loadSettings = (): Settings => {
  try {
    const raw = localStorage.getItem('voxelcraft:settings');
    if (raw) return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch { /* ignore */ }
  return { ...DEFAULT_SETTINGS };
};

export const uiStore = createStore<UIState>({
  screen: 'title',
  overlay: null,
  loading: 0,
  loadingLabel: '',
  settings: { ...DEFAULT_SETTINGS },
  toasts: [],
  achievements: ACHIEVEMENTS.map((a) => ({ ...a })),
  inv: { slots: new Array(36).fill(null), craft: new Array(9).fill(null), cursor: null, selected: 0, result: null },
  mode: 'survival',
  worldName: '',
  furnaceKey: null,
  furnace: null,
  hint: '',
  saved: 0,
  pointerLocked: false,
});

export const hudStore = createStore<HudState>({
  health: 20, hunger: 20, air: 10, xp: 0, level: 0,
  x: 0, y: 0, z: 0, biome: 'Plains', time: 0.3, day: 1, fps: 0, chunks: 0, tris: 0,
  target: null, breaking: 0, weather: 'Clear', underwater: false, hurt: 0,
  flying: false, sprinting: false, mobCount: 0, selectedName: '', selectedAt: 0,
});

export function initSettings() {
  uiStore.set({ settings: loadSettings() });
}

export function persistSettings(s: Settings) {
  try { localStorage.setItem('voxelcraft:settings', JSON.stringify(s)); } catch { /* ignore */ }
}

let toastId = 1;
export function pushToast(t: Omit<Toast, 'id'>) {
  const toast = { ...t, id: toastId++ };
  uiStore.set((s) => ({ toasts: [...s.toasts, toast].slice(-4) }));
  setTimeout(() => {
    uiStore.set((s) => ({ toasts: s.toasts.filter((x) => x.id !== toast.id) }));
  }, 4200);
}
