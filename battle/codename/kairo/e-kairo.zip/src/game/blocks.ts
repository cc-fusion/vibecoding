/** Block + item registry. Pure data so it can be unit tested outside the browser. */

export const B = {
  AIR: 0,
  BEDROCK: 1,
  STONE: 2,
  COBBLE: 3,
  MOSSY_COBBLE: 4,
  DIRT: 5,
  GRASS: 6,
  SAND: 7,
  SANDSTONE: 8,
  GRAVEL: 9,
  CLAY: 10,
  SNOW: 11,
  SNOW_GRASS: 12,
  ICE: 13,
  WATER: 14,
  OAK_LOG: 15,
  OAK_LEAVES: 16,
  BIRCH_LOG: 17,
  BIRCH_LEAVES: 18,
  PLANKS: 19,
  BIRCH_PLANKS: 20,
  CRAFTING_TABLE: 21,
  FURNACE: 22,
  GLASS: 23,
  COAL_ORE: 24,
  IRON_ORE: 25,
  GOLD_ORE: 26,
  DIAMOND_ORE: 27,
  TORCH: 28,
  GLOWSTONE: 29,
  BRICKS: 30,
  CACTUS: 31,
  TALL_GRASS: 32,
  POPPY: 33,
  DANDELION: 34,
  DEAD_BUSH: 35,
  SAPLING: 36,
  WOOL: 37,
  STONE_BRICKS: 38,
  OBSIDIAN: 39,
  LAVA: 40,
} as const;

export type ToolKind = 'pickaxe' | 'axe' | 'shovel' | 'sword' | 'none';
export type SoundKind = 'stone' | 'dirt' | 'grass' | 'wood' | 'sand' | 'glass' | 'cloth' | 'liquid';

export interface BlockDef {
  id: number;
  name: string;
  /** texture tile names, order: +X, -X, +Y, -Y, +Z, -Z */
  tiles: [string, string, string, string, string, string];
  opaque: boolean;
  solid: boolean;
  cross?: boolean;
  liquid?: boolean;
  cutout?: boolean;
  hardness: number;
  tool: ToolKind;
  tier: number; // required tool tier to drop anything (0 = hand)
  drop?: number | ((r: number) => number | null);
  dropCount?: number;
  light?: number;
  sound: SoundKind;
  stack?: number;
  tint?: number; // multiplied into the texture (grass / leaves)
  tintFaces?: number[]; // which face indices receive the tint
  flammable?: boolean;
}

const def = (
  id: number,
  name: string,
  tile: string | { top?: string; bottom?: string; side?: string; all?: string; front?: string },
  o: Partial<BlockDef> = {},
): BlockDef => {
  let tiles: [string, string, string, string, string, string];
  if (typeof tile === 'string') tiles = [tile, tile, tile, tile, tile, tile];
  else {
    const side = tile.side ?? tile.all ?? 'stone';
    const top = tile.top ?? tile.all ?? side;
    const bottom = tile.bottom ?? tile.all ?? side;
    const front = tile.front ?? side;
    tiles = [side, side, top, bottom, front, side];
  }
  return {
    id,
    name,
    tiles,
    opaque: true,
    solid: true,
    hardness: 1,
    tool: 'none',
    tier: 0,
    sound: 'stone',
    ...o,
  };
};

export const BLOCKS: BlockDef[] = [];
const reg = (b: BlockDef) => {
  BLOCKS[b.id] = b;
  return b;
};

reg(def(B.AIR, 'Air', 'stone', { opaque: false, solid: false, hardness: 0 }));
reg(def(B.BEDROCK, 'Bedrock', 'bedrock', { hardness: Infinity, tool: 'pickaxe', tier: 99 }));
reg(def(B.STONE, 'Stone', 'stone', { hardness: 1.5, tool: 'pickaxe', tier: 1, drop: B.COBBLE }));
reg(def(B.COBBLE, 'Cobblestone', 'cobble', { hardness: 2, tool: 'pickaxe', tier: 1 }));
reg(def(B.MOSSY_COBBLE, 'Mossy Cobblestone', 'mossy_cobble', { hardness: 2, tool: 'pickaxe', tier: 1 }));
reg(def(B.DIRT, 'Dirt', 'dirt', { hardness: 0.5, tool: 'shovel', sound: 'dirt' }));
reg(
  def(B.GRASS, 'Grass Block', { top: 'grass_top', side: 'grass_side', bottom: 'dirt' }, {
    hardness: 0.6, tool: 'shovel', sound: 'grass', drop: B.DIRT, tint: 0x8fd35a, tintFaces: [2],
  }),
);
reg(def(B.SAND, 'Sand', 'sand', { hardness: 0.5, tool: 'shovel', sound: 'sand' }));
reg(def(B.SANDSTONE, 'Sandstone', { top: 'sandstone_top', side: 'sandstone_side' }, { hardness: 0.8, tool: 'pickaxe', tier: 1 }));
reg(def(B.GRAVEL, 'Gravel', 'gravel', { hardness: 0.6, tool: 'shovel', sound: 'sand' }));
reg(def(B.CLAY, 'Clay', 'clay', { hardness: 0.6, tool: 'shovel', sound: 'dirt' }));
reg(def(B.SNOW, 'Snow Block', 'snow', { hardness: 0.4, tool: 'shovel', sound: 'cloth' }));
reg(
  def(B.SNOW_GRASS, 'Snowy Grass', { top: 'snow', side: 'grass_snow_side', bottom: 'dirt' }, {
    hardness: 0.6, tool: 'shovel', sound: 'grass', drop: B.DIRT,
  }),
);
reg(def(B.ICE, 'Ice', 'ice', { hardness: 0.5, tool: 'pickaxe', tier: 1, opaque: false, cutout: false, sound: 'glass' }));
reg(
  def(B.WATER, 'Water', 'water', {
    opaque: false, solid: false, liquid: true, hardness: Infinity, sound: 'liquid', tier: 99,
  }),
);
reg(def(B.OAK_LOG, 'Oak Log', { top: 'oak_log_top', side: 'oak_log_side' }, { hardness: 2, tool: 'axe', sound: 'wood', flammable: true }));
reg(
  def(B.OAK_LEAVES, 'Oak Leaves', 'oak_leaves', {
    hardness: 0.2, tool: 'none', opaque: false, cutout: true, sound: 'grass', tint: 0x74c04a, flammable: true,
    drop: (r) => (r < 0.06 ? 106 : r < 0.14 ? B.SAPLING : null),
  }),
);
reg(def(B.BIRCH_LOG, 'Birch Log', { top: 'birch_log_top', side: 'birch_log_side' }, { hardness: 2, tool: 'axe', sound: 'wood', flammable: true }));
reg(
  def(B.BIRCH_LEAVES, 'Birch Leaves', 'birch_leaves', {
    hardness: 0.2, tool: 'none', opaque: false, cutout: true, sound: 'grass', tint: 0x9fd45f, flammable: true,
    drop: (r) => (r < 0.05 ? 106 : r < 0.12 ? B.SAPLING : null),
  }),
);
reg(def(B.PLANKS, 'Oak Planks', 'planks', { hardness: 2, tool: 'axe', sound: 'wood', flammable: true }));
reg(def(B.BIRCH_PLANKS, 'Birch Planks', 'birch_planks', { hardness: 2, tool: 'axe', sound: 'wood', flammable: true }));
reg(
  def(B.CRAFTING_TABLE, 'Crafting Table', { top: 'crafting_top', side: 'crafting_side', bottom: 'planks' }, {
    hardness: 2.5, tool: 'axe', sound: 'wood', flammable: true,
  }),
);
reg(
  def(B.FURNACE, 'Furnace', { top: 'furnace_top', side: 'furnace_side', front: 'furnace_front', bottom: 'furnace_top' }, {
    hardness: 3.5, tool: 'pickaxe', tier: 1,
  }),
);
reg(def(B.GLASS, 'Glass', 'glass', { hardness: 0.3, opaque: false, cutout: true, sound: 'glass', drop: () => null }));
reg(def(B.COAL_ORE, 'Coal Ore', 'coal_ore', { hardness: 3, tool: 'pickaxe', tier: 1, drop: 101 }));
reg(def(B.IRON_ORE, 'Iron Ore', 'iron_ore', { hardness: 3, tool: 'pickaxe', tier: 2 }));
reg(def(B.GOLD_ORE, 'Gold Ore', 'gold_ore', { hardness: 3, tool: 'pickaxe', tier: 3 }));
reg(def(B.DIAMOND_ORE, 'Diamond Ore', 'diamond_ore', { hardness: 3, tool: 'pickaxe', tier: 3, drop: 105 }));
reg(
  def(B.TORCH, 'Torch', 'torch', {
    hardness: 0, opaque: false, solid: false, cross: true, cutout: true, light: 14, sound: 'wood',
  }),
);
reg(def(B.GLOWSTONE, 'Glowstone', 'glowstone', { hardness: 0.3, light: 15, sound: 'glass' }));
reg(def(B.BRICKS, 'Bricks', 'bricks', { hardness: 2, tool: 'pickaxe', tier: 1 }));
reg(
  def(B.CACTUS, 'Cactus', { top: 'cactus_top', side: 'cactus_side' }, {
    hardness: 0.4, sound: 'cloth', opaque: false, cutout: true,
  }),
);
reg(def(B.TALL_GRASS, 'Tall Grass', 'tall_grass', {
  hardness: 0, opaque: false, solid: false, cross: true, cutout: true, sound: 'grass', tint: 0x8fd35a,
  drop: (r) => (r < 0.12 ? 112 : null),
}));
reg(def(B.POPPY, 'Poppy', 'poppy', { hardness: 0, opaque: false, solid: false, cross: true, cutout: true, sound: 'grass' }));
reg(def(B.DANDELION, 'Dandelion', 'dandelion', { hardness: 0, opaque: false, solid: false, cross: true, cutout: true, sound: 'grass' }));
reg(def(B.DEAD_BUSH, 'Dead Bush', 'dead_bush', { hardness: 0, opaque: false, solid: false, cross: true, cutout: true, sound: 'grass', drop: 100 }));
reg(def(B.SAPLING, 'Sapling', 'sapling', { hardness: 0, opaque: false, solid: false, cross: true, cutout: true, sound: 'grass' }));
reg(def(B.WOOL, 'Wool', 'wool', { hardness: 0.8, sound: 'cloth', flammable: true }));
reg(def(B.STONE_BRICKS, 'Stone Bricks', 'stone_bricks', { hardness: 2, tool: 'pickaxe', tier: 1 }));
reg(def(B.OBSIDIAN, 'Obsidian', 'obsidian', { hardness: 12, tool: 'pickaxe', tier: 4 }));
reg(
  def(B.LAVA, 'Lava', 'lava', {
    opaque: false, solid: false, liquid: true, hardness: Infinity, light: 15, sound: 'liquid', tier: 99,
  }),
);

for (let i = 0; i < BLOCKS.length; i++) if (!BLOCKS[i]) BLOCKS[i] = BLOCKS[0];

export const isOpaque = (id: number) => BLOCKS[id].opaque;
export const isSolid = (id: number) => BLOCKS[id].solid;
export const isLiquid = (id: number) => BLOCKS[id].liquid === true;

/* ------------------------------------------------------------------ items */

export interface ItemDef {
  id: number;
  name: string;
  tile: string;
  stack: number;
  block?: number;
  tool?: { kind: ToolKind; tier: number; speed: number; damage: number };
  food?: number;
  fuel?: number; // seconds of burn time
  rarity?: 'common' | 'uncommon' | 'rare' | 'epic';
}

export const ITEMS: ItemDef[] = [];
for (const b of BLOCKS) {
  if (b.id === B.AIR || b.id === B.WATER || b.id === B.LAVA || b.id === B.BEDROCK) continue;
  ITEMS[b.id] = {
    id: b.id,
    name: b.name,
    tile: b.tiles[4],
    stack: 64,
    block: b.id,
    fuel: b.flammable ? (b.id === B.OAK_LOG || b.id === B.BIRCH_LOG ? 15 : 5) : undefined,
  };
}
ITEMS[B.COAL_ORE].fuel = undefined;

const item = (id: number, name: string, tile: string, o: Partial<ItemDef> = {}) => {
  ITEMS[id] = { id, name, tile, stack: 64, ...o };
};

item(100, 'Stick', 'stick', { fuel: 2.5 });
item(101, 'Coal', 'coal', { fuel: 80 });
item(102, 'Charcoal', 'coal', { fuel: 80 });
item(103, 'Iron Ingot', 'iron_ingot', { rarity: 'uncommon' });
item(104, 'Gold Ingot', 'gold_ingot', { rarity: 'rare' });
item(105, 'Diamond', 'diamond', { rarity: 'epic' });
item(106, 'Apple', 'apple', { food: 4 });
item(107, 'Raw Porkchop', 'pork_raw', { food: 3 });
item(108, 'Cooked Porkchop', 'pork_cooked', { food: 8 });
item(109, 'Raw Mutton', 'mutton_raw', { food: 2 });
item(110, 'Cooked Mutton', 'mutton_cooked', { food: 6 });
item(111, 'Brick', 'brick_item');
item(112, 'Seeds', 'seeds');
item(113, 'Bread', 'bread', { food: 5 });

const TOOL_NAMES = ['Wooden', 'Stone', 'Iron', 'Diamond'];
const TOOL_TILES = ['wood', 'stone', 'iron', 'diamond'];
const KINDS: ToolKind[] = ['pickaxe', 'axe', 'shovel', 'sword'];
const KIND_LABEL = ['Pickaxe', 'Axe', 'Shovel', 'Sword'];
const SPEEDS = [2, 4, 6, 8];
const DAMAGE = [[2, 3, 2, 4], [3, 4, 3, 5], [4, 5, 4, 6], [5, 6, 5, 7]];
for (let t = 0; t < 4; t++) {
  for (let k = 0; k < 4; k++) {
    const id = 120 + t * 4 + k;
    item(id, `${TOOL_NAMES[t]} ${KIND_LABEL[k]}`, `${TOOL_TILES[t]}_${KINDS[k]}`, {
      stack: 1,
      tool: { kind: KINDS[k], tier: t + 1, speed: SPEEDS[t], damage: DAMAGE[t][k] },
      rarity: t >= 3 ? 'epic' : t === 2 ? 'uncommon' : 'common',
      fuel: t === 0 ? 10 : undefined,
    });
  }
}

export const getItem = (id: number): ItemDef =>
  ITEMS[id] ?? { id, name: 'Unknown', tile: 'stone', stack: 64 };

export const itemName = (id: number) => getItem(id).name;

/** Seconds to break a block with the given held item. */
export function breakTime(blockId: number, heldId: number | undefined, creative: boolean): number {
  const b = BLOCKS[blockId];
  if (!b || b.hardness === Infinity) return Infinity;
  if (creative) return 0;
  const tool = heldId != null ? getItem(heldId).tool : undefined;
  const canHarvest = b.tier === 0 || (tool != null && tool.kind === b.tool && tool.tier >= b.tier);
  let speed = 1;
  if (tool && tool.kind === b.tool && b.tool !== 'none') speed = tool.speed;
  else if (tool && tool.kind === 'sword' && b.sound === 'cloth') speed = 1.5;
  let t = (b.hardness * 1.5) / speed;
  if (!canHarvest) t = b.hardness * 5;
  return Math.max(0.05, t);
}

export function canHarvest(blockId: number, heldId: number | undefined): boolean {
  const b = BLOCKS[blockId];
  if (b.tier === 0) return true;
  const tool = heldId != null ? getItem(heldId).tool : undefined;
  return !!tool && tool.kind === b.tool && tool.tier >= b.tier;
}

export function blockDrop(blockId: number, heldId: number | undefined, r: number): { id: number; count: number } | null {
  const b = BLOCKS[blockId];
  if (!canHarvest(blockId, heldId)) return null;
  let drop: number | null = b.id;
  if (typeof b.drop === 'function') drop = b.drop(r);
  else if (b.drop !== undefined) drop = b.drop;
  if (b.id === B.GRAVEL && r < 0.1) drop = 101;
  if (drop == null) return null;
  let count = 1;
  if (b.id === B.GLOWSTONE) count = 2 + ((r * 3) | 0);
  if (b.id === B.WOOL) count = 1;
  return { id: drop, count };
}

export const SMELTING: Record<number, number> = {
  [B.IRON_ORE]: 103,
  [B.GOLD_ORE]: 104,
  [B.SAND]: B.GLASS,
  [B.COBBLE]: B.STONE,
  [B.CLAY]: 111,
  [B.OAK_LOG]: 102,
  [B.BIRCH_LOG]: 102,
  107: 108,
  109: 110,
  [B.STONE]: B.STONE_BRICKS,
};
