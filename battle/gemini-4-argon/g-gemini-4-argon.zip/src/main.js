import * as THREE from 'three';
import { TextureManager } from './render/textures.js';
import { SkyAtmosphere } from './render/sky.js';
import { HeldHandRenderer } from './render/hand.js';
import { World } from './world/world.js';
import { Player } from './player/player.js';
import { ParticleSystem } from './entities/particles.js';
import { DropManager } from './entities/drops.js';
import { MobManager } from './entities/mobs.js';
import { SoundManager } from './audio/sound.js';
import { SaveManager } from './storage/save.js';
import { GameUI } from './ui/hud.js';

class TerraCraftApp {
  constructor() {
    this.canvas = document.getElementById('game-canvas');
    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvas,
      antialias: false,
      powerPreference: 'high-performance',
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.autoClear = false;

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 450);

    this.settings = SaveManager.getSettings();
    this.showDebug = Boolean(this.settings.showDebug);

    this.textures = new TextureManager();
    this.sound = new SoundManager();
    this.sound.setVolume(this.settings.volume ?? 0.65);

    this.sky = new SkyAtmosphere(this.scene);
    this.hand = new HeldHandRenderer(this.textures);

    this.world = null;
    this.player = null;
    this.particles = null;
    this.drops = null;
    this.mobs = null;
    this.activeWorldMeta = null; // { id, name, seed, mode }

    // 'title' | 'playing' | 'inventory' | 'pause'
    this.state = 'title';
    this._suppressLockPause = false;
    this._panoramaAngle = 0;
    this._panoramaCenter = { x: 0.5, y: 46, z: 0.5 };
    this._autosaveTimer = 0;
    this._elapsed = 0;
    this._fpsSmooth = 60;

    this.ui = new GameUI(this.textures, this.sound, {
      onStartWorld: (cfg) => this.startWorld(cfg),
      onResume: () => this.resumePlaying(),
      onSave: () => this.saveCurrentWorld(true),
      onQuitToTitle: () => this.quitToTitle(),
      onSettingsChange: (s) => this.applySettings(s),
    });
    this.ui.applySettingsToSliders(this.settings);

    this._initPanoramaWorld();
    this.ui.showScreen('title');

    this._bindEvents();
    this._lastTime = performance.now();
    requestAnimationFrame((t) => this._loop(t));
  }

  _initPanoramaWorld() {
    this._disposeActiveSession();
    this.world = new World(this.scene, this.textures, 'Emerald Valley');
    this.world.renderDistance = 3;
    const sp = this.world.generator.findSpawnPosition();
    this._panoramaCenter = { x: sp.x, y: sp.y + 12, z: sp.z };
    this.world.preloadAround(sp.x, sp.z, 3);
    this.sky.timeOfDay = 0.15;
    this.sky.weather = 'clear';
  }

  _disposeActiveSession() {
    if (this.player) {
      this.scene.remove(this.player.selectionWire);
      this.scene.remove(this.player.crackMesh);
      this.player = null;
    }
    if (this.mobs) { this.mobs.dispose(); this.mobs = null; }
    if (this.drops) { this.drops.dispose(); this.drops = null; }
    if (this.particles) { this.particles.dispose(); this.particles = null; }
    if (this.world) { this.world.dispose(); this.world = null; }
  }

  startWorld(cfg) {
    this._disposeActiveSession();

    const mode = cfg.mode || 'survival';
    const seed = cfg.seed || 'Emerald Valley';
    this.activeWorldMeta = {
      id: cfg.id,
      name: cfg.name || 'World',
      seed,
      mode,
    };

    this.world = new World(
      this.scene,
      this.textures,
      seed,
      cfg.edits || null,
      cfg.furnaces || null
    );
    this.world.renderDistance = this.settings.renderDistance || 5;

    this.particles = new ParticleSystem(this.scene);
    this.drops = new DropManager(this.scene, this.textures);
    this.mobs = new MobManager(this.scene);

    this.player = new Player(this.camera, this.scene, mode);
    this.player.baseFov = this.settings.fov || 75;
    this.player.mouseSensitivity = this.settings.sensitivity || 0.0022;
    this.camera.fov = this.player.baseFov;
    this.camera.updateProjectionMatrix();

    const spawnPos = this.world.generator.findSpawnPosition();

    if (!cfg.isNew && cfg.player) {
      this.world.preloadAround(cfg.player.x, cfg.player.z, 2);
      this.player.restore(cfg.player);
      this.sky.timeOfDay = typeof cfg.timeOfDay === 'number' ? cfg.timeOfDay : 0.16;
      this.sky.dayNumber = cfg.dayNumber || 1;
      this.sky.weather = cfg.weather || 'clear';
    } else {
      this.world.preloadAround(spawnPos.x, spawnPos.z, 2);
      const safeY = this.world.getSurfaceHeight(spawnPos.x, spawnPos.z) + 1.05;
      this.player.position.set(spawnPos.x, safeY, spawnPos.z);
      this.sky.timeOfDay = 0.14;
      this.sky.dayNumber = 1;
      this.sky.weather = 'clear';
    }

    this.mobs.populateInitialAround(this.world, this.player.position.x, this.player.position.z);

    this.player.onMilestone = (m) => {
      this.ui.showToast(`Goal Complete · ${m.title}`, m.desc);
      this.sound.playCraft();
    };

    this.player.onOpenStation = (stationType, hit) => {
      this.openInventory({
        craftingTable: stationType === 'crafting',
        furnacePos: stationType === 'furnace' ? { x: hit.x, y: hit.y, z: hit.z } : null,
      });
    };

    this.player.onInventoryChange = () => {
      this.ui.renderHotbar();
    };

    this.player.onRespawn = () => {
      const sp = this.world.generator.findSpawnPosition();
      const sy = this.world.getSurfaceHeight(sp.x, sp.z) + 1.05;
      this.player.respawn({ x: sp.x, y: sy, z: sp.z });
      this.ui.showToast('Respawned', 'Returned safely to spawn point');
    };

    this.ui.attachSession(this.player, this.world, this.sky);
    this.ui.elPauseTitle.textContent = this.activeWorldMeta.name;

    this.saveCurrentWorld(false);
    this.resumePlaying();
  }

  saveCurrentWorld(notify = false) {
    if (!this.world || !this.player || !this.activeWorldMeta) return false;
    const ok = SaveManager.saveWorld({
      id: this.activeWorldMeta.id,
      name: this.activeWorldMeta.name,
      seed: this.activeWorldMeta.seed,
      mode: this.player.mode,
      timeOfDay: this.sky.timeOfDay,
      dayNumber: this.sky.dayNumber,
      weather: this.sky.weather,
      player: this.player,
      world: this.world,
    });
    if (ok && notify) {
      this.ui.showToast('World Saved', `"${this.activeWorldMeta.name}" saved`);
    }
    return ok;
  }

  applySettings(next) {
    this.settings = { ...this.settings, ...next };
    SaveManager.saveSettings(this.settings);
    this.sound.setVolume(this.settings.volume);
    if (this.world) {
      this.world.renderDistance = this.settings.renderDistance;
      this.world._lastCenterCx = null; // Refresh radial queue
    }
    if (this.player) {
      this.player.baseFov = this.settings.fov;
      this.player.mouseSensitivity = this.settings.sensitivity;
      this.camera.fov = this.settings.fov;
      this.camera.updateProjectionMatrix();
    }
  }

  resumePlaying() {
    if (!this.player) return;
    this.state = 'playing';
    this.ui.showScreen('playing');
    this._requestLock();
  }

  openInventory(options = {}) {
    if (!this.player) return;
    this.state = 'inventory';
    this.player.keys.clear();
    this.player.leftMouseDown = false;
    this.player.rightMouseDown = false;
    this._releaseLock();
    this.ui.showScreen('inventory', options);
  }

  openPause() {
    if (!this.player) return;
    this.state = 'pause';
    this.player.keys.clear();
    this.player.leftMouseDown = false;
    this.player.rightMouseDown = false;
    this.saveCurrentWorld(false);
    this._releaseLock();
    this.ui.showScreen('pause');
  }

  quitToTitle() {
    this.saveCurrentWorld(false);
    this.activeWorldMeta = null;
    this.state = 'title';
    this._releaseLock();
    this._initPanoramaWorld();
    this.ui.showScreen('title');
  }

  _requestLock() {
    try {
      if (document.pointerLockElement !== this.canvas && this.canvas.requestPointerLock) {
        const p = this.canvas.requestPointerLock();
        if (p && typeof p.catch === 'function') p.catch(() => {});
      }
    } catch {
      // Ignore in environments without PointerLock support
    }
  }

  _releaseLock() {
    if (document.pointerLockElement) {
      this._suppressLockPause = true;
      document.exitPointerLock?.();
    }
  }

  _bindEvents() {
    window.addEventListener('resize', () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.hand.onResize(w / h);
      this.renderer.setSize(w, h);
    });

    document.addEventListener('pointerlockchange', () => {
      if (!document.pointerLockElement) {
        if (this._suppressLockPause) {
          this._suppressLockPause = false;
          return;
        }
        if (this.state === 'playing') {
          this.openPause();
        }
      }
    });

    this.canvas.addEventListener('mousedown', (e) => {
      if (this.state !== 'playing' || !this.player) return;
      if (document.pointerLockElement !== this.canvas) {
        this._requestLock();
      }
      if (e.button === 0) this.player.leftMouseDown = true;
      if (e.button === 1) {
        e.preventDefault();
        this.player.pickTargetBlock(this.sound);
      }
      if (e.button === 2) this.player.rightMouseDown = true;
    });

    window.addEventListener('mouseup', (e) => {
      if (!this.player) return;
      if (e.button === 0) this.player.leftMouseDown = false;
      if (e.button === 2) this.player.rightMouseDown = false;
    });

    this.canvas.addEventListener('contextmenu', (e) => e.preventDefault());

    document.addEventListener('mousemove', (e) => {
      if (this.state === 'playing' && this.player && document.pointerLockElement === this.canvas) {
        this.player.onMouseMove(e.movementX, e.movementY);
      }
    });

    window.addEventListener('wheel', (e) => {
      if (this.state !== 'playing' || !this.player) return;
      const dir = e.deltaY > 0 ? 1 : -1;
      this.player.selectedSlot = (this.player.selectedSlot + dir + 9) % 9;
      this.ui.renderHotbar();
    }, { passive: true });

    window.addEventListener('keydown', (e) => {
      if (this.state === 'title') return;

      if (e.code === 'F3') {
        e.preventDefault();
        this.showDebug = !this.showDebug;
        this.settings.showDebug = this.showDebug;
        SaveManager.saveSettings(this.settings);
        return;
      }

      if (e.code === 'KeyE') {
        if (this.state === 'playing') {
          e.preventDefault();
          this.openInventory();
        } else if (this.state === 'inventory') {
          e.preventDefault();
          this.resumePlaying();
        }
        return;
      }

      if (e.code === 'Escape') {
        if (this.state === 'inventory') {
          e.preventDefault();
          this.resumePlaying();
        } else if (this.state === 'pause') {
          e.preventDefault();
          this.resumePlaying();
        } else if (this.state === 'playing' && !document.pointerLockElement) {
          e.preventDefault();
          this.openPause();
        }
        return;
      }

      if (this.state !== 'playing' || !this.player) return;

      if (e.code.startsWith('Digit')) {
        const num = parseInt(e.code.slice(5), 10);
        if (num >= 1 && num <= 9) {
          this.player.selectedSlot = num - 1;
          this.ui.renderHotbar();
          return;
        }
      }

      if (e.code === 'KeyQ') {
        this.player.tossHeldItem(this.drops, this.sound);
        return;
      }

      this.player.onKeyDown(e.code);
    });

    window.addEventListener('keyup', (e) => {
      if (this.player) this.player.onKeyUp(e.code);
    });

    window.addEventListener('beforeunload', () => {
      if (this.state !== 'title') {
        this.saveCurrentWorld(false);
      }
    });
  }

  _loop(now) {
    requestAnimationFrame((t) => this._loop(t));

    const rawDt = (now - this._lastTime) / 1000;
    this._lastTime = now;
    const dt = Math.min(0.08, Math.max(0.0005, rawDt));
    this._elapsed += dt;

    const instFps = 1 / Math.max(0.001, rawDt);
    this._fpsSmooth += (instFps - this._fpsSmooth) * 0.08;

    if (this.state === 'title') {
      // Gentle scenic camera panorama over the live 3D voxel world
      this._panoramaAngle += dt * 0.08;
      const r = 18;
      const cx = this._panoramaCenter.x + Math.cos(this._panoramaAngle) * r;
      const cz = this._panoramaCenter.z + Math.sin(this._panoramaAngle) * r;
      this.camera.position.set(cx, this._panoramaCenter.y, cz);
      this.camera.lookAt(this._panoramaCenter.x, this._panoramaCenter.y - 5, this._panoramaCenter.z);

      const atmos = this.sky.update(dt * 0.4, this.camera.position, 4, false);
      this.textures.updateAtmosphere({ ...atmos, time: this._elapsed });

      this.renderer.clear();
      this.renderer.render(this.scene, this.camera);
      return;
    }

    if (!this.player || !this.world) return;

    const simActive = this.state === 'playing' || this.state === 'inventory';
    if (simActive) {
      if (this.state === 'playing') {
        this.player.update(dt, this.world, this.mobs, this.drops, this.particles, this.hand, this.sound);
      }

      this.world.update(dt, this.player.position.x, this.player.position.z, {
        sound: this.sound,
        spawnDrop: (x, y, z, id, cnt) => this.drops.spawn(x, y, z, id, cnt),
        onExplosion: (ex, ey, ez, radius) => {
          this.sound.playExplosion();
          this.particles.spawnExplosion(ex, ey, ez);
          // Blast damage & knockback to nearby mobs and player
          const pdx = this.player.position.x - ex;
          const pdy = (this.player.position.y + 0.9) - ey;
          const pdz = this.player.position.z - ez;
          const pDist = Math.hypot(pdx, pdy, pdz);
          if (pDist < radius * 1.8) {
            const dmg = Math.round((1 - pDist / (radius * 1.8)) * 14);
            this.player.takeDamage(dmg, pdx, pdz, this.sound);
          }
          for (const m of [...this.mobs.mobs]) {
            const mdx = m.x - ex;
            const mdz = m.z - ez;
            const mDist = Math.hypot(mdx, m.y - ey, mdz);
            if (mDist < radius * 1.9) {
              const mdmg = Math.round((1 - mDist / (radius * 1.9)) * 18);
              this.mobs.damageMob(m, mdmg, mdx, mdz, this.drops, this.particles, null);
            }
          }
        },
      });

      this.drops.update(dt, this.world, this.player, this.sound);
      this.mobs.update(dt, this.world, this.player, this.sky, this.drops, this.particles, this.sound);
      this.particles.update(dt, this.world, this.player.position);

      this._autosaveTimer += dt;
      if (this._autosaveTimer >= 30) {
        this._autosaveTimer = 0;
        this.saveCurrentWorld(false);
      }
    }

    const curBiome = this.world.getBiomeAt(this.player.position.x, this.player.position.z);
    const atmos = this.sky.update(
      simActive ? dt : 0,
      this.camera.position,
      this.world.renderDistance,
      this.player.headInWater,
      curBiome
    );
    this.textures.updateAtmosphere({ ...atmos, time: this._elapsed });

    this.ui.updateHUD(dt, this._fpsSmooth, this.showDebug);

    this.renderer.clear();
    this.renderer.render(this.scene, this.camera);
    this.hand.render(this.renderer);
  }
}

const app = new TerraCraftApp();
window.__TERRACRAFT__ = app;
