// Procedural Web Audio Synthesizer for Voxel Sandbox Feedback

export class SoundManager {
  constructor() {
    this.ctx = null;
    this.masterGain = null;
    this.volume = 0.65;
    this._noiseBuffer = null;
  }

  _ensureContext() {
    if (this.volume <= 0.001) return false;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return false;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = this.volume;
      this.masterGain.connect(this.ctx.destination);

      // Generate 1.5s white noise buffer once
      const rate = this.ctx.sampleRate;
      const buf = this.ctx.createBuffer(1, Math.floor(rate * 1.5), rate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < data.length; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      this._noiseBuffer = buf;
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return true;
  }

  setVolume(v) {
    this.volume = Math.max(0, Math.min(1, v));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(this.volume, this.ctx.currentTime, 0.02);
    }
  }

  _playNoiseBurst({ duration = 0.09, filterType = 'bandpass', freq = 900, q = 1.4, gain = 0.22, attack = 0.004 }) {
    if (!this._ensureContext()) return;
    const now = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this._noiseBuffer;
    src.playbackRate.value = 0.85 + Math.random() * 0.3;

    const filter = this.ctx.createBiquadFilter();
    filter.type = filterType;
    filter.frequency.setValueAtTime(freq * (0.9 + Math.random() * 0.2), now);
    filter.Q.value = q;

    const env = this.ctx.createGain();
    env.gain.setValueAtTime(0.0001, now);
    env.gain.linearRampToValueAtTime(gain, now + attack);
    env.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    src.connect(filter);
    filter.connect(env);
    env.connect(this.masterGain);

    src.start(now, Math.random() * 0.6, duration + 0.02);
  }

  _playTone({ type = 'triangle', startFreq = 220, endFreq = 110, duration = 0.1, gain = 0.18, delay = 0 }) {
    if (!this._ensureContext()) return;
    const now = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    osc.type = type;
    osc.frequency.setValueAtTime(startFreq, now);
    osc.frequency.exponentialRampToValueAtTime(Math.max(20, endFreq), now + duration);

    const env = this.ctx.createGain();
    env.gain.setValueAtTime(0.0001, now);
    env.gain.linearRampToValueAtTime(gain, now + 0.006);
    env.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    osc.connect(env);
    env.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + duration + 0.01);
  }

  playStep(material = 'grass') {
    const jitter = 0.9 + Math.random() * 0.22;
    switch (material) {
      case 'stone':
        this._playNoiseBurst({ duration: 0.06, freq: 1350 * jitter, q: 2.0, gain: 0.10 });
        this._playTone({ type: 'triangle', startFreq: 165 * jitter, endFreq: 95, duration: 0.05, gain: 0.07 });
        break;
      case 'wood':
        this._playTone({ type: 'triangle', startFreq: 210 * jitter, endFreq: 115, duration: 0.065, gain: 0.12 });
        this._playNoiseBurst({ duration: 0.05, freq: 750 * jitter, q: 2.2, gain: 0.07 });
        break;
      case 'sand':
      case 'snow':
        this._playNoiseBurst({ duration: 0.085, freq: 2400 * jitter, q: 0.9, gain: 0.09 });
        break;
      case 'water':
        this._playNoiseBurst({ duration: 0.14, freq: 650 * jitter, q: 1.8, gain: 0.13 });
        break;
      default: // grass / gravel
        this._playNoiseBurst({ duration: 0.075, freq: 1600 * jitter, q: 1.2, gain: 0.10 });
        this._playTone({ type: 'sine', startFreq: 120 * jitter, endFreq: 70, duration: 0.05, gain: 0.05 });
        break;
    }
  }

  playMineHit(material = 'stone') {
    const j = 0.92 + Math.random() * 0.18;
    if (material === 'stone' || material === 'glass') {
      this._playTone({ type: 'triangle', startFreq: 520 * j, endFreq: 260 * j, duration: 0.055, gain: 0.12 });
      this._playNoiseBurst({ duration: 0.05, freq: 1900 * j, q: 2.2, gain: 0.09 });
    } else if (material === 'wood') {
      this._playTone({ type: 'square', startFreq: 250 * j, endFreq: 130 * j, duration: 0.06, gain: 0.08 });
      this._playNoiseBurst({ duration: 0.05, freq: 850 * j, q: 1.8, gain: 0.09 });
    } else {
      this._playNoiseBurst({ duration: 0.065, freq: 1450 * j, q: 1.1, gain: 0.11 });
    }
  }

  playBlockBreak(material = 'stone') {
    const j = 0.9 + Math.random() * 0.2;
    if (material === 'glass') {
      this._playTone({ type: 'sine', startFreq: 1450 * j, endFreq: 780, duration: 0.09, gain: 0.16 });
      this._playTone({ type: 'sine', startFreq: 1950 * j, endFreq: 1100, duration: 0.11, gain: 0.13, delay: 0.03 });
      this._playNoiseBurst({ duration: 0.12, freq: 3400, q: 1.5, gain: 0.18 });
      return;
    }
    if (material === 'wood') {
      this._playTone({ type: 'triangle', startFreq: 230 * j, endFreq: 85, duration: 0.13, gain: 0.22 });
      this._playNoiseBurst({ duration: 0.13, freq: 900 * j, q: 1.4, gain: 0.20 });
      return;
    }
    if (material === 'stone') {
      this._playTone({ type: 'triangle', startFreq: 310 * j, endFreq: 95, duration: 0.13, gain: 0.20 });
      this._playNoiseBurst({ duration: 0.15, freq: 1400 * j, q: 1.1, gain: 0.24 });
      return;
    }
    this._playNoiseBurst({ duration: 0.15, freq: 1550 * j, q: 0.9, gain: 0.22 });
    this._playTone({ type: 'sine', startFreq: 165 * j, endFreq: 68, duration: 0.11, gain: 0.14 });
  }

  playBlockPlace(material = 'stone') {
    const j = 0.94 + Math.random() * 0.14;
    const base = material === 'wood' ? 240 : material === 'stone' ? 290 : 195;
    this._playTone({ type: 'triangle', startFreq: base * j, endFreq: base * 0.58, duration: 0.08, gain: 0.18 });
    this._playNoiseBurst({ duration: 0.06, freq: 1100 * j, q: 1.5, gain: 0.12 });
  }

  playPickup() {
    const j = 0.92 + Math.random() * 0.25;
    this._playTone({ type: 'sine', startFreq: 520 * j, endFreq: 980 * j, duration: 0.085, gain: 0.15 });
  }

  playCraft() {
    this._playTone({ type: 'triangle', startFreq: 440, endFreq: 660, duration: 0.09, gain: 0.16 });
    this._playTone({ type: 'triangle', startFreq: 660, endFreq: 880, duration: 0.12, gain: 0.16, delay: 0.06 });
  }

  playEat() {
    this._playNoiseBurst({ duration: 0.08, freq: 1100, q: 1.2, gain: 0.18 });
    this._playNoiseBurst({ duration: 0.08, freq: 1300, q: 1.2, gain: 0.16 });
    this._playTone({ type: 'sine', startFreq: 280, endFreq: 420, duration: 0.11, gain: 0.14, delay: 0.08 });
  }

  playSwing() {
    this._playNoiseBurst({ duration: 0.08, filterType: 'bandpass', freq: 650, q: 1.6, gain: 0.10 });
  }

  playHitMob() {
    this._playTone({ type: 'sawtooth', startFreq: 210, endFreq: 85, duration: 0.11, gain: 0.18 });
    this._playNoiseBurst({ duration: 0.08, freq: 950, q: 1.3, gain: 0.18 });
  }

  playHurt() {
    this._playTone({ type: 'sawtooth', startFreq: 185, endFreq: 65, duration: 0.16, gain: 0.25 });
    this._playNoiseBurst({ duration: 0.12, freq: 720, q: 1.2, gain: 0.22 });
  }

  playSplash() {
    this._playNoiseBurst({ duration: 0.26, filterType: 'bandpass', freq: 780, q: 1.1, gain: 0.24 });
    this._playTone({ type: 'sine', startFreq: 240, endFreq: 110, duration: 0.18, gain: 0.12 });
  }

  playFuse() {
    this._playNoiseBurst({ duration: 1.1, filterType: 'highpass', freq: 2600, q: 0.8, gain: 0.15 });
  }

  playExplosion() {
    this._playTone({ type: 'sine', startFreq: 115, endFreq: 28, duration: 0.55, gain: 0.42 });
    this._playNoiseBurst({ duration: 0.65, filterType: 'lowpass', freq: 520, q: 0.8, gain: 0.38 });
  }
}
