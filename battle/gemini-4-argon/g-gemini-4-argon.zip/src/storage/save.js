const INDEX_KEY = 'terracraft_worlds_index_v1';
const WORLD_PREFIX = 'terracraft_world_v1_';
const SETTINGS_KEY = 'terracraft_settings_v1';

export class SaveManager {
  static getSettings() {
    try {
      const raw = localStorage.getItem(SETTINGS_KEY);
      if (raw) return JSON.parse(raw);
    } catch {
      // Ignore storage errors
    }
    return {
      renderDistance: 5,
      fov: 75,
      volume: 0.65,
      sensitivity: 0.0022,
      showDebug: false,
    };
  }

  static saveSettings(settings) {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch {
      // Ignore storage errors
    }
  }

  static listWorlds() {
    try {
      const raw = localStorage.getItem(INDEX_KEY);
      if (!raw) return [];
      const arr = JSON.parse(raw);
      return Array.isArray(arr) ? arr.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0)) : [];
    } catch {
      return [];
    }
  }

  static saveWorld({ id, name, seed, mode, timeOfDay, dayNumber, weather, player, world }) {
    const updatedAt = Date.now();
    const payload = {
      version: 1,
      id,
      name,
      seed,
      mode,
      updatedAt,
      timeOfDay,
      dayNumber,
      weather,
      player: player.serialize(),
      edits: world.serializeEdits(),
      furnaces: world.serializeFurnaces(),
    };

    try {
      localStorage.setItem(WORLD_PREFIX + id, JSON.stringify(payload));
      const index = SaveManager.listWorlds().filter((w) => w.id !== id);
      index.unshift({
        id,
        name,
        seed,
        mode,
        dayNumber,
        updatedAt,
      });
      localStorage.setItem(INDEX_KEY, JSON.stringify(index));
      return true;
    } catch (err) {
      console.warn('World save warning:', err);
      return false;
    }
  }

  static loadWorld(id) {
    try {
      const raw = localStorage.getItem(WORLD_PREFIX + id);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  }

  static deleteWorld(id) {
    try {
      localStorage.removeItem(WORLD_PREFIX + id);
      const next = SaveManager.listWorlds().filter((w) => w.id !== id);
      localStorage.setItem(INDEX_KEY, JSON.stringify(next));
    } catch {
      // Ignore storage errors
    }
  }

  static exportWorldJSON(id) {
    const data = SaveManager.loadWorld(id);
    if (!data) return;
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const safeName = (data.name || 'terracraft-world').toLowerCase().replace(/[^a-z0-9-_]+/g, '-');
    a.href = url;
    a.download = `${safeName}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  static importWorldJSON(jsonString) {
    const parsed = JSON.parse(jsonString);
    if (!parsed || typeof parsed !== 'object' || !parsed.seed) {
      throw new Error('Invalid world file');
    }
    const id = 'w_' + Date.now() + '_' + Math.floor(Math.random() * 1000);
    parsed.id = id;
    parsed.updatedAt = Date.now();
    localStorage.setItem(WORLD_PREFIX + id, JSON.stringify(parsed));

    const index = SaveManager.listWorlds().filter((w) => w.id !== id);
    index.unshift({
      id,
      name: parsed.name || 'Imported World',
      seed: parsed.seed,
      mode: parsed.mode || 'survival',
      dayNumber: parsed.dayNumber || 1,
      updatedAt: parsed.updatedAt,
    });
    localStorage.setItem(INDEX_KEY, JSON.stringify(index));
    return parsed;
  }
}
