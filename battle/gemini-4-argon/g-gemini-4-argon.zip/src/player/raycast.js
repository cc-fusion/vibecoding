import { BLOCK, BLOCK_DEFS } from '../world/blocks.js';

export function raycastVoxel(world, origin, direction, maxDistance = 5.5) {
  let dx = direction.x;
  let dy = direction.y;
  let dz = direction.z;
  const len = Math.hypot(dx, dy, dz);
  if (len < 1e-8) return null;
  dx /= len;
  dy /= len;
  dz /= len;

  let x = Math.floor(origin.x);
  let y = Math.floor(origin.y);
  let z = Math.floor(origin.z);

  const stepX = dx > 0 ? 1 : dx < 0 ? -1 : 0;
  const stepY = dy > 0 ? 1 : dy < 0 ? -1 : 0;
  const stepZ = dz > 0 ? 1 : dz < 0 ? -1 : 0;

  const tDeltaX = stepX !== 0 ? Math.abs(1 / dx) : Infinity;
  const tDeltaY = stepY !== 0 ? Math.abs(1 / dy) : Infinity;
  const tDeltaZ = stepZ !== 0 ? Math.abs(1 / dz) : Infinity;

  let tMaxX = stepX > 0
    ? (x + 1 - origin.x) * tDeltaX
    : stepX < 0
      ? (origin.x - x) * tDeltaX
      : Infinity;
  let tMaxY = stepY > 0
    ? (y + 1 - origin.y) * tDeltaY
    : stepY < 0
      ? (origin.y - y) * tDeltaY
      : Infinity;
  let tMaxZ = stepZ > 0
    ? (z + 1 - origin.z) * tDeltaZ
    : stepZ < 0
      ? (origin.z - z) * tDeltaZ
      : Infinity;

  let t = 0;
  let nx = 0, ny = 0, nz = 0;

  while (t <= maxDistance) {
    const id = world.getBlock(x, y, z);
    if (id !== BLOCK.AIR && id !== BLOCK.WATER && id !== BLOCK.LAVA) {
      const def = BLOCK_DEFS[id];
      if (def) {
        return {
          blockId: id,
          x,
          y,
          z,
          normal: [nx, ny, nz],
          placePos: [x + nx, y + ny, z + nz],
          distance: t,
        };
      }
    }

    if (tMaxX < tMaxY) {
      if (tMaxX < tMaxZ) {
        x += stepX;
        t = tMaxX;
        tMaxX += tDeltaX;
        nx = -stepX; ny = 0; nz = 0;
      } else {
        z += stepZ;
        t = tMaxZ;
        tMaxZ += tDeltaZ;
        nx = 0; ny = 0; nz = -stepZ;
      }
    } else {
      if (tMaxY < tMaxZ) {
        y += stepY;
        t = tMaxY;
        tMaxY += tDeltaY;
        nx = 0; ny = -stepY; nz = 0;
      } else {
        z += stepZ;
        t = tMaxZ;
        tMaxZ += tDeltaZ;
        nx = 0; ny = 0; nz = -stepZ;
      }
    }
  }

  return null;
}
