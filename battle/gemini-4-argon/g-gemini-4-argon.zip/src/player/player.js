import * as THREE from 'three';
import {
  BLOCK,
  BLOCK_DEFS,
  CRAFTING_RECIPES,
  ITEM,
  ITEM_DEFS,
  getDef,
  getMaxStack,
  isAnyLog,
  isAnyPlanks,
  isBlockId,
} from '../world/blocks.js';
import { raycastVoxel } from './raycast.js';

export const MILESTONES = [
  { id: 'gather_wood', title: 'Timber!', desc: 'Harvest your first tree log' },
  { id: 'craft_table', title: 'Workbench Ready', desc: 'Craft a Crafting Table from planks' },
  { id: 'wood_pickaxe', title: 'Time to Mine', desc: 'Craft a Wooden Pickaxe at a Crafting Table' },
  { id: 'mine_stone', title: 'Stone Age', desc: 'Mine Cobblestone with a pickaxe' },
  { id: 'place_torch', title: 'Let There Be Light', desc: 'Light up the dark with a Torch' },
  { id: 'craft_furnace', title: 'Hot Topic', desc: 'Build a Stone Furnace' },
  { id: 'smelt_iron', title: 'Acquire Hardware', desc: 'Smelt Raw Iron into an Iron Ingot' },
  { id: 'find_diamond', title: 'Diamonds!', desc: 'Unearth rare Diamonds deep underground' },
];

export class Player {
  constructor(camera, scene, mode = 'survival') {
    this.camera = camera;
    this.scene = scene;
    this.mode = mode; // 'survival' | 'creative'

    this.position = new THREE.Vector3(0.5, 45, 0.5);
    this.velocity = new THREE.Vector3(0, 0, 0);
    this.yaw = 0;
    this.pitch = -0.12;
    this.mouseSensitivity = 0.0022;
    this.baseFov = 75;

    this.halfWidth = 0.30;
    this.height = 1.75;
    this.eyeHeight = 1.60;

    this.onGround = false;
    this.inWater = false;
    this.headInWater = false;
    this.inLava = false;
    this.flying = false;
    this.sprinting = false;
    this.sneaking = false;

    // Survival attributes
    this.maxHealth = 20;
    this.health = 20;
    this.maxHunger = 20;
    this.hunger = 20;
    this.maxOxygen = 15;
    this.oxygen = 15;
    this.hurtCooldown = 0;
    this.damageFlash = 0;
    this._fallPeakY = null;
    this._hungerTimer = 0;
    this._regenTimer = 0;
    this._lavaTimer = 0;

    // 36 inventory slots: 0..8 = Hotbar, 9..35 = Backpack
    this.inventory = Array.from({ length: 36 }, () => null);
    this.selectedSlot = 0;

    // Input state
    this.keys = new Set();
    this.leftMouseDown = false;
    this.rightMouseDown = false;
    this._lastSpaceTap = 0;
    this._placeCooldown = 0;
    this._attackCooldown = 0;
    this._stepDist = 0;

    // Mining state
    this.targetHit = null;
    this.miningBlockKey = null;
    this.miningProgress = 0; // 0..1
    this._mineSoundTimer = 0;

    // Progression milestones
    this.milestones = new Set();
    this.onMilestone = null; // callback(milestoneObj)
    this.onOpenStation = null; // callback('crafting' | 'furnace', pos)
    this.onInventoryChange = null;
    this.onRespawn = null;

    this._initHighlightMeshes();
    this._setupStarterKit();
  }

  _initHighlightMeshes() {
    const boxGeo = new THREE.BoxGeometry(1.006, 1.006, 1.006);
    const edges = new THREE.EdgesGeometry(boxGeo);
    const lineMat = new THREE.LineBasicMaterial({
      color: 0x11151c,
      transparent: true,
      opacity: 0.75,
    });
    this.selectionWire = new THREE.LineSegments(edges, lineMat);
    this.selectionWire.visible = false;
    this.scene.add(this.selectionWire);

    // Mining crack / damage overlay box
    const crackGeo = new THREE.BoxGeometry(1.01, 1.01, 1.01);
    this.crackMat = new THREE.MeshBasicMaterial({
      color: 0x141414,
      transparent: true,
      opacity: 0.0,
      depthWrite: false,
      wireframe: false,
    });
    this.crackMesh = new THREE.Mesh(crackGeo, this.crackMat);
    this.crackMesh.visible = false;
    this.scene.add(this.crackMesh);
    boxGeo.dispose();
  }

  _setupStarterKit() {
    this.inventory.fill(null);
    if (this.mode === 'creative') {
      const starter = [
        { id: BLOCK.GRASS, count: 64 },
        { id: BLOCK.OAK_PLANKS, count: 64 },
        { id: BLOCK.STONE_BRICKS, count: 64 },
        { id: BLOCK.GLASS, count: 64 },
        { id: BLOCK.OAK_LOG, count: 64 },
        { id: BLOCK.TORCH, count: 64 },
        { id: BLOCK.GLOWSTONE, count: 64 },
        { id: BLOCK.BRICKS, count: 64 },
        { id: BLOCK.TNT, count: 64 },
      ];
      starter.forEach((it, idx) => { this.inventory[idx] = { ...it }; });
    } else {
      // Friendly survival start: 3 crisp Red Apples for early journeying
      this.inventory[8] = { id: ITEM.APPLE, count: 3 };
    }
  }

  setMode(newMode) {
    this.mode = newMode;
    if (newMode === 'survival') {
      this.flying = false;
    } else {
      this.health = this.maxHealth;
      this.hunger = this.maxHunger;
      this.oxygen = this.maxOxygen;
    }
  }

  unlockMilestone(id) {
    if (this.milestones.has(id)) return;
    const m = MILESTONES.find((x) => x.id === id);
    if (!m) return;
    this.milestones.add(id);
    this.onMilestone?.(m);
  }

  getHeldSlot() {
    return this.inventory[this.selectedSlot];
  }

  getHeldId() {
    return this.inventory[this.selectedSlot]?.id || 0;
  }

  countItem(id) {
    let total = 0;
    for (const s of this.inventory) {
      if (s && s.id === id) total += s.count;
    }
    return total;
  }

  countTag(tag) {
    let total = 0;
    for (const s of this.inventory) {
      if (!s) continue;
      if (tag === 'ANY_PLANKS' && isAnyPlanks(s.id)) total += s.count;
    }
    return total;
  }

  addItem(id, count = 1, durability = null) {
    if (!id || count <= 0) return 0;
    const maxStack = getMaxStack(id);
    const def = getDef(id);
    let remaining = count;

    // Milestone checks on item acquisition
    if (isAnyLog(id)) this.unlockMilestone('gather_wood');
    if (id === BLOCK.COBBLESTONE) this.unlockMilestone('mine_stone');
    if (id === ITEM.IRON_INGOT) this.unlockMilestone('smelt_iron');
    if (id === ITEM.DIAMOND) this.unlockMilestone('find_diamond');
    if (id === BLOCK.CRAFTING_TABLE) this.unlockMilestone('craft_table');
    if (id === ITEM.WOOD_PICKAXE) this.unlockMilestone('wood_pickaxe');
    if (id === BLOCK.FURNACE) this.unlockMilestone('craft_furnace');

    // 1. Merge into existing non-full stacks first
    if (maxStack > 1) {
      for (let i = 0; i < this.inventory.length && remaining > 0; i++) {
        const slot = this.inventory[i];
        if (slot && slot.id === id && slot.count < maxStack) {
          const space = maxStack - slot.count;
          const add = Math.min(space, remaining);
          slot.count += add;
          remaining -= add;
        }
      }
    }

    // 2. Place into empty slots (prefer hotbar first!)
    for (let i = 0; i < this.inventory.length && remaining > 0; i++) {
      if (!this.inventory[i]) {
        const add = Math.min(maxStack, remaining);
        this.inventory[i] = {
          id,
          count: add,
          durability: durability ?? (def?.durability || null),
        };
        remaining -= add;
      }
    }

    this.onInventoryChange?.();
    return remaining;
  }

  consumeFromSlot(slotIndex, amount = 1) {
    const slot = this.inventory[slotIndex];
    if (!slot) return false;
    slot.count -= amount;
    if (slot.count <= 0) {
      this.inventory[slotIndex] = null;
    }
    this.onInventoryChange?.();
    return true;
  }

  consumeIngredient(req) {
    let needed = req.count;
    for (let i = 0; i < this.inventory.length && needed > 0; i++) {
      const s = this.inventory[i];
      if (!s) continue;
      const match = req.tag === 'ANY_PLANKS' ? isAnyPlanks(s.id) : s.id === req.id;
      if (match) {
        const take = Math.min(s.count, needed);
        s.count -= take;
        needed -= take;
        if (s.count <= 0) this.inventory[i] = null;
      }
    }
    this.onInventoryChange?.();
  }

  canCraft(recipe, hasTableNearby) {
    if (recipe.requiresTable && !hasTableNearby && this.mode !== 'creative') return false;
    for (const req of recipe.inputs) {
      const have = req.tag ? this.countTag(req.tag) : this.countItem(req.id);
      if (have < req.count) return false;
    }
    // Check output space
    const outId = recipe.output.id;
    const outCount = recipe.output.count;
    const maxS = getMaxStack(outId);
    let freeCap = 0;
    for (const s of this.inventory) {
      if (!s) freeCap += maxS;
      else if (s.id === outId && maxS > 1) freeCap += (maxS - s.count);
    }
    return freeCap >= outCount;
  }

  craftRecipe(recipe, hasTableNearby, sound) {
    if (!this.canCraft(recipe, hasTableNearby)) return false;
    for (const req of recipe.inputs) {
      this.consumeIngredient(req);
    }
    this.addItem(recipe.output.id, recipe.output.count);
    sound?.playCraft();
    return true;
  }

  damageHeldTool(sound) {
    if (this.mode === 'creative') return;
    const slot = this.inventory[this.selectedSlot];
    if (!slot) return;
    const def = ITEM_DEFS[slot.id];
    if (!def || !def.durability) return;
    if (slot.durability == null) slot.durability = def.durability;
    slot.durability -= 1;
    if (slot.durability <= 0) {
      this.inventory[this.selectedSlot] = null;
      sound?.playBlockBreak('wood');
    }
    this.onInventoryChange?.();
  }

  pickTargetBlock(sound) {
    if (!this.targetHit) return;
    let id = this.targetHit.blockId;
    if (id === BLOCK.FURNACE_LIT) id = BLOCK.FURNACE;

    // 1. If already in hotbar, select that slot
    for (let i = 0; i < 9; i++) {
      if (this.inventory[i]?.id === id) {
        this.selectedSlot = i;
        this.onInventoryChange?.();
        return;
      }
    }
    // 2. If in backpack, swap into current hotbar slot
    for (let i = 9; i < 36; i++) {
      if (this.inventory[i]?.id === id) {
        const tmp = this.inventory[this.selectedSlot];
        this.inventory[this.selectedSlot] = this.inventory[i];
        this.inventory[i] = tmp;
        this.onInventoryChange?.();
        sound?.playPickup();
        return;
      }
    }
    // 3. In Creative mode, place infinite stack directly into current hotbar slot
    if (this.mode === 'creative') {
      this.inventory[this.selectedSlot] = { id, count: 64, durability: null };
      this.onInventoryChange?.();
      sound?.playPickup();
    }
  }

  tossHeldItem(drops, sound) {
    const slot = this.inventory[this.selectedSlot];
    if (!slot || !drops) return;
    const dir = this.getLookDirection();
    const ox = this.camera.position.x + dir.x * 0.65;
    const oy = this.camera.position.y - 0.15 + dir.y * 0.65;
    const oz = this.camera.position.z + dir.z * 0.65;

    drops.spawn(ox, oy, oz, slot.id, 1, 1.35);
    const newest = drops.drops[drops.drops.length - 1];
    if (newest) {
      newest.vx = dir.x * 5.2;
      newest.vy = dir.y * 4.5 + 2.2;
      newest.vz = dir.z * 5.2;
    }
    this.consumeFromSlot(this.selectedSlot, 1);
    sound?.playSwing();
  }

  onMouseMove(movementX, movementY) {
    this.yaw -= movementX * this.mouseSensitivity;
    this.pitch -= movementY * this.mouseSensitivity;
    const limit = Math.PI / 2 - 0.015;
    this.pitch = Math.max(-limit, Math.min(limit, this.pitch));
  }

  onKeyDown(code) {
    this.keys.add(code);
    if (code === 'Space' && this.mode === 'creative') {
      const now = performance.now();
      if (now - this._lastSpaceTap < 300) {
        this.flying = !this.flying;
        this.velocity.y = 0;
        this._lastSpaceTap = 0;
      } else {
        this._lastSpaceTap = now;
      }
    }
    if (code === 'KeyF' && this.mode === 'creative') {
      this.flying = !this.flying;
      this.velocity.y = 0;
    }
  }

  onKeyUp(code) {
    this.keys.delete(code);
  }

  takeDamage(amount, fromDx = 0, fromDz = 0, sound = null) {
    if (this.mode === 'creative' || this.hurtCooldown > 0 || amount <= 0) return;
    this.health = Math.max(0, this.health - amount);
    this.hurtCooldown = 0.55;
    this.damageFlash = 0.35;
    sound?.playHurt();

    if (fromDx !== 0 || fromDz !== 0) {
      const len = Math.hypot(fromDx, fromDz) || 1;
      this.velocity.x += (fromDx / len) * 5.2;
      this.velocity.z += (fromDz / len) * 5.2;
      this.velocity.y = Math.max(this.velocity.y, 4.0);
    }

    if (this.health <= 0) {
      this.onRespawn?.();
    }
  }

  respawn(spawnPos) {
    this.health = this.maxHealth;
    this.hunger = this.maxHunger;
    this.oxygen = this.maxOxygen;
    this.velocity.set(0, 0, 0);
    this._fallPeakY = null;
    this.position.set(spawnPos.x, spawnPos.y, spawnPos.z);
  }

  getLookDirection() {
    const dir = new THREE.Vector3(0, 0, -1);
    const euler = new THREE.Euler(this.pitch, this.yaw, 0, 'YXZ');
    dir.applyEuler(euler);
    return dir;
  }

  update(dt, world, mobs, drops, particles, hand, sound) {
    if (this.hurtCooldown > 0) this.hurtCooldown = Math.max(0, this.hurtCooldown - dt);
    if (this.damageFlash > 0) this.damageFlash = Math.max(0, this.damageFlash - dt);
    if (this._placeCooldown > 0) this._placeCooldown = Math.max(0, this._placeCooldown - dt);
    if (this._attackCooldown > 0) this._attackCooldown = Math.max(0, this._attackCooldown - dt);

    // 1. Movement & Physics
    this._updateMovementAndPhysics(dt, world, particles, sound);

    // 2. Survival Vitals (Hunger, Regen, Oxygen, Lava, Cactus)
    if (this.mode === 'survival') {
      this._updateSurvivalVitals(dt, world, sound);
    }

    // 3. Camera sync & FOV sprint kick
    const curEye = this.sneaking && !this.flying ? 1.42 : this.eyeHeight;
    this.camera.position.set(this.position.x, this.position.y + curEye, this.position.z);
    this.camera.rotation.order = 'YXZ';
    this.camera.rotation.y = this.yaw;
    this.camera.rotation.x = this.pitch;

    const targetFov = this.baseFov + (this.sprinting ? 7 : 0) - (this.headInWater ? 4 : 0);
    if (Math.abs(this.camera.fov - targetFov) > 0.05) {
      this.camera.fov += (targetFov - this.camera.fov) * Math.min(1, dt * 10);
      this.camera.updateProjectionMatrix();
    }

    // 4. Raycast targeted block
    const lookDir = this.getLookDirection();
    this.targetHit = raycastVoxel(world, this.camera.position, lookDir, 5.5);

    if (this.targetHit) {
      this.selectionWire.visible = true;
      this.selectionWire.position.set(
        this.targetHit.x + 0.5,
        this.targetHit.y + 0.5,
        this.targetHit.z + 0.5
      );
    } else {
      this.selectionWire.visible = false;
    }

    // 5. Handle Left-Click (Combat vs Mob OR Progressive Block Mining)
    this._updateMiningAndCombat(dt, lookDir, world, mobs, drops, particles, hand, sound);

    // 6. Handle Right-Click (Station interact, Eat food, TNT ignite, or Block placement)
    if (this.rightMouseDown && this._placeCooldown <= 0) {
      this._handleRightAction(world, mobs, hand, sound);
    }

    // 7. Update 3D Held Hand
    hand.setItem(this.getHeldId());
    const horizSpeed = Math.hypot(this.velocity.x, this.velocity.z);
    const ex = Math.floor(this.camera.position.x);
    const ey = Math.floor(this.camera.position.y);
    const ez = Math.floor(this.camera.position.z);
    const lightAtPlayer = Math.max(
      world.getSkyLight(ex, ey, ez) / 15,
      world.getBlockLight(ex, ey, ez) / 15
    );
    hand.update(dt, horizSpeed, this.onGround, lightAtPlayer);
  }

  _updateMovementAndPhysics(dt, world, particles, sound) {
    // Check if stuck inside solid block (e.g. chunk loaded late) -> nudge safely up
    if (this._collidesAt(world, this.position.x, this.position.y, this.position.z)) {
      for (let up = 1; up <= 8; up++) {
        if (!this._collidesAt(world, this.position.x, this.position.y + up, this.position.z)) {
          this.position.y += up;
          break;
        }
      }
    }

    const forwardInput = (this.keys.has('KeyW') || this.keys.has('ArrowUp') ? 1 : 0) -
                         (this.keys.has('KeyS') || this.keys.has('ArrowDown') ? 1 : 0);
    const strafeInput = (this.keys.has('KeyD') || this.keys.has('ArrowRight') ? 1 : 0) -
                        (this.keys.has('KeyA') || this.keys.has('ArrowLeft') ? 1 : 0);

    this.sneaking = this.keys.has('KeyC') || this.keys.has('ControlLeft');
    const wantSprint = (this.keys.has('ShiftLeft') || this.keys.has('ShiftRight')) &&
                       forwardInput > 0 && !this.sneaking && (this.hunger > 4 || this.mode === 'creative');
    this.sprinting = wantSprint;

    const footBlock = world.getBlock(
      Math.floor(this.position.x),
      Math.floor(this.position.y + 0.15),
      Math.floor(this.position.z)
    );
    const waistBlock = world.getBlock(
      Math.floor(this.position.x),
      Math.floor(this.position.y + 0.9),
      Math.floor(this.position.z)
    );
    const headBlock = world.getBlock(
      Math.floor(this.position.x),
      Math.floor(this.position.y + 1.58),
      Math.floor(this.position.z)
    );

    const wasInWater = this.inWater;
    this.inWater = footBlock === BLOCK.WATER || waistBlock === BLOCK.WATER;
    this.headInWater = headBlock === BLOCK.WATER;
    this.inLava = footBlock === BLOCK.LAVA || waistBlock === BLOCK.LAVA;

    if (this.inWater && !wasInWater && this.velocity.y < -4) {
      sound?.playSplash();
      particles?.spawnSplash(this.position.x, this.position.y + 0.4, this.position.z);
    }
    if (this.inWater || this.flying) {
      this._fallPeakY = null;
    }

    // Horizontal wish direction
    const sinY = Math.sin(this.yaw);
    const cosY = Math.cos(this.yaw);
    let wishX = -sinY * forwardInput + cosY * strafeInput;
    let wishZ = -cosY * forwardInput - sinY * strafeInput;
    const wishLen = Math.hypot(wishX, wishZ);
    if (wishLen > 1e-5) {
      wishX /= wishLen;
      wishZ /= wishLen;
    }

    if (this.flying && this.mode === 'creative') {
      const flySpeed = this.sprinting ? 16.5 : 10.0;
      this.velocity.x += (wishX * flySpeed - this.velocity.x) * Math.min(1, dt * 12);
      this.velocity.z += (wishZ * flySpeed - this.velocity.z) * Math.min(1, dt * 12);
      let vy = 0;
      if (this.keys.has('Space')) vy += flySpeed * 0.85;
      if (this.keys.has('KeyC') || this.keys.has('ControlLeft')) vy -= flySpeed * 0.85;
      this.velocity.y += (vy - this.velocity.y) * Math.min(1, dt * 12);
    } else if (this.inWater || this.inLava) {
      const swimSpeed = this.sprinting ? 4.4 : 3.3;
      this.velocity.x += (wishX * swimSpeed - this.velocity.x) * Math.min(1, dt * 8);
      this.velocity.z += (wishZ * swimSpeed - this.velocity.z) * Math.min(1, dt * 8);
      if (this.keys.has('Space')) {
        this.velocity.y = Math.min(4.2, this.velocity.y + 18 * dt);
      } else {
        this.velocity.y = Math.max(-3.2, this.velocity.y - 6.5 * dt);
      }
    } else {
      let moveSpeed = 4.6;
      if (this.sprinting) moveSpeed = 6.5;
      else if (this.sneaking) moveSpeed = 2.1;

      const accel = this.onGround ? 16.0 : 5.5;
      this.velocity.x += (wishX * moveSpeed - this.velocity.x) * Math.min(1, dt * accel);
      this.velocity.z += (wishZ * moveSpeed - this.velocity.z) * Math.min(1, dt * accel);

      // Jump!
      if (this.keys.has('Space') && this.onGround) {
        this.velocity.y = 8.35;
        this.onGround = false;
      }

      // Gravity
      this.velocity.y = Math.max(-36, this.velocity.y - 25.0 * dt);
    }

    // Track peak Y while airborne for Survival fall damage
    if (!this.onGround && !this.inWater && !this.flying) {
      if (this._fallPeakY === null || this.position.y > this._fallPeakY) {
        this._fallPeakY = this.position.y;
      }
    }

    // Axis-separated swept AABB resolution
    // 1) Y axis
    const prevVy = this.velocity.y;
    const nextY = this.position.y + this.velocity.y * dt;
    if (!this._collidesAt(world, this.position.x, nextY, this.position.z)) {
      this.position.y = nextY;
      this.onGround = false;
    } else {
      if (prevVy < 0) {
        // Snap cleanly to top of block below
        this.position.y = Math.floor(nextY) + 1.0001;
        if (!this.onGround && this._fallPeakY !== null && this.mode === 'survival' && !this.inWater) {
          const fallDist = this._fallPeakY - this.position.y;
          if (fallDist > 3.6) {
            const dmg = Math.floor(fallDist - 3.2);
            this.takeDamage(dmg, 0, 0, sound);
          }
        }
        this._fallPeakY = null;
        this.onGround = true;
        if (this.flying) this.flying = false;
      } else if (prevVy > 0) {
        this.position.y = Math.floor(nextY + this.height) - this.height - 0.0002;
      }
      this.velocity.y = 0;
    }

    // 2) X axis (with sneak edge-guard!)
    const nextX = this.position.x + this.velocity.x * dt;
    if (!this._collidesAt(world, nextX, this.position.y, this.position.z)) {
      if (this.sneaking && this.onGround && !this._hasSupportBelow(world, nextX, this.position.y, this.position.z)) {
        this.velocity.x = 0;
      } else {
        this.position.x = nextX;
      }
    } else {
      this.velocity.x = 0;
    }

    // 3) Z axis (with sneak edge-guard!)
    const nextZ = this.position.z + this.velocity.z * dt;
    if (!this._collidesAt(world, this.position.x, this.position.y, nextZ)) {
      if (this.sneaking && this.onGround && !this._hasSupportBelow(world, this.position.x, this.position.y, nextZ)) {
        this.velocity.z = 0;
      } else {
        this.position.z = nextZ;
      }
    } else {
      this.velocity.z = 0;
    }

    // Footstep audio
    const hSpeed = Math.hypot(this.velocity.x, this.velocity.z);
    if ((this.onGround || this.inWater) && hSpeed > 0.35 && !this.flying) {
      this._stepDist += hSpeed * dt;
      if (this._stepDist >= (this.inWater ? 2.1 : 1.75)) {
        this._stepDist = 0;
        if (this.inWater) {
          sound?.playStep('water');
        } else {
          const below = world.getBlock(
            Math.floor(this.position.x),
            Math.floor(this.position.y - 0.2),
            Math.floor(this.position.z)
          );
          sound?.playStep(BLOCK_DEFS[below]?.sound || 'grass');
        }
      }
    }
  }

  _collidesAt(world, px, py, pz) {
    const r = this.halfWidth;
    const minX = Math.floor(px - r);
    const maxX = Math.floor(px + r);
    const minY = Math.floor(py + 0.001);
    const maxY = Math.floor(py + this.height - 0.001);
    const minZ = Math.floor(pz - r);
    const maxZ = Math.floor(pz + r);

    for (let y = minY; y <= maxY; y++) {
      for (let z = minZ; z <= maxZ; z++) {
        for (let x = minX; x <= maxX; x++) {
          const bid = world.getBlock(x, y, z);
          if (BLOCK_DEFS[bid]?.solid) return true;
        }
      }
    }
    return false;
  }

  _hasSupportBelow(world, px, py, pz) {
    const r = this.halfWidth * 0.85;
    const minX = Math.floor(px - r);
    const maxX = Math.floor(px + r);
    const minZ = Math.floor(pz - r);
    const maxZ = Math.floor(pz + r);
    const checkY = Math.floor(py - 0.08);
    for (let z = minZ; z <= maxZ; z++) {
      for (let x = minX; x <= maxX; x++) {
        if (BLOCK_DEFS[world.getBlock(x, checkY, z)]?.solid) return true;
      }
    }
    return false;
  }

  _updateSurvivalVitals(dt, world, sound) {
    // Oxygen underwater
    if (this.headInWater) {
      this.oxygen = Math.max(0, this.oxygen - dt);
      if (this.oxygen <= 0) {
        this.takeDamage(2, 0, 0, sound);
        this.oxygen = 1.0; // Tick drowning once per second
      }
    } else {
      this.oxygen = Math.min(this.maxOxygen, this.oxygen + dt * 4.5);
    }

    // Lava or Cactus contact hazard
    if (this.inLava) {
      this._lavaTimer += dt;
      if (this._lavaTimer >= 0.5) {
        this._lavaTimer = 0;
        this.takeDamage(4, 0, 0, sound);
      }
    }

    const bx = Math.floor(this.position.x);
    const by = Math.floor(this.position.y + 0.5);
    const bz = Math.floor(this.position.z);
    for (const [ox, oz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      if (world.getBlock(bx + ox, by, bz + oz) === BLOCK.CACTUS) {
        if (
          Math.abs(this.position.x - (bx + ox + 0.5)) < 0.84 &&
          Math.abs(this.position.z - (bz + oz + 0.5)) < 0.84
        ) {
          this.takeDamage(1, -ox, -oz, sound);
        }
      }
    }

    // Hunger gentle drain while sprinting/mining
    const drainRate = this.sprinting ? 0.14 : 0.022;
    this._hungerTimer += dt * drainRate;
    if (this._hungerTimer >= 1.0) {
      this._hungerTimer -= 1.0;
      this.hunger = Math.max(0, this.hunger - 1);
    }

    // Natural health regeneration when well-fed!
    if (this.hunger >= 15 && this.health < this.maxHealth) {
      this._regenTimer += dt;
      if (this._regenTimer >= 3.2) {
        this._regenTimer = 0;
        this.health = Math.min(this.maxHealth, this.health + 1);
      }
    } else if (this.hunger === 0) {
      this._regenTimer += dt;
      if (this._regenTimer >= 4.0 && this.health > 2) {
        this._regenTimer = 0;
        this.takeDamage(1, 0, 0, sound);
      }
    }
  }

  _getMiningSpeedMultiplier(blockDef) {
    const heldId = this.getHeldId();
    const itemDef = ITEM_DEFS[heldId];
    if (!itemDef || !itemDef.toolType) return 1.0;
    if (blockDef.tool && itemDef.toolType === blockDef.tool) {
      return itemDef.speed || 2.0;
    }
    return 1.0;
  }

  _canHarvestDrop(blockDef) {
    if (!blockDef.minTier) return true;
    const heldId = this.getHeldId();
    const itemDef = ITEM_DEFS[heldId];
    if (!itemDef || itemDef.toolType !== blockDef.tool) return false;
    return (itemDef.tier || 0) >= blockDef.minTier;
  }

  _updateMiningAndCombat(dt, lookDir, world, mobs, drops, particles, hand, sound) {
    if (!this.leftMouseDown) {
      this.miningBlockKey = null;
      this.miningProgress = 0;
      this.crackMesh.visible = false;
      return;
    }

    // 1. Check if attacking a Mob closer than the targeted block
    const mobHit = mobs.raycastMob(this.camera.position, lookDir, 4.4);
    const blockDist = this.targetHit ? this.targetHit.distance : Infinity;

    if (mobHit && mobHit.distance < blockDist) {
      this.miningBlockKey = null;
      this.miningProgress = 0;
      this.crackMesh.visible = false;

      if (this._attackCooldown <= 0) {
        this._attackCooldown = 0.42;
        hand.triggerSwing();
        const heldDef = ITEM_DEFS[this.getHeldId()];
        const dmg = heldDef?.damage || 2;
        mobs.damageMob(mobHit.mob, dmg, lookDir.x, lookDir.z, drops, particles, sound);
        this.damageHeldTool(sound);
      }
      return;
    }

    // 2. Otherwise mine the targeted block
    if (!this.targetHit) {
      if (this._attackCooldown <= 0) {
        this._attackCooldown = 0.35;
        hand.triggerSwing();
        sound?.playSwing();
      }
      this.miningBlockKey = null;
      this.miningProgress = 0;
      this.crackMesh.visible = false;
      return;
    }

    const { x, y, z, blockId, normal } = this.targetHit;
    const def = BLOCK_DEFS[blockId];
    if (!def) return;

    // Creative mode breaks instantly (with small repeat cooldown so you don't drill 10 blocks by accident!)
    if (this.mode === 'creative') {
      if (this._attackCooldown <= 0) {
        this._attackCooldown = 0.18;
        hand.triggerSwing();
        this._finishBreakBlock(x, y, z, blockId, world, drops, particles, sound, false);
      }
      return;
    }

    if (def.unbreakable) {
      this.miningProgress = 0;
      this.crackMesh.visible = false;
      return;
    }

    const key = `${x},${y},${z}`;
    if (key !== this.miningBlockKey) {
      this.miningBlockKey = key;
      this.miningProgress = 0;
    }

    hand.triggerSwing();
    const speedMult = this._getMiningSpeedMultiplier(def);
    const canHarvest = this._canHarvestDrop(def);
    const effectiveHardness = Math.max(0.05, def.hardness * (canHarvest ? 1.0 : 2.6));

    this.miningProgress += (dt * speedMult) / effectiveHardness;

    this._mineSoundTimer -= dt;
    if (this._mineSoundTimer <= 0) {
      this._mineSoundTimer = 0.23;
      sound?.playMineHit(def.sound || 'stone');
      particles?.spawnMineChip(x, y, z, normal, blockId);
    }

    this.crackMesh.visible = true;
    this.crackMesh.position.set(x + 0.5, y + 0.5, z + 0.5);
    this.crackMat.opacity = Math.min(0.55, this.miningProgress * 0.55);

    if (this.miningProgress >= 1.0) {
      this._finishBreakBlock(x, y, z, blockId, world, drops, particles, sound, canHarvest);
      this.damageHeldTool(sound);
      this.miningBlockKey = null;
      this.miningProgress = 0;
      this.crackMesh.visible = false;
    }
  }

  _finishBreakBlock(x, y, z, blockId, world, drops, particles, sound, spawnLoot = true) {
    const def = BLOCK_DEFS[blockId];
    particles?.spawnBlockBreak(x, y, z, blockId);
    sound?.playBlockBreak(def?.sound || 'stone');

    // If breaking a furnace, drop any items inside it!
    if (blockId === BLOCK.FURNACE || blockId === BLOCK.FURNACE_LIT) {
      const f = world.removeFurnace(x, y, z);
      if (f && drops) {
        if (f.inputId && f.inputCount > 0) drops.spawn(x + 0.5, y + 0.5, z + 0.5, f.inputId, f.inputCount);
        if (f.fuelId && f.fuelCount > 0) drops.spawn(x + 0.5, y + 0.5, z + 0.5, f.fuelId, f.fuelCount);
        if (f.outputId && f.outputCount > 0) drops.spawn(x + 0.5, y + 0.5, z + 0.5, f.outputId, f.outputCount);
      }
    }

    world.setBlock(x, y, z, BLOCK.AIR, { recordEdit: true, immediate: true });

    if (spawnLoot && def && drops) {
      if (typeof def.drop === 'number') {
        drops.spawn(x + 0.5, y + 0.35, z + 0.5, def.drop, 1, 0.15);
      } else if (typeof def.drop === 'string' && def.drop.endsWith('_leaves_loot')) {
        // Leaves occasionally drop Sticks or Red Apples!
        const r = Math.random();
        if (r < 0.14) drops.spawn(x + 0.5, y + 0.35, z + 0.5, ITEM.APPLE, 1, 0.15);
        else if (r < 0.32) drops.spawn(x + 0.5, y + 0.35, z + 0.5, ITEM.STICK, 1, 0.15);
        else if (r < 0.45) drops.spawn(x + 0.5, y + 0.35, z + 0.5, blockId, 1, 0.15);
      }
    }
  }

  _handleRightAction(world, mobs, hand, sound) {
    const heldSlot = this.getHeldSlot();
    const heldId = heldSlot?.id || 0;
    const heldDef = getDef(heldId);

    // 1. Check interactive blocks first (Crafting Table, Furnace, TNT) unless sneaking!
    if (this.targetHit && !this.sneaking) {
      const targetDef = BLOCK_DEFS[this.targetHit.blockId];
      if (targetDef?.interactive === 'crafting') {
        this._placeCooldown = 0.28;
        this.onOpenStation?.('crafting', this.targetHit);
        return;
      }
      if (targetDef?.interactive === 'furnace') {
        this._placeCooldown = 0.28;
        this.onOpenStation?.('furnace', this.targetHit);
        return;
      }
      if (targetDef?.interactive === 'tnt') {
        this._placeCooldown = 0.35;
        hand.triggerSwing();
        world.igniteTNT(this.targetHit.x, this.targetHit.y, this.targetHit.z, sound);
        return;
      }
    }

    // 2. Eat held food if hungry (or hurt)
    if (heldDef?.food) {
      if (this.mode === 'survival' && (this.hunger < this.maxHunger || this.health < this.maxHealth)) {
        this._placeCooldown = 0.45;
        hand.triggerSwing();
        this.hunger = Math.min(this.maxHunger, this.hunger + heldDef.food);
        this.health = Math.min(this.maxHealth, this.health + (heldDef.heal || 1));
        this.consumeFromSlot(this.selectedSlot, 1);
        sound?.playEat();
      }
      return;
    }

    // 3. Place held block onto targeted face
    if (!this.targetHit || !isBlockId(heldId)) return;

    let [px, py, pz] = this.targetHit.placePos;
    // If clicking directly on Tall Grass, replace it in place!
    if (BLOCK_DEFS[this.targetHit.blockId]?.replaceable) {
      px = this.targetHit.x;
      py = this.targetHit.y;
      pz = this.targetHit.z;
    }

    if (py < 1 || py >= 95) return;

    const existing = world.getBlock(px, py, pz);
    if (existing !== BLOCK.AIR && existing !== BLOCK.WATER && existing !== BLOCK.LAVA && !BLOCK_DEFS[existing]?.replaceable) {
      return;
    }

    // Torch / Flora need solid support below
    const placeDef = BLOCK_DEFS[heldId];
    if (heldId === BLOCK.TORCH || placeDef?.render === 'cross') {
      const below = world.getBlock(px, py - 1, pz);
      if (!BLOCK_DEFS[below]?.solid) return;
    }

    // Prevent placing a solid block inside the player's own AABB or any Mob's AABB!
    if (placeDef?.solid) {
      const r = this.halfWidth - 0.02;
      const pMinX = this.position.x - r, pMaxX = this.position.x + r;
      const pMinY = this.position.y + 0.02, pMaxY = this.position.y + this.height - 0.02;
      const pMinZ = this.position.z - r, pMaxZ = this.position.z + r;

      if (
        px + 1 > pMinX && px < pMaxX &&
        py + 1 > pMinY && py < pMaxY &&
        pz + 1 > pMinZ && pz < pMaxZ
      ) {
        return;
      }

      if (mobs.intersectsAnyMob(px, py, pz, px + 1, py + 1, pz + 1)) {
        return;
      }
    }

    if (world.setBlock(px, py, pz, heldId, { recordEdit: true, immediate: true })) {
      this._placeCooldown = 0.20;
      hand.triggerSwing();
      sound?.playBlockPlace(placeDef?.sound || 'stone');
      if (heldId === BLOCK.TORCH) this.unlockMilestone('place_torch');
      if (this.mode === 'survival') {
        this.consumeFromSlot(this.selectedSlot, 1);
      }
    }
  }

  serialize() {
    return {
      mode: this.mode,
      x: Number(this.position.x.toFixed(3)),
      y: Number(this.position.y.toFixed(3)),
      z: Number(this.position.z.toFixed(3)),
      yaw: Number(this.yaw.toFixed(4)),
      pitch: Number(this.pitch.toFixed(4)),
      flying: this.flying,
      health: this.health,
      hunger: this.hunger,
      selectedSlot: this.selectedSlot,
      inventory: this.inventory,
      milestones: Array.from(this.milestones),
    };
  }

  restore(data) {
    if (!data) return;
    if (data.mode) this.mode = data.mode;
    if (typeof data.x === 'number') this.position.set(data.x, data.y, data.z);
    if (typeof data.yaw === 'number') this.yaw = data.yaw;
    if (typeof data.pitch === 'number') this.pitch = data.pitch;
    this.flying = Boolean(data.flying && this.mode === 'creative');
    if (typeof data.health === 'number') this.health = data.health;
    if (typeof data.hunger === 'number') this.hunger = data.hunger;
    if (typeof data.selectedSlot === 'number') this.selectedSlot = data.selectedSlot;
    if (Array.isArray(data.inventory) && data.inventory.length === 36) {
      this.inventory = data.inventory.map((s) => (s ? { ...s } : null));
    }
    if (Array.isArray(data.milestones)) {
      this.milestones = new Set(data.milestones);
    }
  }
}
