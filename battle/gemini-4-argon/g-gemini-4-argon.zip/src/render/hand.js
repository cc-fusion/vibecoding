import * as THREE from 'three';
import { BLOCK_DEFS, isBlockId } from '../world/blocks.js';

export class HeldHandRenderer {
  constructor(textures) {
    this.textures = textures;
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(65, window.innerWidth / window.innerHeight, 0.05, 10);

    this.ambLight = new THREE.AmbientLight(0xffffff, 0.72);
    this.dirLight = new THREE.DirectionalLight(0xfff5e0, 0.85);
    this.dirLight.position.set(2, 4, 3);
    this.scene.add(this.ambLight, this.dirLight);

    this.pivot = new THREE.Group();
    this.scene.add(this.pivot);

    this._meshCache = new Map();
    this._currentItemId = -1;
    this._currentMesh = null;

    this._swingProgress = 0;
    this._swingActive = false;
    this._bobTime = 0;

    this.setItem(0);
  }

  onResize(aspect) {
    this.camera.aspect = aspect;
    this.camera.updateProjectionMatrix();
  }

  triggerSwing() {
    if (!this._swingActive || this._swingProgress > 0.45) {
      this._swingActive = true;
      this._swingProgress = 0;
    }
  }

  _buildHeldMesh(id) {
    if (this._meshCache.has(id)) return this._meshCache.get(id);

    let mesh;
    if (!id) {
      // Empty hand: classic voxel character forearm + sleeve
      const group = new THREE.Group();
      const skinGeo = new THREE.BoxGeometry(0.24, 0.62, 0.24);
      const skinMat = new THREE.MeshLambertMaterial({ color: 0xe0ac82 });
      const arm = new THREE.Mesh(skinGeo, skinMat);
      arm.rotation.x = -Math.PI * 0.36;
      arm.rotation.z = 0.22;

      const sleeveGeo = new THREE.BoxGeometry(0.26, 0.24, 0.26);
      const sleeveMat = new THREE.MeshLambertMaterial({ color: 0x2c7ec7 });
      const sleeve = new THREE.Mesh(sleeveGeo, sleeveMat);
      sleeve.position.set(0, -0.20, 0);
      arm.add(sleeve);

      group.add(arm);
      mesh = group;
    } else if (isBlockId(id) && BLOCK_DEFS[id]?.render !== 'cross' && BLOCK_DEFS[id]?.render !== 'torch') {
      // 3D cube with authentic top/side/bottom textures
      const def = BLOCK_DEFS[id];
      const mkMat = (face) => {
        const name = (face === 'top' && def.faces.top) ||
                     (face === 'bottom' && def.faces.bottom) ||
                     (face === 'front' && def.faces.front) ||
                     def.faces.side || def.faces.all;
        const c = this.textures.tileMap.get(name)?.canvas;
        const tex = new THREE.CanvasTexture(c);
        tex.magFilter = THREE.NearestFilter;
        tex.minFilter = THREE.NearestFilter;
        tex.colorSpace = THREE.SRGBColorSpace;
        return new THREE.MeshLambertMaterial({
          map: tex,
          transparent: def.render === 'fluid' || def.render === 'fluid_solid',
          alphaTest: def.render === 'leaves' || def.render === 'glass' ? 0.4 : 0,
        });
      };
      const sideMat = mkMat('side');
      const frontMat = mkMat('front');
      const topMat = mkMat('top');
      const botMat = mkMat('bottom');
      const geo = new THREE.BoxGeometry(0.42, 0.42, 0.42);
      // BoxGeometry material order: +x, -x, +y, -y, +z, -z
      const cube = new THREE.Mesh(geo, [sideMat, sideMat, topMat, botMat, frontMat, sideMat]);
      cube.rotation.set(0.22, -0.68, 0.08);
      mesh = cube;
    } else {
      // Extrude 16x16 pixel art sprite into crisp 3D mini-voxels!
      const sprite = this.textures.getSpriteCanvas(id);
      const group = new THREE.Group();
      if (sprite) {
        const ctx = sprite.getContext('2d');
        const img = ctx.getImageData(0, 0, 16, 16).data;
        const pxSize = 0.039;
        const depth = 0.054;

        // Collect opaque pixels
        const pixels = [];
        for (let y = 0; y < 16; y++) {
          for (let x = 0; x < 16; x++) {
            const idx = (y * 16 + x) * 4;
            if (img[idx + 3] > 110) {
              pixels.push({
                x, y,
                r: img[idx] / 255,
                g: img[idx + 1] / 255,
                b: img[idx + 2] / 255,
              });
            }
          }
        }

        if (pixels.length > 0) {
          const box = new THREE.BoxGeometry(pxSize * 1.02, pxSize * 1.02, depth);
          const mat = new THREE.MeshLambertMaterial({ color: 0xffffff });
          const inst = new THREE.InstancedMesh(box, mat, pixels.length);
          const dummy = new THREE.Object3D();
          const col = new THREE.Color();

          pixels.forEach((p, i) => {
            dummy.position.set((p.x - 8) * pxSize, (8 - p.y) * pxSize, 0);
            dummy.updateMatrix();
            inst.setMatrixAt(i, dummy.matrix);
            col.setRGB(p.r, p.g, p.b, THREE.SRGBColorSpace);
            inst.setColorAt(i, col);
          });
          inst.instanceMatrix.needsUpdate = true;
          if (inst.instanceColor) inst.instanceColor.needsUpdate = true;

          inst.rotation.set(0.08, -0.56, 0.12);
          group.add(inst);
        }
      }
      mesh = group;
    }

    this._meshCache.set(id, mesh);
    return mesh;
  }

  setItem(id) {
    const cleanId = id || 0;
    if (cleanId === this._currentItemId) return;
    this._currentItemId = cleanId;
    if (this._currentMesh) {
      this.pivot.remove(this._currentMesh);
    }
    this._currentMesh = this._buildHeldMesh(cleanId);
    this.pivot.add(this._currentMesh);
  }

  update(dt, walkSpeed, onGround, lightFactor = 1.0) {
    if (onGround && walkSpeed > 0.2) {
      this._bobTime += dt * Math.min(11, walkSpeed * 1.85);
    } else {
      this._bobTime += dt * 1.2;
    }

    const bobX = Math.cos(this._bobTime) * (walkSpeed > 0.2 ? 0.032 : 0.006);
    const bobY = Math.abs(Math.sin(this._bobTime)) * (walkSpeed > 0.2 ? 0.035 : 0.008);

    let swingRotX = 0;
    let swingRotY = 0;
    let swingRotZ = 0;
    let swingOffX = 0;
    let swingOffY = 0;
    let swingOffZ = 0;

    if (this._swingActive) {
      this._swingProgress += dt * 4.6;
      if (this._swingProgress >= 1) {
        this._swingProgress = 0;
        this._swingActive = false;
      } else {
        const s = Math.sin(this._swingProgress * Math.PI);
        const s2 = Math.sin(this._swingProgress * Math.PI * 2);
        swingRotX = -s * 1.05;
        swingRotY = s * 0.45;
        swingRotZ = -s2 * 0.28;
        swingOffX = -s * 0.14;
        swingOffY = -s * 0.08;
        swingOffZ = -s * 0.16;
      }
    }

    const isEmpty = this._currentItemId === 0;
    const isCube = !isEmpty && isBlockId(this._currentItemId) &&
      BLOCK_DEFS[this._currentItemId]?.render !== 'cross' &&
      BLOCK_DEFS[this._currentItemId]?.render !== 'torch';
    const baseX = isEmpty ? 0.52 : isCube ? 0.52 : 0.48;
    const baseY = isEmpty ? -0.36 : isCube ? -0.32 : -0.24;
    const baseZ = isCube ? -0.78 : -0.72;

    this.pivot.position.set(
      baseX + bobX + swingOffX,
      baseY - bobY + swingOffY,
      baseZ + swingOffZ
    );
    this.pivot.rotation.set(swingRotX, swingRotY, swingRotZ);

    const lf = Math.max(0.22, Math.min(1.15, lightFactor));
    this.ambLight.intensity = 0.35 + 0.45 * lf;
    this.dirLight.intensity = 0.35 + 0.65 * lf;
  }

  render(renderer) {
    renderer.clearDepth();
    renderer.render(this.scene, this.camera);
  }
}
