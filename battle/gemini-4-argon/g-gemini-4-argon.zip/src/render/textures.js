import * as THREE from 'three';
import { BLOCK, BLOCK_DEFS, ITEM, ITEM_DEFS, isBlockId } from '../world/blocks.js';
import { createRNG } from '../world/noise.js';

const TILE_PX = 16;
const SLOT_PX = 32; // 16px inner + 8px extruded border on each side
const GRID_DIM = 16; // 16 x 16 = 256 slots
const ATLAS_PX = SLOT_PX * GRID_DIM; // 512 x 512

function hexToRgb(hex) {
  const n = parseInt(hex.replace('#', ''), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function clampByte(v) {
  return v < 0 ? 0 : v > 255 ? 255 : v | 0;
}

function shadeHex(hex, factor) {
  const [r, g, b] = hexToRgb(hex);
  return `rgb(${clampByte(r * factor)},${clampByte(g * factor)},${clampByte(b * factor)})`;
}

function createTileCanvas() {
  const c = document.createElement('canvas');
  c.width = TILE_PX;
  c.height = TILE_PX;
  return c;
}

function fillNoise(ctx, baseHex, variance, rng, alpha = 1) {
  const [br, bg, bb] = hexToRgb(baseHex);
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      const d = (rng() - 0.5) * 2 * variance;
      ctx.fillStyle = `rgba(${clampByte(br + d)},${clampByte(bg + d)},${clampByte(bb + d)},${alpha})`;
      ctx.fillRect(x, y, 1, 1);
    }
  }
}

function drawOreClusters(ctx, stoneRng, oreHex, highlightHex, darkHex) {
  // Base stone
  fillNoise(ctx, '#818489', 14, stoneRng);
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      if (((x * 3 + y * 5) % 11) === 0) {
        ctx.fillStyle = '#6f7277';
        ctx.fillRect(x, y, 2, 1);
      }
    }
  }
  const spots = [
    [3, 3], [4, 3], [3, 4],
    [10, 4], [11, 4], [11, 5],
    [5, 9], [6, 9], [6, 10], [5, 10],
    [11, 11], [12, 11], [11, 12],
    [2, 12], [3, 13]
  ];
  for (const [x, y] of spots) {
    ctx.fillStyle = oreHex;
    ctx.fillRect(x, y, 1, 1);
  }
  ctx.fillStyle = highlightHex;
  ctx.fillRect(3, 3, 1, 1);
  ctx.fillRect(10, 4, 1, 1);
  ctx.fillRect(5, 9, 1, 1);
  ctx.fillRect(11, 11, 1, 1);

  ctx.fillStyle = darkHex;
  ctx.fillRect(4, 4, 1, 1);
  ctx.fillRect(6, 10, 1, 1);
  ctx.fillRect(12, 12, 1, 1);
}

function drawPlanks(ctx, baseHex, darkHex, lightHex, rng) {
  fillNoise(ctx, baseHex, 9, rng);
  for (let row = 0; row < 4; row++) {
    const yTop = row * 4;
    ctx.fillStyle = lightHex;
    ctx.fillRect(0, yTop, 16, 1);
    ctx.fillStyle = darkHex;
    ctx.fillRect(0, yTop + 3, 16, 1);
    const seamX = (row * 7 + 4) % 16;
    ctx.fillRect(seamX, yTop, 1, 4);
    // Nail dots
    ctx.fillStyle = shadeHex(darkHex, 0.85);
    ctx.fillRect((seamX + 2) % 16, yTop + 1, 1, 1);
    ctx.fillRect((seamX + 14) % 16, yTop + 2, 1, 1);
  }
}

function drawLogTop(ctx, barkHex, innerHex, ringHex) {
  ctx.fillStyle = barkHex;
  ctx.fillRect(0, 0, 16, 16);
  ctx.fillStyle = innerHex;
  ctx.fillRect(2, 2, 12, 12);
  ctx.strokeStyle = ringHex;
  ctx.lineWidth = 1;
  ctx.strokeRect(3.5, 3.5, 9, 9);
  ctx.strokeRect(5.5, 5.5, 5, 5);
  ctx.fillStyle = ringHex;
  ctx.fillRect(7, 7, 2, 2);
}

function drawLeaves(ctx, baseHex, lightHex, darkHex, rng) {
  ctx.clearRect(0, 0, 16, 16);
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      const r = rng();
      // Small organic gaps so light peeks through
      if (r < 0.14 && x > 0 && x < 15 && y > 0 && y < 15) continue;
      if (r < 0.42) ctx.fillStyle = darkHex;
      else if (r < 0.78) ctx.fillStyle = baseHex;
      else ctx.fillStyle = lightHex;
      ctx.fillRect(x, y, 1, 1);
    }
  }
}

// Draw 16x16 pixel art tool/item onto a context
function drawPixelPattern(ctx, pattern, palette) {
  ctx.clearRect(0, 0, 16, 16);
  for (let y = 0; y < pattern.length; y++) {
    const row = pattern[y];
    for (let x = 0; x < row.length; x++) {
      const ch = row[x];
      if (ch !== '.' && ch !== ' ' && palette[ch]) {
        ctx.fillStyle = palette[ch];
        ctx.fillRect(x, y, 1, 1);
      }
    }
  }
}

const TOOL_PALETTES = {
  wood: { M: '#ad804b', H: '#cfa167', D: '#78552d', S: '#b5844c', s: '#855b2e' },
  stone: { M: '#9499a1', H: '#bcc2cc', D: '#63676e', S: '#b5844c', s: '#855b2e' },
  iron: { M: '#dde3eb', H: '#ffffff', D: '#96a0ab', S: '#b5844c', s: '#855b2e' },
  diamond: { M: '#42ebe0', H: '#b8fffa', D: '#1da19b', S: '#b5844c', s: '#855b2e' },
};

const PATTERNS = {
  pickaxe: [
    '................',
    '.....HHHHMM.....',
    '....HMMDDDMM....',
    '...HD......MD...',
    '..........ssMD..',
    '.........sS..MD.',
    '........sS...MD.',
    '.......sS....D..',
    '......sS........',
    '.....sS.........',
    '....sS..........',
    '...sS...........',
    '..sS............',
    '.ss.............',
    '................',
    '................',
  ],
  axe: [
    '................',
    '......HHMM......',
    '.....HMMMMD.....',
    '....HMMMMsMD....',
    '....HMMDsS......',
    '.....DDsS.......',
    '......sS........',
    '.....sS.........',
    '....sS..........',
    '...sS...........',
    '..sS............',
    '.ss.............',
    '................',
    '................',
    '................',
    '................',
  ],
  shovel: [
    '................',
    '..........HHM...',
    '.........HMMMD..',
    '.........HMMMD..',
    '.........DsMMD..',
    '........sS.DD...',
    '.......sS.......',
    '......sS........',
    '.....sS.........',
    '....sS..........',
    '...sS...........',
    '..sS............',
    '.ss.............',
    '................',
    '................',
    '................',
  ],
  sword: [
    '................',
    '............HHM.',
    '...........HMMMD',
    '..........HMMMD.',
    '.........HMMMD..',
    '........HMMMD...',
    '.......HMMMD....',
    '....DD.HMMD.....',
    '.....DDHMD......',
    '.....sDDD.......',
    '....sS.DD.......',
    '...sS...D.......',
    '..DS............',
    '.DD.............',
    '................',
    '................',
  ],
  stick: [
    '................',
    '................',
    '............sS..',
    '...........sS...',
    '..........sS....',
    '.........sS.....',
    '........sS......',
    '.......sS.......',
    '......sS........',
    '.....sS.........',
    '....sS..........',
    '...sS...........',
    '..ss............',
    '................',
    '................',
    '................',
  ],
  ingot: [
    '................',
    '................',
    '................',
    '................',
    '.....HHHHHH.....',
    '...HHMMMMMMMD...',
    '..HMMMMMMMMMMD..',
    '..HMMHHHHMMMMD..',
    '..DMMMMMMMMMDD..',
    '...DDDDDDDDDD...',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
  ],
  coal: [
    '................',
    '................',
    '......DDDD......',
    '....DDMMMMDD....',
    '...DMMHHMMMMD...',
    '...DMHMMMMMMD...',
    '..DMMMMMMMMMMD..',
    '..DMMMMMMMMDDD..',
    '...DMMMMMMMDD...',
    '....DDMMMMDD....',
    '.....DDDDDD.....',
    '................',
    '................',
    '................',
    '................',
    '................',
  ],
  diamond: [
    '................',
    '................',
    '.....DDDDDD.....',
    '....DHHHHHHD....',
    '...DHHMMMMMMD...',
    '..DHMMHHHHMMMD..',
    '..DMMMMMMMMMMD..',
    '...DMMMMMMMMD...',
    '....DMMMMMMD....',
    '.....DMMMMD.....',
    '......DDDD......',
    '................',
    '................',
    '................',
    '................',
    '................',
  ],
  apple: [
    '................',
    '.......ssG......',
    '.......sGG......',
    '....DDDsDDD.....',
    '...DHHMMMDDDD...',
    '..DHMMMMMMMDDD..',
    '..DHMMMMMMMMDD..',
    '..DMMMMMMMMMDD..',
    '..DMMMMMMMMMDD..',
    '...DMMMMMMMDD...',
    '....DMMMMMDD....',
    '.....DD.DDD.....',
    '................',
    '................',
    '................',
    '................',
  ],
  meat: [
    '................',
    '................',
    '....DDDDDD......',
    '...DHHMMMMDD....',
    '..DHMMMMMMMMD...',
    '..DMMMMMMBBMMD..',
    '..DMMMMMBWWBMD..',
    '...DMMMMBBBBMD..',
    '....DMMMMMMMDD..',
    '.....DDDDDDDD...',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
  ],
};

export class TextureManager {
  constructor() {
    this.rng = createRNG(202604);
    this.tileMap = new Map(); // name -> { index, u0, v0, u1, v1, canvas }
    this.itemCanvases = new Map(); // itemId -> 16x16 canvas
    this.iconCache = new Map(); // blockOrItemId -> dataURL

    this.atlasCanvas = document.createElement('canvas');
    this.atlasCanvas.width = ATLAS_PX;
    this.atlasCanvas.height = ATLAS_PX;
    this.atlasCtx = this.atlasCanvas.getContext('2d');

    this._buildAllBlockTiles();
    this._buildAllItemSprites();

    this.atlasTexture = new THREE.CanvasTexture(this.atlasCanvas);
    this.atlasTexture.colorSpace = THREE.SRGBColorSpace;
    this.atlasTexture.magFilter = THREE.NearestFilter;
    this.atlasTexture.minFilter = THREE.NearestFilter;
    this.atlasTexture.generateMipmaps = false;
    this.atlasTexture.needsUpdate = true;

    this.sharedUniforms = {
      uAtlas: { value: this.atlasTexture },
      uSunIntensity: { value: 1.0 },
      uSkyTint: { value: new THREE.Color(1.0, 0.99, 0.96) },
      uTorchTint: { value: new THREE.Color(1.08, 0.82, 0.48) },
      uMinAmbient: { value: 0.055 },
      uFogColor: { value: new THREE.Color(0x87ceeb) },
      uFogNear: { value: 48.0 },
      uFogFar: { value: 110.0 },
      uTime: { value: 0.0 },
    };

    this.opaqueMaterial = this._createChunkMaterial({ cutout: false, fluid: false });
    this.cutoutMaterial = this._createChunkMaterial({ cutout: true, fluid: false });
    this.fluidMaterial = this._createChunkMaterial({ cutout: false, fluid: true });
  }

  _createChunkMaterial({ cutout, fluid }) {
    return new THREE.ShaderMaterial({
      uniforms: this.sharedUniforms,
      transparent: fluid,
      depthWrite: !fluid,
      side: cutout || fluid ? THREE.DoubleSide : THREE.FrontSide,
      vertexShader: `
        attribute vec3 aLight; // x: ao * dirShade, y: skyLight [0..1], z: blockLight [0..1]
        uniform float uTime;
        varying vec2 vUv;
        varying vec3 vLight;
        varying float vFogDepth;

        void main() {
          vUv = uv;
          vLight = aLight;
          vec3 pos = position;
          ${fluid ? `
            // Subtle surface ripple on fluid vertices
            float wave = sin(pos.x * 2.1 + uTime * 2.4) * cos(pos.z * 2.1 + uTime * 1.9) * 0.032;
            pos.y += wave;
          ` : ''}
          vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
          vFogDepth = length(mvPosition.xyz);
          gl_Position = projectionMatrix * mvPosition;
        }
      `,
      fragmentShader: `
        uniform sampler2D uAtlas;
        uniform float uSunIntensity;
        uniform vec3 uSkyTint;
        uniform vec3 uTorchTint;
        uniform float uMinAmbient;
        uniform vec3 uFogColor;
        uniform float uFogNear;
        uniform float uFogFar;
        uniform float uTime;

        varying vec2 vUv;
        varying vec3 vLight;
        varying float vFogDepth;

        void main() {
          vec4 texel = texture2D(uAtlas, vUv);
          ${cutout ? 'if (texel.a < 0.45) discard;' : ''}

          float shade = vLight.x;
          float sky = vLight.y;
          float blockL = vLight.z;

          float flicker = 0.975 + 0.025 * sin(uTime * 7.5 + vFogDepth * 0.3);
          vec3 skyContrib = sky * uSunIntensity * uSkyTint;
          vec3 torchContrib = blockL * flicker * uTorchTint;
          vec3 totalLight = max(skyContrib, torchContrib);
          // Blend secondary light slightly so lit caves near daylight blend naturally
          totalLight += min(skyContrib, torchContrib) * 0.28;
          totalLight = max(totalLight, vec3(uMinAmbient));

          vec3 litColor = texel.rgb * totalLight * shade;

          float fogFactor = smoothstep(uFogNear, uFogFar, vFogDepth);
          vec3 finalRgb = mix(litColor, uFogColor, fogFactor);
          float outAlpha = ${fluid ? 'mix(texel.a * 0.80, 0.96, fogFactor)' : 'texel.a'};

          gl_FragColor = vec4(finalRgb, outAlpha);
          #include <colorspace_fragment>
        }
      `,
    });
  }

  updateAtmosphere({ sunIntensity, skyTint, fogColor, fogNear, fogFar, time, underwater }) {
    const u = this.sharedUniforms;
    u.uSunIntensity.value = sunIntensity;
    u.uSkyTint.value.copy(skyTint);
    u.uFogColor.value.copy(fogColor);
    u.uFogNear.value = fogNear;
    u.uFogFar.value = fogFar;
    u.uTime.value = time;
    u.uMinAmbient.value = underwater ? 0.16 : 0.055;
  }

  _registerTile(name, drawFn) {
    const index = this.tileMap.size;
    const tileCanvas = createTileCanvas();
    const ctx = tileCanvas.getContext('2d');
    drawFn(ctx, this.rng);

    const gx = index % GRID_DIM;
    const gy = Math.floor(index / GRID_DIM);
    const sx = gx * SLOT_PX;
    const sy = gy * SLOT_PX;
    const ix = sx + 8;
    const iy = sy + 8;

    const actx = this.atlasCtx;
    // Draw center 16x16
    actx.drawImage(tileCanvas, ix, iy);
    // Extrude top & bottom borders (8px)
    for (let p = 1; p <= 8; p++) {
      actx.drawImage(tileCanvas, 0, 0, 16, 1, ix, iy - p, 16, 1);
      actx.drawImage(tileCanvas, 0, 15, 16, 1, ix, iy + 15 + p, 16, 1);
    }
    // Extrude left & right borders (including corners)
    for (let p = 1; p <= 8; p++) {
      actx.drawImage(this.atlasCanvas, ix, sy, 1, SLOT_PX, ix - p, sy, 1, SLOT_PX);
      actx.drawImage(this.atlasCanvas, ix + 15, sy, 1, SLOT_PX, ix + 15 + p, sy, 1, SLOT_PX);
    }

    // Three.js UV origin (0,0) is bottom-left
    const u0 = ix / ATLAS_PX;
    const u1 = (ix + TILE_PX) / ATLAS_PX;
    const v1 = 1.0 - iy / ATLAS_PX;
    const v0 = 1.0 - (iy + TILE_PX) / ATLAS_PX;

    this.tileMap.set(name, { index, u0, v0, u1, v1, canvas: tileCanvas });
  }

  getTileUV(name) {
    return this.tileMap.get(name) || this.tileMap.get('stone');
  }

  getBlockFaceUV(blockId, faceName) {
    const def = BLOCK_DEFS[blockId];
    if (!def || !def.faces) return this.getTileUV('stone');
    const f = def.faces;
    let key = f.all;
    if (faceName === 'top' && f.top) key = f.top;
    else if (faceName === 'bottom' && f.bottom) key = f.bottom;
    else if (faceName === 'front' && f.front) key = f.front;
    else if (f.side) key = f.side;
    return this.getTileUV(key);
  }

  _buildAllBlockTiles() {
    // Grass top
    this._registerTile('grass_top', (ctx, rng) => {
      fillNoise(ctx, '#58a832', 16, rng);
      for (let i = 0; i < 24; i++) {
        ctx.fillStyle = rng() > 0.5 ? '#6abf40' : '#489127';
        ctx.fillRect((rng() * 16) | 0, (rng() * 16) | 0, 1, 2);
      }
    });

    // Dirt
    this._registerTile('dirt', (ctx, rng) => {
      fillNoise(ctx, '#795335', 16, rng);
      for (let i = 0; i < 18; i++) {
        ctx.fillStyle = rng() > 0.4 ? '#614127' : '#966b49';
        ctx.fillRect((rng() * 16) | 0, (rng() * 16) | 0, 1, 1);
      }
    });

    // Grass side
    this._registerTile('grass_side', (ctx, rng) => {
      const dirt = this.tileMap.get('dirt').canvas;
      ctx.drawImage(dirt, 0, 0);
      for (let x = 0; x < 16; x++) {
        const overhang = 2 + (((x * 7 + 3) % 4) === 0 ? 2 : ((x * 5) % 3 === 0 ? 1 : 0));
        for (let y = 0; y < overhang; y++) {
          ctx.fillStyle = y === overhang - 1 ? '#448723' : (rng() > 0.5 ? '#5cb035' : '#519e2c');
          ctx.fillRect(x, y, 1, 1);
        }
      }
    });

    // Snow & Snowy grass side
    this._registerTile('snow', (ctx, rng) => {
      fillNoise(ctx, '#f0f7fc', 8, rng);
      for (let i = 0; i < 12; i++) {
        ctx.fillStyle = '#dceaf5';
        ctx.fillRect((rng() * 16) | 0, (rng() * 16) | 0, 2, 1);
      }
    });

    this._registerTile('snow_side', (ctx) => {
      ctx.drawImage(this.tileMap.get('dirt').canvas, 0, 0);
      for (let x = 0; x < 16; x++) {
        const overhang = 3 + ((x * 5 + 2) % 3 === 0 ? 2 : 0);
        for (let y = 0; y < overhang; y++) {
          ctx.fillStyle = y === overhang - 1 ? '#cde0f0' : '#f2f8fc';
          ctx.fillRect(x, y, 1, 1);
        }
      }
    });

    // Stone
    this._registerTile('stone', (ctx, rng) => {
      fillNoise(ctx, '#80848a', 14, rng);
      for (let y = 0; y < 16; y += 2) {
        const x = ((y * 5) + 3) % 13;
        ctx.fillStyle = '#6c7076';
        ctx.fillRect(x, y, 3, 1);
      }
    });

    // Cobblestone
    this._registerTile('cobblestone', (ctx, rng) => {
      fillNoise(ctx, '#73767b', 18, rng);
      const stones = [
        [1, 1, 6, 4], [8, 0, 7, 5], [0, 6, 5, 5], [6, 5, 6, 5],
        [13, 6, 3, 5], [1, 12, 7, 4], [9, 11, 6, 5]
      ];
      for (const [x, y, w, h] of stones) {
        ctx.fillStyle = '#8b8f96';
        ctx.fillRect(x, y, w - 1, h - 1);
        ctx.fillStyle = '#9fa3ab';
        ctx.fillRect(x, y, w - 2, 1);
        ctx.fillStyle = '#53565a';
        ctx.fillRect(x + w - 1, y, 1, h);
        ctx.fillRect(x, y + h - 1, w, 1);
      }
    });

    // Mossy Cobblestone
    this._registerTile('mossy_cobble', (ctx, rng) => {
      ctx.drawImage(this.tileMap.get('cobblestone').canvas, 0, 0);
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          if (rng() < 0.34) {
            ctx.fillStyle = rng() > 0.4 ? '#4d8236' : '#659c46';
            ctx.fillRect(x, y, 1, 1);
          }
        }
      }
    });

    // Stone bricks
    this._registerTile('stone_bricks', (ctx, rng) => {
      fillNoise(ctx, '#84878d', 10, rng);
      ctx.fillStyle = '#55585d';
      ctx.fillRect(0, 7, 16, 1);
      ctx.fillRect(0, 15, 16, 1);
      ctx.fillRect(7, 0, 1, 8);
      ctx.fillRect(15, 8, 1, 8);
      ctx.fillStyle = '#9ea2a8';
      ctx.fillRect(0, 0, 7, 1);
      ctx.fillRect(8, 0, 8, 1);
      ctx.fillRect(0, 8, 15, 1);
    });

    // Sand & Sandstone
    this._registerTile('sand', (ctx, rng) => {
      fillNoise(ctx, '#dfd199', 12, rng);
      for (let y = 2; y < 16; y += 4) {
        ctx.fillStyle = '#ebdfb0';
        ctx.fillRect((y * 3) % 12, y, 4, 1);
      }
    });

    this._registerTile('sandstone_top', (ctx, rng) => {
      fillNoise(ctx, '#e2d49d', 8, rng);
      ctx.strokeStyle = '#cbb97d';
      ctx.strokeRect(1.5, 1.5, 13, 13);
    });

    this._registerTile('sandstone_bottom', (ctx, rng) => {
      fillNoise(ctx, '#cbb97d', 12, rng);
    });

    this._registerTile('sandstone_side', (ctx, rng) => {
      fillNoise(ctx, '#dac98f', 10, rng);
      ctx.fillStyle = '#ede0b1';
      ctx.fillRect(0, 0, 16, 3);
      ctx.fillStyle = '#bfa96d';
      ctx.fillRect(0, 3, 16, 1);
      ctx.fillRect(0, 11, 16, 1);
    });

    // Gravel & Clay & Bedrock
    this._registerTile('gravel', (ctx, rng) => {
      fillNoise(ctx, '#888381', 24, rng);
    });

    this._registerTile('clay', (ctx, rng) => {
      fillNoise(ctx, '#9ca4b3', 10, rng);
    });

    this._registerTile('bedrock', (ctx, rng) => {
      fillNoise(ctx, '#38393d', 32, rng);
      for (let i = 0; i < 25; i++) {
        ctx.fillStyle = '#1f2023';
        ctx.fillRect((rng() * 15) | 0, (rng() * 15) | 0, 2, 2);
      }
    });

    // Ice
    this._registerTile('ice', (ctx, rng) => {
      fillNoise(ctx, '#8dc2f7', 8, rng, 0.85);
      ctx.fillStyle = 'rgba(235,248,255,0.75)';
      for (let i = 0; i < 12; i++) {
        ctx.fillRect((i * 3) % 14, i, 2, 1);
      }
    });

    // Oak Log & Planks
    this._registerTile('oak_log_side', (ctx, rng) => {
      fillNoise(ctx, '#6b4f30', 12, rng);
      for (let x = 0; x < 16; x += 2) {
        ctx.fillStyle = x % 4 === 0 ? '#523b21' : '#7d5d39';
        ctx.fillRect(x, 0, 1, 16);
      }
    });
    this._registerTile('oak_log_top', (ctx) => drawLogTop(ctx, '#6b4f30', '#b59360', '#8f6f42'));
    this._registerTile('oak_planks', (ctx, rng) => drawPlanks(ctx, '#ad8650', '#7d5c32', '#c7a069', rng));

    // Birch Log & Planks
    this._registerTile('birch_log_side', (ctx, rng) => {
      fillNoise(ctx, '#dedad1', 10, rng);
      const marks = [[2, 3, 3], [10, 2, 4], [5, 7, 4], [12, 9, 3], [1, 12, 4], [8, 14, 3]];
      for (const [x, y, w] of marks) {
        ctx.fillStyle = '#383632';
        ctx.fillRect(x, y, w, 1);
        ctx.fillStyle = '#736f67';
        ctx.fillRect(x, y + 1, w - 1, 1);
      }
    });
    this._registerTile('birch_log_top', (ctx) => drawLogTop(ctx, '#d9d5cb', '#cfc199', '#ab9b72'));
    this._registerTile('birch_planks', (ctx, rng) => drawPlanks(ctx, '#ccb87e', '#9e8b56', '#e0cfa0', rng));

    // Spruce Log & Planks
    this._registerTile('spruce_log_side', (ctx, rng) => {
      fillNoise(ctx, '#47321e', 10, rng);
      for (let x = 0; x < 16; x += 3) {
        ctx.fillStyle = '#302011';
        ctx.fillRect(x, 0, 1, 16);
      }
    });
    this._registerTile('spruce_log_top', (ctx) => drawLogTop(ctx, '#47321e', '#8c6a43', '#66492a'));
    this._registerTile('spruce_planks', (ctx, rng) => drawPlanks(ctx, '#785735', '#543b21', '#916d47', rng));

    // Leaves
    this._registerTile('oak_leaves', (ctx, rng) => drawLeaves(ctx, '#3f8a27', '#55ab38', '#2a6618', rng));
    this._registerTile('birch_leaves', (ctx, rng) => drawLeaves(ctx, '#63993d', '#7db553', '#497829', rng));
    this._registerTile('spruce_leaves', (ctx, rng) => drawLeaves(ctx, '#2d5c36', '#3f784a', '#1d4024', rng));

    // Ores
    this._registerTile('coal_ore', (ctx, rng) => drawOreClusters(ctx, rng, '#26282b', '#43464d', '#141517'));
    this._registerTile('iron_ore', (ctx, rng) => drawOreClusters(ctx, rng, '#cf9e7c', '#f0cbb1', '#9c6e50'));
    this._registerTile('gold_ore', (ctx, rng) => drawOreClusters(ctx, rng, '#f5cc36', '#fff29c', '#ba8d14'));
    this._registerTile('diamond_ore', (ctx, rng) => drawOreClusters(ctx, rng, '#3be6dc', '#b8fff9', '#199994'));

    // Water & Lava
    this._registerTile('water', (ctx, rng) => {
      fillNoise(ctx, '#286fe0', 12, rng, 0.82);
      ctx.fillStyle = 'rgba(130, 195, 255, 0.55)';
      ctx.fillRect(2, 3, 5, 1);
      ctx.fillRect(9, 8, 5, 1);
      ctx.fillRect(3, 13, 6, 1);
    });

    this._registerTile('lava', (ctx, rng) => {
      fillNoise(ctx, '#eb5b13', 20, rng, 0.96);
      ctx.fillStyle = '#ffcf33';
      ctx.fillRect(2, 2, 4, 2);
      ctx.fillRect(9, 7, 5, 2);
      ctx.fillRect(4, 12, 5, 2);
      ctx.fillStyle = '#b82c09';
      ctx.fillRect(8, 2, 4, 2);
      ctx.fillRect(1, 8, 4, 2);
    });

    // Crafting Table
    this._registerTile('crafting_top', (ctx, rng) => {
      fillNoise(ctx, '#a67a46', 8, rng);
      ctx.fillStyle = '#5e4020';
      ctx.fillRect(0, 0, 16, 2);
      ctx.fillRect(0, 14, 16, 2);
      ctx.fillRect(0, 0, 2, 16);
      ctx.fillRect(14, 0, 2, 16);
      // 3x3 crafting grid lines
      ctx.fillStyle = '#6b4926';
      ctx.fillRect(2, 6, 12, 1);
      ctx.fillRect(2, 10, 12, 1);
      ctx.fillRect(6, 2, 1, 12);
      ctx.fillRect(10, 2, 1, 12);
    });

    this._registerTile('crafting_side', (ctx) => {
      ctx.drawImage(this.tileMap.get('oak_planks').canvas, 0, 0);
      ctx.fillStyle = '#5e4020';
      ctx.fillRect(0, 0, 16, 3);
      ctx.fillStyle = '#8c6236';
      ctx.fillRect(1, 1, 14, 1);
      // Mini saw & hammer silhouette
      ctx.fillStyle = '#cfd5de';
      ctx.fillRect(4, 6, 2, 6);
      ctx.fillRect(3, 6, 4, 2);
      ctx.fillStyle = '#6e4c26';
      ctx.fillRect(4, 9, 2, 5);
      ctx.fillStyle = '#cfd5de';
      ctx.fillRect(10, 6, 3, 5);
      ctx.fillStyle = '#6e4c26';
      ctx.fillRect(11, 5, 2, 2);
    });

    // Furnace
    this._registerTile('furnace_top', (ctx, rng) => {
      fillNoise(ctx, '#74777d', 10, rng);
      ctx.strokeStyle = '#525559';
      ctx.strokeRect(1.5, 1.5, 13, 13);
    });

    this._registerTile('furnace_side', (ctx) => {
      ctx.drawImage(this.tileMap.get('cobblestone').canvas, 0, 0);
      ctx.fillStyle = '#525559';
      ctx.fillRect(0, 0, 16, 2);
      ctx.fillRect(0, 14, 16, 2);
    });

    this._registerTile('furnace_front', (ctx) => {
      ctx.drawImage(this.tileMap.get('furnace_side').canvas, 0, 0);
      ctx.fillStyle = '#26282b';
      ctx.fillRect(4, 4, 8, 4);
      ctx.fillRect(4, 10, 8, 4);
      ctx.fillStyle = '#474a50';
      ctx.fillRect(3, 3, 10, 1);
      ctx.fillRect(3, 9, 10, 1);
    });

    this._registerTile('furnace_front_lit', (ctx) => {
      ctx.drawImage(this.tileMap.get('furnace_front').canvas, 0, 0);
      ctx.fillStyle = '#ff7b1c';
      ctx.fillRect(4, 10, 8, 4);
      ctx.fillStyle = '#ffe054';
      ctx.fillRect(5, 11, 6, 2);
    });

    // Glass
    this._registerTile('glass', (ctx) => {
      ctx.clearRect(0, 0, 16, 16);
      ctx.fillStyle = '#d7f2fc';
      ctx.fillRect(0, 0, 16, 1);
      ctx.fillRect(0, 15, 16, 1);
      ctx.fillRect(0, 0, 1, 16);
      ctx.fillRect(15, 0, 1, 16);
      // Glint streaks
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(3, 3, 2, 1);
      ctx.fillRect(2, 4, 2, 1);
      ctx.fillRect(11, 11, 2, 1);
      ctx.fillRect(10, 12, 2, 1);
    });

    // Bricks
    this._registerTile('bricks', (ctx, rng) => {
      fillNoise(ctx, '#a84f3d', 12, rng);
      ctx.fillStyle = '#cfc7bc';
      for (let y = 3; y < 16; y += 4) {
        ctx.fillRect(0, y, 16, 1);
      }
      ctx.fillRect(7, 0, 1, 3);
      ctx.fillRect(3, 4, 1, 3);
      ctx.fillRect(11, 4, 1, 3);
      ctx.fillRect(7, 8, 1, 3);
      ctx.fillRect(3, 12, 1, 3);
      ctx.fillRect(11, 12, 1, 3);
    });

    // Bookshelf
    this._registerTile('bookshelf', (ctx) => {
      ctx.drawImage(this.tileMap.get('oak_planks').canvas, 0, 0);
      ctx.fillStyle = '#3d2814';
      ctx.fillRect(1, 2, 14, 5);
      ctx.fillRect(1, 9, 14, 5);
      const colors = ['#c9382e', '#2d7ec7', '#3a9c45', '#d9a52b', '#8742b8', '#2da69a'];
      for (let row = 0; row < 2; row++) {
        const y = row === 0 ? 2 : 9;
        let x = 2;
        let ci = row * 3;
        while (x < 14) {
          ctx.fillStyle = colors[ci % colors.length];
          ctx.fillRect(x, y, 2, 5);
          ctx.fillStyle = '#f2ead8';
          ctx.fillRect(x, y + 1, 2, 1);
          x += 3;
          ci++;
        }
      }
    });

    // Glowstone
    this._registerTile('glowstone', (ctx, rng) => {
      fillNoise(ctx, '#d49831', 22, rng);
      for (let i = 0; i < 32; i++) {
        ctx.fillStyle = rng() > 0.4 ? '#fff39e' : '#ffcf54';
        ctx.fillRect((rng() * 14 + 1) | 0, (rng() * 14 + 1) | 0, 2, 2);
      }
    });

    // Torch
    this._registerTile('torch', (ctx) => {
      ctx.clearRect(0, 0, 16, 16);
      ctx.fillStyle = '#7c5832';
      ctx.fillRect(7, 6, 2, 10);
      ctx.fillStyle = '#996f40';
      ctx.fillRect(7, 7, 1, 9);
      ctx.fillStyle = '#ff7b1c';
      ctx.fillRect(6, 3, 4, 3);
      ctx.fillStyle = '#fff380';
      ctx.fillRect(7, 4, 2, 2);
    });

    // TNT
    this._registerTile('tnt_side', (ctx) => {
      ctx.fillStyle = '#cf3223';
      ctx.fillRect(0, 0, 16, 16);
      for (let x = 0; x < 16; x += 4) {
        ctx.fillStyle = '#ab2418';
        ctx.fillRect(x + 3, 0, 1, 16);
      }
      ctx.fillStyle = '#f2efe9';
      ctx.fillRect(0, 5, 16, 6);
      ctx.fillStyle = '#1f1f1f';
      // T N T letters
      ctx.fillRect(2, 6, 3, 1); ctx.fillRect(3, 6, 1, 4);
      ctx.fillRect(6, 6, 1, 4); ctx.fillRect(7, 7, 1, 1); ctx.fillRect(8, 8, 1, 1); ctx.fillRect(9, 6, 1, 4);
      ctx.fillRect(11, 6, 3, 1); ctx.fillRect(12, 6, 1, 4);
    });
    this._registerTile('tnt_top', (ctx, rng) => {
      fillNoise(ctx, '#cf3223', 14, rng);
      ctx.fillStyle = '#2b2b2b';
      ctx.fillRect(6, 6, 4, 4);
      ctx.fillStyle = '#e8e2d5';
      ctx.fillRect(7, 7, 2, 2);
    });
    this._registerTile('tnt_bottom', (ctx, rng) => fillNoise(ctx, '#a6261b', 12, rng));

    // Cactus
    this._registerTile('cactus_side', (ctx, rng) => {
      fillNoise(ctx, '#3b8224', 10, rng);
      for (let x = 1; x < 16; x += 4) {
        ctx.fillStyle = '#296317';
        ctx.fillRect(x, 0, 1, 16);
        ctx.fillStyle = '#dce8b5';
        ctx.fillRect(x, (x * 3) % 14 + 1, 1, 1);
        ctx.fillRect(x, (x * 7 + 5) % 14 + 1, 1, 1);
      }
    });
    this._registerTile('cactus_top', (ctx, rng) => {
      fillNoise(ctx, '#4b9630', 10, rng);
      ctx.strokeStyle = '#2b6618';
      ctx.strokeRect(1.5, 1.5, 13, 13);
    });

    // Flora (Cross-quad cutouts)
    this._registerTile('tall_grass', (ctx, rng) => {
      ctx.clearRect(0, 0, 16, 16);
      const blades = [2, 4, 6, 8, 10, 12, 14];
      for (const bx of blades) {
        const h = 6 + ((rng() * 8) | 0);
        let cx = bx;
        for (let y = 15; y >= 16 - h; y--) {
          ctx.fillStyle = y < 10 ? '#6cc23e' : '#4a9625';
          ctx.fillRect(cx, y, 1, 1);
          if (rng() < 0.25) cx = Math.max(1, Math.min(14, cx + (rng() > 0.5 ? 1 : -1)));
        }
      }
    });

    this._registerTile('poppy', (ctx) => {
      ctx.clearRect(0, 0, 16, 16);
      ctx.fillStyle = '#3b8522';
      ctx.fillRect(7, 8, 2, 8);
      ctx.fillRect(5, 12, 2, 1);
      ctx.fillRect(9, 11, 2, 1);
      ctx.fillStyle = '#e02f26';
      ctx.fillRect(5, 4, 6, 4);
      ctx.fillRect(6, 3, 4, 5);
      ctx.fillStyle = '#ff6559';
      ctx.fillRect(6, 4, 2, 2);
      ctx.fillStyle = '#2b1816';
      ctx.fillRect(7, 6, 2, 1);
    });

    this._registerTile('dandelion', (ctx) => {
      ctx.clearRect(0, 0, 16, 16);
      ctx.fillStyle = '#3b8522';
      ctx.fillRect(7, 8, 2, 8);
      ctx.fillRect(6, 12, 1, 2);
      ctx.fillStyle = '#f5d427';
      ctx.fillRect(5, 4, 6, 4);
      ctx.fillRect(6, 3, 4, 5);
      ctx.fillStyle = '#fff587';
      ctx.fillRect(6, 4, 3, 2);
    });

    this._registerTile('blue_orchid', (ctx) => {
      ctx.clearRect(0, 0, 16, 16);
      ctx.fillStyle = '#337a24';
      ctx.fillRect(7, 7, 2, 9);
      ctx.fillStyle = '#2ea3f2';
      ctx.fillRect(4, 3, 8, 4);
      ctx.fillRect(6, 2, 4, 6);
      ctx.fillStyle = '#9be0ff';
      ctx.fillRect(6, 3, 3, 2);
    });

    this._registerTile('glow_shroom', (ctx) => {
      ctx.clearRect(0, 0, 16, 16);
      ctx.fillStyle = '#b9ded6';
      ctx.fillRect(7, 9, 2, 7);
      ctx.fillStyle = '#1fb59c';
      ctx.fillRect(4, 5, 8, 4);
      ctx.fillRect(5, 4, 6, 5);
      ctx.fillStyle = '#8affeb';
      ctx.fillRect(6, 5, 2, 2);
      ctx.fillRect(9, 6, 2, 1);
    });

    this._registerTile('dead_bush', (ctx) => {
      ctx.clearRect(0, 0, 16, 16);
      ctx.fillStyle = '#876238';
      ctx.fillRect(7, 9, 2, 7);
      ctx.fillRect(5, 7, 2, 3);
      ctx.fillRect(9, 6, 2, 4);
      ctx.fillRect(3, 5, 2, 2);
      ctx.fillRect(11, 4, 2, 2);
    });

    // Wool
    this._registerTile('wool', (ctx, rng) => {
      fillNoise(ctx, '#f0f1f5', 10, rng);
    });
  }

  _buildAllItemSprites() {
    const makeItem = (id, drawFn) => {
      const c = createTileCanvas();
      drawFn(c.getContext('2d'));
      this.itemCanvases.set(id, c);
    };

    makeItem(ITEM.STICK, (ctx) => drawPixelPattern(ctx, PATTERNS.stick, TOOL_PALETTES.wood));
    makeItem(ITEM.COAL, (ctx) => drawPixelPattern(ctx, PATTERNS.coal, { M: '#303338', H: '#545961', D: '#181a1d' }));
    makeItem(ITEM.RAW_IRON, (ctx) => drawPixelPattern(ctx, PATTERNS.coal, { M: '#cf9e7c', H: '#f5d2b8', D: '#8c5e42' }));
    makeItem(ITEM.IRON_INGOT, (ctx) => drawPixelPattern(ctx, PATTERNS.ingot, { M: '#d5dbe0', H: '#ffffff', D: '#8b949e' }));
    makeItem(ITEM.RAW_GOLD, (ctx) => drawPixelPattern(ctx, PATTERNS.coal, { M: '#f2c830', H: '#fff399', D: '#ab7e11' }));
    makeItem(ITEM.GOLD_INGOT, (ctx) => drawPixelPattern(ctx, PATTERNS.ingot, { M: '#f5cc33', H: '#fff7ad', D: '#b58412' }));
    makeItem(ITEM.DIAMOND, (ctx) => drawPixelPattern(ctx, PATTERNS.diamond, { M: '#3be6dc', H: '#bdfffa', D: '#19948f' }));
    makeItem(ITEM.BRICK_ITEM, (ctx) => drawPixelPattern(ctx, PATTERNS.ingot, { M: '#b85742', H: '#d67863', D: '#7d3425' }));

    const toolList = [
      [ITEM.WOOD_PICKAXE, 'pickaxe', 'wood'],
      [ITEM.WOOD_AXE, 'axe', 'wood'],
      [ITEM.WOOD_SHOVEL, 'shovel', 'wood'],
      [ITEM.WOOD_SWORD, 'sword', 'wood'],

      [ITEM.STONE_PICKAXE, 'pickaxe', 'stone'],
      [ITEM.STONE_AXE, 'axe', 'stone'],
      [ITEM.STONE_SHOVEL, 'shovel', 'stone'],
      [ITEM.STONE_SWORD, 'sword', 'stone'],

      [ITEM.IRON_PICKAXE, 'pickaxe', 'iron'],
      [ITEM.IRON_AXE, 'axe', 'iron'],
      [ITEM.IRON_SHOVEL, 'shovel', 'iron'],
      [ITEM.IRON_SWORD, 'sword', 'iron'],

      [ITEM.DIAMOND_PICKAXE, 'pickaxe', 'diamond'],
      [ITEM.DIAMOND_AXE, 'axe', 'diamond'],
      [ITEM.DIAMOND_SHOVEL, 'shovel', 'diamond'],
      [ITEM.DIAMOND_SWORD, 'sword', 'diamond'],
    ];

    for (const [id, kind, mat] of toolList) {
      makeItem(id, (ctx) => drawPixelPattern(ctx, PATTERNS[kind], TOOL_PALETTES[mat]));
    }

    makeItem(ITEM.APPLE, (ctx) => drawPixelPattern(ctx, PATTERNS.apple, {
      M: '#de2b21', H: '#ff7b73', D: '#991811', s: '#6e4a26', G: '#49a82c'
    }));
    makeItem(ITEM.RAW_MEAT, (ctx) => drawPixelPattern(ctx, PATTERNS.meat, {
      M: '#db5c5c', H: '#f79999', D: '#9c3333', B: '#f0e6d8', W: '#ffffff'
    }));
    makeItem(ITEM.COOKED_MEAT, (ctx) => drawPixelPattern(ctx, PATTERNS.meat, {
      M: '#8f4d28', H: '#ba7145', D: '#572b13', B: '#e3d5c1', W: '#f7efe4'
    }));
  }

  getSpriteCanvas(id) {
    if (this.itemCanvases.has(id)) return this.itemCanvases.get(id);
    const b = BLOCK_DEFS[id];
    if (b) {
      const f = b.faces;
      const key = f?.front || f?.side || f?.all || f?.top || 'stone';
      return this.tileMap.get(key)?.canvas || null;
    }
    return null;
  }

  getIconDataURL(id) {
    if (!id) return '';
    if (this.iconCache.has(id)) return this.iconCache.get(id);

    const out = document.createElement('canvas');
    out.width = 48;
    out.height = 48;
    const ctx = out.getContext('2d');
    ctx.imageSmoothingEnabled = false;

    if (isBlockId(id)) {
      const def = BLOCK_DEFS[id];
      if (def.render === 'cross' || def.render === 'torch') {
        const sprite = this.getSpriteCanvas(id);
        if (sprite) ctx.drawImage(sprite, 4, 4, 40, 40);
      } else {
        // Render crisp isometric 3D block icon
        const topName = def.faces.top || def.faces.all;
        const leftName = def.faces.front || def.faces.side || def.faces.all;
        const rightName = def.faces.side || def.faces.all;

        const topC = this.tileMap.get(topName)?.canvas;
        const leftC = this.tileMap.get(leftName)?.canvas;
        const rightC = this.tileMap.get(rightName)?.canvas;

        // Top diamond
        if (topC) {
          ctx.save();
          ctx.translate(24, 6);
          ctx.transform(1.15, 0.58, -1.15, 0.58, 0, 0);
          ctx.drawImage(topC, 0, 0, 16, 16);
          ctx.restore();
        }
        // Left face
        if (leftC) {
          ctx.save();
          ctx.translate(5.6, 15.2);
          ctx.transform(1.15, 0.58, 0, 1.22, 0, 0);
          ctx.drawImage(leftC, 0, 0, 16, 16);
          ctx.fillStyle = 'rgba(0,0,0,0.16)';
          ctx.fillRect(0, 0, 16, 16);
          ctx.restore();
        }
        // Right face
        if (rightC) {
          ctx.save();
          ctx.translate(24, 24.5);
          ctx.transform(1.15, -0.58, 0, 1.22, 0, 0);
          ctx.drawImage(rightC, 0, 0, 16, 16);
          ctx.fillStyle = 'rgba(0,0,0,0.33)';
          ctx.fillRect(0, 0, 16, 16);
          ctx.restore();
        }
      }
    } else if (ITEM_DEFS[id]) {
      const sprite = this.itemCanvases.get(id);
      if (sprite) {
        ctx.save();
        ctx.shadowColor = 'rgba(0, 0, 0, 0.85)';
        ctx.shadowBlur = 2;
        ctx.shadowOffsetX = 1;
        ctx.shadowOffsetY = 1;
        ctx.drawImage(sprite, 4, 4, 40, 40);
        ctx.restore();
      }
    }

    const url = out.toDataURL();
    this.iconCache.set(id, url);
    return url;
  }
}
