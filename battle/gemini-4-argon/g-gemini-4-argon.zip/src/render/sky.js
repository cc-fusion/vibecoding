import * as THREE from 'three';
import { BIOME } from '../world/terrain.js';

export class SkyAtmosphere {
  constructor(scene) {
    this.scene = scene;

    // 0.0 = Dawn, 0.25 = Noon, 0.50 = Sunset, 0.75 = Midnight
    this.timeOfDay = 0.16; // Start in crisp morning sunlight
    this.dayNumber = 1;
    this.cycleDuration = 600; // 10 minutes per full day-night cycle
    this.pausedTime = false;

    // Weather: 'clear' | 'rain'
    this.weather = 'clear';
    this.rainStrength = 0;
    this._weatherTimer = 190;

    // Entity lighting for Mobs, Drops, Held Hand
    this.hemiLight = new THREE.HemisphereLight(0xdff2ff, 0x6b604b, 0.85);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xfff8e6, 1.05);
    this.sunLight.position.set(40, 80, 30);
    this.scene.add(this.sunLight);

    // Sky Group (centered on camera every frame)
    this.skyGroup = new THREE.Group();
    this.scene.add(this.skyGroup);

    this._buildSkyDome();
    this._buildCelestialBodies();
    this._buildStars();
    this._buildClouds();
    this._buildWeatherParticles();

    // Output state consumed by chunk shaders
    this.currentSunIntensity = 1.0;
    this.currentSkyTint = new THREE.Color(1, 1, 1);
    this.currentFogColor = new THREE.Color(0x8bc8f8);
  }

  _buildSkyDome() {
    const geo = new THREE.SphereGeometry(280, 24, 16);
    this.skyUniforms = {
      uZenithColor: { value: new THREE.Color(0x3b86eb) },
      uHorizonColor: { value: new THREE.Color(0x9bd2ff) },
      uBottomColor: { value: new THREE.Color(0x6da8db) },
    };
    const mat = new THREE.ShaderMaterial({
      uniforms: this.skyUniforms,
      side: THREE.BackSide,
      depthWrite: false,
      vertexShader: `
        varying vec3 vWorldDir;
        void main() {
          vWorldDir = normalize(position);
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform vec3 uZenithColor;
        uniform vec3 uHorizonColor;
        uniform vec3 uBottomColor;
        varying vec3 vWorldDir;
        void main() {
          float h = vWorldDir.y;
          vec3 col;
          if (h >= 0.0) {
            col = mix(uHorizonColor, uZenithColor, pow(h, 0.58));
          } else {
            col = mix(uHorizonColor, uBottomColor, clamp(-h * 3.0, 0.0, 1.0));
          }
          gl_FragColor = vec4(col, 1.0);
          #include <colorspace_fragment>
        }
      `,
    });
    this.skyDome = new THREE.Mesh(geo, mat);
    this.skyDome.renderOrder = -10;
    this.skyGroup.add(this.skyDome);
  }

  _buildCelestialBodies() {
    this.orbitPivot = new THREE.Group();
    this.skyGroup.add(this.orbitPivot);

    // Sun + warm glow halo
    const sunCoreGeo = new THREE.PlaneGeometry(24, 24);
    const sunCoreMat = new THREE.MeshBasicMaterial({
      color: 0xfff5b8,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    this.sunMesh = new THREE.Mesh(sunCoreGeo, sunCoreMat);
    this.sunMesh.position.set(0, 220, 0);
    this.sunMesh.rotation.x = Math.PI / 2;

    const sunHaloGeo = new THREE.PlaneGeometry(46, 46);
    const sunHaloMat = new THREE.MeshBasicMaterial({
      color: 0xffb84d,
      transparent: true,
      opacity: 0.32,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    const halo = new THREE.Mesh(sunHaloGeo, sunHaloMat);
    halo.position.z = -0.2;
    this.sunMesh.add(halo);
    this.orbitPivot.add(this.sunMesh);

    // Moon with pixel crater texture
    const mc = document.createElement('canvas');
    mc.width = 8;
    mc.height = 8;
    const mctx = mc.getContext('2d');
    mctx.fillStyle = '#e8f0ff';
    mctx.fillRect(0, 0, 8, 8);
    mctx.fillStyle = '#bac8e3';
    mctx.fillRect(1, 2, 2, 2);
    mctx.fillRect(5, 1, 2, 1);
    mctx.fillRect(4, 5, 2, 2);
    const moonTex = new THREE.CanvasTexture(mc);
    moonTex.magFilter = THREE.NearestFilter;
    moonTex.colorSpace = THREE.SRGBColorSpace;

    const moonGeo = new THREE.PlaneGeometry(20, 20);
    const moonMat = new THREE.MeshBasicMaterial({
      map: moonTex,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    this.moonMesh = new THREE.Mesh(moonGeo, moonMat);
    this.moonMesh.position.set(0, -220, 0);
    this.moonMesh.rotation.x = -Math.PI / 2;
    this.orbitPivot.add(this.moonMesh);
  }

  _buildStars() {
    const count = 420;
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 0.88 + 0.08); // Upper hemisphere
      const r = 245;
      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = r * Math.cos(phi);
      positions[i * 3 + 2] = r * Math.sin(phi) * Math.sin(theta);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    this.starMat = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 2.0,
      sizeAttenuation: false,
      transparent: true,
      opacity: 0,
      depthWrite: false,
    });
    this.stars = new THREE.Points(geo, this.starMat);
    this.skyGroup.add(this.stars);
  }

  _buildClouds() {
    this.cloudGroup = new THREE.Group();
    this.scene.add(this.cloudGroup);

    const puffs = [];
    for (let i = 0; i < 36; i++) {
      const cx = (Math.random() - 0.5) * 320;
      const cz = (Math.random() - 0.5) * 320;
      const parts = 2 + Math.floor(Math.random() * 3);
      for (let p = 0; p < parts; p++) {
        puffs.push({
          x: cx + (p - 1) * 10,
          y: 86 + (p % 2) * 1.2,
          z: cz + ((p * 7) % 9 - 4),
          sx: 12 + Math.random() * 14,
          sz: 10 + Math.random() * 12,
        });
      }
    }

    const box = new THREE.BoxGeometry(1, 2.6, 1);
    // Bake soft 3D face shading into cloud box vertices so undersides stay bright & fluffy
    const normAttr = box.getAttribute('normal');
    const cloudCols = new Float32Array(normAttr.count * 3);
    for (let i = 0; i < normAttr.count; i++) {
      const ny = normAttr.getY(i);
      const shade = ny > 0.5 ? 1.0 : ny < -0.5 ? 0.84 : 0.92;
      cloudCols[i * 3] = shade;
      cloudCols[i * 3 + 1] = shade;
      cloudCols[i * 3 + 2] = shade;
    }
    box.setAttribute('color', new THREE.BufferAttribute(cloudCols, 3));
    this.cloudMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      vertexColors: true,
      transparent: true,
      opacity: 0.86,
      depthWrite: false,
    });
    this.cloudInstanced = new THREE.InstancedMesh(box, this.cloudMat, puffs.length);
    this.cloudInstanced.frustumCulled = false;
    this.cloudData = puffs;

    const dummy = new THREE.Object3D();
    puffs.forEach((pf, idx) => {
      dummy.position.set(pf.x, pf.y, pf.z);
      dummy.scale.set(pf.sx, 1, pf.sz);
      dummy.updateMatrix();
      this.cloudInstanced.setMatrixAt(idx, dummy.matrix);
    });
    this.cloudGroup.add(this.cloudInstanced);
    this._cloudOffset = 0;
  }

  _buildWeatherParticles() {
    const count = 900;
    this.weatherCount = count;
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 44;
      positions[i * 3 + 1] = Math.random() * 32;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 44;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    this.weatherMat = new THREE.PointsMaterial({
      color: 0xa8d4ff,
      size: 0.22,
      transparent: true,
      opacity: 0,
      depthWrite: false,
    });
    this.weatherPoints = new THREE.Points(geo, this.weatherMat);
    this.weatherPoints.visible = false;
    this.scene.add(this.weatherPoints);
  }

  isNight() {
    return this.timeOfDay > 0.53 && this.timeOfDay < 0.97;
  }

  getTimeLabel() {
    const t = this.timeOfDay;
    if (t < 0.08 || t >= 0.95) return 'Dawn';
    if (t < 0.43) return 'Day';
    if (t < 0.55) return 'Sunset';
    return 'Night';
  }

  update(dt, cameraPos, renderDistanceChunks, underwater = false, currentBiome = BIOME.PLAINS) {
    if (!this.pausedTime) {
      this.timeOfDay += dt / this.cycleDuration;
      if (this.timeOfDay >= 1.0) {
        this.timeOfDay -= 1.0;
        this.dayNumber++;
      }
    }

    // Gentle natural weather cycle
    this._weatherTimer -= dt;
    if (this._weatherTimer <= 0) {
      if (this.weather === 'clear') {
        this.weather = Math.random() < 0.30 ? 'rain' : 'clear';
        this._weatherTimer = this.weather === 'rain' ? 75 + Math.random() * 55 : 160 + Math.random() * 120;
      } else {
        this.weather = 'clear';
        this._weatherTimer = 180 + Math.random() * 140;
      }
    }

    const targetRain = this.weather === 'rain' ? 1 : 0;
    this.rainStrength += (targetRain - this.rainStrength) * Math.min(1, dt * 0.6);

    // Sun angle: timeOfDay = 0 -> horizon rising, 0.25 -> overhead noon, 0.5 -> setting, 0.75 -> nadir
    const angle = this.timeOfDay * Math.PI * 2;
    const sunElev = Math.sin(angle); // [-1..1], +1 at noon, -1 at midnight

    this.skyGroup.position.copy(cameraPos);
    this.orbitPivot.rotation.z = angle - Math.PI / 2;
    this.orbitPivot.rotation.x = 0.22; // Slight seasonal tilt

    // Smoothly compute sky colors from sun elevation
    const dayFactor = THREE.MathUtils.smoothstep(sunElev, -0.16, 0.28);
    const twilightFactor = Math.max(0, 1.0 - Math.abs(sunElev - 0.02) * 4.2);

    const dayZenith = new THREE.Color(0x2d7ef0);
    const dayHorizon = new THREE.Color(0x9bd4ff);
    const nightZenith = new THREE.Color(0x060b1c);
    const nightHorizon = new THREE.Color(0x121d38);
    const sunsetHorizon = new THREE.Color(0xf27b44);
    const sunsetZenith = new THREE.Color(0x47468a);

    const zenith = nightZenith.clone().lerp(dayZenith, dayFactor).lerp(sunsetZenith, twilightFactor * 0.55);
    const horizon = nightHorizon.clone().lerp(dayHorizon, dayFactor).lerp(sunsetHorizon, twilightFactor * 0.82);

    if (this.rainStrength > 0.01) {
      const stormCol = new THREE.Color(0x526173).multiplyScalar(0.3 + 0.7 * dayFactor);
      zenith.lerp(stormCol, this.rainStrength * 0.65);
      horizon.lerp(stormCol, this.rainStrength * 0.65);
    }

    if (underwater) {
      const waterCol = new THREE.Color(0x0d3d73).multiplyScalar(0.35 + 0.65 * dayFactor);
      this.skyUniforms.uZenithColor.value.copy(waterCol);
      this.skyUniforms.uHorizonColor.value.copy(waterCol);
      this.skyUniforms.uBottomColor.value.copy(waterCol);
      this.currentFogColor.copy(waterCol);
    } else {
      this.skyUniforms.uZenithColor.value.copy(zenith);
      this.skyUniforms.uHorizonColor.value.copy(horizon);
      this.skyUniforms.uBottomColor.value.copy(horizon).multiplyScalar(0.72);
      this.currentFogColor.copy(horizon);
    }

    // Star opacity at night
    this.starMat.opacity = Math.max(0, (1 - dayFactor * 1.25) * (1 - this.rainStrength * 0.85));

    // Chunk sun intensity & sky tint
    const baseSun = 0.14 + 0.86 * dayFactor;
    this.currentSunIntensity = baseSun * (1 - this.rainStrength * 0.28);

    const noonTint = new THREE.Color(1.0, 0.99, 0.96);
    const nightTint = new THREE.Color(0.58, 0.70, 0.98);
    const sunsetTint = new THREE.Color(1.06, 0.80, 0.62);
    this.currentSkyTint.copy(nightTint).lerp(noonTint, dayFactor).lerp(sunsetTint, twilightFactor * 0.65);

    // Update Three.js lights for Mobs, Drops, Clouds, and Held Item
    this.sunLight.intensity = Math.max(0.12, dayFactor * 1.05 * (1 - this.rainStrength * 0.35));
    this.sunLight.color.copy(this.currentSkyTint);
    this.sunLight.position.set(
      cameraPos.x + Math.cos(angle) * 80,
      cameraPos.y + Math.max(18, Math.abs(sunElev) * 90),
      cameraPos.z + 35
    );
    this.hemiLight.intensity = 0.25 + 0.62 * dayFactor;
    this.hemiLight.color.copy(horizon).lerp(new THREE.Color(0xffffff), 0.45);

    // Drift 3D clouds relative to player
    this._cloudOffset += dt * 1.4;
    const dummy = new THREE.Object3D();
    for (let i = 0; i < this.cloudData.length; i++) {
      const pf = this.cloudData[i];
      let wx = pf.x + this._cloudOffset;
      // Wrap clouds in a 320x320 box centered on player
      wx = cameraPos.x + ((((wx - cameraPos.x) % 320) + 480) % 320 - 160);
      const wz = cameraPos.z + ((((pf.z - cameraPos.z) % 320) + 480) % 320 - 160);
      dummy.position.set(wx, pf.y, wz);
      dummy.scale.set(pf.sx, 1, pf.sz);
      dummy.updateMatrix();
      this.cloudInstanced.setMatrixAt(i, dummy.matrix);
    }
    this.cloudInstanced.instanceMatrix.needsUpdate = true;
    this.cloudMat.color.copy(this.currentSkyTint).multiplyScalar(0.32 + 0.68 * dayFactor);

    // Update Rain / Snow particles around player
    if (this.rainStrength > 0.02 && !underwater) {
      this.weatherPoints.visible = true;
      const isSnow = currentBiome === BIOME.TAIGA || (currentBiome === BIOME.MOUNTAINS && cameraPos.y > 50);
      this.weatherMat.color.setHex(isSnow ? 0xf5fbff : 0x9ecbff);
      this.weatherMat.size = isSnow ? 0.28 : 0.19;
      this.weatherMat.opacity = this.rainStrength * (isSnow ? 0.85 : 0.62);

      const fallSpeed = isSnow ? 5.5 : 24.0;
      const posAttr = this.weatherPoints.geometry.getAttribute('position');
      const arr = posAttr.array;
      for (let i = 0; i < this.weatherCount; i++) {
        arr[i * 3 + 1] -= fallSpeed * dt;
        if (isSnow) {
          arr[i * 3] += Math.sin(this._cloudOffset * 2 + i) * dt * 1.2;
        }
        if (arr[i * 3 + 1] < -10) {
          arr[i * 3] = (Math.random() - 0.5) * 44;
          arr[i * 3 + 1] = 22 + Math.random() * 8;
          arr[i * 3 + 2] = (Math.random() - 0.5) * 44;
        }
      }
      posAttr.needsUpdate = true;
      this.weatherPoints.position.set(cameraPos.x, cameraPos.y, cameraPos.z);
    } else {
      this.weatherPoints.visible = false;
    }

    const maxDist = renderDistanceChunks * 16;
    return {
      sunIntensity: this.currentSunIntensity,
      skyTint: this.currentSkyTint,
      fogColor: this.currentFogColor,
      fogNear: underwater ? 2.0 : maxDist * 0.52,
      fogFar: underwater ? 22.0 : maxDist * 0.96,
      underwater,
    };
  }
}
