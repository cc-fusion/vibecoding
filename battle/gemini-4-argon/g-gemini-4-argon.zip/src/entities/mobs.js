import * as THREE from 'three';
import { BLOCK, BLOCK_DEFS, ITEM } from '../world/blocks.js';
import { SEA_LEVEL } from '../world/terrain.js';

function makeBox(w, h, d, colorHex, offsetY = 0) {
  const geo = new THREE.BoxGeometry(w, h, d);
  if (offsetY !== 0) geo.translate(0, offsetY, 0);
  const mat = new THREE.MeshLambertMaterial({ color: colorHex });
  return new THREE.Mesh(geo, mat);
}

export class MobManager {
  constructor(scene) {
    this.scene = scene;
    this.mobs = [];
    this.group = new THREE.Group();
    this.scene.add(this.group);
    this._spawnTimer = 2.0;
  }

  _createQuadrupedMesh(type) {
    const root = new THREE.Group();
    const mats = [];
    const track = (m) => { mats.push(m.material); return m; };

    let bodyCol = 0xf2f2f5;
    let headCol = 0xc5beb8;
    let legCol = 0xb8b0aa;
    let bodyH = 0.62, bodyW = 0.68, bodyL = 0.96, legH = 0.48;

    if (type === 'pig') {
      bodyCol = 0xf29eb0;
      headCol = 0xf5a8b8;
      legCol = 0xe0899b;
      bodyH = 0.54; bodyW = 0.60; bodyL = 0.88; legH = 0.36;
    } else if (type === 'cow') {
      bodyCol = 0x5c3c28;
      headCol = 0x6b4730;
      legCol = 0x4d3120;
      bodyH = 0.68; bodyW = 0.68; bodyL = 1.04; legH = 0.54;
    }

    const body = track(makeBox(bodyW, bodyH, bodyL, bodyCol));
    body.position.set(0, legH + bodyH * 0.5, 0);
    root.add(body);

    if (type === 'cow') {
      const patch = track(makeBox(bodyW + 0.02, 0.34, 0.42, 0xeae5dc));
      patch.position.set(0, legH + bodyH * 0.55, 0.08);
      root.add(patch);
    }

    const headPivot = new THREE.Group();
    headPivot.position.set(0, legH + bodyH * 0.72, bodyL * 0.52);
    const head = track(makeBox(0.46, 0.44, 0.46, headCol, 0));
    head.position.set(0, 0, 0.14);
    headPivot.add(head);

    // Eyes
    const eyeL = track(makeBox(0.08, 0.08, 0.05, 0x1c1c1e));
    const eyeR = track(makeBox(0.08, 0.08, 0.05, 0x1c1c1e));
    eyeL.position.set(-0.14, 0.05, 0.38);
    eyeR.position.set(0.14, 0.05, 0.38);
    headPivot.add(eyeL, eyeR);

    if (type === 'pig') {
      const snout = track(makeBox(0.24, 0.16, 0.12, 0xe07e93));
      snout.position.set(0, -0.06, 0.41);
      headPivot.add(snout);
    } else if (type === 'cow') {
      const hornL = track(makeBox(0.07, 0.16, 0.07, 0xdcd7c9));
      const hornR = track(makeBox(0.07, 0.16, 0.07, 0xdcd7c9));
      hornL.position.set(-0.24, 0.24, 0.12);
      hornR.position.set(0.24, 0.24, 0.12);
      headPivot.add(hornL, hornR);
    } else if (type === 'sheep') {
      const woolCap = track(makeBox(0.50, 0.20, 0.44, 0xf4f4f7));
      woolCap.position.set(0, 0.18, 0.10);
      headPivot.add(woolCap);
    }

    root.add(headPivot);

    const lx = bodyW * 0.33;
    const lz = bodyL * 0.34;
    const legs = [];
    for (const [px, pz] of [[-lx, lz], [lx, lz], [-lx, -lz], [lx, -lz]]) {
      const leg = track(makeBox(0.19, legH, 0.19, legCol, -legH * 0.5));
      leg.position.set(px, legH, pz);
      root.add(leg);
      legs.push(leg);
    }

    return { root, headPivot, legs, mats, height: legH + bodyH + 0.25, radius: 0.42 };
  }

  _createZombieMesh() {
    const root = new THREE.Group();
    const mats = [];
    const track = (m) => { mats.push(m.material); return m; };

    const legL = track(makeBox(0.22, 0.68, 0.22, 0x37407a, -0.34));
    const legR = track(makeBox(0.22, 0.68, 0.22, 0x37407a, -0.34));
    legL.position.set(-0.12, 0.68, 0);
    legR.position.set(0.12, 0.68, 0);

    const torso = track(makeBox(0.48, 0.68, 0.26, 0x26858c));
    torso.position.set(0, 1.02, 0);

    const headPivot = new THREE.Group();
    headPivot.position.set(0, 1.36, 0);
    const head = track(makeBox(0.46, 0.46, 0.46, 0x5c8c46, 0.23));
    const eyeL = track(makeBox(0.09, 0.07, 0.05, 0x141a12));
    const eyeR = track(makeBox(0.09, 0.07, 0.05, 0x141a12));
    eyeL.position.set(-0.11, 0.25, 0.24);
    eyeR.position.set(0.11, 0.25, 0.24);
    headPivot.add(head, eyeL, eyeR);

    // Outstretched zombie arms
    const armL = track(makeBox(0.20, 0.64, 0.20, 0x5c8c46, -0.28));
    const armR = track(makeBox(0.20, 0.64, 0.20, 0x5c8c46, -0.28));
    armL.position.set(-0.35, 1.30, 0);
    armR.position.set(0.35, 1.30, 0);
    armL.rotation.x = -Math.PI * 0.44;
    armR.rotation.x = -Math.PI * 0.44;

    root.add(legL, legR, torso, headPivot, armL, armR);
    return { root, headPivot, legs: [legL, legR], arms: [armL, armR], mats, height: 1.82, radius: 0.36 };
  }

  _createSlimeMesh() {
    const root = new THREE.Group();
    const outerGeo = new THREE.BoxGeometry(0.76, 0.76, 0.76);
    outerGeo.translate(0, 0.38, 0);
    const outerMat = new THREE.MeshLambertMaterial({
      color: 0x55d64b,
      transparent: true,
      opacity: 0.74,
    });
    const outer = new THREE.Mesh(outerGeo, outerMat);

    const innerGeo = new THREE.BoxGeometry(0.44, 0.44, 0.44);
    innerGeo.translate(0, 0.38, 0);
    const innerMat = new THREE.MeshLambertMaterial({ color: 0x2d8f28 });
    const inner = new THREE.Mesh(innerGeo, innerMat);

    const eyeL = makeBox(0.11, 0.11, 0.06, 0x163814);
    const eyeR = makeBox(0.11, 0.11, 0.06, 0x163814);
    eyeL.position.set(-0.15, 0.46, 0.36);
    eyeR.position.set(0.15, 0.46, 0.36);

    root.add(inner, outer, eyeL, eyeR);
    return { root, headPivot: null, legs: [], mats: [outerMat, innerMat], height: 0.80, radius: 0.38 };
  }

  spawnMob(type, x, y, z) {
    let rig;
    let maxHp = 10;
    let hostile = false;
    let speed = 1.65;

    if (type === 'zombie') {
      rig = this._createZombieMesh();
      maxHp = 16;
      hostile = true;
      speed = 2.45;
    } else if (type === 'slime') {
      rig = this._createSlimeMesh();
      maxHp = 10;
      hostile = true;
      speed = 2.1;
    } else {
      rig = this._createQuadrupedMesh(type);
      maxHp = type === 'cow' ? 12 : 8;
      speed = 1.45;
    }

    rig.root.position.set(x, y, z);
    this.group.add(rig.root);

    const mob = {
      type,
      hostile,
      rig,
      x,
      y,
      z,
      vx: 0,
      vy: 0,
      vz: 0,
      yaw: Math.random() * Math.PI * 2,
      targetYaw: Math.random() * Math.PI * 2,
      hp: maxHp,
      maxHp,
      speed,
      baseSpeed: speed,
      state: 'idle',
      aiTimer: 1 + Math.random() * 3,
      panicTimer: 0,
      hurtFlash: 0,
      attackCooldown: 0,
      walkPhase: Math.random() * 10,
      onGround: false,
      burnTimer: 0,
    };
    this.mobs.push(mob);
    return mob;
  }

  populateInitialAround(world, px, pz) {
    const types = ['sheep', 'pig', 'cow', 'sheep'];
    let spawned = 0;
    for (let attempt = 0; attempt < 28 && spawned < 7; attempt++) {
      const angle = (attempt / 28) * Math.PI * 2 + Math.random() * 0.4;
      const dist = 10 + Math.random() * 24;
      const wx = Math.floor(px + Math.cos(angle) * dist);
      const wz = Math.floor(pz + Math.sin(angle) * dist);
      const sy = world.getSurfaceHeight(wx, wz);
      const ground = world.getBlock(wx, sy, wz);
      if (sy > SEA_LEVEL && (ground === BLOCK.GRASS || ground === BLOCK.SNOW_GRASS)) {
        this.spawnMob(types[spawned % types.length], wx + 0.5, sy + 1.02, wz + 0.5);
        spawned++;
      }
    }
  }

  raycastMob(origin, dir, maxDist = 4.6) {
    let closest = null;
    let bestT = maxDist;

    for (const mob of this.mobs) {
      // Intersect ray with mob AABB
      const r = mob.rig.radius + 0.1;
      const minX = mob.x - r, maxX = mob.x + r;
      const minY = mob.y, maxY = mob.y + mob.rig.height;
      const minZ = mob.z - r, maxZ = mob.z + r;

      let tmin = -Infinity;
      let tmax = Infinity;

      const axes = [
        [origin.x, dir.x, minX, maxX],
        [origin.y, dir.y, minY, maxY],
        [origin.z, dir.z, minZ, maxZ],
      ];

      let hit = true;
      for (const [o, d, mn, mx] of axes) {
        if (Math.abs(d) < 1e-7) {
          if (o < mn || o > mx) { hit = false; break; }
        } else {
          let t1 = (mn - o) / d;
          let t2 = (mx - o) / d;
          if (t1 > t2) { const tmp = t1; t1 = t2; t2 = tmp; }
          tmin = Math.max(tmin, t1);
          tmax = Math.min(tmax, t2);
          if (tmin > tmax) { hit = false; break; }
        }
      }

      if (hit && tmax >= 0 && tmin <= bestT) {
        const hitDist = Math.max(0, tmin);
        if (hitDist <= bestT) {
          bestT = hitDist;
          closest = { mob, distance: hitDist };
        }
      }
    }

    return closest;
  }

  damageMob(mob, amount, knockDirX, knockDirZ, drops, particles, sound) {
    mob.hp -= amount;
    mob.hurtFlash = 0.25;
    const len = Math.hypot(knockDirX, knockDirZ) || 1;
    mob.vx = (knockDirX / len) * 6.2;
    mob.vz = (knockDirZ / len) * 6.2;
    mob.vy = 4.2;

    if (!mob.hostile) {
      mob.panicTimer = 4.0;
      mob.targetYaw = Math.atan2(mob.vx, mob.vz);
    }

    sound?.playHitMob();
    particles?.spawnBurst(mob.x, mob.y + mob.rig.height * 0.5, mob.z, '#e84848', 12, 3.2, 0.11);

    if (mob.hp <= 0) {
      this._killMob(mob, drops, particles);
      return true;
    }
    return false;
  }

  _killMob(mob, drops, particles) {
    particles?.spawnBurst(mob.x, mob.y + 0.5, mob.z, '#f0f0f0', 22, 3.5, 0.15);
    if (drops) {
      if (mob.type === 'sheep') {
        drops.spawn(mob.x, mob.y + 0.4, mob.z, BLOCK.WOOL, 1);
        drops.spawn(mob.x + 0.1, mob.y + 0.4, mob.z, ITEM.RAW_MEAT, 1 + (Math.random() < 0.5 ? 1 : 0));
      } else if (mob.type === 'pig' || mob.type === 'cow') {
        drops.spawn(mob.x, mob.y + 0.4, mob.z, ITEM.RAW_MEAT, 1 + Math.floor(Math.random() * 2));
      } else if (mob.type === 'zombie') {
        const loot = Math.random() < 0.35 ? ITEM.RAW_IRON : ITEM.COAL;
        drops.spawn(mob.x, mob.y + 0.4, mob.z, loot, 1);
      } else if (mob.type === 'slime') {
        drops.spawn(mob.x, mob.y + 0.4, mob.z, BLOCK.GLOW_SHROOM, 1);
      }
    }
    this._removeMob(mob);
  }

  _removeMob(mob) {
    const idx = this.mobs.indexOf(mob);
    if (idx !== -1) this.mobs.splice(idx, 1);
    this.group.remove(mob.rig.root);
    mob.rig.root.traverse((obj) => {
      if (obj.geometry) obj.geometry.dispose();
    });
    for (const m of mob.rig.mats) m.dispose();
  }

  intersectsAnyMob(minX, minY, minZ, maxX, maxY, maxZ) {
    for (const m of this.mobs) {
      const r = m.rig.radius;
      if (
        maxX > m.x - r && minX < m.x + r &&
        maxY > m.y && minY < m.y + m.rig.height &&
        maxZ > m.z - r && minZ < m.z + r
      ) {
        return true;
      }
    }
    return false;
  }

  update(dt, world, player, sky, drops, particles, sound) {
    const px = player.position.x;
    const py = player.position.y;
    const pz = player.position.z;
    const isNight = sky.isNight();
    const survival = player.mode === 'survival';

    // Periodic ambient spawning & distant despawning
    this._spawnTimer -= dt;
    if (this._spawnTimer <= 0) {
      this._spawnTimer = 4.5;
      if (this.mobs.length < 18) {
        const angle = Math.random() * Math.PI * 2;
        const dist = 18 + Math.random() * 22;
        const wx = Math.floor(px + Math.cos(angle) * dist);
        const wz = Math.floor(pz + Math.sin(angle) * dist);
        const sy = world.getSurfaceHeight(wx, wz);
        const ground = world.getBlock(wx, sy, wz);

        if (sy > SEA_LEVEL) {
          const blockL = world.getBlockLight(wx, sy + 1, wz);
          if (isNight && survival && blockL < 6 && Math.random() < 0.55) {
            const hType = Math.random() < 0.72 ? 'zombie' : 'slime';
            this.spawnMob(hType, wx + 0.5, sy + 1.05, wz + 0.5);
          } else if (!isNight && (ground === BLOCK.GRASS || ground === BLOCK.SNOW_GRASS)) {
            const pTypes = ['sheep', 'pig', 'cow'];
            this.spawnMob(pTypes[Math.floor(Math.random() * pTypes.length)], wx + 0.5, sy + 1.05, wz + 0.5);
          }
        }
      }
    }

    for (let i = this.mobs.length - 1; i >= 0; i--) {
      const m = this.mobs[i];
      const dxP = px - m.x;
      const dyP = py - m.y;
      const dzP = pz - m.z;
      const distP = Math.hypot(dxP, dyP, dzP);

      // Despawn far mobs
      if (distP > 78 || m.y < -10) {
        this._removeMob(m);
        continue;
      }

      // Zombies burn in bright morning sunlight unless standing under shade or water!
      if (m.type === 'zombie' && !isNight) {
        const skyL = world.getSkyLight(Math.floor(m.x), Math.floor(m.y + 1), Math.floor(m.z));
        const inWater = world.getBlock(Math.floor(m.x), Math.floor(m.y + 0.5), Math.floor(m.z)) === BLOCK.WATER;
        if (skyL >= 13 && !inWater && sky.rainStrength < 0.4) {
          m.burnTimer += dt;
          if (m.burnTimer >= 1.1) {
            m.burnTimer = 0;
            particles?.spawnBurst(m.x, m.y + 1.1, m.z, '#ff8822', 6, 1.5, 0.10);
            if (this.damageMob(m, 3, 0, 0, drops, particles, null)) continue;
          }
        }
      }

      if (m.hurtFlash > 0) {
        m.hurtFlash = Math.max(0, m.hurtFlash - dt);
        const emissiveHex = m.hurtFlash > 0 ? 0x992222 : 0x000000;
        for (const mat of m.rig.mats) mat.emissive.setHex(emissiveHex);
      }

      if (m.attackCooldown > 0) m.attackCooldown -= dt;

      // AI Decision Making
      let moveForward = 0;
      if (m.hostile && survival && distP < 18) {
        m.targetYaw = Math.atan2(dxP, dzP);
        moveForward = m.baseSpeed;
        if (m.type === 'slime' && m.onGround && Math.random() < dt * 2.4) {
          m.vy = 5.8;
        }
        // Contact melee attack
        if (distP < 1.15 && Math.abs(dyP) < 1.6 && m.attackCooldown <= 0) {
          m.attackCooldown = 1.15;
          player.takeDamage(m.type === 'zombie' ? 3 : 2, dxP, dzP);
        }
      } else if (m.panicTimer > 0) {
        m.panicTimer -= dt;
        moveForward = m.baseSpeed * 1.75;
        if (Math.random() < dt * 2.5) {
          m.targetYaw += (Math.random() - 0.5) * 1.6;
        }
      } else {
        m.aiTimer -= dt;
        if (m.aiTimer <= 0) {
          if (m.state === 'walk') {
            m.state = 'idle';
            m.aiTimer = 1.8 + Math.random() * 3.5;
          } else {
            m.state = 'walk';
            m.targetYaw = Math.random() * Math.PI * 2;
            m.aiTimer = 2.0 + Math.random() * 3.5;
          }
        }
        if (m.state === 'walk') moveForward = m.baseSpeed;
      }

      // Smooth yaw turn
      let diff = m.targetYaw - m.yaw;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      m.yaw += diff * Math.min(1, dt * 6.5);

      const desiredVx = Math.sin(m.yaw) * moveForward;
      const desiredVz = Math.cos(m.yaw) * moveForward;
      m.vx += (desiredVx - m.vx) * Math.min(1, dt * 7);
      m.vz += (desiredVz - m.vz) * Math.min(1, dt * 7);

      // Buoyancy in water or standard gravity
      const inWater = world.getBlock(Math.floor(m.x), Math.floor(m.y + 0.35), Math.floor(m.z)) === BLOCK.WATER;
      if (inWater) {
        m.vy = Math.min(2.6, m.vy + 14 * dt);
      } else {
        m.vy = Math.max(-24, m.vy - 22 * dt);
      }

      // Move & collide with voxel world + auto-jump 1-block ledges
      const r = m.rig.radius;
      const nextY = m.y + m.vy * dt;
      if (this._collides(world, m.x, nextY, m.z, r, m.rig.height)) {
        if (m.vy < 0) m.onGround = true;
        m.vy = 0;
      } else {
        m.y = nextY;
        m.onGround = false;
      }

      let blockedHoriz = false;
      const nextX = m.x + m.vx * dt;
      if (!this._collides(world, nextX, m.y, m.z, r, m.rig.height)) {
        m.x = nextX;
      } else {
        blockedHoriz = true;
        m.vx = 0;
      }

      const nextZ = m.z + m.vz * dt;
      if (!this._collides(world, m.x, m.y, nextZ, r, m.rig.height)) {
        m.z = nextZ;
      } else {
        blockedHoriz = true;
        m.vz = 0;
      }

      if (blockedHoriz && m.onGround && moveForward > 0.1) {
        m.vy = 6.9; // Hop up 1-block terrain steps!
        m.onGround = false;
      }

      // Animate legs & head
      const hSpeed = Math.hypot(m.vx, m.vz);
      if (hSpeed > 0.15) {
        m.walkPhase += dt * hSpeed * 4.2;
        const swing = Math.sin(m.walkPhase) * 0.62;
        if (m.rig.legs.length === 4) {
          m.rig.legs[0].rotation.x = swing;
          m.rig.legs[3].rotation.x = swing;
          m.rig.legs[1].rotation.x = -swing;
          m.rig.legs[2].rotation.x = -swing;
        } else if (m.rig.legs.length === 2) {
          m.rig.legs[0].rotation.x = swing;
          m.rig.legs[1].rotation.x = -swing;
        }
      } else {
        for (const leg of m.rig.legs) {
          leg.rotation.x *= 0.85;
        }
      }

      // Slime squash & stretch
      if (m.type === 'slime') {
        const stretch = m.onGround ? 0.92 : 1.16;
        const squash = 1 / Math.sqrt(stretch);
        m.rig.root.scale.set(squash, stretch, squash);
      }

      // Subtle look-at player when nearby
      if (m.rig.headPivot) {
        if (distP < 7 && !m.hostile) {
          const lookYaw = Math.atan2(dxP, dzP) - m.yaw;
          const clamped = Math.max(-0.55, Math.min(0.55, Math.sin(lookYaw)));
          m.rig.headPivot.rotation.y += (clamped - m.rig.headPivot.rotation.y) * dt * 5;
        } else {
          m.rig.headPivot.rotation.y *= 0.9;
        }
      }

      m.rig.root.position.set(m.x, m.y, m.z);
      m.rig.root.rotation.y = m.yaw;
    }
  }

  _collides(world, x, y, z, r, h) {
    const minX = Math.floor(x - r);
    const maxX = Math.floor(x + r);
    const minY = Math.floor(y + 0.02);
    const maxY = Math.floor(y + h - 0.02);
    const minZ = Math.floor(z - r);
    const maxZ = Math.floor(z + r);

    for (let by = minY; by <= maxY; by++) {
      for (let bz = minZ; bz <= maxZ; bz++) {
        for (let bx = minX; bx <= maxX; bx++) {
          if (BLOCK_DEFS[world.getBlock(bx, by, bz)]?.solid) return true;
        }
      }
    }
    return false;
  }

  dispose() {
    while (this.mobs.length > 0) {
      this._removeMob(this.mobs[0]);
    }
    this.scene.remove(this.group);
  }
}
