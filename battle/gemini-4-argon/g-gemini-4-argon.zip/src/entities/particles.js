import * as THREE from 'three';
import { BLOCK, BLOCK_DEFS } from '../world/blocks.js';

const MAX_PARTICLES = 450;

export class ParticleSystem {
  constructor(scene) {
    this.scene = scene;
    const geo = new THREE.BoxGeometry(1, 1, 1);
    const mat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    this.mesh = new THREE.InstancedMesh(geo, mat, MAX_PARTICLES);
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.mesh.frustumCulled = false;

    // Initialize instanceColor buffer
    const tmpCol = new THREE.Color(1, 1, 1);
    for (let i = 0; i < MAX_PARTICLES; i++) {
      this.mesh.setColorAt(i, tmpCol);
    }
    this.scene.add(this.mesh);

    this.particles = [];
    this._dummy = new THREE.Object3D();
    this._color = new THREE.Color();
    this._torchTimer = 0;
  }

  spawnBurst(x, y, z, baseHex = '#888888', count = 18, speed = 3.6, size = 0.13) {
    const base = new THREE.Color(baseHex);
    for (let i = 0; i < count; i++) {
      if (this.particles.length >= MAX_PARTICLES) {
        this.particles.shift();
      }
      const shade = 0.78 + Math.random() * 0.4;
      this.particles.push({
        x: x + (Math.random() - 0.5) * 0.65,
        y: y + (Math.random() - 0.5) * 0.65,
        z: z + (Math.random() - 0.5) * 0.65,
        vx: (Math.random() - 0.5) * speed * 2,
        vy: Math.random() * speed + 1.2,
        vz: (Math.random() - 0.5) * speed * 2,
        gravity: 16.0,
        size: size * (0.7 + Math.random() * 0.6),
        life: 0.42 + Math.random() * 0.45,
        maxLife: 0.85,
        r: Math.min(1, base.r * shade),
        g: Math.min(1, base.g * shade),
        b: Math.min(1, base.b * shade),
      });
    }
  }

  spawnBlockBreak(wx, wy, wz, blockId) {
    const def = BLOCK_DEFS[blockId];
    const hex = def?.particleColor || '#888888';
    this.spawnBurst(wx + 0.5, wy + 0.5, wz + 0.5, hex, 24, 3.8, 0.14);
  }

  spawnMineChip(wx, wy, wz, normal, blockId) {
    const def = BLOCK_DEFS[blockId];
    const hex = def?.particleColor || '#888888';
    const px = wx + 0.5 + normal[0] * 0.52;
    const py = wy + 0.5 + normal[1] * 0.52;
    const pz = wz + 0.5 + normal[2] * 0.52;
    this.spawnBurst(px, py, pz, hex, 4, 2.1, 0.09);
  }

  spawnExplosion(x, y, z) {
    this.spawnBurst(x, y, z, '#ff922b', 45, 9.5, 0.28);
    this.spawnBurst(x, y, z, '#f2f2f2', 45, 7.5, 0.34);
    this.spawnBurst(x, y, z, '#4a4a4a', 35, 6.0, 0.25);
  }

  spawnSplash(x, y, z) {
    this.spawnBurst(x, y, z, '#5eb3ff', 16, 3.2, 0.11);
  }

  spawnTorchEmber(wx, wy, wz) {
    if (this.particles.length >= MAX_PARTICLES) return;
    const smoke = Math.random() < 0.35;
    this.particles.push({
      x: wx + 0.5 + (Math.random() - 0.5) * 0.12,
      y: wy + 0.72,
      z: wz + 0.5 + (Math.random() - 0.5) * 0.12,
      vx: (Math.random() - 0.5) * 0.25,
      vy: 0.75 + Math.random() * 0.55,
      vz: (Math.random() - 0.5) * 0.25,
      gravity: -0.2,
      size: smoke ? 0.09 : 0.075,
      life: 0.5 + Math.random() * 0.35,
      maxLife: 0.85,
      r: smoke ? 0.38 : 1.0,
      g: smoke ? 0.38 : 0.75,
      b: smoke ? 0.40 : 0.22,
    });
  }

  update(dt, world, playerPos) {
    // Emit subtle cozy torch embers on nearby torches
    this._torchTimer += dt;
    if (this._torchTimer >= 0.14 && world && playerPos) {
      this._torchTimer = 0;
      const px = Math.floor(playerPos.x);
      const py = Math.floor(playerPos.y);
      const pz = Math.floor(playerPos.z);
      for (let i = 0; i < 6; i++) {
        const tx = px + Math.floor((Math.random() - 0.5) * 18);
        const ty = py + Math.floor((Math.random() - 0.5) * 10);
        const tz = pz + Math.floor((Math.random() - 0.5) * 18);
        if (world.getBlock(tx, ty, tz) === BLOCK.TORCH) {
          this.spawnTorchEmber(tx, ty, tz);
        }
      }
    }

    const dummy = this._dummy;
    const col = this._color;
    let activeCount = 0;

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.particles.splice(i, 1);
        continue;
      }

      p.vy -= p.gravity * dt;
      const nx = p.x + p.vx * dt;
      const ny = p.y + p.vy * dt;
      const nz = p.z + p.vz * dt;

      if (world && BLOCK_DEFS[world.getBlock(Math.floor(nx), Math.floor(ny), Math.floor(nz))]?.solid) {
        p.vy *= -0.28;
        p.vx *= 0.65;
        p.vz *= 0.65;
      } else {
        p.x = nx;
        p.y = ny;
        p.z = nz;
      }

      const scale = p.size * Math.min(1, p.life * 3.2);
      dummy.position.set(p.x, p.y, p.z);
      dummy.scale.setScalar(scale);
      dummy.updateMatrix();
      this.mesh.setMatrixAt(activeCount, dummy.matrix);

      col.setRGB(p.r, p.g, p.b);
      this.mesh.setColorAt(activeCount, col);
      activeCount++;
    }

    this.mesh.count = activeCount;
    this.mesh.instanceMatrix.needsUpdate = true;
    if (this.mesh.instanceColor) this.mesh.instanceColor.needsUpdate = true;
  }

  dispose() {
    this.scene.remove(this.mesh);
    this.mesh.geometry.dispose();
    this.mesh.material.dispose();
  }
}
