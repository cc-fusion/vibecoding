import * as THREE from 'three';
import { BLOCK_DEFS, isBlockId } from '../world/blocks.js';

export class DropManager {
  constructor(scene, textures) {
    this.scene = scene;
    this.textures = textures;
    this.drops = [];
    this.group = new THREE.Group();
    this.scene.add(this.group);

    this._cubeGeo = new THREE.BoxGeometry(0.32, 0.32, 0.32);
    this._flatGeo = new THREE.PlaneGeometry(0.42, 0.42);
    this._matCache = new Map();
  }

  _getMaterial(id) {
    if (this._matCache.has(id)) return this._matCache.get(id);
    const canvas = this.textures.getSpriteCanvas(id);
    let mat;
    if (canvas) {
      const tex = new THREE.CanvasTexture(canvas);
      tex.magFilter = THREE.NearestFilter;
      tex.minFilter = THREE.NearestFilter;
      tex.colorSpace = THREE.SRGBColorSpace;
      const isFlat = !isBlockId(id) || BLOCK_DEFS[id]?.render === 'cross' || BLOCK_DEFS[id]?.render === 'torch';
      mat = new THREE.MeshLambertMaterial({
        map: tex,
        alphaTest: isFlat ? 0.4 : 0,
        side: isFlat ? THREE.DoubleSide : THREE.FrontSide,
      });
    } else {
      mat = new THREE.MeshLambertMaterial({ color: 0xffffff });
    }
    this._matCache.set(id, mat);
    return mat;
  }

  spawn(x, y, z, id, count = 1, delay = 0.28) {
    if (!id || count <= 0) return;

    // Merge into nearby identical drop to keep scene super clean
    for (const d of this.drops) {
      if (d.id === id && d.count + count <= 64) {
        const distSq = (d.x - x) ** 2 + (d.y - y) ** 2 + (d.z - z) ** 2;
        if (distSq < 1.2) {
          d.count += count;
          return;
        }
      }
    }

    if (this.drops.length >= 120) {
      const oldest = this.drops.shift();
      this.group.remove(oldest.mesh);
    }

    const isFlat = !isBlockId(id) || BLOCK_DEFS[id]?.render === 'cross' || BLOCK_DEFS[id]?.render === 'torch';
    const mesh = new THREE.Mesh(isFlat ? this._flatGeo : this._cubeGeo, this._getMaterial(id));
    mesh.position.set(x, y, z);
    this.group.add(mesh);

    this.drops.push({
      id,
      count,
      mesh,
      x,
      y,
      z,
      vx: (Math.random() - 0.5) * 2.4,
      vy: 3.2 + Math.random() * 1.4,
      vz: (Math.random() - 0.5) * 2.4,
      age: 0,
      pickupDelay: delay,
      phase: Math.random() * Math.PI * 2,
    });
  }

  update(dt, world, player, sound) {
    const px = player.position.x;
    const py = player.position.y + 0.85;
    const pz = player.position.z;

    for (let i = this.drops.length - 1; i >= 0; i--) {
      const d = this.drops[i];
      d.age += dt;
      if (d.pickupDelay > 0) d.pickupDelay -= dt;

      if (d.age > 180) {
        this.group.remove(d.mesh);
        this.drops.splice(i, 1);
        continue;
      }

      // Gravity + ground rest
      d.vy = Math.max(-18, d.vy - 16 * dt);
      const nextY = d.y + d.vy * dt;
      if (BLOCK_DEFS[world.getBlock(Math.floor(d.x), Math.floor(nextY - 0.18), Math.floor(d.z))]?.solid) {
        d.y = Math.floor(nextY - 0.18) + 1.18;
        d.vy = 0;
        d.vx *= 0.78;
        d.vz *= 0.78;
      } else {
        d.y = nextY;
      }

      const nx = d.x + d.vx * dt;
      if (!BLOCK_DEFS[world.getBlock(Math.floor(nx), Math.floor(d.y), Math.floor(d.z))]?.solid) {
        d.x = nx;
      } else {
        d.vx = 0;
      }

      const nz = d.z + d.vz * dt;
      if (!BLOCK_DEFS[world.getBlock(Math.floor(d.x), Math.floor(d.y), Math.floor(nz))]?.solid) {
        d.z = nz;
      } else {
        d.vz = 0;
      }

      // Magnetic pull toward player when close
      if (d.pickupDelay <= 0) {
        const dx = px - d.x;
        const dy = py - d.y;
        const dz = pz - d.z;
        const dist = Math.hypot(dx, dy, dz);

        if (dist < 2.2) {
          const pull = (2.4 - dist) * 8.5 * dt;
          d.x += (dx / Math.max(0.1, dist)) * pull;
          d.y += (dy / Math.max(0.1, dist)) * pull;
          d.z += (dz / Math.max(0.1, dist)) * pull;

          if (dist < 0.75) {
            const remainder = player.addItem(d.id, d.count);
            if (remainder < d.count) {
              sound?.playPickup();
            }
            if (remainder <= 0) {
              this.group.remove(d.mesh);
              this.drops.splice(i, 1);
              continue;
            } else {
              d.count = remainder;
            }
          }
        }
      }

      d.mesh.rotation.y += dt * 2.1;
      const bob = Math.sin(d.age * 3.2 + d.phase) * 0.07;
      d.mesh.position.set(d.x, d.y + bob, d.z);
    }
  }

  dispose() {
    for (const mat of this._matCache.values()) {
      if (mat.map) mat.map.dispose();
      mat.dispose();
    }
    this._cubeGeo.dispose();
    this._flatGeo.dispose();
    this.scene.remove(this.group);
  }
}
