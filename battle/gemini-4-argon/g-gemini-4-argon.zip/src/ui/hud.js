import {
  BLOCK,
  BLOCK_DEFS,
  CRAFTING_RECIPES,
  CREATIVE_PALETTE,
  ITEM_DEFS,
  SMELTING_RECIPES,
  getDef,
  getMaxStack,
} from '../world/blocks.js';
import { MILESTONES } from '../player/player.js';
import { SaveManager } from '../storage/save.js';

const SCENIC_SEEDS = [
  'Emerald Valley',
  'Whispering Pines',
  'Crystal Caverns',
  'Sunlit Peaks',
  'Golden Oasis',
  'Frostfire Fjords',
  'Amber Highlands',
  'Misty Meadows',
];

export class GameUI {
  constructor(textures, sound, callbacks) {
    this.textures = textures;
    this.sound = sound;
    this.cb = callbacks; // { onStartWorld, onResume, onSave, onQuitToTitle, onSettingsChange }

    this.selectedNewMode = 'survival';
    this.activeCraftCategory = 'All';
    this.activeInvTab = 'craft';
    this.activeFurnacePos = null; // { x, y, z } when interacting with a furnace
    this.forceCraftingTable = false;

    // Held item on cursor while rearranging inventory
    this.cursorStack = null; // { id, count, durability }

    this._lastHeldSlot = -1;
    this._lastHeldId = -1;
    this._labelTimer = 0;

    this._cacheElements();
    this._bindMenuEvents();
    this._bindInventoryEvents();
    this._bindPauseEvents();
  }

  _cacheElements() {
    this.elTitleScreen = document.getElementById('title-screen');
    this.elHud = document.getElementById('hud');
    this.elInvModal = document.getElementById('inventory-modal');
    this.elPauseModal = document.getElementById('pause-modal');

    this.elUnderwater = document.getElementById('underwater-overlay');
    this.elDamage = document.getElementById('damage-overlay');

    this.elTimeIcon = document.getElementById('time-icon');
    this.elTimeLabel = document.getElementById('time-label');
    this.elBiomeLabel = document.getElementById('biome-label');
    this.elDebug = document.getElementById('debug-panel');
    this.elToasts = document.getElementById('toast-container');

    this.elMiningRing = document.getElementById('mining-ring');
    this.elMiningBar = document.getElementById('mining-ring-bar');
    this.elInteractHint = document.getElementById('interact-hint');

    this.elHeldName = document.getElementById('held-item-name');
    this.elFlightInd = document.getElementById('flight-indicator');
    this.elVitalsRow = document.getElementById('vitals-row');
    this.elHearts = document.getElementById('hearts-bar');
    this.elHunger = document.getElementById('hunger-bar');
    this.elOxygen = document.getElementById('oxygen-bar');
    this.elHotbar = document.getElementById('hotbar');

    // Title elements
    this.elTabWorlds = document.getElementById('tab-btn-worlds');
    this.elTabNew = document.getElementById('tab-btn-new');
    this.elPanelWorlds = document.getElementById('panel-worlds');
    this.elPanelNew = document.getElementById('panel-new-world');
    this.elWorldsList = document.getElementById('saved-worlds-list');
    this.elInputName = document.getElementById('input-world-name');
    this.elInputSeed = document.getElementById('input-world-seed');

    // Inventory elements
    this.elInvTabFurnace = document.getElementById('inv-tab-furnace');
    this.elInvTabPalette = document.getElementById('inv-tab-palette');
    this.elStationBadge = document.getElementById('station-badge');
    this.elRecipesGrid = document.getElementById('recipes-grid');
    this.elCreativeGrid = document.getElementById('creative-grid');
    this.elMilestonesList = document.getElementById('milestones-list');
    this.elBackpackGrid = document.getElementById('backpack-grid');
    this.elInvHotbarGrid = document.getElementById('inv-hotbar-grid');

    this.elFurnaceInput = document.getElementById('furnace-slot-input');
    this.elFurnaceFuel = document.getElementById('furnace-slot-fuel');
    this.elFurnaceOutput = document.getElementById('furnace-slot-output');
    this.elFurnaceFlame = document.getElementById('furnace-flame');
    this.elFurnaceArrow = document.getElementById('furnace-arrow-fill');

    this.elCursorItem = document.getElementById('cursor-item');
    this.elCursorImg = document.getElementById('cursor-item-img');
    this.elCursorCount = document.getElementById('cursor-item-count');
    this.elTooltip = document.getElementById('item-tooltip');

    // Pause elements
    this.elPauseTitle = document.getElementById('pause-world-title');
    this.elBtnSave = document.getElementById('btn-save-world');
    this.elBtnToggleMode = document.getElementById('btn-toggle-mode');
    this.elCreativeEnv = document.getElementById('creative-env-controls');
    this.elBtnRain = document.getElementById('btn-toggle-rain');

    this.elSliderRender = document.getElementById('slider-render');
    this.elValRender = document.getElementById('val-render');
    this.elSliderFov = document.getElementById('slider-fov');
    this.elValFov = document.getElementById('val-fov');
    this.elSliderVol = document.getElementById('slider-volume');
    this.elValVol = document.getElementById('val-volume');
    this.elSliderSens = document.getElementById('slider-sens');
    this.elValSens = document.getElementById('val-sens');
  }

  _bindMenuEvents() {
    const switchTitleTab = (tab) => {
      const isWorlds = tab === 'worlds';
      this.elTabWorlds.classList.toggle('active', isWorlds);
      this.elTabNew.classList.toggle('active', !isWorlds);
      this.elPanelWorlds.classList.toggle('hidden', !isWorlds);
      this.elPanelNew.classList.toggle('hidden', isWorlds);
    };

    this.elTabWorlds.addEventListener('click', () => switchTitleTab('worlds'));
    this.elTabNew.addEventListener('click', () => switchTitleTab('new'));
    document.getElementById('btn-go-create').addEventListener('click', () => switchTitleTab('new'));

    document.getElementById('btn-random-seed').addEventListener('click', () => {
      const pick = SCENIC_SEEDS[Math.floor(Math.random() * SCENIC_SEEDS.length)];
      this.elInputSeed.value = `${pick}-${Math.floor(100 + Math.random() * 900)}`;
    });

    document.querySelectorAll('.mode-card').forEach((btn) => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.mode-card').forEach((b) => b.classList.remove('active'));
        btn.classList.add('active');
        this.selectedNewMode = btn.dataset.mode;
      });
    });

    this.elPanelNew.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = this.elInputName.value.trim() || 'New World';
      const seed = this.elInputSeed.value.trim() || `${SCENIC_SEEDS[Math.floor(Math.random() * SCENIC_SEEDS.length)]}-${Date.now() % 10000}`;
      const id = 'w_' + Date.now();
      this.cb.onStartWorld({ id, name, seed, mode: this.selectedNewMode, isNew: true });
    });

    document.getElementById('import-world-input').addEventListener('change', (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const imported = SaveManager.importWorldJSON(String(reader.result));
          this.refreshWorldsList();
          switchTitleTab('worlds');
          this.showToast('World Imported', `Loaded "${imported.name}"`);
        } catch {
          alert('Could not import file. Please choose a valid TerraCraft JSON export.');
        }
      };
      reader.readAsText(file);
      e.target.value = '';
    });
  }

  refreshWorldsList() {
    const worlds = SaveManager.listWorlds();
    this.elWorldsList.innerHTML = '';

    if (worlds.length === 0) {
      this.elTabWorlds.classList.remove('active');
      this.elTabNew.classList.add('active');
      this.elPanelWorlds.classList.add('hidden');
      this.elPanelNew.classList.remove('hidden');

      const empty = document.createElement('div');
      empty.className = 'empty-worlds';
      empty.textContent = 'No saved worlds yet. Create your first world to begin exploring!';
      this.elWorldsList.appendChild(empty);
      return;
    }

    this.elTabWorlds.classList.add('active');
    this.elTabNew.classList.remove('active');
    this.elPanelWorlds.classList.remove('hidden');
    this.elPanelNew.classList.add('hidden');

    for (const w of worlds) {
      const row = document.createElement('div');
      row.className = 'world-item';
      const dateStr = w.updatedAt ? new Date(w.updatedAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '';
      const modeCap = w.mode === 'creative' ? 'Creative' : 'Survival';

      const meta = document.createElement('div');
      meta.className = 'world-meta';
      const strong = document.createElement('strong');
      strong.textContent = w.name || 'World';
      const sub = document.createElement('span');
      sub.textContent = `${modeCap} · Day ${w.dayNumber || 1} · Seed: ${w.seed} ${dateStr ? '· ' + dateStr : ''}`;
      meta.append(strong, sub);

      const btns = document.createElement('div');
      btns.className = 'world-item-btns';

      const playBtn = document.createElement('button');
      playBtn.type = 'button';
      playBtn.className = 'btn btn-primary btn-sm';
      playBtn.textContent = 'Play';
      playBtn.addEventListener('click', () => {
        const saved = SaveManager.loadWorld(w.id);
        if (saved) this.cb.onStartWorld({ ...saved, isNew: false });
      });

      const expBtn = document.createElement('button');
      expBtn.type = 'button';
      expBtn.className = 'btn btn-secondary btn-sm';
      expBtn.textContent = 'Export';
      expBtn.addEventListener('click', () => SaveManager.exportWorldJSON(w.id));

      const delBtn = document.createElement('button');
      delBtn.type = 'button';
      delBtn.className = 'btn btn-danger btn-sm';
      delBtn.textContent = '✕';
      delBtn.title = 'Delete World';
      delBtn.addEventListener('click', () => {
        SaveManager.deleteWorld(w.id);
        this.refreshWorldsList();
      });

      btns.append(playBtn, expBtn, delBtn);
      row.append(meta, btns);
      this.elWorldsList.appendChild(row);
    }
  }

  _bindInventoryEvents() {
    document.getElementById('btn-close-inv').addEventListener('click', () => {
      this.cb.onResume();
    });

    // Inventory top tabs
    document.querySelectorAll('#inv-mode-tabs .seg-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        this.switchInvTab(btn.dataset.invtab);
      });
    });

    // Crafting category pills
    document.querySelectorAll('#craft-cat-pills .pill-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('#craft-cat-pills .pill-btn').forEach((b) => b.classList.remove('active'));
        btn.classList.add('active');
        this.activeCraftCategory = btn.dataset.cat;
        this.renderInventoryContents();
      });
    });

    // Furnace slot clicks
    [this.elFurnaceInput, this.elFurnaceFuel, this.elFurnaceOutput].forEach((el) => {
      el.addEventListener('mousedown', (e) => {
        e.preventDefault();
        this._handleFurnaceSlotClick(el.dataset.fslot, e.button === 2);
      });
      el.addEventListener('contextmenu', (e) => e.preventDefault());
    });

    // Mouse move for floating cursor stack & tooltip
    window.addEventListener('mousemove', (e) => {
      if (!this.elCursorItem.classList.contains('hidden')) {
        this.elCursorItem.style.left = `${e.clientX}px`;
        this.elCursorItem.style.top = `${e.clientY}px`;
      }
      if (!this.elTooltip.classList.contains('hidden')) {
        this.elTooltip.style.left = `${e.clientX + 14}px`;
        this.elTooltip.style.top = `${e.clientY - 12}px`;
      }
    });

    // Populate static Creative Palette once
    this.elCreativeGrid.innerHTML = '';
    for (const id of CREATIVE_PALETTE) {
      const def = getDef(id);
      if (!def) continue;
      const cell = document.createElement('div');
      cell.className = 'inv-slot';
      const img = document.createElement('img');
      img.src = this.textures.getIconDataURL(id);
      img.alt = def.name;
      cell.appendChild(img);

      cell.addEventListener('mouseenter', () => this._showTooltip(def.name));
      cell.addEventListener('mouseleave', () => this._hideTooltip());
      cell.addEventListener('mousedown', (e) => {
        e.preventDefault();
        if (!this.player) return;
        const count = e.shiftKey ? getMaxStack(id) : (getMaxStack(id) > 1 ? 16 : 1);
        this.player.addItem(id, count);
        this.sound?.playPickup();
        this.renderInventoryContents();
        this.renderHotbar();
      });
      this.elCreativeGrid.appendChild(cell);
    }
  }

  _bindPauseEvents() {
    document.getElementById('btn-resume').addEventListener('click', () => this.cb.onResume());

    this.elBtnSave.addEventListener('click', () => {
      const ok = this.cb.onSave();
      if (ok) {
        this.elBtnSave.textContent = 'Saved ✓';
        setTimeout(() => { this.elBtnSave.textContent = 'Save World'; }, 1400);
      }
    });

    this.elBtnToggleMode.addEventListener('click', () => {
      if (!this.player) return;
      const next = this.player.mode === 'survival' ? 'creative' : 'survival';
      this.player.setMode(next);
      this.syncPauseState();
    });

    document.querySelectorAll('[data-settime]').forEach((btn) => {
      btn.addEventListener('click', () => {
        if (this.sky) {
          this.sky.timeOfDay = parseFloat(btn.dataset.settime);
        }
      });
    });

    this.elBtnRain.addEventListener('click', () => {
      if (this.sky) {
        this.sky.weather = this.sky.weather === 'rain' ? 'clear' : 'rain';
        this.syncPauseState();
      }
    });

    document.getElementById('btn-quit-title').addEventListener('click', () => {
      this.cb.onQuitToTitle();
    });

    const emitSettings = () => {
      const settings = {
        renderDistance: parseInt(this.elSliderRender.value, 10),
        fov: parseInt(this.elSliderFov.value, 10),
        volume: parseInt(this.elSliderVol.value, 10) / 100,
        sensitivity: (parseInt(this.elSliderSens.value, 10) / 100) * 0.0022,
      };
      this.elValRender.textContent = String(settings.renderDistance);
      this.elValFov.textContent = `${settings.fov}°`;
      this.elValVol.textContent = `${Math.round(settings.volume * 100)}%`;
      this.elValSens.textContent = `${this.elSliderSens.value}%`;
      this.cb.onSettingsChange(settings);
    };

    [this.elSliderRender, this.elSliderFov, this.elSliderVol, this.elSliderSens].forEach((s) => {
      s.addEventListener('input', emitSettings);
    });
  }

  applySettingsToSliders(settings) {
    this.elSliderRender.value = String(settings.renderDistance ?? 5);
    this.elValRender.textContent = String(settings.renderDistance ?? 5);

    this.elSliderFov.value = String(settings.fov ?? 75);
    this.elValFov.textContent = `${settings.fov ?? 75}°`;

    const volPct = Math.round((settings.volume ?? 0.65) * 100);
    this.elSliderVol.value = String(volPct);
    this.elValVol.textContent = `${volPct}%`;

    const sensPct = Math.round(((settings.sensitivity ?? 0.0022) / 0.0022) * 100);
    this.elSliderSens.value = String(sensPct);
    this.elValSens.textContent = `${sensPct}%`;
  }

  attachSession(player, world, sky) {
    this.player = player;
    this.world = world;
    this.sky = sky;
    this._lastHeldSlot = -1;
    this._lastHeldId = -1;
    this.renderHotbar();
  }

  showScreen(screen, options = {}) {
    // Return cursor stack safely to inventory whenever closing inventory
    if (screen !== 'inventory' && this.cursorStack && this.player) {
      this.player.addItem(this.cursorStack.id, this.cursorStack.count, this.cursorStack.durability);
      this.cursorStack = null;
      this._syncCursorVisual();
    }
    this._hideTooltip();

    this.elTitleScreen.classList.toggle('hidden', screen !== 'title');
    this.elHud.classList.toggle('hidden', screen === 'title');
    this.elInvModal.classList.toggle('hidden', screen !== 'inventory');
    this.elPauseModal.classList.toggle('hidden', screen !== 'pause');

    if (screen === 'title') {
      this.refreshWorldsList();
    } else if (screen === 'inventory') {
      this.activeFurnacePos = options.furnacePos || null;
      this.forceCraftingTable = Boolean(options.craftingTable);

      const hasFurnace = Boolean(this.activeFurnacePos);
      this.elInvTabFurnace.classList.toggle('hidden', !hasFurnace);
      this.elInvTabPalette.classList.toggle('hidden', this.player?.mode !== 'creative');

      if (hasFurnace) {
        this.switchInvTab('furnace');
      } else if (options.craftingTable) {
        this.switchInvTab('craft');
      } else if (this.activeInvTab === 'furnace') {
        this.switchInvTab('craft');
      } else if (this.activeInvTab === 'palette' && this.player?.mode !== 'creative') {
        this.switchInvTab('craft');
      } else {
        this.switchInvTab(this.activeInvTab);
      }
      this.renderInventoryContents();
    } else if (screen === 'pause') {
      this.syncPauseState();
    }
  }

  switchInvTab(tab) {
    this.activeInvTab = tab;
    document.querySelectorAll('#inv-mode-tabs .seg-btn').forEach((b) => {
      b.classList.toggle('active', b.dataset.invtab === tab);
    });
    document.getElementById('inv-panel-craft').classList.toggle('hidden', tab !== 'craft');
    document.getElementById('inv-panel-furnace').classList.toggle('hidden', tab !== 'furnace');
    document.getElementById('inv-panel-palette').classList.toggle('hidden', tab !== 'palette');
    document.getElementById('inv-panel-milestones').classList.toggle('hidden', tab !== 'milestones');
    this.renderInventoryContents();
  }

  syncPauseState() {
    if (!this.player || !this.sky) return;
    const isCreative = this.player.mode === 'creative';
    this.elBtnToggleMode.textContent = `Mode: ${isCreative ? 'Creative' : 'Survival'}`;
    this.elCreativeEnv.classList.toggle('hidden', !isCreative);
    this.elBtnRain.classList.toggle('active', this.sky.weather === 'rain');
    this.elBtnRain.textContent = this.sky.weather === 'rain' ? 'Rain: On' : 'Rain: Off';
  }

  showToast(title, subtitle = '') {
    const item = document.createElement('div');
    item.className = 'toast-item';
    const strong = document.createElement('strong');
    strong.textContent = title;
    const span = document.createElement('span');
    span.textContent = subtitle;
    item.append(strong, span);
    this.elToasts.appendChild(item);

    setTimeout(() => {
      item.style.opacity = '0';
      item.style.transition = 'opacity 0.35s ease';
      setTimeout(() => item.remove(), 360);
    }, 3400);
  }

  renderHotbar() {
    if (!this.player) return;
    this.elHotbar.innerHTML = '';
    for (let i = 0; i < 9; i++) {
      const slot = this.player.inventory[i];
      const cell = this._createSlotElement(slot, i, true);
      if (i === this.player.selectedSlot) cell.classList.add('selected');
      cell.addEventListener('mousedown', (e) => {
        e.preventDefault();
        this.player.selectedSlot = i;
        this.renderHotbar();
      });
      this.elHotbar.appendChild(cell);
    }
  }

  _createSlotElement(slot, index, showKeyNumber = false) {
    const div = document.createElement('div');
    div.className = 'inv-slot';

    if (showKeyNumber) {
      const k = document.createElement('span');
      k.className = 'slot-key';
      k.textContent = String(index + 1);
      div.appendChild(k);
    }

    if (slot && slot.id) {
      const def = getDef(slot.id);
      const img = document.createElement('img');
      img.src = this.textures.getIconDataURL(slot.id);
      img.alt = def?.name || '';
      div.appendChild(img);

      if (slot.count > 1) {
        const cnt = document.createElement('span');
        cnt.className = 'slot-count';
        cnt.textContent = String(slot.count);
        div.appendChild(cnt);
      }

      if (def?.durability && slot.durability != null && slot.durability < def.durability) {
        const bar = document.createElement('div');
        bar.className = 'slot-durability';
        const fill = document.createElement('span');
        const pct = Math.max(0, Math.min(100, (slot.durability / def.durability) * 100));
        fill.style.width = `${pct}%`;
        fill.style.background = pct > 50 ? '#4ec968' : pct > 22 ? '#f5b342' : '#e05252';
        bar.appendChild(fill);
        div.appendChild(bar);
      }
    }

    return div;
  }

  renderInventoryContents() {
    if (!this.player || !this.world) return;

    // 1. Crafting Table check
    const nearTable = this.forceCraftingTable || this.world.isNearBlock(
      this.player.position.x,
      this.player.position.y,
      this.player.position.z,
      [BLOCK.CRAFTING_TABLE],
      4.8
    );

    if (this.player.mode === 'creative' || nearTable) {
      this.elStationBadge.textContent = 'Crafting Table Active (All Recipes)';
      this.elStationBadge.classList.add('table-active');
    } else {
      this.elStationBadge.textContent = 'Hand Crafting (Place Crafting Table for Tools)';
      this.elStationBadge.classList.remove('table-active');
    }

    // 2. Render Crafting Recipes
    if (this.activeInvTab === 'craft') {
      this.elRecipesGrid.innerHTML = '';
      const filtered = CRAFTING_RECIPES.filter(
        (r) => this.activeCraftCategory === 'All' || r.category === this.activeCraftCategory
      );

      // Sort craftable recipes first for friendliness!
      filtered.sort((a, b) => {
        const ca = this.player.canCraft(a, nearTable) ? 1 : 0;
        const cb = this.player.canCraft(b, nearTable) ? 1 : 0;
        return cb - ca;
      });

      for (const rec of filtered) {
        const craftable = this.player.canCraft(rec, nearTable);
        const outDef = getDef(rec.output.id);
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = `recipe-card ${craftable ? 'craftable' : 'locked'}`;

        const iconWrap = document.createElement('div');
        iconWrap.className = 'recipe-out-icon';
        const img = document.createElement('img');
        img.src = this.textures.getIconDataURL(rec.output.id);
        iconWrap.appendChild(img);
        if (rec.output.count > 1) {
          const c = document.createElement('span');
          c.className = 'slot-count';
          c.textContent = String(rec.output.count);
          iconWrap.appendChild(c);
        }

        const info = document.createElement('div');
        info.className = 'recipe-info';
        const title = document.createElement('div');
        title.className = 'recipe-name';
        title.textContent = outDef?.name || rec.id;

        const reqs = document.createElement('div');
        reqs.className = 'recipe-reqs';
        const parts = rec.inputs.map((inp) => {
          const have = inp.tag ? this.player.countTag(inp.tag) : this.player.countItem(inp.id);
          const nm = inp.label || getDef(inp.id)?.name || 'Item';
          const ok = have >= inp.count;
          return `<span class="${ok ? 'req-ok' : 'req-missing'}">${have}/${inp.count} ${nm}</span>`;
        });
        if (rec.requiresTable && !nearTable && this.player.mode !== 'creative') {
          parts.push('<span class="req-missing">[Needs Table]</span>');
        }
        reqs.innerHTML = parts.join(' · ');

        info.append(title, reqs);
        btn.append(iconWrap, info);

        btn.addEventListener('click', (e) => {
          const times = e.shiftKey ? 4 : 1;
          let craftedAny = false;
          for (let t = 0; t < times; t++) {
            if (this.player.craftRecipe(rec, nearTable, craftedAny ? null : this.sound)) {
              craftedAny = true;
            } else {
              break;
            }
          }
          if (craftedAny) {
            this.renderInventoryContents();
            this.renderHotbar();
          }
        });

        this.elRecipesGrid.appendChild(btn);
      }
    }

    // 3. Render Furnace Slots if open
    if (this.activeInvTab === 'furnace' && this.activeFurnacePos) {
      this._renderFurnaceStatus();
    }

    // 4. Render Milestones if open
    if (this.activeInvTab === 'milestones') {
      this.elMilestonesList.innerHTML = '';
      for (const m of MILESTONES) {
        const done = this.player.milestones.has(m.id);
        const div = document.createElement('div');
        div.className = `milestone-item ${done ? 'done' : ''}`;
        div.innerHTML = `
          <div class="milestone-check">${done ? '✓' : '·'}</div>
          <div class="milestone-text">
            <strong>${m.title}</strong>
            <span>${m.desc}</span>
          </div>
        `;
        this.elMilestonesList.appendChild(div);
      }
    }

    // 5. Render Backpack (9..35) & Hotbar Mirror (0..8)
    this.elBackpackGrid.innerHTML = '';
    for (let i = 9; i < 36; i++) {
      this.elBackpackGrid.appendChild(this._buildInteractiveInvCell(i, false));
    }

    this.elInvHotbarGrid.innerHTML = '';
    for (let i = 0; i < 9; i++) {
      this.elInvHotbarGrid.appendChild(this._buildInteractiveInvCell(i, true));
    }
  }

  _buildInteractiveInvCell(index, isHotbar) {
    const slot = this.player.inventory[index];
    const cell = this._createSlotElement(slot, index, isHotbar);
    if (isHotbar && index === this.player.selectedSlot) {
      cell.classList.add('selected');
    }

    cell.addEventListener('mouseenter', () => {
      const s = this.player.inventory[index];
      if (s?.id) this._showTooltip(getDef(s.id)?.name || '');
    });
    cell.addEventListener('mouseleave', () => this._hideTooltip());
    cell.addEventListener('contextmenu', (e) => e.preventDefault());

    cell.addEventListener('mousedown', (e) => {
      e.preventDefault();
      this._handleInventorySlotClick(index, e.button === 2, e.shiftKey);
    });

    return cell;
  }

  _handleInventorySlotClick(index, rightClick, shiftKey) {
    const inv = this.player.inventory;
    const slot = inv[index];

    // Shift-click quick transfer!
    if (shiftKey && slot && !this.cursorStack) {
      // If Furnace tab is open, try loading smeltable item or fuel straight into Furnace!
      if (this.activeInvTab === 'furnace' && this.activeFurnacePos) {
        const f = this.world.getOrCreateFurnace(
          this.activeFurnacePos.x,
          this.activeFurnacePos.y,
          this.activeFurnacePos.z
        );
        const isSmeltable = SMELTING_RECIPES.some((r) => r.input === slot.id);
        const isFuel = Boolean(getDef(slot.id)?.fuel);

        if (isSmeltable && (f.inputId === 0 || f.inputId === slot.id)) {
          const canAdd = Math.min(slot.count, 64 - f.inputCount);
          if (canAdd > 0) {
            f.inputId = slot.id;
            f.inputCount += canAdd;
            slot.count -= canAdd;
            if (slot.count <= 0) inv[index] = null;
            this.renderInventoryContents();
            this.renderHotbar();
            return;
          }
        } else if (isFuel && (f.fuelId === 0 || f.fuelId === slot.id)) {
          const canAdd = Math.min(slot.count, 64 - f.fuelCount);
          if (canAdd > 0) {
            f.fuelId = slot.id;
            f.fuelCount += canAdd;
            slot.count -= canAdd;
            if (slot.count <= 0) inv[index] = null;
            this.renderInventoryContents();
            this.renderHotbar();
            return;
          }
        }
      }

      // Otherwise transfer between Hotbar (0..8) and Backpack (9..35)
      const rangeStart = index < 9 ? 9 : 0;
      const rangeEnd = index < 9 ? 36 : 9;
      const maxS = getMaxStack(slot.id);

      if (maxS > 1) {
        for (let i = rangeStart; i < rangeEnd && slot.count > 0; i++) {
          if (inv[i] && inv[i].id === slot.id && inv[i].count < maxS) {
            const move = Math.min(slot.count, maxS - inv[i].count);
            inv[i].count += move;
            slot.count -= move;
          }
        }
      }
      for (let i = rangeStart; i < rangeEnd && slot.count > 0; i++) {
        if (!inv[i]) {
          inv[i] = { ...slot };
          slot.count = 0;
          break;
        }
      }
      if (slot.count <= 0) inv[index] = null;
      this.renderInventoryContents();
      this.renderHotbar();
      return;
    }

    if (!this.cursorStack) {
      if (!slot) return;
      if (rightClick && slot.count > 1) {
        // Pick up half
        const half = Math.ceil(slot.count / 2);
        this.cursorStack = { ...slot, count: half };
        slot.count -= half;
      } else {
        this.cursorStack = { ...slot };
        inv[index] = null;
      }
    } else {
      const maxS = getMaxStack(this.cursorStack.id);
      if (!slot) {
        if (rightClick && this.cursorStack.count > 1) {
          inv[index] = { ...this.cursorStack, count: 1 };
          this.cursorStack.count -= 1;
        } else {
          inv[index] = { ...this.cursorStack };
          this.cursorStack = null;
        }
      } else if (slot.id === this.cursorStack.id && maxS > 1) {
        const take = rightClick ? 1 : this.cursorStack.count;
        const move = Math.min(take, maxS - slot.count);
        slot.count += move;
        this.cursorStack.count -= move;
        if (this.cursorStack.count <= 0) this.cursorStack = null;
      } else if (!rightClick) {
        // Swap
        inv[index] = { ...this.cursorStack };
        this.cursorStack = { ...slot };
      }
    }

    this._syncCursorVisual();
    this.renderInventoryContents();
    this.renderHotbar();
  }

  _handleFurnaceSlotClick(slotType, rightClick) {
    if (!this.activeFurnacePos || !this.world || !this.player) return;
    const f = this.world.getOrCreateFurnace(
      this.activeFurnacePos.x,
      this.activeFurnacePos.y,
      this.activeFurnacePos.z
    );

    if (slotType === 'output') {
      if (f.outputId && f.outputCount > 0) {
        const rem = this.player.addItem(f.outputId, f.outputCount);
        f.outputCount = rem;
        if (f.outputCount <= 0) f.outputId = 0;
        this.sound?.playCraft();
      }
      this.renderInventoryContents();
      this.renderHotbar();
      return;
    }

    const idProp = slotType === 'input' ? 'inputId' : 'fuelId';
    const cntProp = slotType === 'input' ? 'inputCount' : 'fuelCount';

    if (!this.cursorStack) {
      if (f[idProp] && f[cntProp] > 0) {
        this.cursorStack = { id: f[idProp], count: f[cntProp], durability: null };
        f[idProp] = 0;
        f[cntProp] = 0;
      }
    } else {
      const putCount = rightClick ? 1 : this.cursorStack.count;
      if (f[idProp] === 0 || f[idProp] === this.cursorStack.id) {
        const move = Math.min(putCount, 64 - f[cntProp]);
        if (move > 0) {
          f[idProp] = this.cursorStack.id;
          f[cntProp] += move;
          this.cursorStack.count -= move;
          if (this.cursorStack.count <= 0) this.cursorStack = null;
        }
      } else {
        // Swap with cursor
        const prev = { id: f[idProp], count: f[cntProp], durability: null };
        f[idProp] = this.cursorStack.id;
        f[cntProp] = this.cursorStack.count;
        this.cursorStack = prev;
      }
    }

    this._syncCursorVisual();
    this.renderInventoryContents();
    this.renderHotbar();
  }

  _renderFurnaceStatus() {
    if (!this.activeFurnacePos || !this.world) return;
    const f = this.world.getOrCreateFurnace(
      this.activeFurnacePos.x,
      this.activeFurnacePos.y,
      this.activeFurnacePos.z
    );

    const fillSlot = (el, id, count) => {
      el.innerHTML = '';
      if (id && count > 0) {
        const img = document.createElement('img');
        img.src = this.textures.getIconDataURL(id);
        el.appendChild(img);
        if (count > 1) {
          const span = document.createElement('span');
          span.className = 'slot-count';
          span.textContent = String(count);
          el.appendChild(span);
        }
      }
    };

    fillSlot(this.elFurnaceInput, f.inputId, f.inputCount);
    fillSlot(this.elFurnaceFuel, f.fuelId, f.fuelCount);
    fillSlot(this.elFurnaceOutput, f.outputId, f.outputCount);

    this.elFurnaceFlame.classList.toggle('lit', f.burnTime > 0);
    const pct = f.maxProgress > 0 ? Math.min(100, (f.progress / f.maxProgress) * 100) : 0;
    this.elFurnaceArrow.style.width = `${pct}%`;
  }

  _syncCursorVisual() {
    if (!this.cursorStack) {
      this.elCursorItem.classList.add('hidden');
      return;
    }
    this.elCursorItem.classList.remove('hidden');
    this.elCursorImg.src = this.textures.getIconDataURL(this.cursorStack.id);
    this.elCursorCount.textContent = this.cursorStack.count > 1 ? String(this.cursorStack.count) : '';
  }

  _showTooltip(text) {
    if (!text) return;
    this.elTooltip.textContent = text;
    this.elTooltip.classList.remove('hidden');
  }

  _hideTooltip() {
    this.elTooltip.classList.add('hidden');
  }

  updateHUD(dt, fps, showDebug) {
    if (!this.player || !this.world || !this.sky) return;

    // Live furnace progress while modal is open
    if (!this.elInvModal.classList.contains('hidden') && this.activeInvTab === 'furnace' && this.activeFurnacePos) {
      this._renderFurnaceStatus();
    }

    // 1. Overlays (Underwater & Hurt flash)
    this.elUnderwater.classList.toggle('hidden', !this.player.headInWater);
    this.elDamage.style.opacity = this.player.damageFlash > 0
      ? String(Math.min(0.85, this.player.damageFlash * 2.2))
      : '0';

    // 2. Top-left World Pill (Time + Biome)
    const phase = this.sky.getTimeLabel();
    const isRain = this.sky.rainStrength > 0.35;
    this.elTimeIcon.textContent = isRain ? '🌧' : (phase === 'Night' ? '🌙' : phase === 'Sunset' || phase === 'Dawn' ? '🌅' : '☀');
    this.elTimeLabel.textContent = `Day ${this.sky.dayNumber} · ${isRain ? 'Rain' : phase}`;
    const biome = this.world.getBiomeAt(this.player.position.x, this.player.position.z);
    this.elBiomeLabel.textContent = biome;

    // 3. Crosshair Radial Mining Ring & Station Hint
    if (this.player.miningProgress > 0.01) {
      this.elMiningRing.classList.remove('hidden');
      const circum = 106.8;
      const offset = circum * (1 - Math.min(1, this.player.miningProgress));
      this.elMiningBar.style.strokeDashoffset = String(offset);
    } else {
      this.elMiningRing.classList.add('hidden');
    }

    const hitId = this.player.targetHit?.blockId;
    const hitInteractive = hitId ? BLOCK_DEFS[hitId]?.interactive : null;
    if (hitInteractive && !this.player.sneaking) {
      this.elInteractHint.classList.remove('hidden');
      this.elInteractHint.textContent =
        hitInteractive === 'crafting' ? 'Right-Click · Open Crafting Table'
          : hitInteractive === 'furnace' ? 'Right-Click · Open Furnace'
            : 'Right-Click · Ignite TNT';
    } else {
      this.elInteractHint.classList.add('hidden');
    }

    // 4. Held Item Fading Name Label
    const curHeldId = this.player.getHeldId();
    if (this.player.selectedSlot !== this._lastHeldSlot || curHeldId !== this._lastHeldId) {
      this._lastHeldSlot = this.player.selectedSlot;
      this._lastHeldId = curHeldId;
      this.renderHotbar();
      if (curHeldId) {
        this.elHeldName.textContent = getDef(curHeldId)?.name || '';
        this.elHeldName.classList.add('visible');
        this._labelTimer = 2.0;
      } else {
        this.elHeldName.classList.remove('visible');
      }
    }
    if (this._labelTimer > 0) {
      this._labelTimer -= dt;
      if (this._labelTimer <= 0) {
        this.elHeldName.classList.remove('visible');
      }
    }

    // 5. Survival Vitals vs Creative Flight Indicator
    if (this.player.mode === 'survival') {
      this.elVitalsRow.classList.remove('hidden');
      this.elFlightInd.classList.add('hidden');
      this._renderVitals();
    } else {
      this.elVitalsRow.classList.add('hidden');
      this.elFlightInd.classList.toggle('hidden', !this.player.flying);
    }

    // 6. Optional F3 Diagnostics
    if (showDebug) {
      this.elDebug.classList.remove('hidden');
      const p = this.player.position;
      const cx = Math.floor(p.x / 16);
      const cz = Math.floor(p.z / 16);
      const skyL = this.world.getSkyLight(Math.floor(p.x), Math.floor(p.y + 1), Math.floor(p.z));
      const blkL = this.world.getBlockLight(Math.floor(p.x), Math.floor(p.y + 1), Math.floor(p.z));
      this.elDebug.textContent =
        `FPS: ${Math.round(fps)}\n` +
        `XYZ: ${p.x.toFixed(1)} / ${p.y.toFixed(1)} / ${p.z.toFixed(1)}\n` +
        `Chunk: (${cx}, ${cz}) · Loaded: ${this.world.chunks.size}\n` +
        `Light: Sky ${skyL} · Block ${blkL}\n` +
        `Mode: ${this.player.mode}${this.player.flying ? ' (Flying)' : ''}`;
    } else {
      this.elDebug.classList.add('hidden');
    }
  }

  _renderVitals() {
    const hp = Math.ceil(this.player.health);
    const hunger = Math.ceil(this.player.hunger);
    const oxy = this.player.oxygen;

    // Only rebuild DOM pips when values change
    if (this._cachedHp !== hp) {
      this._cachedHp = hp;
      this.elHearts.innerHTML = '';
      for (let i = 0; i < 10; i++) {
        const pip = document.createElement('span');
        pip.className = 'vital-pip';
        const val = hp - i * 2;
        if (val >= 2) {
          pip.textContent = '❤';
          pip.style.color = '#ef4444';
        } else if (val === 1) {
          pip.textContent = '❤';
          pip.style.color = '#f89898';
          pip.style.opacity = '0.72';
        } else {
          pip.textContent = '♡';
          pip.style.color = 'rgba(255,255,255,0.35)';
        }
        this.elHearts.appendChild(pip);
      }
    }

    if (this._cachedHunger !== hunger) {
      this._cachedHunger = hunger;
      this.elHunger.innerHTML = '';
      for (let i = 0; i < 10; i++) {
        const pip = document.createElement('span');
        pip.className = 'vital-pip';
        const val = hunger - i * 2;
        if (val >= 2) {
          pip.textContent = '🍗';
          pip.style.opacity = '1';
        } else if (val === 1) {
          pip.textContent = '🍗';
          pip.style.opacity = '0.55';
        } else {
          pip.textContent = '·';
          pip.style.color = 'rgba(255,255,255,0.35)';
        }
        this.elHunger.appendChild(pip);
      }
    }

    if (this.player.headInWater || oxy < this.player.maxOxygen - 0.2) {
      this.elOxygen.classList.remove('hidden');
      const bubbles = Math.ceil((oxy / this.player.maxOxygen) * 10);
      if (this._cachedBubbles !== bubbles) {
        this._cachedBubbles = bubbles;
        this.elOxygen.innerHTML = '';
        for (let i = 0; i < 10; i++) {
          const b = document.createElement('span');
          b.className = 'vital-pip';
          b.textContent = i < bubbles ? '○' : '·';
          b.style.color = '#7dd3fc';
          this.elOxygen.appendChild(b);
        }
      }
    } else {
      this.elOxygen.classList.add('hidden');
    }
  }
}
