import * as THREE from 'three';
import { BLOCK, BLOCK_DEFS, getBlockLight, isOpaqueBlock } from './blocks.js';
import { CHUNK_SIZE, WORLD_HEIGHT } from './terrain.js';

const SLICE = CHUNK_SIZE * CHUNK_SIZE;
const VOLUME = SLICE * WORLD_HEIGHT;

// Reusable typed BFS queue to avoid GC pressure during chunk lighting
const BFS_QUEUE = new Int32Array(VOLUME * 2);

const DIRS6 = [
  [1, 0, 0], [-1, 0, 0],
  [0, 1, 0], [0, -1, 0],
  [0, 0, 1], [0, 0, -1],
];

// Six cube faces with verified outward CCW vertices, UVs, directional shade, and tangent axes for AO
const CUBE_FACES = [
  {
    name: 'top',
    dir: [0, 1, 0],
    shade: 1.0,
    t1: [1, 0, 0],
    t2: [0, 0, 1],
    verts: [
      { pos: [0, 1, 1], uv: [0, 0], c: [-1, 1] },
      { pos: [1, 1, 1], uv: [1, 0], c: [1, 1] },
      { pos: [1, 1, 0], uv: [1, 1], c: [1, -1] },
      { pos: [0, 1, 0], uv: [0, 1], c: [-1, -1] },
    ],
  },
  {
    name: 'bottom',
    dir: [0, -1, 0],
    shade: 0.54,
    t1: [1, 0, 0],
    t2: [0, 0, 1],
    verts: [
      { pos: [0, 0, 0], uv: [0, 0], c: [-1, -1] },
      { pos: [1, 0, 0], uv: [1, 0], c: [1, -1] },
      { pos: [1, 0, 1], uv: [1, 1], c: [1, 1] },
      { pos: [0, 0, 1], uv: [0, 1], c: [-1, 1] },
    ],
  },
  {
    name: 'front', // +Z
    dir: [0, 0, 1],
    shade: 0.86,
    t1: [1, 0, 0],
    t2: [0, 1, 0],
    verts: [
      { pos: [0, 0, 1], uv: [0, 0], c: [-1, -1] },
      { pos: [1, 0, 1], uv: [1, 0], c: [1, -1] },
      { pos: [1, 1, 1], uv: [1, 1], c: [1, 1] },
      { pos: [0, 1, 1], uv: [0, 1], c: [-1, 1] },
    ],
  },
  {
    name: 'side', // -Z
    dir: [0, 0, -1],
    shade: 0.82,
    t1: [1, 0, 0],
    t2: [0, 1, 0],
    verts: [
      { pos: [1, 0, 0], uv: [0, 0], c: [1, -1] },
      { pos: [0, 0, 0], uv: [1, 0], c: [-1, -1] },
      { pos: [0, 1, 0], uv: [1, 1], c: [-1, 1] },
      { pos: [1, 1, 0], uv: [0, 1], c: [1, 1] },
    ],
  },
  {
    name: 'side', // +X
    dir: [1, 0, 0],
    shade: 0.73,
    t1: [0, 0, 1],
    t2: [0, 1, 0],
    verts: [
      { pos: [1, 0, 1], uv: [0, 0], c: [1, -1] },
      { pos: [1, 0, 0], uv: [1, 0], c: [-1, -1] },
      { pos: [1, 1, 0], uv: [1, 1], c: [-1, 1] },
      { pos: [1, 1, 1], uv: [0, 1], c: [1, 1] },
    ],
  },
  {
    name: 'side', // -X
    dir: [-1, 0, 0],
    shade: 0.71,
    t1: [0, 0, 1],
    t2: [0, 1, 0],
    verts: [
      { pos: [0, 0, 0], uv: [0, 0], c: [-1, -1] },
      { pos: [0, 0, 1], uv: [1, 0], c: [1, -1] },
      { pos: [0, 1, 1], uv: [1, 1], c: [1, 1] },
      { pos: [0, 1, 0], uv: [0, 1], c: [-1, 1] },
    ],
  },
];

const AO_CURVE = [1.0, 0.80, 0.62, 0.44];

class MeshBufferBuilder {
  constructor() {
    this.positions = [];
    this.uvs = [];
    this.lights = [];
    this.indices = [];
    this.vertCount = 0;
  }

  pushQuad(v0, v1, v2, v3, uv0, uv1, uv2, uv3, l0, l1, l2, l3, flipDiag = false) {
    const base = this.vertCount;
    this.positions.push(
      v0[0], v0[1], v0[2],
      v1[0], v1[1], v1[2],
      v2[0], v2[1], v2[2],
      v3[0], v3[1], v3[2]
    );
    this.uvs.push(
      uv0[0], uv0[1],
      uv1[0], uv1[1],
      uv2[0], uv2[1],
      uv3[0], uv3[1]
    );
    this.lights.push(
      l0[0], l0[1], l0[2],
      l1[0], l1[1], l1[2],
      l2[0], l2[1], l2[2],
      l3[0], l3[1], l3[2]
    );
    if (flipDiag) {
      this.indices.push(base + 1, base + 2, base + 3, base + 1, base + 3, base);
    } else {
      this.indices.push(base, base + 1, base + 2, base, base + 2, base + 3);
    }
    this.vertCount += 4;
  }

  toGeometry() {
    if (this.vertCount === 0) return null;
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(this.positions, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(this.uvs, 2));
    geo.setAttribute('aLight', new THREE.Float32BufferAttribute(this.lights, 3));
    geo.setIndex(this.indices);
    geo.computeBoundingSphere();
    return geo;
  }
}

export class Chunk {
  constructor(cx, cz) {
    this.cx = cx;
    this.cz = cz;
    this.blocks = new Uint8Array(VOLUME);
    this.skyLight = new Uint8Array(VOLUME);
    this.blockLight = new Uint8Array(VOLUME);
    this.dirty = true;
    this.lightDirty = true;

    this.group = new THREE.Group();
    this.group.position.set(cx * CHUNK_SIZE, 0, cz * CHUNK_SIZE);
    this.opaqueMesh = null;
    this.cutoutMesh = null;
    this.fluidMesh = null;
  }

  index(lx, y, lz) {
    return (y * CHUNK_SIZE + lz) * CHUNK_SIZE + lx;
  }

  getLocal(lx, y, lz) {
    if (lx < 0 || lx >= CHUNK_SIZE || lz < 0 || lz >= CHUNK_SIZE || y < 0 || y >= WORLD_HEIGHT) {
      return BLOCK.AIR;
    }
    return this.blocks[(y * CHUNK_SIZE + lz) * CHUNK_SIZE + lx];
  }

  setLocal(lx, y, lz, id) {
    if (lx < 0 || lx >= CHUNK_SIZE || lz < 0 || lz >= CHUNK_SIZE || y < 0 || y >= WORLD_HEIGHT) {
      return;
    }
    this.blocks[(y * CHUNK_SIZE + lz) * CHUNK_SIZE + lx] = id;
    this.dirty = true;
    this.lightDirty = true;
  }

  getSkyLocal(lx, y, lz) {
    if (y >= WORLD_HEIGHT) return 15;
    if (y < 0) return 0;
    return this.skyLight[(y * CHUNK_SIZE + lz) * CHUNK_SIZE + lx];
  }

  getBlockLightLocal(lx, y, lz) {
    if (y < 0 || y >= WORLD_HEIGHT) return 0;
    return this.blockLight[(y * CHUNK_SIZE + lz) * CHUNK_SIZE + lx];
  }

  computeLighting(world) {
    this.skyLight.fill(0);
    this.blockLight.fill(0);

    // 1. Top-down Skylight column sweep + queue seed
    let qHead = 0;
    let qTail = 0;

    for (let lz = 0; lz < CHUNK_SIZE; lz++) {
      for (let lx = 0; lx < CHUNK_SIZE; lx++) {
        let light = 15;
        for (let y = WORLD_HEIGHT - 1; y >= 0; y--) {
          const idx = (y * CHUNK_SIZE + lz) * CHUNK_SIZE + lx;
          const id = this.blocks[idx];
          if (id !== BLOCK.AIR) {
            const def = BLOCK_DEFS[id];
            if (def?.opaque) {
              light = 0;
            } else if (def?.render === 'leaves' || def?.fluid || id === BLOCK.ICE) {
              light = Math.max(0, light - 2);
            }
          }
          this.skyLight[idx] = light;
          if (light > 0) {
            BFS_QUEUE[qTail++] = idx;
          }
        }
      }
    }

    // Seed skylight from 4 neighbor chunk borders so cave entrances across borders stay smooth
    const nNorth = world.getChunk(this.cx, this.cz - 1);
    const nSouth = world.getChunk(this.cx, this.cz + 1);
    const nWest = world.getChunk(this.cx - 1, this.cz);
    const nEast = world.getChunk(this.cx + 1, this.cz);

    const seedBorderSky = (neighbor, isX, neighborEdge, myEdge) => {
      if (!neighbor || neighbor.lightDirty) return;
      for (let y = 1; y < WORLD_HEIGHT; y++) {
        for (let i = 0; i < CHUNK_SIZE; i++) {
          const nl = isX
            ? neighbor.getSkyLocal(neighborEdge, y, i)
            : neighbor.getSkyLocal(i, y, neighborEdge);
          if (nl <= 1) continue;
          const lx = isX ? myEdge : i;
          const lz = isX ? i : myEdge;
          const idx = (y * CHUNK_SIZE + lz) * CHUNK_SIZE + lx;
          if (!isOpaqueBlock(this.blocks[idx]) && nl - 1 > this.skyLight[idx]) {
            this.skyLight[idx] = nl - 1;
            BFS_QUEUE[qTail++] = idx;
          }
        }
      }
    };

    seedBorderSky(nWest, true, CHUNK_SIZE - 1, 0);
    seedBorderSky(nEast, true, 0, CHUNK_SIZE - 1);
    seedBorderSky(nNorth, false, CHUNK_SIZE - 1, 0);
    seedBorderSky(nSouth, false, 0, CHUNK_SIZE - 1);

    // Flood skylight horizontally & into overhangs
    while (qHead < qTail) {
      const idx = BFS_QUEUE[qHead++];
      const curL = this.skyLight[idx];
      if (curL <= 1) continue;

      const lx = idx & 15;
      const lz = (idx >> 4) & 15;
      const y = idx >> 8;

      for (let d = 0; d < 6; d++) {
        const nx = lx + DIRS6[d][0];
        const ny = y + DIRS6[d][1];
        const nz = lz + DIRS6[d][2];
        if (nx < 0 || nx >= CHUNK_SIZE || nz < 0 || nz >= CHUNK_SIZE || ny < 0 || ny >= WORLD_HEIGHT) continue;
        const nIdx = (ny * CHUNK_SIZE + nz) * CHUNK_SIZE + nx;
        const nId = this.blocks[nIdx];
        if (isOpaqueBlock(nId)) continue;
        const atten = (nId === BLOCK.WATER || BLOCK_DEFS[nId]?.render === 'leaves') ? 2 : 1;
        const nextL = curL - atten;
        if (nextL > this.skyLight[nIdx]) {
          this.skyLight[nIdx] = nextL;
          if (nextL > 1) BFS_QUEUE[qTail++] = nIdx;
        }
      }
    }

    // 2. Block Light (Torches, Glowstone, Lava, Lit Furnace, Glow Shrooms)
    qHead = 0;
    qTail = 0;
    for (let idx = 0; idx < VOLUME; idx++) {
      const emit = getBlockLight(this.blocks[idx]);
      if (emit > 0) {
        this.blockLight[idx] = emit;
        BFS_QUEUE[qTail++] = idx;
      }
    }

    // Also pull block light across the 4 neighbor chunk edges so torches near chunk borders cross seamlessly!
    const seedBorderBlock = (neighbor, isX, neighborEdge, myEdge) => {
      if (!neighbor) return;
      for (let y = 1; y < WORLD_HEIGHT; y++) {
        for (let i = 0; i < CHUNK_SIZE; i++) {
          const nId = isX
            ? neighbor.getLocal(neighborEdge, y, i)
            : neighbor.getLocal(i, y, neighborEdge);
          const nl = Math.max(
            getBlockLight(nId),
            isX
              ? neighbor.getBlockLightLocal(neighborEdge, y, i)
              : neighbor.getBlockLightLocal(i, y, neighborEdge)
          );
          if (nl <= 1) continue;
          const lx = isX ? myEdge : i;
          const lz = isX ? i : myEdge;
          const idx = (y * CHUNK_SIZE + lz) * CHUNK_SIZE + lx;
          if (!isOpaqueBlock(this.blocks[idx]) && nl - 1 > this.blockLight[idx]) {
            this.blockLight[idx] = nl - 1;
            BFS_QUEUE[qTail++] = idx;
          }
        }
      }
    };

    seedBorderBlock(nWest, true, CHUNK_SIZE - 1, 0);
    seedBorderBlock(nEast, true, 0, CHUNK_SIZE - 1);
    seedBorderBlock(nNorth, false, CHUNK_SIZE - 1, 0);
    seedBorderBlock(nSouth, false, 0, CHUNK_SIZE - 1);

    while (qHead < qTail) {
      const idx = BFS_QUEUE[qHead++];
      const curL = this.blockLight[idx];
      if (curL <= 1) continue;

      const lx = idx & 15;
      const lz = (idx >> 4) & 15;
      const y = idx >> 8;

      for (let d = 0; d < 6; d++) {
        const nx = lx + DIRS6[d][0];
        const ny = y + DIRS6[d][1];
        const nz = lz + DIRS6[d][2];
        if (nx < 0 || nx >= CHUNK_SIZE || nz < 0 || nz >= CHUNK_SIZE || ny < 0 || ny >= WORLD_HEIGHT) continue;
        const nIdx = (ny * CHUNK_SIZE + nz) * CHUNK_SIZE + nx;
        if (isOpaqueBlock(this.blocks[nIdx])) continue;
        const nextL = curL - 1;
        if (nextL > this.blockLight[nIdx]) {
          this.blockLight[nIdx] = nextL;
          if (nextL > 1) BFS_QUEUE[qTail++] = nIdx;
        }
      }
    }

    this.lightDirty = false;
  }

  buildMesh(world, textures) {
    if (this.lightDirty) {
      this.computeLighting(world);
    }

    const opaqueBuilder = new MeshBufferBuilder();
    const cutoutBuilder = new MeshBufferBuilder();
    const fluidBuilder = new MeshBufferBuilder();

    const baseWx = this.cx * CHUNK_SIZE;
    const baseWz = this.cz * CHUNK_SIZE;
    const selfBlocks = this.blocks;
    const selfSky = this.skyLight;
    const selfBlk = this.blockLight;

    // Cache 3x3 chunk neighborhood once so inner voxel loop does zero string/Map allocations!
    const grid = new Array(9);
    for (let dz = -1; dz <= 1; dz++) {
      for (let dx = -1; dx <= 1; dx++) {
        grid[(dz + 1) * 3 + (dx + 1)] = (dx === 0 && dz === 0)
          ? this
          : world.getChunk(this.cx + dx, this.cz + dz);
      }
    }

    const fastBlock = (lx, y, lz) => {
      if (y < 0 || y >= WORLD_HEIGHT) return BLOCK.AIR;
      if (lx >= 0 && lx < 16 && lz >= 0 && lz < 16) {
        return selfBlocks[(y << 8) | (lz << 4) | lx];
      }
      const gx = lx < 0 ? 0 : lx >= 16 ? 2 : 1;
      const gz = lz < 0 ? 0 : lz >= 16 ? 2 : 1;
      const ch = grid[gz * 3 + gx];
      return ch ? ch.blocks[(y << 8) | ((lz & 15) << 4) | (lx & 15)] : BLOCK.AIR;
    };

    const fastSky = (lx, y, lz) => {
      if (y >= WORLD_HEIGHT) return 15;
      if (y < 0) return 0;
      if (lx >= 0 && lx < 16 && lz >= 0 && lz < 16) {
        return selfSky[(y << 8) | (lz << 4) | lx];
      }
      const gx = lx < 0 ? 0 : lx >= 16 ? 2 : 1;
      const gz = lz < 0 ? 0 : lz >= 16 ? 2 : 1;
      const ch = grid[gz * 3 + gx];
      return ch ? ch.skyLight[(y << 8) | ((lz & 15) << 4) | (lx & 15)] : 15;
    };

    const fastBlkLight = (lx, y, lz) => {
      if (y < 0 || y >= WORLD_HEIGHT) return 0;
      if (lx >= 0 && lx < 16 && lz >= 0 && lz < 16) {
        return selfBlk[(y << 8) | (lz << 4) | lx];
      }
      const gx = lx < 0 ? 0 : lx >= 16 ? 2 : 1;
      const gz = lz < 0 ? 0 : lz >= 16 ? 2 : 1;
      const ch = grid[gz * 3 + gx];
      return ch ? ch.blockLight[(y << 8) | ((lz & 15) << 4) | (lx & 15)] : 0;
    };

    const isAOBlockerLocal = (lx, y, lz) => {
      const bid = fastBlock(lx, y, lz);
      if (bid === BLOCK.AIR) return false;
      const d = BLOCK_DEFS[bid];
      return Boolean(d && (d.opaque || d.render === 'leaves'));
    };

    const vPos = [[0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0]];
    const vUV = [[0, 0], [0, 0], [0, 0], [0, 0]];
    const vLight = [[0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0]];
    const aoVals = [0, 0, 0, 0];

    for (let y = 0; y < WORLD_HEIGHT; y++) {
      for (let lz = 0; lz < CHUNK_SIZE; lz++) {
        const wz = baseWz + lz;
        for (let lx = 0; lx < CHUNK_SIZE; lx++) {
          const id = selfBlocks[(y << 8) | (lz << 4) | lx];
          if (id === BLOCK.AIR) continue;

          const def = BLOCK_DEFS[id];
          if (!def) continue;
          const wx = baseWx + lx;

          // Cross-quad flora (Flowers, Tall Grass, Mushrooms, Dead Bush)
          if (def.render === 'cross') {
            this._emitCrossFlora(cutoutBuilder, lx, y, lz, wx, wz, id, world, textures);
            continue;
          }

          // 3D Standing Voxel Torch
          if (def.render === 'torch') {
            this._emitTorch(cutoutBuilder, lx, y, lz, wx, wz, world, textures);
            continue;
          }

          const isFluid = def.render === 'fluid';
          const isFluidSolid = def.render === 'fluid_solid'; // Ice
          const isLeaves = def.render === 'leaves';
          const isGlass = def.render === 'glass';
          const isCactus = def.render === 'cactus';

          const targetBuilder = (isFluid || isFluidSolid)
            ? fluidBuilder
            : (isLeaves || isGlass || isCactus)
              ? cutoutBuilder
              : opaqueBuilder;

          // Lower fluid surface slightly when air is above
          const topHeight = (isFluid && fastBlock(lx, y + 1, lz) !== id) ? 0.88 : 1.0;
          const inset = isCactus ? 0.0625 : 0.0; // Authentic 1/16th cactus inset!

          for (let f = 0; f < 6; f++) {
            const face = CUBE_FACES[f];
            const nlx = lx + face.dir[0];
            const nly = y + face.dir[1];
            const nlz = lz + face.dir[2];

            const neighborId = fastBlock(nlx, nly, nlz);

            // Face culling logic
            if (!isCactus || f < 2) {
              if (isFluid) {
                if (neighborId === id || isOpaqueBlock(neighborId)) continue;
              } else if (isFluidSolid || isGlass) {
                if (neighborId === id || isOpaqueBlock(neighborId)) continue;
              } else if (isLeaves) {
                if (isOpaqueBlock(neighborId)) continue;
              } else {
                if (isOpaqueBlock(neighborId)) continue;
              }
            }

            const tile = textures.getBlockFaceUV(id, face.name);
            const { u0, v0, u1, v1 } = tile;
            const selfEmit = getBlockLight(id);

            for (let vi = 0; vi < 4; vi++) {
              const vd = face.verts[vi];
              let px = lx + vd.pos[0];
              let py = y + (vd.pos[1] === 1 ? topHeight : 0);
              let pz = lz + vd.pos[2];

              if (inset > 0 && f >= 2) {
                px -= face.dir[0] * inset;
                pz -= face.dir[2] * inset;
              }

              vPos[vi][0] = px; vPos[vi][1] = py; vPos[vi][2] = pz;
              vUV[vi][0] = vd.uv[0] === 0 ? u0 : u1;
              vUV[vi][1] = vd.uv[1] === 0 ? v0 : v1;

              if (selfEmit >= 13) {
                aoVals[vi] = 0;
                vLight[vi][0] = 1.0;
                vLight[vi][1] = fastSky(nlx, nly, nlz) / 15.0;
                vLight[vi][2] = 1.0;
              } else {
                const c1 = vd.c[0];
                const c2 = vd.c[1];
                const s1x = nlx + face.t1[0] * c1;
                const s1y = nly + face.t1[1] * c1;
                const s1z = nlz + face.t1[2] * c1;

                const s2x = nlx + face.t2[0] * c2;
                const s2y = nly + face.t2[1] * c2;
                const s2z = nlz + face.t2[2] * c2;

                const cx = nlx + face.t1[0] * c1 + face.t2[0] * c2;
                const cy = nly + face.t1[1] * c1 + face.t2[1] * c2;
                const cz = nlz + face.t1[2] * c1 + face.t2[2] * c2;

                const b1 = isAOBlockerLocal(s1x, s1y, s1z) ? 1 : 0;
                const b2 = isAOBlockerLocal(s2x, s2y, s2z) ? 1 : 0;
                const bc = (b1 && b2) ? 1 : (isAOBlockerLocal(cx, cy, cz) ? 1 : 0);
                const occ = (b1 && b2) ? 3 : (b1 + b2 + bc);
                aoVals[vi] = occ;

                let skySum = fastSky(nlx, nly, nlz);
                let blkSum = fastBlkLight(nlx, nly, nlz);
                let count = 1;

                if (!b1) {
                  skySum += fastSky(s1x, s1y, s1z);
                  blkSum += fastBlkLight(s1x, s1y, s1z);
                  count++;
                }
                if (!b2) {
                  skySum += fastSky(s2x, s2y, s2z);
                  blkSum += fastBlkLight(s2x, s2y, s2z);
                  count++;
                }
                if (!(b1 && b2) && !bc) {
                  skySum += fastSky(cx, cy, cz);
                  blkSum += fastBlkLight(cx, cy, cz);
                  count++;
                }

                vLight[vi][0] = AO_CURVE[occ] * face.shade;
                vLight[vi][1] = (skySum / count) / 15.0;
                vLight[vi][2] = Math.max(selfEmit / 15.0, (blkSum / count) / 15.0);
              }
            }

            const flip = (aoVals[0] + aoVals[2]) > (aoVals[1] + aoVals[3]);
            targetBuilder.pushQuad(
              vPos[0], vPos[1], vPos[2], vPos[3],
              vUV[0], vUV[1], vUV[2], vUV[3],
              vLight[0], vLight[1], vLight[2], vLight[3],
              flip
            );
          }
        }
      }
    }

    this._replaceMeshes(
      opaqueBuilder.toGeometry(),
      cutoutBuilder.toGeometry(),
      fluidBuilder.toGeometry(),
      textures
    );
    this.dirty = false;
  }

  _emitCrossFlora(builder, lx, y, lz, wx, wz, id, world, textures) {
    const tile = textures.getBlockFaceUV(id, 'all');
    const { u0, v0, u1, v1 } = tile;
    const sky = world.getSkyLight(wx, y, wz) / 15.0;
    const blk = Math.max(getBlockLight(id), world.getBlockLight(wx, y, wz)) / 15.0;
    const l = [0.92, sky, blk];

    // Slight deterministic offset so wildflowers/grass look organic
    const jx = (((wx * 73856093) ^ (wz * 19349663)) & 7) / 48 - 0.07;
    const jz = (((wx * 83492791) ^ (wz * 2971215073)) & 7) / 48 - 0.07;
    const x0 = lx + 0.08 + jx;
    const x1 = lx + 0.92 + jx;
    const z0 = lz + 0.08 + jz;
    const z1 = lz + 0.92 + jz;

    builder.pushQuad(
      [x0, y, z0], [x1, y, z1], [x1, y + 0.92, z1], [x0, y + 0.92, z0],
      [u0, v0], [u1, v0], [u1, v1], [u0, v1],
      l, l, l, l
    );
    builder.pushQuad(
      [x0, y, z1], [x1, y, z0], [x1, y + 0.92, z0], [x0, y + 0.92, z1],
      [u0, v0], [u1, v0], [u1, v1], [u0, v1],
      l, l, l, l
    );
  }

  _emitTorch(builder, lx, y, lz, wx, wz, world, textures) {
    const tile = textures.getTileUV('torch');
    // Map narrow center strip of torch tile so 3D slim torch has crisp wood handle + glowing flame head!
    const uSpan = tile.u1 - tile.u0;
    const vSpan = tile.v1 - tile.v0;
    const su0 = tile.u0 + uSpan * (6 / 16);
    const su1 = tile.u0 + uSpan * (10 / 16);
    const sv0 = tile.v0;
    const sv1 = tile.v0 + vSpan * (13 / 16);

    const sky = world.getSkyLight(wx, y, wz) / 15.0;
    const lSide = [0.95, sky, 1.0];
    const lTop = [1.0, sky, 1.0];

    const x0 = lx + 0.43;
    const x1 = lx + 0.57;
    const z0 = lz + 0.43;
    const z1 = lz + 0.57;
    const h = y + 0.68;

    // 4 sides of slim 3D torch post
    builder.pushQuad(
      [x0, y, z1], [x1, y, z1], [x1, h, z1], [x0, h, z1],
      [su0, sv0], [su1, sv0], [su1, sv1], [su0, sv1],
      lSide, lSide, lTop, lTop
    );
    builder.pushQuad(
      [x1, y, z0], [x0, y, z0], [x0, h, z0], [x1, h, z0],
      [su0, sv0], [su1, sv0], [su1, sv1], [su0, sv1],
      lSide, lSide, lTop, lTop
    );
    builder.pushQuad(
      [x1, y, z1], [x1, y, z0], [x1, h, z0], [x1, h, z1],
      [su0, sv0], [su1, sv0], [su1, sv1], [su0, sv1],
      lSide, lSide, lTop, lTop
    );
    builder.pushQuad(
      [x0, y, z0], [x0, y, z1], [x0, h, z1], [x0, h, z0],
      [su0, sv0], [su1, sv0], [su1, sv1], [su0, sv1],
      lSide, lSide, lTop, lTop
    );
    // Glowing top ember cap
    const tu0 = tile.u0 + uSpan * (7 / 16);
    const tu1 = tile.u0 + uSpan * (9 / 16);
    const tv0 = tile.v0 + vSpan * (10 / 16);
    const tv1 = tile.v0 + vSpan * (12 / 16);
    builder.pushQuad(
      [x0, h, z1], [x1, h, z1], [x1, h, z0], [x0, h, z0],
      [tu0, tv0], [tu1, tv0], [tu1, tv1], [tu0, tv1],
      lTop, lTop, lTop, lTop
    );
  }

  _replaceMeshes(opaqueGeo, cutoutGeo, fluidGeo, textures) {
    if (this.opaqueMesh) {
      this.group.remove(this.opaqueMesh);
      this.opaqueMesh.geometry.dispose();
      this.opaqueMesh = null;
    }
    if (this.cutoutMesh) {
      this.group.remove(this.cutoutMesh);
      this.cutoutMesh.geometry.dispose();
      this.cutoutMesh = null;
    }
    if (this.fluidMesh) {
      this.group.remove(this.fluidMesh);
      this.fluidMesh.geometry.dispose();
      this.fluidMesh = null;
    }

    if (opaqueGeo) {
      this.opaqueMesh = new THREE.Mesh(opaqueGeo, textures.opaqueMaterial);
      this.opaqueMesh.renderOrder = 0;
      this.group.add(this.opaqueMesh);
    }
    if (cutoutGeo) {
      this.cutoutMesh = new THREE.Mesh(cutoutGeo, textures.cutoutMaterial);
      this.cutoutMesh.renderOrder = 1;
      this.group.add(this.cutoutMesh);
    }
    if (fluidGeo) {
      this.fluidMesh = new THREE.Mesh(fluidGeo, textures.fluidMaterial);
      this.fluidMesh.renderOrder = 2;
      this.group.add(this.fluidMesh);
    }
  }

  dispose() {
    if (this.opaqueMesh) this.opaqueMesh.geometry.dispose();
    if (this.cutoutMesh) this.cutoutMesh.geometry.dispose();
    if (this.fluidMesh) this.fluidMesh.geometry.dispose();
    this.group.clear();
  }
}
