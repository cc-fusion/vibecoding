import { BLOCK } from './blocks.js';
import { SeededNoise } from './noise.js';

export const CHUNK_SIZE = 16;
export const WORLD_HEIGHT = 96;
export const SEA_LEVEL = 28;

export const BIOME = {
  OCEAN: 'Ocean Shore',
  PLAINS: 'Emerald Plains',
  FOREST: 'Whispering Woods',
  DESERT: 'Golden Dunes',
  TAIGA: 'Snowy Taiga',
  MOUNTAINS: 'Craggy Peaks',
};

export class TerrainGenerator {
  constructor(seed = 'TerraCraft') {
    this.seed = seed;
    this.noise = new SeededNoise(seed);
    this._columnCache = new Map();
  }

  getColumnInfo(wx, wz) {
    const key = `${wx},${wz}`;
    if (this._columnCache.has(key)) {
      return this._columnCache.get(key);
    }
    if (this._columnCache.size > 16384) {
      this._columnCache.clear();
    }

    const n = this.noise;
    // Domain warp for natural organic coastlines and biome borders
    const warpX = n.noise2D(wx * 0.006, wz * 0.006) * 14;
    const warpZ = n.noise2D(wx * 0.006 + 91.3, wz * 0.006 - 47.7) * 14;
    const sx = wx + warpX;
    const sz = wz + warpZ;

    const temperature = n.fbm2D(sx * 0.0022 + 120, sz * 0.0022 - 80, 3, 0.5, 2.0); // [-1, 1]
    const humidity = n.fbm2D(sx * 0.0025 - 210, sz * 0.0025 + 150, 3, 0.5, 2.0); // [-1, 1]
    const continental = n.fbm2D(wx * 0.0032, wz * 0.0032, 4, 0.52, 2.0); // [-1, 1]
    const detail = n.fbm2D(wx * 0.016, wz * 0.016, 3, 0.5, 2.05);
    const ridge = n.ridged2D(wx * 0.0055 + 31, wz * 0.0055 - 19, 4, 0.5, 2.1); // [0, 1]

    // Base elevation
    let heightF = SEA_LEVEL + 5 + continental * 16 + detail * 4.5;

    // Mountain uplift where continental + ridge align
    const mountainFactor = Math.max(0, (continental + 0.18) * 0.85) * Math.pow(ridge, 2.1);
    heightF += mountainFactor * 36;

    // Smooth valleys / lake basins
    if (continental < -0.18) {
      heightF -= (-0.18 - continental) * 18;
    }

    const height = Math.max(5, Math.min(WORLD_HEIGHT - 8, Math.round(heightF)));

    // Classify biome
    let biome = BIOME.PLAINS;
    if (height <= SEA_LEVEL + 1 && continental < -0.12) {
      biome = BIOME.OCEAN;
    } else if (mountainFactor > 0.34 || height >= 54) {
      biome = BIOME.MOUNTAINS;
    } else if (temperature < -0.24) {
      biome = BIOME.TAIGA;
    } else if (temperature > 0.28 && humidity < 0.05) {
      biome = BIOME.DESERT;
    } else if (humidity > 0.08) {
      biome = BIOME.FOREST;
    } else {
      biome = BIOME.PLAINS;
    }

    const info = { height, biome, temperature, humidity, mountainFactor };
    this._columnCache.set(key, info);
    return info;
  }

  _isCave(wx, wy, wz, surfaceY) {
    if (wy <= 2 || wy > surfaceY - 1) return false;
    // Allow dramatic surface cave entrances occasionally on hillsides
    const depth = surfaceY - wy;
    if (depth < 4) {
      const entrance = this.noise.noise2D(wx * 0.025 + 400, wz * 0.025 - 300);
      if (entrance < 0.58) return false;
    }
    // Two intersecting 3D noise fields create winding tunnels + caverns
    // Short-circuit: n1*n1 + n2*n2 < 0.032 is only possible when |n1| < 0.179
    const n1 = this.noise.noise3D(wx * 0.042, wy * 0.055, wz * 0.042);
    if (n1 > -0.18 && n1 < 0.18) {
      const n2 = this.noise.noise3D(wx * 0.042 + 73.1, wy * 0.055 + 19.7, wz * 0.042 - 51.4);
      if (n1 * n1 + n2 * n2 < 0.032) return true;
    }

    // Deeper spacious caverns
    if (wy < 26) {
      const cavern = this.noise.noise3D(wx * 0.028 - 120, wy * 0.038, wz * 0.028 + 88);
      if (cavern > 0.66) return true;
    }
    return false;
  }

  _getTreeSpecAt(wx, wz) {
    // Fast O(1) hash check first: max tree probability in any biome is 0.032
    const h = this.noise.coordHash2D(wx, wz, 701);
    if (h >= 0.032) return null;

    const col = this.getColumnInfo(wx, wz);
    const { height, biome } = col;
    if (height <= SEA_LEVEL + 1 || height >= WORLD_HEIGHT - 14) return null;

    // Prevent trees right on top of cave openings
    if (this._isCave(wx, height, wz, height)) return null;

    if (biome === BIOME.FOREST) {
      if (h < 0.032) {
        const birch = this.noise.coordHash2D(wx, wz, 702) < 0.32;
        return { type: birch ? 'birch' : 'oak', baseY: height + 1 };
      }
    } else if (biome === BIOME.PLAINS) {
      if (h < 0.0055) {
        const birch = this.noise.coordHash2D(wx, wz, 702) < 0.25;
        return { type: birch ? 'birch' : 'oak', baseY: height + 1 };
      }
    } else if (biome === BIOME.TAIGA) {
      if (h < 0.022) {
        return { type: 'spruce', baseY: height + 1 };
      }
    } else if (biome === BIOME.MOUNTAINS && height < 56) {
      if (h < 0.007) {
        return { type: 'spruce', baseY: height + 1 };
      }
    } else if (biome === BIOME.DESERT) {
      if (h < 0.009) {
        return { type: 'cactus', baseY: height + 1 };
      }
    }
    return null;
  }

  populateChunk(chunk) {
    const cx0 = chunk.cx * CHUNK_SIZE;
    const cz0 = chunk.cz * CHUNK_SIZE;
    const n = this.noise;

    // 1. Terrain strata, caves, water, lava, ores
    for (let lz = 0; lz < CHUNK_SIZE; lz++) {
      const wz = cz0 + lz;
      for (let lx = 0; lx < CHUNK_SIZE; lx++) {
        const wx = cx0 + lx;
        const col = this.getColumnInfo(wx, wz);
        const surfY = col.height;
        const biome = col.biome;

        for (let y = 0; y < WORLD_HEIGHT; y++) {
          if (y === 0) {
            chunk.setLocal(lx, y, lz, BLOCK.BEDROCK);
            continue;
          }
          if (y === 1 && n.coordHash3D(wx, y, wz, 11) < 0.55) {
            chunk.setLocal(lx, y, lz, BLOCK.BEDROCK);
            continue;
          }

          if (y <= surfY) {
            // Check 3D caves
            if (this._isCave(wx, y, wz, surfY)) {
              if (y <= 7) {
                chunk.setLocal(lx, y, lz, BLOCK.LAVA);
              } else {
                chunk.setLocal(lx, y, lz, BLOCK.AIR);
              }
              continue;
            }

            let blockId = BLOCK.STONE;

            if (y === surfY) {
              if (surfY < SEA_LEVEL - 1) {
                const bedPick = n.coordHash2D(wx, wz, 33);
                blockId = bedPick < 0.25 ? BLOCK.CLAY : bedPick < 0.55 ? BLOCK.SAND : BLOCK.GRAVEL;
              } else if (surfY <= SEA_LEVEL + 1 && biome !== BIOME.TAIGA) {
                blockId = biome === BIOME.MOUNTAINS ? BLOCK.GRAVEL : BLOCK.SAND;
              } else if (biome === BIOME.DESERT) {
                blockId = BLOCK.SAND;
              } else if (biome === BIOME.TAIGA) {
                blockId = BLOCK.SNOW_GRASS;
              } else if (biome === BIOME.MOUNTAINS) {
                if (surfY >= 60) blockId = BLOCK.SNOW;
                else if (surfY >= 50) blockId = n.coordHash2D(wx, wz, 44) < 0.65 ? BLOCK.STONE : BLOCK.GRAVEL;
                else blockId = BLOCK.GRASS;
              } else {
                blockId = BLOCK.GRASS;
              }
            } else if (y >= surfY - 3) {
              if (biome === BIOME.DESERT || (surfY <= SEA_LEVEL + 1 && biome !== BIOME.TAIGA)) {
                blockId = y === surfY - 3 ? BLOCK.SANDSTONE : BLOCK.SAND;
              } else if (biome === BIOME.MOUNTAINS && surfY >= 52) {
                blockId = y >= surfY - 1 && surfY >= 62 ? BLOCK.SNOW : BLOCK.STONE;
              } else {
                blockId = BLOCK.DIRT;
              }
            } else {
              // Underground stone & depth-stratified ore veins
              blockId = this._pickUndergroundBlock(wx, y, wz);
            }

            chunk.setLocal(lx, y, lz, blockId);
          } else if (y <= SEA_LEVEL) {
            if (y === SEA_LEVEL && biome === BIOME.TAIGA) {
              chunk.setLocal(lx, y, lz, BLOCK.ICE);
            } else {
              chunk.setLocal(lx, y, lz, BLOCK.WATER);
            }
          }
        }

        // Surface flora (flowers, tall grass, dead bushes)
        if (surfY > SEA_LEVEL + 1 && chunk.getLocal(lx, surfY, lz) !== BLOCK.AIR && chunk.getLocal(lx, surfY + 1, lz) === BLOCK.AIR) {
          const ground = chunk.getLocal(lx, surfY, lz);
          const fh = n.coordHash2D(wx, wz, 905);
          if (ground === BLOCK.GRASS) {
            if (fh < 0.11) chunk.setLocal(lx, surfY + 1, lz, BLOCK.TALL_GRASS);
            else if (fh < 0.125) chunk.setLocal(lx, surfY + 1, lz, BLOCK.DANDELION);
            else if (fh < 0.138) chunk.setLocal(lx, surfY + 1, lz, BLOCK.POPPY);
            else if (fh < 0.145 && biome === BIOME.FOREST) chunk.setLocal(lx, surfY + 1, lz, BLOCK.BLUE_ORCHID);
          } else if (ground === BLOCK.SAND && biome === BIOME.DESERT) {
            if (fh < 0.015) chunk.setLocal(lx, surfY + 1, lz, BLOCK.DEAD_BUSH);
          }
        }

        // Cave floor luminous mushrooms for atmospheric underground discovery
        for (let y = 8; y < Math.min(surfY - 5, 38); y++) {
          if (chunk.getLocal(lx, y, lz) === BLOCK.AIR && chunk.getLocal(lx, y - 1, lz) === BLOCK.STONE) {
            if (n.coordHash3D(wx, y, wz, 1337) < 0.012) {
              chunk.setLocal(lx, y, lz, BLOCK.GLOW_SHROOM);
            }
          }
        }
      }
    }

    // 2. Seamless Cross-Chunk Trees & Cacti (scan 3-block margin around chunk)
    const MARGIN = 3;
    for (let tz = -MARGIN; tz < CHUNK_SIZE + MARGIN; tz++) {
      const wz = cz0 + tz;
      for (let tx = -MARGIN; tx < CHUNK_SIZE + MARGIN; tx++) {
        const wx = cx0 + tx;
        const spec = this._getTreeSpecAt(wx, wz);
        if (!spec) continue;
        this._stampStructureInChunk(chunk, tx, spec.baseY, tz, wx, wz, spec.type);
      }
    }
  }

  _pickUndergroundBlock(wx, y, wz) {
    const n = this.noise;
    // Ore & gravel cluster noise
    const vein = n.noise3D(wx * 0.15 + 17, y * 0.15 - 23, wz * 0.15 + 41);
    if (vein > 0.62) {
      const selector = n.coordHash3D(wx >> 1, y >> 1, wz >> 1, 505);
      if (y <= 15 && selector < 0.14) return BLOCK.DIAMOND_ORE;
      if (y <= 28 && selector < 0.30) return BLOCK.GOLD_ORE;
      if (y <= 54 && selector < 0.62) return BLOCK.IRON_ORE;
      return BLOCK.COAL_ORE;
    }
    if (vein < -0.70) return BLOCK.GRAVEL;
    return BLOCK.STONE;
  }

  _stampStructureInChunk(chunk, lx, baseY, lz, wx, wz, type) {
    const setIfInside = (x, y, z, blockId, onlyAir = false) => {
      if (x < 0 || x >= CHUNK_SIZE || z < 0 || z >= CHUNK_SIZE || y < 1 || y >= WORLD_HEIGHT - 1) return;
      if (onlyAir) {
        const cur = chunk.getLocal(x, y, z);
        if (
          cur !== BLOCK.AIR &&
          cur !== BLOCK.TALL_GRASS &&
          cur !== BLOCK.POPPY &&
          cur !== BLOCK.DANDELION &&
          cur !== BLOCK.BLUE_ORCHID
        ) {
          return;
        }
      }
      chunk.setLocal(x, y, z, blockId);
    };

    const hVar = this.noise.coordHash2D(wx, wz, 888);

    if (type === 'cactus') {
      const ch = 2 + Math.floor(hVar * 2.5);
      // Do not place cactus directly adjacent to solid blocks horizontally
      for (let i = 0; i < ch; i++) {
        setIfInside(lx, baseY + i, lz, BLOCK.CACTUS, false);
      }
      return;
    }

    if (type === 'oak' || type === 'birch') {
      const logId = type === 'birch' ? BLOCK.BIRCH_LOG : BLOCK.OAK_LOG;
      const leafId = type === 'birch' ? BLOCK.BIRCH_LEAVES : BLOCK.OAK_LEAVES;
      const trunkH = 4 + Math.floor(hVar * 2.6);

      // Canopy first (onlyAir = true so trunks win)
      for (let dy = trunkH - 2; dy <= trunkH + 1; dy++) {
        const radius = dy >= trunkH ? 1 : 2;
        for (let dz = -radius; dz <= radius; dz++) {
          for (let dx = -radius; dx <= radius; dx++) {
            if (Math.abs(dx) === radius && Math.abs(dz) === radius) {
              if (dy > trunkH - 1 || this.noise.coordHash3D(wx + dx, baseY + dy, wz + dz, 91) < 0.45) {
                continue;
              }
            }
            setIfInside(lx + dx, baseY + dy, lz + dz, leafId, true);
          }
        }
      }
      // Trunk
      setIfInside(lx, baseY - 1, lz, BLOCK.DIRT, false);
      for (let i = 0; i < trunkH; i++) {
        setIfInside(lx, baseY + i, lz, logId, false);
      }
      return;
    }

    if (type === 'spruce') {
      const trunkH = 6 + Math.floor(hVar * 3);
      for (let dy = 2; dy <= trunkH + 1; dy++) {
        const fromTop = trunkH + 1 - dy;
        const radius = fromTop <= 1 ? (fromTop === 0 ? 0 : 1) : (fromTop % 2 === 0 ? 1 : 2);
        for (let dz = -radius; dz <= radius; dz++) {
          for (let dx = -radius; dx <= radius; dx++) {
            if (radius > 1 && Math.abs(dx) === radius && Math.abs(dz) === radius) continue;
            setIfInside(lx + dx, baseY + dy, lz + dz, BLOCK.SPRUCE_LEAVES, true);
          }
        }
      }
      setIfInside(lx, baseY - 1, lz, BLOCK.DIRT, false);
      for (let i = 0; i < trunkH; i++) {
        setIfInside(lx, baseY + i, lz, BLOCK.SPRUCE_LOG, false);
      }
    }
  }

  findSpawnPosition() {
    // Spiral search outward from (0,0) for a scenic land spot above sea level
    let best = { x: 0.5, y: 45, z: 0.5, score: -999 };
    for (let r = 0; r <= 96; r += 4) {
      const steps = Math.max(1, r * 2);
      for (let s = 0; s < steps; s++) {
        const angle = (s / steps) * Math.PI * 2;
        const wx = Math.round(Math.cos(angle) * r);
        const wz = Math.round(Math.sin(angle) * r);
        const col = this.getColumnInfo(wx, wz);
        if (col.height <= SEA_LEVEL + 1 || col.height > 54) continue;
        if (this._isCave(wx, col.height, wz, col.height)) continue;
        if (this._getTreeSpecAt(wx, wz)) continue;

        let score = 50 - r * 0.15;
        if (col.biome === BIOME.PLAINS || col.biome === BIOME.FOREST) score += 25;
        if (score > best.score) {
          best = { x: wx + 0.5, y: col.height + 1.05, z: wz + 0.5, score };
          if (score > 65) return best;
        }
      }
    }
    const fallbackCol = this.getColumnInfo(0, 0);
    return { x: 0.5, y: Math.max(SEA_LEVEL + 2, fallbackCol.height + 1.05), z: 0.5 };
  }
}
