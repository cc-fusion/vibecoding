import * as THREE from 'three';
import { BLOCK, BLOCK_DEFS, SMELTING_RECIPES, getBlockLight, getDef } from './blocks.js';
import { Chunk } from './chunk.js';
import { CHUNK_SIZE, SEA_LEVEL, TerrainGenerator, WORLD_HEIGHT } from './terrain.js';

export class World {
  constructor(scene, textures, seed = 'TerraCraft', savedEdits = null, savedFurnaces = null) {
    this.scene = scene;
    this.textures = textures;
    this.seed = seed;
    this.generator = new TerrainGenerator(seed);

    this.chunks = new Map(); // "cx,cz" -> Chunk
    this.worldGroup = new THREE.Group();
    this.scene.add(this.worldGroup);

    // Persistent delta edits: Map<"cx,cz", Map<idx, blockId>>
    this.edits = new Map();
    if (savedEdits) {
      this._deserializeEdits(savedEdits);
    }

    // Active furnaces: Map<"x,y,z", { inputId, inputCount, fuelId, fuelCount, outputId, outputCount, burnTime, maxBurnTime, progress, lit }>
    this.furnaces = new Map();
    if (savedFurnaces) {
      for (const [k, v] of Object.entries(savedFurnaces)) {
        this.furnaces.set(k, { ...v });
      }
    }

    // Active primed TNT entities
    this.primedTnts = [];
    this.fluidQueue = [];
    this._fluidTimer = 0;

    this.renderDistance = 5;
    this._loadQueue = [];
    this._lastCenterCx = null;
    this._lastCenterCz = null;
  }

  chunkKey(cx, cz) {
    return `${cx},${cz}`;
  }

  worldToChunk(wx, wz) {
    const cx = Math.floor(wx / CHUNK_SIZE);
    const cz = Math.floor(wz / CHUNK_SIZE);
    const lx = ((wx % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
    const lz = ((wz % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
    return { cx, cz, lx, lz };
  }

  getChunk(cx, cz) {
    return this.chunks.get(`${cx},${cz}`) || null;
  }

  getBlock(wx, wy, wz) {
    wx = Math.floor(wx);
    wy = Math.floor(wy);
    wz = Math.floor(wz);
    if (wy < 0 || wy >= WORLD_HEIGHT) return BLOCK.AIR;
    const cx = Math.floor(wx / CHUNK_SIZE);
    const cz = Math.floor(wz / CHUNK_SIZE);
    const chunk = this.chunks.get(`${cx},${cz}`);
    if (!chunk) return BLOCK.AIR;
    const lx = wx - cx * CHUNK_SIZE;
    const lz = wz - cz * CHUNK_SIZE;
    return chunk.blocks[(wy * CHUNK_SIZE + lz) * CHUNK_SIZE + lx];
  }

  getSkyLight(wx, wy, wz) {
    if (wy >= WORLD_HEIGHT) return 15;
    if (wy < 0) return 0;
    const cx = Math.floor(wx / CHUNK_SIZE);
    const cz = Math.floor(wz / CHUNK_SIZE);
    const chunk = this.chunks.get(`${cx},${cz}`);
    if (!chunk) return 15;
    const lx = wx - cx * CHUNK_SIZE;
    const lz = wz - cz * CHUNK_SIZE;
    return chunk.getSkyLocal(lx, wy, lz);
  }

  getBlockLight(wx, wy, wz) {
    if (wy < 0 || wy >= WORLD_HEIGHT) return 0;
    const cx = Math.floor(wx / CHUNK_SIZE);
    const cz = Math.floor(wz / CHUNK_SIZE);
    const chunk = this.chunks.get(`${cx},${cz}`);
    if (!chunk) return 0;
    const lx = wx - cx * CHUNK_SIZE;
    const lz = wz - cz * CHUNK_SIZE;
    return chunk.getBlockLightLocal(lx, wy, lz);
  }

  getBiomeAt(wx, wz) {
    return this.generator.getColumnInfo(Math.floor(wx), Math.floor(wz)).biome;
  }

  getSurfaceHeight(wx, wz) {
    wx = Math.floor(wx);
    wz = Math.floor(wz);
    const chunk = this.getChunk(Math.floor(wx / CHUNK_SIZE), Math.floor(wz / CHUNK_SIZE));
    if (chunk) {
      for (let y = WORLD_HEIGHT - 1; y >= 1; y--) {
        const id = this.getBlock(wx, y, wz);
        if (id !== BLOCK.AIR && BLOCK_DEFS[id]?.solid) return y;
      }
    }
    return this.generator.getColumnInfo(wx, wz).height;
  }

  ensureChunkGenerated(cx, cz) {
    const key = `${cx},${cz}`;
    let chunk = this.chunks.get(key);
    if (chunk) return chunk;

    chunk = new Chunk(cx, cz);
    this.generator.populateChunk(chunk);

    // Apply saved delta edits for this chunk if any
    const chunkEdits = this.edits.get(key);
    if (chunkEdits) {
      for (const [idx, blockId] of chunkEdits.entries()) {
        chunk.blocks[idx] = blockId;
      }
    }

    this.chunks.set(key, chunk);
    this.worldGroup.add(chunk.group);

    // Mark immediate 4 neighbors dirty so seamless chunk border culling & lighting update
    const neighbors = [
      this.getChunk(cx - 1, cz),
      this.getChunk(cx + 1, cz),
      this.getChunk(cx, cz - 1),
      this.getChunk(cx, cz + 1),
    ];
    for (const n of neighbors) {
      if (n) {
        n.lightDirty = true;
        n.dirty = true;
      }
    }
    return chunk;
  }

  // Generate an initial safe area synchronously before spawning player
  preloadAround(wx, wz, radius = 2) {
    const centerCx = Math.floor(wx / CHUNK_SIZE);
    const centerCz = Math.floor(wz / CHUNK_SIZE);
    for (let dz = -radius; dz <= radius; dz++) {
      for (let dx = -radius; dx <= radius; dx++) {
        this.ensureChunkGenerated(centerCx + dx, centerCz + dz);
      }
    }
    for (let dz = -radius; dz <= radius; dz++) {
      for (let dx = -radius; dx <= radius; dx++) {
        const c = this.getChunk(centerCx + dx, centerCz + dz);
        if (c) c.computeLighting(this);
      }
    }
    for (let dz = -radius; dz <= radius; dz++) {
      for (let dx = -radius; dx <= radius; dx++) {
        const c = this.getChunk(centerCx + dx, centerCz + dz);
        if (c && c.dirty) c.buildMesh(this, this.textures);
      }
    }
  }

  setBlock(wx, wy, wz, id, { recordEdit = true, immediate = true } = {}) {
    wx = Math.floor(wx);
    wy = Math.floor(wy);
    wz = Math.floor(wz);
    if (wy < 0 || wy >= WORLD_HEIGHT) return false;

    const { cx, cz, lx, lz } = this.worldToChunk(wx, wz);
    const chunk = this.ensureChunkGenerated(cx, cz);
    const prevId = chunk.getLocal(lx, wy, lz);
    if (prevId === id) return false;

    chunk.setLocal(lx, wy, lz, id);

    if (recordEdit) {
      const cKey = `${cx},${cz}`;
      let map = this.edits.get(cKey);
      if (!map) {
        map = new Map();
        this.edits.set(cKey, map);
      }
      map.set(chunk.index(lx, wy, lz), id);
    }

    // If a plant/torch above just lost its supporting block, pop it off cleanly
    if (id === BLOCK.AIR && wy + 1 < WORLD_HEIGHT) {
      const above = this.getBlock(wx, wy + 1, wz);
      const aboveDef = BLOCK_DEFS[above];
      if (aboveDef && (aboveDef.render === 'cross' || above === BLOCK.TORCH || above === BLOCK.CACTUS)) {
        this.setBlock(wx, wy + 1, wz, BLOCK.AIR, { recordEdit, immediate: false });
      }
    }

    // Check adjacent water flow when opening air next to water at/below sea level
    if (id === BLOCK.AIR) {
      this._checkAdjacentWater(wx, wy, wz);
    }

    // Determine which neighbor chunks need light/mesh refresh
    const lightChanged = getBlockLight(prevId) > 0 || getBlockLight(id) > 0 ||
      BLOCK_DEFS[prevId]?.opaque !== BLOCK_DEFS[id]?.opaque;

    const affected = new Set([chunk]);
    const checkNeighbor = (dcx, dcz, cond) => {
      if (!cond) return;
      const nc = this.getChunk(cx + dcx, cz + dcz);
      if (nc) {
        nc.lightDirty = true;
        nc.dirty = true;
        affected.add(nc);
      }
    };

    const margin = lightChanged ? 13 : 0;
    checkNeighbor(-1, 0, lx <= margin);
    checkNeighbor(1, 0, lx >= CHUNK_SIZE - 1 - margin);
    checkNeighbor(0, -1, lz <= margin);
    checkNeighbor(0, 1, lz >= CHUNK_SIZE - 1 - margin);
    if (lightChanged) {
      checkNeighbor(-1, -1, lx <= margin && lz <= margin);
      checkNeighbor(1, -1, lx >= CHUNK_SIZE - 1 - margin && lz <= margin);
      checkNeighbor(-1, 1, lx <= margin && lz >= CHUNK_SIZE - 1 - margin);
      checkNeighbor(1, 1, lx >= CHUNK_SIZE - 1 - margin && lz >= CHUNK_SIZE - 1 - margin);
    }

    if (immediate) {
      // Compute center chunk lighting first so neighbors can read its border light
      chunk.computeLighting(this);
      for (const c of affected) {
        if (c !== chunk && c.lightDirty) c.computeLighting(this);
      }
      // Second pass on center if neighbor light bounced back
      chunk.computeLighting(this);
      for (const c of affected) {
        c.buildMesh(this, this.textures);
      }
    }

    return true;
  }

  _checkAdjacentWater(wx, wy, wz) {
    if (wy > SEA_LEVEL) return;
    const adj = [
      [wx + 1, wy, wz], [wx - 1, wy, wz],
      [wx, wy, wz + 1], [wx, wy, wz - 1],
      [wx, wy + 1, wz],
    ];
    for (const [ax, ay, az] of adj) {
      if (this.getBlock(ax, ay, az) === BLOCK.WATER) {
        if (this.fluidQueue.length < 96) {
          this.fluidQueue.push({ wx, wy, wz, depth: 0 });
        }
        break;
      }
    }
  }

  // Ignites a TNT block into a 3D blinking explosive entity
  igniteTNT(wx, wy, wz, sound, fuse = 3.0) {
    this.setBlock(wx, wy, wz, BLOCK.AIR, { recordEdit: true, immediate: true });
    const geo = new THREE.BoxGeometry(0.98, 0.98, 0.98);
    // Textured TNT cube using face materials or tinted canvas texture
    const sprite = this.textures.getSpriteCanvas(BLOCK.TNT);
    const tex = new THREE.CanvasTexture(sprite);
    tex.magFilter = THREE.NearestFilter;
    tex.minFilter = THREE.NearestFilter;
    tex.colorSpace = THREE.SRGBColorSpace;
    const mat = new THREE.MeshLambertMaterial({ map: tex, emissive: new THREE.Color(0x000000) });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(wx + 0.5, wy + 0.5, wz + 0.5);
    this.scene.add(mesh);

    if (sound) sound.playFuse();

    this.primedTnts.push({
      mesh,
      mat,
      tex,
      x: wx + 0.5,
      y: wy + 0.5,
      z: wz + 0.5,
      vx: (Math.random() - 0.5) * 2.2,
      vy: 4.2,
      vz: (Math.random() - 0.5) * 2.2,
      timer: fuse,
    });
  }

  _detonateTNT(tnt, callbacks) {
    const cx = Math.floor(tnt.x);
    const cy = Math.floor(tnt.y);
    const cz = Math.floor(tnt.z);
    const radius = 3.4;
    const rCeil = Math.ceil(radius);

    if (callbacks?.onExplosion) {
      callbacks.onExplosion(tnt.x, tnt.y, tnt.z, radius);
    }

    const dirtyChunks = new Set();

    for (let dy = -rCeil; dy <= rCeil; dy++) {
      for (let dz = -rCeil; dz <= rCeil; dz++) {
        for (let dx = -rCeil; dx <= rCeil; dx++) {
          const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
          if (dist > radius + (Math.random() - 0.5) * 0.45) continue;
          const bx = cx + dx;
          const by = cy + dy;
          const bz = cz + dz;
          if (by <= 1 || by >= WORLD_HEIGHT) continue;
          const bid = this.getBlock(bx, by, bz);
          if (bid === BLOCK.AIR || bid === BLOCK.BEDROCK || bid === BLOCK.WATER || bid === BLOCK.LAVA) continue;

          if (bid === BLOCK.TNT) {
            this.igniteTNT(bx, by, bz, callbacks?.sound, 0.6 + Math.random() * 0.5);
            continue;
          }

          const def = BLOCK_DEFS[bid];
          if (def && def.drop && typeof def.drop === 'number' && Math.random() < 0.38) {
            callbacks?.spawnDrop?.(bx + 0.5, by + 0.5, bz + 0.5, def.drop, 1);
          }

          this.setBlock(bx, by, bz, BLOCK.AIR, { recordEdit: true, immediate: false });
          const { cx: chx, cz: chz } = this.worldToChunk(bx, bz);
          const ch = this.getChunk(chx, chz);
          if (ch) dirtyChunks.add(ch);
        }
      }
    }

    // Rebuild affected chunks + immediate neighbors once at end of blast
    const rebuildSet = new Set(dirtyChunks);
    for (const ch of dirtyChunks) {
      for (const [ox, oz] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) {
        const n = this.getChunk(ch.cx + ox, ch.cz + oz);
        if (n) {
          n.lightDirty = true;
          n.dirty = true;
          rebuildSet.add(n);
        }
      }
    }
    for (const ch of rebuildSet) ch.computeLighting(this);
    for (const ch of rebuildSet) ch.buildMesh(this, this.textures);
  }

  getOrCreateFurnace(wx, wy, wz) {
    const key = `${wx},${wy},${wz}`;
    if (!this.furnaces.has(key)) {
      this.furnaces.set(key, {
        wx, wy, wz,
        inputId: 0, inputCount: 0,
        fuelId: 0, fuelCount: 0,
        outputId: 0, outputCount: 0,
        burnTime: 0, maxBurnTime: 1,
        progress: 0, maxProgress: 3.5,
        lit: false,
      });
    }
    return this.furnaces.get(key);
  }

  removeFurnace(wx, wy, wz) {
    const key = `${wx},${wy},${wz}`;
    const f = this.furnaces.get(key);
    this.furnaces.delete(key);
    return f || null;
  }

  _tickFurnaces(dt) {
    for (const f of this.furnaces.values()) {
      const recipe = SMELTING_RECIPES.find((r) => r.input === f.inputId && f.inputCount > 0);
      const canOutput = recipe && (
        f.outputId === 0 ||
        (f.outputId === recipe.output && f.outputCount + recipe.count <= 64)
      );

      if (f.burnTime > 0) {
        f.burnTime = Math.max(0, f.burnTime - dt);
      }

      if (f.burnTime <= 0 && canOutput && f.fuelId && f.fuelCount > 0) {
        const fuelDef = getDef(f.fuelId);
        if (fuelDef?.fuel) {
          f.burnTime = fuelDef.fuel;
          f.maxBurnTime = fuelDef.fuel;
          f.fuelCount--;
          if (f.fuelCount <= 0) f.fuelId = 0;
        }
      }

      if (f.burnTime > 0 && canOutput) {
        f.maxProgress = recipe.time;
        f.progress += dt;
        if (f.progress >= recipe.time) {
          f.progress = 0;
          f.inputCount--;
          if (f.inputCount <= 0) f.inputId = 0;
          f.outputId = recipe.output;
          f.outputCount += recipe.count;
        }
      } else {
        f.progress = Math.max(0, f.progress - dt * 2);
      }

      const shouldBeLit = f.burnTime > 0;
      if (shouldBeLit !== f.lit) {
        f.lit = shouldBeLit;
        const curBlock = this.getBlock(f.wx, f.wy, f.wz);
        if (curBlock === BLOCK.FURNACE || curBlock === BLOCK.FURNACE_LIT) {
          this.setBlock(
            f.wx, f.wy, f.wz,
            shouldBeLit ? BLOCK.FURNACE_LIT : BLOCK.FURNACE,
            { recordEdit: true, immediate: true }
          );
        }
      }
    }
  }

  update(dt, playerX, playerZ, callbacks = null) {
    // 1. Update primed TNT
    for (let i = this.primedTnts.length - 1; i >= 0; i--) {
      const t = this.primedTnts[i];
      t.timer -= dt;
      t.vy -= 18 * dt;

      // Simple vertical & horizontal block stop for primed TNT
      const nextY = t.y + t.vy * dt;
      if (BLOCK_DEFS[this.getBlock(Math.floor(t.x), Math.floor(nextY - 0.49), Math.floor(t.z))]?.solid) {
        t.vy = 0;
        t.vx *= 0.82;
        t.vz *= 0.82;
      } else {
        t.y = nextY;
      }
      if (!BLOCK_DEFS[this.getBlock(Math.floor(t.x + t.vx * dt), Math.floor(t.y), Math.floor(t.z))]?.solid) {
        t.x += t.vx * dt;
      }
      if (!BLOCK_DEFS[this.getBlock(Math.floor(t.x), Math.floor(t.y), Math.floor(t.z + t.vz * dt))]?.solid) {
        t.z += t.vz * dt;
      }

      t.mesh.position.set(t.x, t.y, t.z);
      const flash = Math.sin(t.timer * 22) > 0;
      t.mat.emissive.setHex(flash ? 0xaa8888 : 0x000000);
      const swell = t.timer < 0.4 ? 1 + (0.4 - t.timer) * 0.45 : 1;
      t.mesh.scale.setScalar(swell);

      if (t.timer <= 0) {
        this.scene.remove(t.mesh);
        t.mesh.geometry.dispose();
        t.mat.dispose();
        t.tex.dispose();
        this.primedTnts.splice(i, 1);
        this._detonateTNT(t, callbacks);
      }
    }

    // 2. Bounded water flow
    this._fluidTimer += dt;
    if (this._fluidTimer >= 0.22 && this.fluidQueue.length > 0) {
      this._fluidTimer = 0;
      const batch = this.fluidQueue.splice(0, 8);
      for (const item of batch) {
        if (this.getBlock(item.wx, item.wy, item.wz) === BLOCK.AIR && item.wy <= SEA_LEVEL) {
          this.setBlock(item.wx, item.wy, item.wz, BLOCK.WATER, { recordEdit: true, immediate: true });
          if (item.depth < 4) {
            for (const [ox, oy, oz] of [[1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [0, -1, 0]]) {
              const nx = item.wx + ox;
              const ny = item.wy + oy;
              const nz = item.wz + oz;
              if (ny >= 1 && this.getBlock(nx, ny, nz) === BLOCK.AIR && this.fluidQueue.length < 96) {
                this.fluidQueue.push({ wx: nx, wy: ny, wz: nz, depth: item.depth + 1 });
              }
            }
          }
        }
      }
    }

    // 3. Tick active furnaces
    if (this.furnaces.size > 0) {
      this._tickFurnaces(dt);
    }

    // 4. Radial Chunk Streaming & Time-Budgeted Meshing
    const centerCx = Math.floor(playerX / CHUNK_SIZE);
    const centerCz = Math.floor(playerZ / CHUNK_SIZE);
    const R = this.renderDistance;

    if (centerCx !== this._lastCenterCx || centerCz !== this._lastCenterCz) {
      this._lastCenterCx = centerCx;
      this._lastCenterCz = centerCz;

      // Unload distant chunks beyond R + 2
      const unloadDistSq = (R + 2.5) * (R + 2.5);
      for (const [key, ch] of this.chunks.entries()) {
        const dx = ch.cx - centerCx;
        const dz = ch.cz - centerCz;
        if (dx * dx + dz * dz > unloadDistSq) {
          this.worldGroup.remove(ch.group);
          ch.dispose();
          this.chunks.delete(key);
        }
      }

      // Build radial priority list
      this._loadQueue = [];
      for (let dz = -R; dz <= R; dz++) {
        for (let dx = -R; dx <= R; dx++) {
          if (dx * dx + dz * dz <= R * R + 1) {
            this._loadQueue.push({ cx: centerCx + dx, cz: centerCz + dz, d2: dx * dx + dz * dz });
          }
        }
      }
      this._loadQueue.sort((a, b) => a.d2 - b.d2);
    }

    const frameStart = performance.now();
    const BUDGET_MS = 5.5;

    // Generate missing chunks within frame budget
    while (this._loadQueue.length > 0 && performance.now() - frameStart < BUDGET_MS) {
      const next = this._loadQueue.shift();
      if (!this.chunks.has(`${next.cx},${next.cz}`)) {
        this.ensureChunkGenerated(next.cx, next.cz);
      }
    }

    // Rebuild dirty chunk meshes nearest-first within frame budget
    if (performance.now() - frameStart < BUDGET_MS) {
      const dirtyList = [];
      for (const ch of this.chunks.values()) {
        if (ch.dirty) {
          const dx = ch.cx - centerCx;
          const dz = ch.cz - centerCz;
          dirtyList.push({ ch, d2: dx * dx + dz * dz });
        }
      }
      dirtyList.sort((a, b) => a.d2 - b.d2);
      for (let i = 0; i < dirtyList.length; i++) {
        dirtyList[i].ch.buildMesh(this, this.textures);
        if (performance.now() - frameStart >= BUDGET_MS) break;
      }
    }
  }

  isNearBlock(x, y, z, blockIds, radius = 4.5) {
    const r = Math.ceil(radius);
    const ix = Math.floor(x);
    const iy = Math.floor(y);
    const iz = Math.floor(z);
    for (let dy = -r; dy <= r; dy++) {
      for (let dz = -r; dz <= r; dz++) {
        for (let dx = -r; dx <= r; dx++) {
          const bid = this.getBlock(ix + dx, iy + dy, iz + dz);
          if (blockIds.includes(bid)) return true;
        }
      }
    }
    return false;
  }

  serializeEdits() {
    const out = {};
    for (const [cKey, map] of this.edits.entries()) {
      if (map.size === 0) continue;
      const arr = [];
      for (const [idx, bid] of map.entries()) {
        arr.push(idx, bid);
      }
      out[cKey] = arr;
    }
    return out;
  }

  _deserializeEdits(obj) {
    for (const [cKey, arr] of Object.entries(obj)) {
      const map = new Map();
      for (let i = 0; i < arr.length; i += 2) {
        map.set(arr[i], arr[i + 1]);
      }
      this.edits.set(cKey, map);
    }
  }

  serializeFurnaces() {
    const out = {};
    for (const [k, v] of this.furnaces.entries()) {
      out[k] = { ...v };
    }
    return out;
  }

  dispose() {
    for (const ch of this.chunks.values()) {
      ch.dispose();
    }
    this.chunks.clear();
    for (const t of this.primedTnts) {
      this.scene.remove(t.mesh);
      t.mesh.geometry.dispose();
      t.mat.dispose();
      t.tex.dispose();
    }
    this.primedTnts = [];
    this.scene.remove(this.worldGroup);
  }
}
