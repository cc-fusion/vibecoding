// Complete Block, Item, Tool, Crafting & Smelting Registry

export const BLOCK = {
  AIR: 0,
  GRASS: 1,
  DIRT: 2,
  STONE: 3,
  COBBLESTONE: 4,
  SAND: 5,
  SANDSTONE: 6,
  GRAVEL: 7,
  CLAY: 8,
  SNOW_GRASS: 9,
  SNOW: 10,
  ICE: 11,
  BEDROCK: 12,
  OAK_LOG: 13,
  BIRCH_LOG: 14,
  SPRUCE_LOG: 15,
  OAK_LEAVES: 16,
  BIRCH_LEAVES: 17,
  SPRUCE_LEAVES: 18,
  OAK_PLANKS: 19,
  BIRCH_PLANKS: 20,
  SPRUCE_PLANKS: 21,
  COAL_ORE: 22,
  IRON_ORE: 23,
  GOLD_ORE: 24,
  DIAMOND_ORE: 25,
  WATER: 26,
  LAVA: 27,
  CRAFTING_TABLE: 28,
  FURNACE: 29,
  FURNACE_LIT: 30,
  GLASS: 31,
  STONE_BRICKS: 32,
  MOSSY_COBBLESTONE: 33,
  BRICKS: 34,
  BOOKSHELF: 35,
  GLOWSTONE: 36,
  TORCH: 37,
  TNT: 38,
  CACTUS: 39,
  TALL_GRASS: 40,
  POPPY: 41,
  DANDELION: 42,
  BLUE_ORCHID: 43,
  GLOW_SHROOM: 44,
  DEAD_BUSH: 45,
  WOOL: 46,
};

export const ITEM = {
  STICK: 101,
  COAL: 102,
  RAW_IRON: 103,
  IRON_INGOT: 104,
  RAW_GOLD: 105,
  GOLD_INGOT: 106,
  DIAMOND: 107,
  BRICK_ITEM: 108,

  WOOD_PICKAXE: 110,
  WOOD_AXE: 111,
  WOOD_SHOVEL: 112,
  WOOD_SWORD: 113,

  STONE_PICKAXE: 114,
  STONE_AXE: 115,
  STONE_SHOVEL: 116,
  STONE_SWORD: 117,

  IRON_PICKAXE: 118,
  IRON_AXE: 119,
  IRON_SHOVEL: 120,
  IRON_SWORD: 121,

  DIAMOND_PICKAXE: 122,
  DIAMOND_AXE: 123,
  DIAMOND_SHOVEL: 124,
  DIAMOND_SWORD: 125,

  APPLE: 126,
  RAW_MEAT: 127,
  COOKED_MEAT: 128,
};

// Render modes for chunk mesher:
// 'cube' = standard 6-face block
// 'leaves' = cube with cutout alpha (doesn't occlude neighbor non-leaf faces, casts soft AO)
// 'glass' = cube with cutout frame (culls same-id neighbors)
// 'fluid' = translucent fluid (water/lava) with lowered top face
// 'cross' = intersecting diagonal flora quads
// 'torch' = slim 3D standing voxel torch with glowing tip
// 'cactus' = slightly inset or standard spiky cactus block

export const BLOCK_DEFS = {
  [BLOCK.AIR]: {
    id: BLOCK.AIR, name: 'Air', solid: false, opaque: false, render: 'none', hardness: 0
  },
  [BLOCK.GRASS]: {
    id: BLOCK.GRASS, name: 'Grass Block', solid: true, opaque: true, render: 'cube',
    hardness: 0.65, tool: 'shovel', sound: 'grass', drop: BLOCK.DIRT,
    faces: { top: 'grass_top', bottom: 'dirt', side: 'grass_side' },
    particleColor: '#5ca935'
  },
  [BLOCK.DIRT]: {
    id: BLOCK.DIRT, name: 'Dirt', solid: true, opaque: true, render: 'cube',
    hardness: 0.55, tool: 'shovel', sound: 'gravel', drop: BLOCK.DIRT,
    faces: { all: 'dirt' }, particleColor: '#7a5234'
  },
  [BLOCK.STONE]: {
    id: BLOCK.STONE, name: 'Stone', solid: true, opaque: true, render: 'cube',
    hardness: 1.6, tool: 'pickaxe', minTier: 1, sound: 'stone', drop: BLOCK.COBBLESTONE,
    faces: { all: 'stone' }, particleColor: '#84878c'
  },
  [BLOCK.COBBLESTONE]: {
    id: BLOCK.COBBLESTONE, name: 'Cobblestone', solid: true, opaque: true, render: 'cube',
    hardness: 1.8, tool: 'pickaxe', minTier: 1, sound: 'stone', drop: BLOCK.COBBLESTONE,
    faces: { all: 'cobblestone' }, particleColor: '#73767a'
  },
  [BLOCK.SAND]: {
    id: BLOCK.SAND, name: 'Sand', solid: true, opaque: true, render: 'cube',
    hardness: 0.5, tool: 'shovel', sound: 'sand', drop: BLOCK.SAND,
    faces: { all: 'sand' }, particleColor: '#dfd199'
  },
  [BLOCK.SANDSTONE]: {
    id: BLOCK.SANDSTONE, name: 'Sandstone', solid: true, opaque: true, render: 'cube',
    hardness: 1.1, tool: 'pickaxe', minTier: 1, sound: 'stone', drop: BLOCK.SANDSTONE,
    faces: { top: 'sandstone_top', bottom: 'sandstone_bottom', side: 'sandstone_side' },
    particleColor: '#d7c587'
  },
  [BLOCK.GRAVEL]: {
    id: BLOCK.GRAVEL, name: 'Gravel', solid: true, opaque: true, render: 'cube',
    hardness: 0.6, tool: 'shovel', sound: 'gravel', drop: BLOCK.GRAVEL,
    faces: { all: 'gravel' }, particleColor: '#898482'
  },
  [BLOCK.CLAY]: {
    id: BLOCK.CLAY, name: 'Clay', solid: true, opaque: true, render: 'cube',
    hardness: 0.65, tool: 'shovel', sound: 'gravel', drop: BLOCK.CLAY,
    faces: { all: 'clay' }, particleColor: '#9aa2b1'
  },
  [BLOCK.SNOW_GRASS]: {
    id: BLOCK.SNOW_GRASS, name: 'Snowy Grass', solid: true, opaque: true, render: 'cube',
    hardness: 0.65, tool: 'shovel', sound: 'snow', drop: BLOCK.DIRT,
    faces: { top: 'snow', bottom: 'dirt', side: 'snow_side' },
    particleColor: '#eef6fa'
  },
  [BLOCK.SNOW]: {
    id: BLOCK.SNOW, name: 'Snow Block', solid: true, opaque: true, render: 'cube',
    hardness: 0.4, tool: 'shovel', sound: 'snow', drop: BLOCK.SNOW,
    faces: { all: 'snow' }, particleColor: '#f3f9fc'
  },
  [BLOCK.ICE]: {
    id: BLOCK.ICE, name: 'Ice', solid: true, opaque: false, render: 'fluid_solid',
    hardness: 0.6, tool: 'pickaxe', sound: 'glass', drop: BLOCK.ICE,
    faces: { all: 'ice' }, particleColor: '#9bc7f5'
  },
  [BLOCK.BEDROCK]: {
    id: BLOCK.BEDROCK, name: 'Bedrock', solid: true, opaque: true, render: 'cube',
    hardness: Infinity, unbreakable: true, sound: 'stone', drop: null,
    faces: { all: 'bedrock' }, particleColor: '#3a3b3e'
  },
  [BLOCK.OAK_LOG]: {
    id: BLOCK.OAK_LOG, name: 'Oak Log', solid: true, opaque: true, render: 'cube',
    hardness: 1.4, tool: 'axe', sound: 'wood', drop: BLOCK.OAK_LOG, fuel: 15,
    faces: { top: 'oak_log_top', bottom: 'oak_log_top', side: 'oak_log_side' },
    particleColor: '#6f5232'
  },
  [BLOCK.BIRCH_LOG]: {
    id: BLOCK.BIRCH_LOG, name: 'Birch Log', solid: true, opaque: true, render: 'cube',
    hardness: 1.4, tool: 'axe', sound: 'wood', drop: BLOCK.BIRCH_LOG, fuel: 15,
    faces: { top: 'birch_log_top', bottom: 'birch_log_top', side: 'birch_log_side' },
    particleColor: '#d9d5cc'
  },
  [BLOCK.SPRUCE_LOG]: {
    id: BLOCK.SPRUCE_LOG, name: 'Spruce Log', solid: true, opaque: true, render: 'cube',
    hardness: 1.4, tool: 'axe', sound: 'wood', drop: BLOCK.SPRUCE_LOG, fuel: 15,
    faces: { top: 'spruce_log_top', bottom: 'spruce_log_top', side: 'spruce_log_side' },
    particleColor: '#48331e'
  },
  [BLOCK.OAK_LEAVES]: {
    id: BLOCK.OAK_LEAVES, name: 'Oak Leaves', solid: true, opaque: false, render: 'leaves',
    hardness: 0.25, sound: 'grass', drop: 'oak_leaves_loot',
    faces: { all: 'oak_leaves' }, particleColor: '#448c2b'
  },
  [BLOCK.BIRCH_LEAVES]: {
    id: BLOCK.BIRCH_LEAVES, name: 'Birch Leaves', solid: true, opaque: false, render: 'leaves',
    hardness: 0.25, sound: 'grass', drop: 'birch_leaves_loot',
    faces: { all: 'birch_leaves' }, particleColor: '#679c41'
  },
  [BLOCK.SPRUCE_LEAVES]: {
    id: BLOCK.SPRUCE_LEAVES, name: 'Spruce Needles', solid: true, opaque: false, render: 'leaves',
    hardness: 0.25, sound: 'grass', drop: 'spruce_leaves_loot',
    faces: { all: 'spruce_leaves' }, particleColor: '#315e38'
  },
  [BLOCK.OAK_PLANKS]: {
    id: BLOCK.OAK_PLANKS, name: 'Oak Planks', solid: true, opaque: true, render: 'cube',
    hardness: 1.3, tool: 'axe', sound: 'wood', drop: BLOCK.OAK_PLANKS, fuel: 10,
    faces: { all: 'oak_planks' }, particleColor: '#a6824e'
  },
  [BLOCK.BIRCH_PLANKS]: {
    id: BLOCK.BIRCH_PLANKS, name: 'Birch Planks', solid: true, opaque: true, render: 'cube',
    hardness: 1.3, tool: 'axe', sound: 'wood', drop: BLOCK.BIRCH_PLANKS, fuel: 10,
    faces: { all: 'birch_planks' }, particleColor: '#c9b77c'
  },
  [BLOCK.SPRUCE_PLANKS]: {
    id: BLOCK.SPRUCE_PLANKS, name: 'Spruce Planks', solid: true, opaque: true, render: 'cube',
    hardness: 1.3, tool: 'axe', sound: 'wood', drop: BLOCK.SPRUCE_PLANKS, fuel: 10,
    faces: { all: 'spruce_planks' }, particleColor: '#755634'
  },
  [BLOCK.COAL_ORE]: {
    id: BLOCK.COAL_ORE, name: 'Coal Ore', solid: true, opaque: true, render: 'cube',
    hardness: 2.2, tool: 'pickaxe', minTier: 1, sound: 'stone', drop: ITEM.COAL,
    faces: { all: 'coal_ore' }, particleColor: '#43464b'
  },
  [BLOCK.IRON_ORE]: {
    id: BLOCK.IRON_ORE, name: 'Iron Ore', solid: true, opaque: true, render: 'cube',
    hardness: 2.6, tool: 'pickaxe', minTier: 2, sound: 'stone', drop: ITEM.RAW_IRON,
    faces: { all: 'iron_ore' }, particleColor: '#c59c7e'
  },
  [BLOCK.GOLD_ORE]: {
    id: BLOCK.GOLD_ORE, name: 'Gold Ore', solid: true, opaque: true, render: 'cube',
    hardness: 2.8, tool: 'pickaxe', minTier: 3, sound: 'stone', drop: ITEM.RAW_GOLD,
    faces: { all: 'gold_ore' }, particleColor: '#f3cf49'
  },
  [BLOCK.DIAMOND_ORE]: {
    id: BLOCK.DIAMOND_ORE, name: 'Diamond Ore', solid: true, opaque: true, render: 'cube',
    hardness: 3.2, tool: 'pickaxe', minTier: 3, sound: 'stone', drop: ITEM.DIAMOND,
    faces: { all: 'diamond_ore' }, particleColor: '#54e8e0'
  },
  [BLOCK.WATER]: {
    id: BLOCK.WATER, name: 'Water', solid: false, opaque: false, fluid: true, render: 'fluid',
    hardness: Infinity, unbreakable: true, sound: 'water',
    faces: { all: 'water' }, particleColor: '#3579e6'
  },
  [BLOCK.LAVA]: {
    id: BLOCK.LAVA, name: 'Lava', solid: false, opaque: false, fluid: true, render: 'fluid',
    hardness: Infinity, unbreakable: true, light: 14, sound: 'water',
    faces: { all: 'lava' }, particleColor: '#f5671a'
  },
  [BLOCK.CRAFTING_TABLE]: {
    id: BLOCK.CRAFTING_TABLE, name: 'Crafting Table', solid: true, opaque: true, render: 'cube',
    hardness: 1.4, tool: 'axe', sound: 'wood', drop: BLOCK.CRAFTING_TABLE, interactive: 'crafting',
    faces: { top: 'crafting_top', bottom: 'oak_planks', side: 'crafting_side' },
    particleColor: '#9c6e3e'
  },
  [BLOCK.FURNACE]: {
    id: BLOCK.FURNACE, name: 'Furnace', solid: true, opaque: true, render: 'cube',
    hardness: 2.2, tool: 'pickaxe', minTier: 1, sound: 'stone', drop: BLOCK.FURNACE, interactive: 'furnace',
    faces: { top: 'furnace_top', bottom: 'furnace_top', side: 'furnace_side', front: 'furnace_front' },
    particleColor: '#75777b'
  },
  [BLOCK.FURNACE_LIT]: {
    id: BLOCK.FURNACE_LIT, name: 'Lit Furnace', solid: true, opaque: true, render: 'cube',
    hardness: 2.2, tool: 'pickaxe', minTier: 1, sound: 'stone', drop: BLOCK.FURNACE,
    light: 13, interactive: 'furnace',
    faces: { top: 'furnace_top', bottom: 'furnace_top', side: 'furnace_side', front: 'furnace_front_lit' },
    particleColor: '#f59838'
  },
  [BLOCK.GLASS]: {
    id: BLOCK.GLASS, name: 'Glass', solid: true, opaque: false, render: 'glass',
    hardness: 0.4, sound: 'glass', drop: BLOCK.GLASS,
    faces: { all: 'glass' }, particleColor: '#d9f3fc'
  },
  [BLOCK.STONE_BRICKS]: {
    id: BLOCK.STONE_BRICKS, name: 'Stone Bricks', solid: true, opaque: true, render: 'cube',
    hardness: 1.8, tool: 'pickaxe', minTier: 1, sound: 'stone', drop: BLOCK.STONE_BRICKS,
    faces: { all: 'stone_bricks' }, particleColor: '#7e8185'
  },
  [BLOCK.MOSSY_COBBLESTONE]: {
    id: BLOCK.MOSSY_COBBLESTONE, name: 'Mossy Cobblestone', solid: true, opaque: true, render: 'cube',
    hardness: 1.8, tool: 'pickaxe', minTier: 1, sound: 'stone', drop: BLOCK.MOSSY_COBBLESTONE,
    faces: { all: 'mossy_cobble' }, particleColor: '#5b7a4a'
  },
  [BLOCK.BRICKS]: {
    id: BLOCK.BRICKS, name: 'Bricks', solid: true, opaque: true, render: 'cube',
    hardness: 1.9, tool: 'pickaxe', minTier: 1, sound: 'stone', drop: BLOCK.BRICKS,
    faces: { all: 'bricks' }, particleColor: '#a65341'
  },
  [BLOCK.BOOKSHELF]: {
    id: BLOCK.BOOKSHELF, name: 'Bookshelf', solid: true, opaque: true, render: 'cube',
    hardness: 1.3, tool: 'axe', sound: 'wood', drop: BLOCK.BOOKSHELF,
    faces: { top: 'oak_planks', bottom: 'oak_planks', side: 'bookshelf' },
    particleColor: '#9c7847'
  },
  [BLOCK.GLOWSTONE]: {
    id: BLOCK.GLOWSTONE, name: 'Glowstone', solid: true, opaque: true, render: 'cube',
    hardness: 0.5, sound: 'glass', drop: BLOCK.GLOWSTONE, light: 15,
    faces: { all: 'glowstone' }, particleColor: '#ffd966'
  },
  [BLOCK.TORCH]: {
    id: BLOCK.TORCH, name: 'Torch', solid: false, opaque: false, render: 'torch',
    hardness: 0.05, sound: 'wood', drop: BLOCK.TORCH, light: 14,
    faces: { all: 'torch' }, particleColor: '#ffbe42'
  },
  [BLOCK.TNT]: {
    id: BLOCK.TNT, name: 'TNT', solid: true, opaque: true, render: 'cube',
    hardness: 0.2, sound: 'grass', drop: BLOCK.TNT, interactive: 'tnt',
    faces: { top: 'tnt_top', bottom: 'tnt_bottom', side: 'tnt_side' },
    particleColor: '#d93829'
  },
  [BLOCK.CACTUS]: {
    id: BLOCK.CACTUS, name: 'Cactus', solid: true, opaque: false, render: 'cactus',
    hardness: 0.45, sound: 'grass', drop: BLOCK.CACTUS,
    faces: { top: 'cactus_top', bottom: 'cactus_top', side: 'cactus_side' },
    particleColor: '#488c2c'
  },
  [BLOCK.TALL_GRASS]: {
    id: BLOCK.TALL_GRASS, name: 'Tall Grass', solid: false, opaque: false, render: 'cross',
    hardness: 0.02, sound: 'grass', drop: null, replaceable: true,
    faces: { all: 'tall_grass' }, particleColor: '#5aa632'
  },
  [BLOCK.POPPY]: {
    id: BLOCK.POPPY, name: 'Red Poppy', solid: false, opaque: false, render: 'cross',
    hardness: 0.02, sound: 'grass', drop: BLOCK.POPPY,
    faces: { all: 'poppy' }, particleColor: '#e0352b'
  },
  [BLOCK.DANDELION]: {
    id: BLOCK.DANDELION, name: 'Dandelion', solid: false, opaque: false, render: 'cross',
    hardness: 0.02, sound: 'grass', drop: BLOCK.DANDELION,
    faces: { all: 'dandelion' }, particleColor: '#f5d42f'
  },
  [BLOCK.BLUE_ORCHID]: {
    id: BLOCK.BLUE_ORCHID, name: 'Blue Orchid', solid: false, opaque: false, render: 'cross',
    hardness: 0.02, sound: 'grass', drop: BLOCK.BLUE_ORCHID,
    faces: { all: 'blue_orchid' }, particleColor: '#3ca9f5'
  },
  [BLOCK.GLOW_SHROOM]: {
    id: BLOCK.GLOW_SHROOM, name: 'Luminous Shroom', solid: false, opaque: false, render: 'cross',
    hardness: 0.05, sound: 'grass', drop: BLOCK.GLOW_SHROOM, light: 9,
    faces: { all: 'glow_shroom' }, particleColor: '#4cf2c9'
  },
  [BLOCK.DEAD_BUSH]: {
    id: BLOCK.DEAD_BUSH, name: 'Dead Bush', solid: false, opaque: false, render: 'cross',
    hardness: 0.02, sound: 'wood', drop: ITEM.STICK,
    faces: { all: 'dead_bush' }, particleColor: '#8f6b41'
  },
  [BLOCK.WOOL]: {
    id: BLOCK.WOOL, name: 'Wool', solid: true, opaque: true, render: 'cube',
    hardness: 0.5, sound: 'grass', drop: BLOCK.WOOL,
    faces: { all: 'wool' }, particleColor: '#f0f0f2'
  },
};

// Tool tiers: 1 = Wood, 2 = Stone, 3 = Iron, 4 = Diamond
export const ITEM_DEFS = {
  [ITEM.STICK]: { id: ITEM.STICK, name: 'Stick', icon: 'stick', maxStack: 64, fuel: 5 },
  [ITEM.COAL]: { id: ITEM.COAL, name: 'Coal', icon: 'coal', maxStack: 64, fuel: 40 },
  [ITEM.RAW_IRON]: { id: ITEM.RAW_IRON, name: 'Raw Iron', icon: 'raw_iron', maxStack: 64 },
  [ITEM.IRON_INGOT]: { id: ITEM.IRON_INGOT, name: 'Iron Ingot', icon: 'iron_ingot', maxStack: 64 },
  [ITEM.RAW_GOLD]: { id: ITEM.RAW_GOLD, name: 'Raw Gold', icon: 'raw_gold', maxStack: 64 },
  [ITEM.GOLD_INGOT]: { id: ITEM.GOLD_INGOT, name: 'Gold Ingot', icon: 'gold_ingot', maxStack: 64 },
  [ITEM.DIAMOND]: { id: ITEM.DIAMOND, name: 'Diamond', icon: 'diamond', maxStack: 64 },
  [ITEM.BRICK_ITEM]: { id: ITEM.BRICK_ITEM, name: 'Clay Brick', icon: 'brick_item', maxStack: 64 },

  [ITEM.WOOD_PICKAXE]: {
    id: ITEM.WOOD_PICKAXE, name: 'Wooden Pickaxe', icon: 'wood_pickaxe',
    maxStack: 1, toolType: 'pickaxe', tier: 1, speed: 2.4, damage: 3, durability: 60, fuel: 10
  },
  [ITEM.WOOD_AXE]: {
    id: ITEM.WOOD_AXE, name: 'Wooden Axe', icon: 'wood_axe',
    maxStack: 1, toolType: 'axe', tier: 1, speed: 2.4, damage: 4, durability: 60, fuel: 10
  },
  [ITEM.WOOD_SHOVEL]: {
    id: ITEM.WOOD_SHOVEL, name: 'Wooden Shovel', icon: 'wood_shovel',
    maxStack: 1, toolType: 'shovel', tier: 1, speed: 2.4, damage: 2, durability: 60, fuel: 10
  },
  [ITEM.WOOD_SWORD]: {
    id: ITEM.WOOD_SWORD, name: 'Wooden Sword', icon: 'wood_sword',
    maxStack: 1, toolType: 'sword', tier: 1, speed: 1.5, damage: 5, durability: 60, fuel: 10
  },

  [ITEM.STONE_PICKAXE]: {
    id: ITEM.STONE_PICKAXE, name: 'Stone Pickaxe', icon: 'stone_pickaxe',
    maxStack: 1, toolType: 'pickaxe', tier: 2, speed: 4.2, damage: 4, durability: 132
  },
  [ITEM.STONE_AXE]: {
    id: ITEM.STONE_AXE, name: 'Stone Axe', icon: 'stone_axe',
    maxStack: 1, toolType: 'axe', tier: 2, speed: 4.2, damage: 5, durability: 132
  },
  [ITEM.STONE_SHOVEL]: {
    id: ITEM.STONE_SHOVEL, name: 'Stone Shovel', icon: 'stone_shovel',
    maxStack: 1, toolType: 'shovel', tier: 2, speed: 4.2, damage: 3, durability: 132
  },
  [ITEM.STONE_SWORD]: {
    id: ITEM.STONE_SWORD, name: 'Stone Sword', icon: 'stone_sword',
    maxStack: 1, toolType: 'sword', tier: 2, speed: 1.5, damage: 6, durability: 132
  },

  [ITEM.IRON_PICKAXE]: {
    id: ITEM.IRON_PICKAXE, name: 'Iron Pickaxe', icon: 'iron_pickaxe',
    maxStack: 1, toolType: 'pickaxe', tier: 3, speed: 6.5, damage: 5, durability: 250
  },
  [ITEM.IRON_AXE]: {
    id: ITEM.IRON_AXE, name: 'Iron Axe', icon: 'iron_axe',
    maxStack: 1, toolType: 'axe', tier: 3, speed: 6.5, damage: 6, durability: 250
  },
  [ITEM.IRON_SHOVEL]: {
    id: ITEM.IRON_SHOVEL, name: 'Iron Shovel', icon: 'iron_shovel',
    maxStack: 1, toolType: 'shovel', tier: 3, speed: 6.5, damage: 4, durability: 250
  },
  [ITEM.IRON_SWORD]: {
    id: ITEM.IRON_SWORD, name: 'Iron Sword', icon: 'iron_sword',
    maxStack: 1, toolType: 'sword', tier: 3, speed: 1.6, damage: 7, durability: 250
  },

  [ITEM.DIAMOND_PICKAXE]: {
    id: ITEM.DIAMOND_PICKAXE, name: 'Diamond Pickaxe', icon: 'diamond_pickaxe',
    maxStack: 1, toolType: 'pickaxe', tier: 4, speed: 9.5, damage: 6, durability: 800
  },
  [ITEM.DIAMOND_AXE]: {
    id: ITEM.DIAMOND_AXE, name: 'Diamond Axe', icon: 'diamond_axe',
    maxStack: 1, toolType: 'axe', tier: 4, speed: 9.5, damage: 8, durability: 800
  },
  [ITEM.DIAMOND_SHOVEL]: {
    id: ITEM.DIAMOND_SHOVEL, name: 'Diamond Shovel', icon: 'diamond_shovel',
    maxStack: 1, toolType: 'shovel', tier: 4, speed: 9.5, damage: 5, durability: 800
  },
  [ITEM.DIAMOND_SWORD]: {
    id: ITEM.DIAMOND_SWORD, name: 'Diamond Sword', icon: 'diamond_sword',
    maxStack: 1, toolType: 'sword', tier: 4, speed: 1.7, damage: 9, durability: 800
  },

  [ITEM.APPLE]: {
    id: ITEM.APPLE, name: 'Red Apple', icon: 'apple', maxStack: 64, food: 4, heal: 2
  },
  [ITEM.RAW_MEAT]: {
    id: ITEM.RAW_MEAT, name: 'Raw Meat', icon: 'raw_meat', maxStack: 64, food: 3, heal: 1
  },
  [ITEM.COOKED_MEAT]: {
    id: ITEM.COOKED_MEAT, name: 'Cooked Steak', icon: 'cooked_meat', maxStack: 64, food: 8, heal: 4
  },
};

export function isBlockId(id) {
  return id > 0 && id < 100 && Boolean(BLOCK_DEFS[id]);
}

export function getDef(id) {
  if (!id) return null;
  return BLOCK_DEFS[id] || ITEM_DEFS[id] || null;
}

export function getMaxStack(id) {
  const def = getDef(id);
  if (!def) return 64;
  return def.maxStack ?? 64;
}

export function isSolidBlock(id) {
  const b = BLOCK_DEFS[id];
  return b ? b.solid : false;
}

export function isOpaqueBlock(id) {
  const b = BLOCK_DEFS[id];
  return b ? b.opaque : false;
}

export function getBlockLight(id) {
  const b = BLOCK_DEFS[id];
  return b?.light || 0;
}

export function isAnyPlanks(id) {
  return id === BLOCK.OAK_PLANKS || id === BLOCK.BIRCH_PLANKS || id === BLOCK.SPRUCE_PLANKS;
}

export function isAnyLog(id) {
  return id === BLOCK.OAK_LOG || id === BLOCK.BIRCH_LOG || id === BLOCK.SPRUCE_LOG;
}

// Crafting Recipes:
// requiresTable: false = craftable anywhere in hand inventory (2x2 equivalent)
// requiresTable: true  = unlocked when near or interacting with a Crafting Table
// Note: 'ANY_PLANKS' matches Oak, Birch, or Spruce Planks automatically!
export const CRAFTING_RECIPES = [
  // Basics (Hand-craftable anywhere!)
  {
    id: 'oak_planks',
    category: 'Basics',
    output: { id: BLOCK.OAK_PLANKS, count: 4 },
    inputs: [{ id: BLOCK.OAK_LOG, count: 1 }],
    requiresTable: false,
  },
  {
    id: 'birch_planks',
    category: 'Basics',
    output: { id: BLOCK.BIRCH_PLANKS, count: 4 },
    inputs: [{ id: BLOCK.BIRCH_LOG, count: 1 }],
    requiresTable: false,
  },
  {
    id: 'spruce_planks',
    category: 'Basics',
    output: { id: BLOCK.SPRUCE_PLANKS, count: 4 },
    inputs: [{ id: BLOCK.SPRUCE_LOG, count: 1 }],
    requiresTable: false,
  },
  {
    id: 'sticks',
    category: 'Basics',
    output: { id: ITEM.STICK, count: 4 },
    inputs: [{ tag: 'ANY_PLANKS', label: 'Any Planks', iconId: BLOCK.OAK_PLANKS, count: 2 }],
    requiresTable: false,
  },
  {
    id: 'crafting_table',
    category: 'Basics',
    output: { id: BLOCK.CRAFTING_TABLE, count: 1 },
    inputs: [{ tag: 'ANY_PLANKS', label: 'Any Planks', iconId: BLOCK.OAK_PLANKS, count: 4 }],
    requiresTable: false,
  },
  {
    id: 'torches_coal',
    category: 'Basics',
    output: { id: BLOCK.TORCH, count: 4 },
    inputs: [{ id: ITEM.COAL, count: 1 }, { id: ITEM.STICK, count: 1 }],
    requiresTable: false,
  },

  // Tools & Weapons (Requires Crafting Table)
  {
    id: 'wood_pickaxe',
    category: 'Tools',
    output: { id: ITEM.WOOD_PICKAXE, count: 1 },
    inputs: [
      { tag: 'ANY_PLANKS', label: 'Any Planks', iconId: BLOCK.OAK_PLANKS, count: 3 },
      { id: ITEM.STICK, count: 2 }
    ],
    requiresTable: true,
  },
  {
    id: 'wood_axe',
    category: 'Tools',
    output: { id: ITEM.WOOD_AXE, count: 1 },
    inputs: [
      { tag: 'ANY_PLANKS', label: 'Any Planks', iconId: BLOCK.OAK_PLANKS, count: 3 },
      { id: ITEM.STICK, count: 2 }
    ],
    requiresTable: true,
  },
  {
    id: 'wood_shovel',
    category: 'Tools',
    output: { id: ITEM.WOOD_SHOVEL, count: 1 },
    inputs: [
      { tag: 'ANY_PLANKS', label: 'Any Planks', iconId: BLOCK.OAK_PLANKS, count: 1 },
      { id: ITEM.STICK, count: 2 }
    ],
    requiresTable: true,
  },
  {
    id: 'wood_sword',
    category: 'Tools',
    output: { id: ITEM.WOOD_SWORD, count: 1 },
    inputs: [
      { tag: 'ANY_PLANKS', label: 'Any Planks', iconId: BLOCK.OAK_PLANKS, count: 2 },
      { id: ITEM.STICK, count: 1 }
    ],
    requiresTable: true,
  },

  {
    id: 'stone_pickaxe',
    category: 'Tools',
    output: { id: ITEM.STONE_PICKAXE, count: 1 },
    inputs: [{ id: BLOCK.COBBLESTONE, count: 3 }, { id: ITEM.STICK, count: 2 }],
    requiresTable: true,
  },
  {
    id: 'stone_axe',
    category: 'Tools',
    output: { id: ITEM.STONE_AXE, count: 1 },
    inputs: [{ id: BLOCK.COBBLESTONE, count: 3 }, { id: ITEM.STICK, count: 2 }],
    requiresTable: true,
  },
  {
    id: 'stone_shovel',
    category: 'Tools',
    output: { id: ITEM.STONE_SHOVEL, count: 1 },
    inputs: [{ id: BLOCK.COBBLESTONE, count: 1 }, { id: ITEM.STICK, count: 2 }],
    requiresTable: true,
  },
  {
    id: 'stone_sword',
    category: 'Tools',
    output: { id: ITEM.STONE_SWORD, count: 1 },
    inputs: [{ id: BLOCK.COBBLESTONE, count: 2 }, { id: ITEM.STICK, count: 1 }],
    requiresTable: true,
  },

  {
    id: 'iron_pickaxe',
    category: 'Tools',
    output: { id: ITEM.IRON_PICKAXE, count: 1 },
    inputs: [{ id: ITEM.IRON_INGOT, count: 3 }, { id: ITEM.STICK, count: 2 }],
    requiresTable: true,
  },
  {
    id: 'iron_axe',
    category: 'Tools',
    output: { id: ITEM.IRON_AXE, count: 1 },
    inputs: [{ id: ITEM.IRON_INGOT, count: 3 }, { id: ITEM.STICK, count: 2 }],
    requiresTable: true,
  },
  {
    id: 'iron_shovel',
    category: 'Tools',
    output: { id: ITEM.IRON_SHOVEL, count: 1 },
    inputs: [{ id: ITEM.IRON_INGOT, count: 1 }, { id: ITEM.STICK, count: 2 }],
    requiresTable: true,
  },
  {
    id: 'iron_sword',
    category: 'Tools',
    output: { id: ITEM.IRON_SWORD, count: 1 },
    inputs: [{ id: ITEM.IRON_INGOT, count: 2 }, { id: ITEM.STICK, count: 1 }],
    requiresTable: true,
  },

  {
    id: 'diamond_pickaxe',
    category: 'Tools',
    output: { id: ITEM.DIAMOND_PICKAXE, count: 1 },
    inputs: [{ id: ITEM.DIAMOND, count: 3 }, { id: ITEM.STICK, count: 2 }],
    requiresTable: true,
  },
  {
    id: 'diamond_axe',
    category: 'Tools',
    output: { id: ITEM.DIAMOND_AXE, count: 1 },
    inputs: [{ id: ITEM.DIAMOND, count: 3 }, { id: ITEM.STICK, count: 2 }],
    requiresTable: true,
  },
  {
    id: 'diamond_shovel',
    category: 'Tools',
    output: { id: ITEM.DIAMOND_SHOVEL, count: 1 },
    inputs: [{ id: ITEM.DIAMOND, count: 1 }, { id: ITEM.STICK, count: 2 }],
    requiresTable: true,
  },
  {
    id: 'diamond_sword',
    category: 'Tools',
    output: { id: ITEM.DIAMOND_SWORD, count: 1 },
    inputs: [{ id: ITEM.DIAMOND, count: 2 }, { id: ITEM.STICK, count: 1 }],
    requiresTable: true,
  },

  // Utility & Building
  {
    id: 'furnace',
    category: 'Utility',
    output: { id: BLOCK.FURNACE, count: 1 },
    inputs: [{ id: BLOCK.COBBLESTONE, count: 8 }],
    requiresTable: true,
  },
  {
    id: 'stone_bricks',
    category: 'Building',
    output: { id: BLOCK.STONE_BRICKS, count: 4 },
    inputs: [{ id: BLOCK.STONE, count: 4 }],
    requiresTable: false,
  },
  {
    id: 'sandstone',
    category: 'Building',
    output: { id: BLOCK.SANDSTONE, count: 1 },
    inputs: [{ id: BLOCK.SAND, count: 4 }],
    requiresTable: false,
  },
  {
    id: 'bricks_block',
    category: 'Building',
    output: { id: BLOCK.BRICKS, count: 1 },
    inputs: [{ id: ITEM.BRICK_ITEM, count: 4 }],
    requiresTable: false,
  },
  {
    id: 'bookshelf',
    category: 'Building',
    output: { id: BLOCK.BOOKSHELF, count: 1 },
    inputs: [
      { tag: 'ANY_PLANKS', label: 'Any Planks', iconId: BLOCK.OAK_PLANKS, count: 6 },
      { id: BLOCK.WOOL, count: 2 }
    ],
    requiresTable: true,
  },
  {
    id: 'glowstone',
    category: 'Utility',
    output: { id: BLOCK.GLOWSTONE, count: 1 },
    inputs: [{ id: BLOCK.TORCH, count: 4 }, { id: ITEM.GOLD_INGOT, count: 1 }],
    requiresTable: true,
  },
  {
    id: 'mossy_cobble',
    category: 'Building',
    output: { id: BLOCK.MOSSY_COBBLESTONE, count: 1 },
    inputs: [{ id: BLOCK.COBBLESTONE, count: 1 }, { id: BLOCK.OAK_LEAVES, count: 1 }],
    requiresTable: false,
  },
  {
    id: 'tnt',
    category: 'Utility',
    output: { id: BLOCK.TNT, count: 1 },
    inputs: [{ id: BLOCK.SAND, count: 4 }, { id: ITEM.COAL, count: 3 }],
    requiresTable: true,
  },
];

// Furnace Smelting Recipes
export const SMELTING_RECIPES = [
  { input: ITEM.RAW_IRON, output: ITEM.IRON_INGOT, count: 1, time: 4.0 },
  { input: ITEM.RAW_GOLD, output: ITEM.GOLD_INGOT, count: 1, time: 4.5 },
  { input: BLOCK.SAND, output: BLOCK.GLASS, count: 1, time: 3.5 },
  { input: BLOCK.COBBLESTONE, output: BLOCK.STONE, count: 1, time: 3.5 },
  { input: BLOCK.CLAY, output: ITEM.BRICK_ITEM, count: 4, time: 3.5 },
  { input: ITEM.RAW_MEAT, output: ITEM.COOKED_MEAT, count: 1, time: 3.5 },
  { input: BLOCK.OAK_LOG, output: ITEM.COAL, count: 1, time: 3.5 },
  { input: BLOCK.BIRCH_LOG, output: ITEM.COAL, count: 1, time: 3.5 },
  { input: BLOCK.SPRUCE_LOG, output: ITEM.COAL, count: 1, time: 3.5 },
];

export const CREATIVE_PALETTE = [
  BLOCK.GRASS, BLOCK.DIRT, BLOCK.STONE, BLOCK.COBBLESTONE, BLOCK.STONE_BRICKS, BLOCK.MOSSY_COBBLESTONE,
  BLOCK.OAK_LOG, BLOCK.BIRCH_LOG, BLOCK.SPRUCE_LOG,
  BLOCK.OAK_PLANKS, BLOCK.BIRCH_PLANKS, BLOCK.SPRUCE_PLANKS,
  BLOCK.OAK_LEAVES, BLOCK.BIRCH_LEAVES, BLOCK.SPRUCE_LEAVES,
  BLOCK.SAND, BLOCK.SANDSTONE, BLOCK.GRAVEL, BLOCK.CLAY, BLOCK.BRICKS,
  BLOCK.SNOW, BLOCK.ICE, BLOCK.GLASS, BLOCK.WOOL, BLOCK.BOOKSHELF,
  BLOCK.COAL_ORE, BLOCK.IRON_ORE, BLOCK.GOLD_ORE, BLOCK.DIAMOND_ORE,
  BLOCK.CRAFTING_TABLE, BLOCK.FURNACE, BLOCK.TORCH, BLOCK.GLOWSTONE, BLOCK.TNT,
  BLOCK.CACTUS, BLOCK.POPPY, BLOCK.DANDELION, BLOCK.BLUE_ORCHID, BLOCK.GLOW_SHROOM,
  ITEM.DIAMOND_PICKAXE, ITEM.DIAMOND_AXE, ITEM.DIAMOND_SHOVEL, ITEM.DIAMOND_SWORD,
  ITEM.COOKED_MEAT, ITEM.APPLE,
];
