import { chromium } from 'playwright';
import http from 'http';
import fs from 'fs';
import path from 'path';

const PORT = 4178;
const distHtml = fs.readFileSync(path.resolve('dist/index.html'));

const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(distHtml);
});

await new Promise((resolve) => server.listen(PORT, '127.0.0.1', resolve));

const errors = [];
const warnings = [];

function assert(cond, msg) {
  if (!cond) throw new Error(`Assertion failed: ${msg}`);
}

try {
  const browser = await chromium.launch({
    headless: true,
    args: [
      '--disable-dev-shm-usage',
      '--use-gl=angle',
      '--use-angle=swiftshader',
      '--enable-unsafe-swiftshader',
      '--ignore-gpu-blocklist',
    ],
  });

  const context = await browser.newContext({ viewport: { width: 1024, height: 640 } });
  const page = await context.newPage();

  page.on('pageerror', (err) => errors.push(`PAGEERROR: ${err.message}\n${err.stack}`));
  page.on('console', (msg) => {
    if (msg.type() === 'error') errors.push(`CONSOLE ERROR: ${msg.text()}`);
    if (msg.type() === 'warning') warnings.push(`CONSOLE WARN: ${msg.text()}`);
  });

  const logStep = (s) => console.log(`[${((performance.now()) / 1000).toFixed(1)}s] ${s}`);
  logStep('Navigating to page...');
  await page.goto(`http://127.0.0.1:${PORT}`, { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(700);
  logStep('Page loaded, creating world...');

  // 1. Create New Survival World
  await page.fill('#input-world-name', 'Verification Valley');
  await page.fill('#input-world-seed', 'Emerald Valley');
  await page.click('#panel-new-world button[type="submit"]');
  await page.waitForTimeout(900);
  logStep('World created!');

  // 2. Test Physics, Held Tool 3D View, Mining, Drops, Crafting, and Furnace Smelting
  const gameplayCheck = await page.evaluate(() => {
    const app = window.__TERRACRAFT__;
    app.player.pitch = -0.15;
    app.player.yaw = 0.72;
    app.player.addItem(13, 4);   // 4 Oak Logs
    app.player.addItem(103, 2);  // 2 Raw Iron
    app.player.addItem(102, 3);  // 3 Coal
    app.player.addItem(122, 1);  // Diamond Pickaxe in slot 3
    app.player.selectedSlot = 3; // Hold Diamond Pickaxe to inspect 3D held view!
    return {
      state: app.state,
      chunks: app.world.chunks.size,
      mobs: app.mobs.mobs.length,
      onGround: app.player.onGround,
      heldId: app.player.getHeldId(),
    };
  });
  console.log('1. Gameplay Check:', gameplayCheck);
  assert(gameplayCheck.state === 'playing', 'Should enter playing state');
  assert(gameplayCheck.chunks >= 25, 'Should preload chunks around spawn');
  assert(gameplayCheck.onGround === true, 'Player should rest on solid ground');

  await page.waitForTimeout(450);
  logStep('Taking shot-2...');
  await page.screenshot({ path: 'tests/shot-2-gameplay-day.png', animations: 'allow' });
  logStep('Took shot-2!');

  // 3. Test Crafting Chain: Oak Logs -> Planks -> Sticks + Crafting Table -> Place Table -> Craft Wooden Pickaxe
  const craftChain = await page.evaluate(() => {
    const app = window.__TERRACRAFT__;
    const p = app.player;
    // Open inventory & craft Planks, Sticks, Crafting Table
    app.openInventory();
    const clickRecipeByName = (name) => {
      const cards = Array.from(document.querySelectorAll('#recipes-grid .recipe-card.craftable'));
      const found = cards.find((c) => c.querySelector('.recipe-name')?.textContent === name);
      if (found) { found.click(); return true; }
      return false;
    };
    const cPlanks1 = clickRecipeByName('Oak Planks');
    const cPlanks2 = clickRecipeByName('Oak Planks');
    const cSticks = clickRecipeByName('Stick');
    const cTable = clickRecipeByName('Crafting Table');

    // Place Crafting Table next to player and verify Wooden Pickaxe unlocks!
    const bx = Math.floor(p.position.x) + 1;
    const bz = Math.floor(p.position.z);
    const by = app.world.getSurfaceHeight(bx, bz) + 1;
    app.world.setBlock(bx, by, bz, 28, { recordEdit: true, immediate: true });
    app.ui.renderInventoryContents();
    const cPickaxe = clickRecipeByName('Wooden Pickaxe');
    app.resumePlaying();

    return {
      cPlanks1, cPlanks2, cSticks, cTable, cPickaxe,
      hasWoodPick: p.countItem(110) >= 1,
      milestones: Array.from(p.milestones),
    };
  });
  console.log('2. Crafting Chain:', craftChain);
  assert(craftChain.hasWoodPick, 'Should craft Wooden Pickaxe when near Crafting Table');

  // 4. Test Furnace Smelting (Raw Iron + Coal -> Lit Furnace emitting light -> Iron Ingot!)
  const furnaceCheck = await page.evaluate(() => {
    const app = window.__TERRACRAFT__;
    const fx = Math.floor(app.player.position.x) + 2;
    const fz = Math.floor(app.player.position.z);
    const fy = app.world.getSurfaceHeight(fx, fz) + 1;
    app.world.setBlock(fx, fy, fz, 29, { recordEdit: true, immediate: true }); // Furnace
    const f = app.world.getOrCreateFurnace(fx, fy, fz);
    f.inputId = 103; f.inputCount = 1; // Raw Iron
    f.fuelId = 102; f.fuelCount = 1;   // Coal
    // Simulate 4.5s of furnace smelting
    for (let i = 0; i < 45; i++) app.world._tickFurnaces(0.11);
    return {
      litBlockId: app.world.getBlock(fx, fy, fz),
      blockLightAtFurnace: app.world.getBlockLight(fx, fy, fz),
      outputId: f.outputId,
      outputCount: f.outputCount,
    };
  });
  console.log('3. Furnace Smelting Check:', furnaceCheck);
  assert(furnaceCheck.litBlockId === 30, 'Furnace should turn into Lit Furnace (id 30)');
  assert(furnaceCheck.blockLightAtFurnace >= 12, 'Lit Furnace should emit warm block light');
  assert(furnaceCheck.outputId === 104 && furnaceCheck.outputCount === 1, 'Raw Iron should smelt into Iron Ingot (104)');

  // 5. Test Save -> Quit -> Reload -> Load Saved World Persistence
  await page.evaluate(() => window.__TERRACRAFT__.quitToTitle());
  await page.waitForTimeout(250);
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(450);

  // Click Play on the saved world
  await page.click('.world-item .btn-primary');
  await page.waitForTimeout(600);

  const restoredCheck = await page.evaluate(() => {
    const app = window.__TERRACRAFT__;
    return {
      state: app.state,
      worldName: app.activeWorldMeta?.name,
      hasWoodPick: app.player.countItem(110) >= 1,
      furnacesCount: app.world.furnaces.size,
      editsChunksCount: app.world.edits.size,
    };
  });
  console.log('4. Persistence Reload Check:', restoredCheck);
  assert(restoredCheck.state === 'playing', 'Saved world should resume playing');
  assert(restoredCheck.hasWoodPick, 'Inventory items should persist across reload');
  assert(restoredCheck.furnacesCount >= 1 && restoredCheck.editsChunksCount >= 1, 'World edits & furnaces should persist');
  logStep('All assertions passed! Closing...');
  server.close();
  console.log('Warnings:', warnings.length, 'Errors:', errors.length);
  if (errors.length > 0) {
    console.error(errors.join('\n'));
    process.exit(1);
  }
  console.log('ALL RUNTIME VERIFICATION TESTS PASSED!');
  process.exit(0);
} finally {
  server.close();
}

console.log('Warnings:', warnings.length, 'Errors:', errors.length);
if (errors.length > 0) {
  console.error(errors.join('\n'));
  process.exit(1);
}
console.log('ALL RUNTIME VERIFICATION TESTS PASSED!');
process.exit(0);
