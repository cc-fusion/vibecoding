# TerraCraft — Voxel Sandbox Game Architecture & Execution Plan

## 1. Core Technical Stack & Structure
- **Main Body**: Plain HTML (`index.html`), Plain CSS (`src/style.css`), and Modular Plain JavaScript (`src/main.js` + ES modules in `src/`). No React UI framework.
- **3D Rendering**: Three.js (`three` v0.186) with custom chunk `BufferGeometry`, vertex ambient occlusion + block torchlight colors, and padded procedural pixel-art `CanvasTexture` atlas.
- **Build Output**: Bundled cleanly via `npm run build` into `dist/index.html`.

## 2. Module Breakdown
1. `src/world/noise.js` — Deterministic seeded PRNG, 2D & 3D Simplex/FBM noise utilities.
2. `src/world/blocks.js` — Registry of ~40 blocks and ~24 items/tools/weapons/food with hardness, tool affinity, light emission, transparency, drops, and crafting/smelting recipes.
3. `src/render/textures.js` — Procedural 16x16 pixel-art texture atlas generator (with extruded tile borders to eliminate UV seam bleeding) + 2D item icon data URLs for crisp UI rendering.
4. `src/world/terrain.js` — Multi-biome procedural generator (Plains, Forest, Desert, Snowy Taiga, Mountain Crags, Ocean/Beach), 3D cave carving, depth-stratified ores, trees, flora, and water/lava levels.
5. `src/world/chunk.js` — `16x96x16` chunk storage, local light propagation (torches, glowstone, lava, lit furnace), face culling, 4-neighbor smooth vertex Ambient Occlusion, opaque/cutout/water geometry builders.
6. `src/world/world.js` — World manager, radial chunk streaming queue, synchronous neighbor-aware block edits, block light updates, TNT explosions, and furnace state ticks.
7. `src/player/raycast.js` — Fast 3D DDA voxel raycasting (`reach = 5.5`) returning hit block, normal, adjacent placement coordinate, and distance.
8. `src/player/player.js` — First-person camera, Pointer Lock, swept axis-separated AABB collision, gravity, sprinting, swimming/underwater oxygen, fall damage, progressive mining, placement, hunger/health survival loop, and Creative flight mode.
9. `src/render/hand.js` — 3D first-person held arm/block/tool view with walk bobbing and swing animation.
10. `src/render/sky.js` — Dynamic day-night sky dome, sun, moon, twinkling starfield, 3D drifting voxel clouds, dynamic fog, and rain/snow weather system.
11. `src/entities/particles.js` — 3D voxel debris bursts, mining chips, torch flames, water splashes, and explosion particles.
12. `src/entities/drops.js` — 3D floating/rotating item drops on the ground with physics and magnetic player pickup.
13. `src/entities/mobs.js` — Articulated 3D voxel creatures (Sheep, Pig, Cow, nocturnal Zombie, Cave Slime) with animations, AI, combat knockback, and loot drops.
14. `src/audio/sound.js` — Procedural Web Audio synthesizer for material-aware footsteps, block mining/breaking, placement, item pickup, crafting, eating, combat, TNT, and weather ambience.
15. `src/storage/save.js` — Multi-world persistence in `localStorage` using seed + delta chunk modifications, player state, inventory, time, and world export/import.
16. `src/ui/hud.js` — Clean, friendly vanilla DOM UI: World Selection / Creation menu, unobtrusive HUD (hotbar, hearts, hunger, oxygen, crosshair with mining ring), categorized Inventory & Crafting/Smelting modal (`E`), Progression milestones, and Pause/Settings modal (`ESC`).
17. `src/main.js` — Main game loop, event orchestration, resize handling, autosave, and runtime hooks.

## 3. Execution & Verification Phases
- **Phase 1**: Noise, Block/Item/Recipe registry, Procedural Texture Atlas + UI Icon generator.
- **Phase 2**: Multi-biome terrain + 3D caves + Chunk meshing (AO + Torchlight + Water/Flora) + World streaming.
- **Phase 3**: Sky/Day-Night/Weather + First-person Player Physics, Raycast, Mining/Placing + 3D Held Hand + Audio + Particles.
- **Phase 4**: Drops, Mobs (Passive & Hostile), TNT & Smelting Furnaces, Persistence (`save.js`).
- **Phase 5**: Clean HTML/CSS/JS UI (Start Menu, HUD, Inventory/Crafting/Furnace, Settings, Controls) + Main game orchestration.
- **Phase 6**: Build verification (`npm run build`), runtime verification, bug fixing, and visual/performance polish.
