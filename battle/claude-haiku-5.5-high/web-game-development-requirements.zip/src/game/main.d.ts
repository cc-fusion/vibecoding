// Type declarations for the vanilla JavaScript game entry (src/game/main.js).
export function mountGame(el: HTMLElement): () => void;
