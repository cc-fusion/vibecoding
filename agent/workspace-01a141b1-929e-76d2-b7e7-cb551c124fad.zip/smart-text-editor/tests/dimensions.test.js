import test from 'node:test';
import assert from 'node:assert/strict';
import { suggestFor } from '../src/suggest.js';
import { findExpression, evalReadings } from '../src/analyze.js';
import { parseText } from '../src/parser.js';
import { evaluateAst, dEq } from '../src/evaluator.js';
import { D, configureFor } from '../src/numeric.js';

const suggest = text => suggestFor(text, text.length);
const cases = [
  ['3000mAh/500mA=', '6h'],
  ['3000mAh/6h=', '500mA'],
  ['500mA*6h=', '3Ah'],
  ['3Ah*12V=', '36Wh'],
  ['36Wh/12V=', '3Ah'],
  ['60Wh/12W=', '5h'],
  ['12V*2A=', '24W'],
  ['24W/12V=', '2A'],
  ['12V/2A=', '6Ω'],
  ['2A*6ohm=', '12V'],
  ['100km/2h=', '50km/h'],
  ['60mph*2h=', '120mi'],
  ['10m/2m=', '5'],
  ['1kWh/1h=', '1kW'],
  ['10N/2m^2=', '5Pa'],
  ['2kg*3m/s^2=', '6N'],
  ['10N*2m=', '20J'],
  ['10MB/2s=', '5MB/s'],
  ['1L*2A=', '2L·A'],
  ['10m+20cm=', '10.2m'],
  ['(3000mAh)/(500mA)=', '6h'],
  ['3Ah/500mA=', '6h'],
  ['3000mAh/0.5A=', '6h'],
  ['3000 mA·h / 500 mA =', '6 h'],
  ['3000 mA h / 500 mA =', '6 h'],
  ['3000mAh/500mA', '=6h'],
  ['Runtime: 3000mAh/500mA=', '6h'],
  ['1 N·m to J =', '1 J'],
  ['1 kg⋅m/s² to N =', '1 N'],
  ['1 KiB to B =', '1024 B'],
  ['1 MiB to KiB =', '1024 KiB'],
  ['1 MB to B =', '1000000 B'],
  ['1 MB to Mb =', '8 Mb'],
  ['1 Mib to Kib =', '1024 Kib'],
  ['1 MiB/s to KiB/s =', '1024 KiB/s'],
  ['1 Ah to C =', '3600 C'],
  ['3600 C to Ah =', '1 Ah'],
  ['3000 mAh to Ah =', '3 Ah'],
  ['3600 As to Ah =', '1 Ah'],
  ['1 A*s to C =', '1 C'],
  ['1 C/s to A =', '1 A'],
  ['C(5,2)=', '10'],
  ['1c to k=', '274.15k']
];
for (const [expr, expected] of cases) {
  test(`correct inline dimensions: ${expr}`, () => {
    const first = suggest(expr)[0];
    assert.ok(first?.inlineEligible, JSON.stringify(first));
    assert.equal(expr.endsWith('=') ? first.ins : first.insertText, expected);
  });
}

test('every proposed arithmetic unit has the full expression dimensions', () => {
  for (const [text] of cases.slice(0, 25)) {
    const expr = text.slice(0, -1);
    configureFor(expr);
    const original = evalReadings(findExpression(expr)).readings[0].q;
    for (const chip of suggest(text)) {
      const parsed = parseText(chip.ins, 'sci');
      assert.ok(parsed?.ast, `${text}: output cannot be parsed: ${chip.ins}`);
      const readings = evaluateAst(parsed.ast, new Map());
      assert.ok(readings?.length, chip.ins);
      assert.ok(readings.some(r => dEq(r.q.d, original.d)), `${text} produced ${chip.ins} with wrong dimensions`);
    }
  }
});

test('mixed-prefix charge/current matrix is always time', () => {
  const charges = { Ah: 3600, mAh: 3.6, 'µAh': 0.0036, C: 1, mC: 0.001 };
  const currents = { A: 1, mA: 0.001, 'µA': 0.000001, kA: 1000 };
  for (const [qUnit, qFactor] of Object.entries(charges)) {
    for (const [iUnit, iFactor] of Object.entries(currents)) {
      const expr = `3000${qUnit}/500${iUnit}`;
      const reading = evalReadings(findExpression(expr)).readings[0].q;
      assert.deepEqual(reading.d, [0, 0, 1, 0, 0, 0, 0]);
      const expected = new D(6).times(qFactor).div(iFactor);
      assert.ok(reading.v.minus(expected).abs().lt('1e-35'));
      assert.ok(suggest(expr + '=')[0]?.inlineEligible, expr);
    }
  }
});

for (const expr of [
  '10bogus/2m=', '10bogus / 2m =', '10bogus 2m=',
  '3000unknown/500mA=', 'bogus / 500mA =', 'foo*(500mA)=',
  '(2m + nope) / 5s =', '3Ah to Wh =', '3Ah to A =',
  '60Wh/0W=', '1m+1s=', '12V+2A=', '3000mAh/0mA=',
  '10nope / 2m to cm =', '3000unknown / 500mA to h =',
  '1+'.repeat(260) + '2m='
]) {
  test(`no misleading partial/incompatible result: ${expr.slice(0, 60)}`, () => {
    assert.deepEqual(suggest(expr), []);
  });
}

test('ordinary prose and bullet notes still work', () => {
  for (const expr of ['Runtime is 3000mAh/500mA=', '- 3000mAh/500mA=', 'Battery 1: 3000mAh/500mA=']) {
    assert.equal(suggest(expr)[0]?.ins, '6h', expr);
  }
});
test('incorrect already-typed current can be replaced by the runtime', () => {
  const chip = suggest('3000mAh/500mA=0.5A')[0];
  assert.equal(chip.kind, 'replace');
  assert.equal(chip.replaceLen, 4);
  assert.equal(chip.insertText, '6h');
});
test('a plain quantity still offers conversion choices', () => {
  const result = suggest('1m');
  assert.ok(result.length);
  assert.ok(result.every(chip => !chip.inlineEligible));
});
