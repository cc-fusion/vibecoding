# Dimensional-conversion audit and fixes

## Main fix: battery capacity divided by current is time

`3000mAh/500mA=` now shows **`6h` inline**. Tab inserts it; Enter remains a newline. The alternate chips contain other **time** units, not amperes.

The previous engine did not define `Ah`/`mAh`. Its expression finder silently skipped the unsupported numerator and evaluated only `500mA`, producing current conversions. Separately, its “bare quantity” check treated multiplication/division of multiple quantities as conversion-only input, suppressing a primary inline answer even when the dimensions were correct.

Both causes are fixed, rather than special-casing that one expression.

## Issues found and corrected

| Category | Example | Correct primary result | What was wrong before |
| --- | --- | --- | --- |
| Capacity ÷ current | `3000mAh/500mA=` | `6h` | Unknown numerator was discarded; current conversions appeared. |
| Capacity ÷ time | `3000mAh/6h=` | `500mA` | Unknown numerator was discarded; time conversions appeared. |
| Current × time | `500mA*6h=` | `3Ah` (also `3000mAh`) | No usable charge output units or primary result. |
| Charge × voltage | `3Ah*12V=` | `36Wh` | Charge was unrecognized; only the voltage suffix was evaluated. |
| Energy ÷ voltage | `36Wh/12V=` | `3Ah` | No charge-unit result. |
| Energy ÷ power | `60Wh/12W=` | `5h` | Main result was suppressed; conversion-only chips started with seconds. |
| Voltage × current | `12V*2A=` | `24W` | Main watt result was omitted; an alternative such as `0.024kW` came first, without inline text. |
| Power ÷ voltage | `24W/12V=` | `2A` | Main ampere result was omitted. |
| Voltage ÷ current | `12V/2A=` | `6Ω` | Main resistance result was omitted. |
| Current × resistance | `2A*6ohm=` | `12V` | Main voltage result was omitted. |
| Distance ÷ time | `100km/2h=` | `50km/h` | Only alternative conversions were offered; no primary inline speed. |
| Speed × time | `60mph*2h=` | `120mi` | Correct distance appeared only as a conversion chip, not inline. |
| Force ÷ area | `10N/2m^2=` | `5Pa` | The pascal result was omitted in favor of alternative pressure units. |
| Mass × acceleration | `2kg*3m/s^2=` | `6N` | No primary inline force result. |
| Force × distance | `10N*2m=` | `20J` | No primary inline energy result. |
| Data ÷ time | `10MB/2s=` | `5MB/s` | Byte-rate result was suppressed; bit-rate alternatives dominated. |
| Unit-product notation | `1 N·m to J =` | `1 J` | Middle-dot multiplication was not recognized, including in compound outputs emitted by the app itself. |
| IEC binary units | `1 KiB to B =` | `1024 B` | Binary prefixes were missing. Decimal `1 kB = 1000 B` remains distinct. |
| Coulomb notation | `3600 C to Ah =` | `1 Ah` | Charge units were missing and `C` was reserved only for combinations. `C(5,2)` still returns `10`. |
| Volume/voltage family collision | `1L*2A=` | `2L·A` | Liters and volts shared an internal family code, potentially selecting an inappropriate derivation and suppressing the valid compound result. They now have separate codes. |
| Unknown operands | `3000unknown/500mA=` | No calculation suggestion | The engine used to silently evaluate just the recognized denominator. |
| Oversized expressions | An expression beyond the 500-character parser limit | No calculation suggestion | Truncating a long expression could evaluate a valid-looking suffix instead of the whole expression. It now fails closed. |

## How normalization works

- Added charge units `Ah`, `mAh`, other SI-prefixed ampere-hours, `C` (coulombs), and `As` (ampere-seconds).
- Unit cancellation uses the full seven-dimensional quantity vector **and scale factors**. Thus mixed forms such as `3Ah/500mA` and `3000mAh/0.5A` also produce `6h`.
- Where possible, results use an equivalent familiar unit (`h`, `Wh`, `Ah`, `km/h`, `MB/s`, etc.). Other recognized dimensions fall back to suitable named units; genuinely unusual dimensions keep their compound notation.
- A single bare quantity still offers conversion choices. Arithmetic involving multiple numbers or unit factors now produces a primary inline answer.
- Both `·` and `⋅` are accepted as multiplication, alongside existing `*` and `×` syntax.
- IEC binary data prefixes from kibi through exbi are separate from decimal SI prefixes. Bit/byte case distinctions remain intact.
- Expression discovery still supports prose labels and bullets, such as `Runtime: 3000mAh/500mA=`, but no longer skips over an earlier malformed mathematical operand. For notes containing earlier unrelated numbers, use a colon or semicolon to explicitly separate the label from the expression.

## Important limits retained

- `Ah` measures charge, not energy. `3Ah to Wh` cannot be resolved without voltage; `3Ah*12V` can. The app does not guess missing voltage.
- `3000mAh/500mA = 6h` is an ideal constant-current calculation, not a battery-discharge simulation.
- Incompatible additions/conversions and division by zero do not produce results.
- No silent rewriting of the note: inline results are accepted with Tab/click; incorrect already-typed results, such as `3000mAh/500mA=0.5A`, offer a replacement chip for `6h`.
- The application remains vanilla HTML/CSS/JavaScript, offline-capable, with Decimal.js for precision. Enter and up/down remain native; left/right still switch suggestions.

## Verification

**110 passing engine tests**, including the existing 225-pair pressure matrix and a new 20-pair mixed-prefix charge/current matrix. New tests also check that every proposed arithmetic output has the same dimensions as its full input, that compound outputs can be parsed again, that bad operands never become suffix-only results, and that `C(5,2)`/Celsius shorthand still work.

Browser tests verify visible results and Tab acceptance for battery/electrical/mechanical/data expressions, replacement of an incorrect current result, rejection of unknown operands, existing pressure/temperature behavior, keyboard shortcuts, persistence, mobile/dark rendering, and offline/sandbox operation.
