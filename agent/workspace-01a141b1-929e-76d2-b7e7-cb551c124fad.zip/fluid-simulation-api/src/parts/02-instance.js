  // ---------------------------------------------------------------------------
  // The simulation instance
  // ---------------------------------------------------------------------------

  /**
   * Create a fluid simulation. Prefer `FluidSimulation.create(options)`.
   *
   * @param {Object} [options] see docs/API.md - everything is optional.
   */
  function FluidSimulation(options) {
    var opts = assign({}, DEFAULT_OPTIONS, options || {});
    opts.hotkeys = assign({}, DEFAULT_OPTIONS.hotkeys, (options && options.hotkeys) || {});
    this.options = opts;

    this.version = VERSION;
    this.destroyed = false;
    this.ready = false;
    this.running = false;
    this.degraded = { mobile: false, noLinearFiltering: false };

    this._handlers = {};
    this._rafId = null;
    this._lastUpdateTime = now();
    this._colorUpdateTimer = 0.0;
    this._pausedByVisibility = false;
    this._contextLost = false;
    this._inputEnabled = false;
    this._keyboardEnabled = false;
    this._resizeObserver = null;
    this._pointerMap = null;
    this._activeIds = [];

    this.pointers = [new Pointer(-1)];
    this._splatStack = [];
    this._colorGenerator = defaultColorGenerator;
    this._boundTick = this._tick.bind(this);

    // ---- configuration -----------------------------------------------------
    this.config = cloneConfig(DEFAULT_CONFIG);
    if (opts.preset) {
      var preset = PRESETS[opts.preset];
      if (!preset) {
        throw new FluidError(ERROR_CODES.NO_CANVAS,
          'Unknown preset "' + opts.preset + '". Available: ' + Object.keys(PRESETS).join(', '));
      }
      assign(this.config, cloneConfig(preset));
    }
    if (opts.config) assign(this.config, cloneConfig(opts.config));
    /** Snapshot of the configuration this instance was created with. */
    this._initialConfig = cloneConfig(this.config);

    // ---- element -----------------------------------------------------------
    this.canvas = resolveCanvas(opts);
    this._ownsCanvas = !(opts.canvas instanceof Object && opts.canvas.nodeType === 1);

    // ---- WebGL -------------------------------------------------------------
    this._initResources();
    this.ready = true;

    // ---- interaction / integration ----------------------------------------
    if (opts.input) this.enableInput();
    if (opts.keyboard) this.enableKeyboard();
    this._bindResizeObserver();
    this._bindVisibility();

    // ---- initial state -----------------------------------------------------
    if (opts.initialSplats === 'random') this.randomSplats(5 + Math.floor(Math.random() * 20));
    else if (opts.initialSplats) this.randomSplats(clamp(opts.initialSplats | 0, 0, 50));

    if (opts.autoStart && opts.autoUpdate !== false) this.start();
    var self = this;
    // ready is emitted on the next microtask so listeners can be attached first.
    setTimeout(function () {
      if (!self.destroyed) self._emit(EVENTS.READY, { canvas: self.canvas, gl: self.gl, config: self.getConfig() });
    }, 0);
  }

  // ---------------------------------------------------------------------------
  // Creation helpers
  // ---------------------------------------------------------------------------

  function now() {
    if (typeof performance !== 'undefined' && performance.now) return performance.now();
    return Date.now();
  }

  function resolveCanvas(opts) {
    if (typeof document === 'undefined') {
      throw new FluidError(ERROR_CODES.NO_CANVAS,
        'FluidSimulation needs a DOM: there is no document in this environment. ' +
        'Create instances in the browser, not during server-side rendering.');
    }
    var canvas = opts.canvas;
    if (typeof canvas === 'string') {
      canvas = document.querySelector(canvas);
      if (!canvas) {
        throw new FluidError(ERROR_CODES.NO_CANVAS, 'No element matches the canvas selector "' + opts.canvas + '".');
      }
    }
    if (canvas == null) {
      canvas = createCanvasElement(opts);
    } else if (!(canvas instanceof Object) || canvas.nodeType !== 1) {
      throw new FluidError(ERROR_CODES.NO_CANVAS, 'options.canvas must be an element or a CSS selector.');
    }
    if (canvas.tagName !== 'CANVAS') {
      canvas = promoteToCanvas(canvas, opts);
    }
    if (opts.id) canvas.id = opts.id;
    if (opts.className && !canvas.className) canvas.className = opts.className;
    if (opts.style && canvas.style) applyStyle(canvas, opts.style);
    ensureTouchAction(canvas);
    return canvas;
  }

  function createCanvasElement(opts) {
    var parent = opts.container;
    if (typeof parent === 'string') parent = document.querySelector(parent);
    if (!parent) parent = document.body;
    if (!parent) {
      throw new FluidError(ERROR_CODES.NO_CANVAS,
        'No container available; call create() after the document body exists.');
    }
    var canvas = document.createElement('canvas');
    canvas.className = opts.className || 'fluid-canvas';
    if (opts.container) {
      // Fill the given container and leave the rest of the page alone.
      makePositioned(parent);
      applyStyle(canvas, {
        position: 'absolute',
        top: '0',
        left: '0',
        width: '100%',
        height: '100%',
        display: 'block'
      });
    } else {
      // No container: behave like the original app, full-bleed behind everything.
      applyStyle(canvas, {
        position: 'fixed',
        top: '0',
        left: '0',
        width: '100%',
        height: '100%',
        display: 'block',
        pointerEvents: 'none',
        zIndex: '-1'
      });
    }
    parent.appendChild(canvas);
    return canvas;
  }

  function makePositioned(element) {
    if (!element.style || typeof getComputedStyle !== 'function') return;
    var computed = getComputedStyle(element);
    if (computed && computed.position === 'static') element.style.position = 'relative';
  }

  /** A non-canvas element (usually a div) gets a canvas child that fills it. */
  function promoteToCanvas(container, opts) {
    makePositioned(container);
    var canvas = document.createElement('canvas');
    canvas.className = opts.className || 'fluid-canvas';
    applyStyle(canvas, {
      position: 'absolute',
      top: '0',
      left: '0',
      width: '100%',
      height: '100%',
      display: 'block'
    });
    container.appendChild(canvas);
    return canvas;
  }

  function applyStyle(element, style) {
    Object.keys(style).forEach(function (key) {
      element.style[key] = style[key];
    });
  }

  function ensureTouchAction(canvas) {
    if (!canvas.style) return;
    var current = canvas.style.touchAction;
    if (!current || current === 'auto') {
      canvas.style.touchAction = 'none';
      canvas.style.webkitTouchAction = 'none';
    }
  }

  // ---------------------------------------------------------------------------
  // Lifecycle
  // ---------------------------------------------------------------------------

  /**
   * Start (or restart) the animation loop. Safe to call repeatedly.
   * @returns {FluidSimulation} this
   */
  FluidSimulation.prototype.start = function () {
    assertAlive(this);
    if (!this.running) {
      this.running = true;
      this._lastUpdateTime = now();
      this._rafId = requestAnimationFrame(this._boundTick);
    }
    return this;
  };

  /** Stop the animation loop but keep all GL state (see resume() to continue). */
  FluidSimulation.prototype.stop = function () {
    if (this.destroyed) return this;
    this.running = false;
    if (this._rafId != null && typeof cancelAnimationFrame === 'function') {
      cancelAnimationFrame(this._rafId);
    }
    this._rafId = null;
    return this;
  };

  /** Freeze the simulation (rendering continues; the physics does not advance). */
  FluidSimulation.prototype.pause = function () {
    assertAlive(this);
    if (!this.config.PAUSED) {
      this.config.PAUSED = true;
      this._emit(EVENTS.PAUSE, {});
    }
    return this;
  };

  /** Resume a paused simulation. */
  FluidSimulation.prototype.resume = function () {
    assertAlive(this);
    if (this.config.PAUSED) {
      this.config.PAUSED = false;
      this._lastUpdateTime = now();
      this._emit(EVENTS.RESUME, {});
    }
    if (!this.running) this.start();
    return this;
  };

  FluidSimulation.prototype.togglePause = function () {
    return this.config.PAUSED ? this.resume() : this.pause();
  };

  FluidSimulation.prototype.isPaused = function () {
    return !!this.config.PAUSED;
  };

  FluidSimulation.prototype.isRunning = function () {
    return !!this.running && !this.destroyed;
  };

  FluidSimulation.prototype.isDestroyed = function () {
    return !!this.destroyed;
  };

  /** Re-read the canvas size and rebuild framebuffers if it changed. */
  FluidSimulation.prototype.resize = function () {
    assertAlive(this);
    if (this._resizeCanvas()) this._handleResize();
    return this;
  };

  /** Release every listener, GL resource and (optionally) the canvas element. */
  FluidSimulation.prototype.destroy = function () {
    if (this.destroyed) return this;
    this.destroyed = true;
    this.stop();
    this.disableInput();
    this.disableKeyboard();
    this._unbindResizeObserver();
    this._unbindVisibility();

    var gl = this.gl;
    if (gl) {
      if (this.canvas && this._onContextLost) {
        this.canvas.removeEventListener('webglcontextlost', this._onContextLost);
        this.canvas.removeEventListener('webglcontextrestored', this._onContextRestored);
      }
      this._deleteFramebuffers();
      this._deletePrograms();
      if (this._vertexBuffer) gl.deleteBuffer(this._vertexBuffer);
      if (this._indexBuffer) gl.deleteBuffer(this._indexBuffer);
      var lose = gl.getExtension('WEBGL_lose_context');
      if (this.options.releaseContext && lose) lose.loseContext();
    }

    this._emit(EVENTS.DESTROY, {});
    this._handlers = {};
    this.ready = false;

    if (this._ownsCanvas && this.options.removeCanvasOnDestroy && this.canvas && this.canvas.parentNode) {
      this.canvas.parentNode.removeChild(this.canvas);
    }
    return this;
  };

  // Alias: some code bases prefer deinit()/dispose().
  FluidSimulation.prototype.dispose = FluidSimulation.prototype.destroy;

  // ---------------------------------------------------------------------------
  // Resource creation
  // ---------------------------------------------------------------------------

  FluidSimulation.prototype._initResources = function () {
    var context = getWebGLContext(this.canvas, this.options);
    this.gl = context.gl;
    this.isWebGL2 = context.isWebGL2;
    this.ext = context.ext;

    if (this.options.autoDegrade !== false) this._applyCapabilityDegradation();

    this._createPrograms();
    this._createBlit();
    this._updateKeywords();
    this._initDithering();
    this._initFramebuffers();
  };

  FluidSimulation.prototype._applyCapabilityDegradation = function () {
    if (!this.ext.supportLinearFiltering) {
      this.config.DYE_RESOLUTION = 512;
      this.config.SHADING = false;
      this.config.BLOOM = false;
      this.config.SUNRAYS = false;
      this.degraded.noLinearFiltering = true;
      warn('This device does not support linear filtering of float textures; ' +
        'quality, shading, bloom and sunrays were disabled.');
    }
    if (this.options.mobileQuality !== false && isMobile()) {
      this.config.DYE_RESOLUTION = Math.min(this.config.DYE_RESOLUTION, 512);
      this.degraded.mobile = true;
    }
  };

  FluidSimulation.prototype._createPrograms = function () {
    var gl = this.gl;
    var S = SHADERS;

    var baseVertexShader = compileShader(gl, gl.VERTEX_SHADER, S.baseVertex);
    var blurVertexShader = compileShader(gl, gl.VERTEX_SHADER, S.blurVertex);
    this._shaderCache = { baseVertex: baseVertexShader, blurVertex: blurVertexShader };

    var advectionKeywords = this.ext.supportLinearFiltering ? null : ['MANUAL_FILTERING'];

    this.programs = {
      blur: new Program(gl, blurVertexShader, compileShader(gl, gl.FRAGMENT_SHADER, S.blur)),
      copy: new Program(gl, baseVertexShader, compileShader(gl, gl.FRAGMENT_SHADER, S.copy)),
      clear: new Program(gl, baseVertexShader, compileShader(gl, gl.FRAGMENT_SHADER, S.clear)),
      color: new Program(gl, baseVertexShader, compileShader(gl, gl.FRAGMENT_SHADER, S.color)),
      checkerboard: new Program(gl, baseVertexShader, compileShader(gl, gl.FRAGMENT_SHADER, S.checkerboard)),
      bloomPrefilter: new Program(gl, baseVertexShader, compileShader(gl, gl.FRAGMENT_SHADER, S.bloomPrefilter)),
      bloomBlur: new Program(gl, baseVertexShader, compileShader(gl, gl.FRAGMENT_SHADER, S.bloomBlur)),
      bloomFinal: new Program(gl, baseVertexShader, compileShader(gl, gl.FRAGMENT_SHADER, S.bloomFinal)),
      sunraysMask: new Program(gl, baseVertexShader, compileShader(gl, gl.FRAGMENT_SHADER, S.sunraysMask)),
      sunrays: new Program(gl, baseVertexShader, compileShader(gl, gl.FRAGMENT_SHADER, S.sunrays)),
      splat: new Program(gl, baseVertexShader, compileShader(gl, gl.FRAGMENT_SHADER, S.splat)),
      advection: new Program(gl, baseVertexShader, compileShader(gl, gl.FRAGMENT_SHADER, S.advection, advectionKeywords)),
      divergence: new Program(gl, baseVertexShader, compileShader(gl, gl.FRAGMENT_SHADER, S.divergence)),
      curl: new Program(gl, baseVertexShader, compileShader(gl, gl.FRAGMENT_SHADER, S.curl)),
      vorticity: new Program(gl, baseVertexShader, compileShader(gl, gl.FRAGMENT_SHADER, S.vorticity)),
      pressure: new Program(gl, baseVertexShader, compileShader(gl, gl.FRAGMENT_SHADER, S.pressure)),
      gradientSubtract: new Program(gl, baseVertexShader, compileShader(gl, gl.FRAGMENT_SHADER, S.gradientSubtract))
    };

    this.displayMaterial = new Material(gl, baseVertexShader, SHADERS.display);
  };

  FluidSimulation.prototype._createBlit = function () {
    var gl = this.gl;
    var self = this;

    this._vertexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this._vertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, -1, 1, 1, 1, 1, -1]), gl.STATIC_DRAW);
    this._indexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this._indexBuffer);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array([0, 1, 2, 0, 2, 3]), gl.STATIC_DRAW);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(0);

    /** Draw the full-screen quad into `target` (null = the visible canvas). */
    this.blit = function (target, clear) {
      if (target == null) {
        gl.viewport(0, 0, gl.drawingBufferWidth, gl.drawingBufferHeight);
        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      } else {
        gl.viewport(0, 0, target.width, target.height);
        gl.bindFramebuffer(gl.FRAMEBUFFER, target.fbo);
      }
      if (clear) {
        gl.clearColor(0.0, 0.0, 0.0, 1.0);
        gl.clear(gl.COLOR_BUFFER_BIT);
      }
      gl.drawElements(gl.TRIANGLES, 6, gl.UNSIGNED_SHORT, 0);
      self._drawCalls++;
    };

    this._drawCalls = 0;
  };

  FluidSimulation.prototype._initDithering = function () {
    var gl = this.gl;
    if (this.ditheringTexture) {
      gl.deleteTexture(this.ditheringTexture.texture);
      this.ditheringTexture = null;
    }
    var url = this.options.ditheringUrl;
    if (url) {
      this.ditheringTexture = this._createTextureAsync(url);
    } else if (this.config.DITHERING !== false) {
      this.ditheringTexture = this._createDataTexture(createNoiseData(64), 64, 64);
    } else {
      // Flat mid-grey: the bloom noise term becomes a constant, so nothing shimmers.
      this.ditheringTexture = this._createDataTexture(new Uint8Array([128, 128, 128, 255]), 1, 1);
    }
  };

  /**
   * Enable/disable bloom dithering, or point it at your own noise texture:
   * `setDithering(true)`, `setDithering(false)`, `setDithering('noise.png')`.
   */
  FluidSimulation.prototype.setDithering = function (value) {
    assertAlive(this);
    if (typeof value === 'string') {
      this.options.ditheringUrl = value;
      this.config.DITHERING = true;
    } else {
      this.options.ditheringUrl = null;
      this.config.DITHERING = value !== false;
    }
    this._initDithering();
    return this;
  };

  FluidSimulation.prototype._createDataTexture = function (data, width, height) {
    var gl = this.gl;
    var texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, data);
    return makeTextureHandle(gl, texture, width, height);
  };

  FluidSimulation.prototype._createTextureAsync = function (url) {
    var gl = this.gl;
    var handle = this._createDataTexture(new Uint8Array([128, 128, 128, 255]), 1, 1);
    if (typeof Image === 'undefined') return handle;
    var image = new Image();
    image.crossOrigin = 'anonymous';
    image.onload = function () {
      if (handle.disposed) return;
      handle.width = image.width;
      handle.height = image.height;
      gl.bindTexture(gl.TEXTURE_2D, handle.texture);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
    };
    image.onerror = function () {
      warn('Could not load the dithering texture "' + url + '"; using generated noise instead.');
    };
    image.src = url;
    return handle;
  };

  function makeTextureHandle(gl, texture, width, height) {
    return {
      texture: texture,
      width: width,
      height: height,
      disposed: false,
      attach: function (id) {
        gl.activeTexture(gl.TEXTURE0 + id);
        gl.bindTexture(gl.TEXTURE_2D, texture);
        return id;
      },
      dispose: function () {
        this.disposed = true;
        gl.deleteTexture(texture);
      }
    };
  }

  // ---------------------------------------------------------------------------
  // Framebuffers
  // ---------------------------------------------------------------------------

  FluidSimulation.prototype._initFramebuffers = function () {
    var gl = this.gl;
    var config = this.config;
    var simRes = getResolution(gl, config.SIM_RESOLUTION);
    var dyeRes = getResolution(gl, config.DYE_RESOLUTION);

    var texType = this.ext.halfFloatTexType;
    var rgba = this.ext.formatRGBA;
    var rg = this.ext.formatRG;
    var r = this.ext.formatR;
    var filtering = this.ext.supportLinearFiltering ? gl.LINEAR : gl.NEAREST;

    gl.disable(gl.BLEND);

    if (this.dye == null) {
      this.dye = this._createDoubleFBO(dyeRes.width, dyeRes.height, rgba.internalFormat, rgba.format, texType, filtering);
    } else {
      this.dye = this._resizeDoubleFBO(this.dye, dyeRes.width, dyeRes.height, rgba.internalFormat, rgba.format, texType, filtering);
    }

    if (this.velocity == null) {
      this.velocity = this._createDoubleFBO(simRes.width, simRes.height, rg.internalFormat, rg.format, texType, filtering);
    } else {
      this.velocity = this._resizeDoubleFBO(this.velocity, simRes.width, simRes.height, rg.internalFormat, rg.format, texType, filtering);
    }

    this.divergence = this._createFBO(simRes.width, simRes.height, r.internalFormat, r.format, texType, gl.NEAREST);
    this.curl = this._createFBO(simRes.width, simRes.height, r.internalFormat, r.format, texType, gl.NEAREST);
    this.pressure = this._createDoubleFBO(simRes.width, simRes.height, r.internalFormat, r.format, texType, gl.NEAREST);

    this._initBloomFramebuffers();
    this._initSunraysFramebuffers();
  };

  FluidSimulation.prototype._initBloomFramebuffers = function () {
    var gl = this.gl;
    var config = this.config;
    var res = getResolution(gl, config.BLOOM_RESOLUTION);

    var texType = this.ext.halfFloatTexType;
    var rgba = this.ext.formatRGBA;
    var filtering = this.ext.supportLinearFiltering ? gl.LINEAR : gl.NEAREST;

    if (this.bloom) this.bloom.dispose();
    this.bloom = this._createFBO(res.width, res.height, rgba.internalFormat, rgba.format, texType, filtering);

    if (this.bloomFramebuffers) {
      this.bloomFramebuffers.forEach(function (fbo) { fbo.dispose(); });
    }
    this.bloomFramebuffers = [];
    for (var i = 0; i < config.BLOOM_ITERATIONS; i++) {
      var width = res.width >> (i + 1);
      var height = res.height >> (i + 1);
      if (width < 2 || height < 2) break;
      this.bloomFramebuffers.push(this._createFBO(width, height, rgba.internalFormat, rgba.format, texType, filtering));
    }
  };

  FluidSimulation.prototype._initSunraysFramebuffers = function () {
    var gl = this.gl;
    var config = this.config;
    var res = getResolution(gl, config.SUNRAYS_RESOLUTION);

    var texType = this.ext.halfFloatTexType;
    var r = this.ext.formatR;
    var filtering = this.ext.supportLinearFiltering ? gl.LINEAR : gl.NEAREST;

    if (this.sunrays) this.sunrays.dispose();
    if (this.sunraysTemp) this.sunraysTemp.dispose();
    this.sunrays = this._createFBO(res.width, res.height, r.internalFormat, r.format, texType, filtering);
    this.sunraysTemp = this._createFBO(res.width, res.height, r.internalFormat, r.format, texType, filtering);
  };

  FluidSimulation.prototype._createFBO = function (w, h, internalFormat, format, type, param) {
    var gl = this.gl;
    gl.activeTexture(gl.TEXTURE0);
    var texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, param);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, param);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texImage2D(gl.TEXTURE_2D, 0, internalFormat, w, h, 0, format, type, null);

    var fbo = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, texture, 0);
    gl.viewport(0, 0, w, h);
    gl.clear(gl.COLOR_BUFFER_BIT);

    return {
      texture: texture,
      fbo: fbo,
      width: w,
      height: h,
      texelSizeX: 1.0 / w,
      texelSizeY: 1.0 / h,
      attach: function (id) {
        gl.activeTexture(gl.TEXTURE0 + id);
        gl.bindTexture(gl.TEXTURE_2D, texture);
        return id;
      },
      dispose: function () {
        gl.deleteFramebuffer(fbo);
        gl.deleteTexture(texture);
      }
    };
  };

  FluidSimulation.prototype._createDoubleFBO = function (w, h, internalFormat, format, type, param) {
    var fbo1 = this._createFBO(w, h, internalFormat, format, type, param);
    var fbo2 = this._createFBO(w, h, internalFormat, format, type, param);

    return {
      width: w,
      height: h,
      texelSizeX: fbo1.texelSizeX,
      texelSizeY: fbo1.texelSizeY,
      get read() { return fbo1; },
      set read(value) { fbo1 = value; },
      get write() { return fbo2; },
      set write(value) { fbo2 = value; },
      swap: function () {
        var temp = fbo1;
        fbo1 = fbo2;
        fbo2 = temp;
      },
      dispose: function () {
        fbo1.dispose();
        fbo2.dispose();
      }
    };
  };

  FluidSimulation.prototype._resizeFBO = function (target, w, h, internalFormat, format, type, param) {
    var gl = this.gl;
    var newFBO = this._createFBO(w, h, internalFormat, format, type, param);
    var copy = this.programs.copy;
    copy.bind();
    gl.uniform1i(copy.uniforms.uTexture, target.attach(0));
    this.blit(newFBO);
    target.dispose();
    return newFBO;
  };

  FluidSimulation.prototype._resizeDoubleFBO = function (target, w, h, internalFormat, format, type, param) {
    if (target.width === w && target.height === h) return target;
    target.read = this._resizeFBO(target.read, w, h, internalFormat, format, type, param);
    target.write.dispose();
    target.write = this._createFBO(w, h, internalFormat, format, type, param);
    target.width = w;
    target.height = h;
    target.texelSizeX = 1.0 / w;
    target.texelSizeY = 1.0 / h;
    return target;
  };

  FluidSimulation.prototype._deleteFramebuffers = function () {
    var self = this;
    ['dye', 'velocity', 'divergence', 'curl', 'pressure', 'bloom', 'sunrays', 'sunraysTemp'].forEach(function (key) {
      if (self[key] && self[key].dispose) self[key].dispose();
      self[key] = null;
    });
    if (this.bloomFramebuffers) {
      this.bloomFramebuffers.forEach(function (fbo) { fbo.dispose(); });
      this.bloomFramebuffers = [];
    }
    if (this.ditheringTexture) {
      this.ditheringTexture.dispose();
      this.ditheringTexture = null;
    }
  };

  FluidSimulation.prototype._deletePrograms = function () {
    var self = this;
    if (this.programs) {
      Object.keys(this.programs).forEach(function (key) { self.programs[key].dispose(); });
      this.programs = null;
    }
    if (this.displayMaterial) {
      this.displayMaterial.dispose();
      this.displayMaterial = null;
    }
    if (this._shaderCache) {
      Object.keys(this._shaderCache).forEach(function (key) { self.gl.deleteShader(self._shaderCache[key]); });
      this._shaderCache = null;
    }
  };

  // ---------------------------------------------------------------------------
  // Keywords
  // ---------------------------------------------------------------------------

  FluidSimulation.prototype._updateKeywords = function () {
    if (!this.displayMaterial) return;
    var keywords = [];
    if (this.config.SHADING) keywords.push('SHADING');
    if (this.config.BLOOM) keywords.push('BLOOM');
    if (this.config.SUNRAYS) keywords.push('SUNRAYS');
    this.displayMaterial.setKeywords(keywords);
  };
