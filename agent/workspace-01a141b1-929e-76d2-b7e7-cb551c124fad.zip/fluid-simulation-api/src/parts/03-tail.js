  // ---------------------------------------------------------------------------
  // Module-level API
  // ---------------------------------------------------------------------------

  /** Every live instance created through FluidSimulation.create(). */
  var instances = [];

  /**
   * Create a simulation and keep it in FluidSimulation.instances until destroyed.
   * @returns {FluidSimulation}
   */
  function create(options) {
    var instance = new FluidSimulation(options);
    instances.push(instance);
    instance.once(EVENTS.DESTROY, function () {
      var index = instances.indexOf(instance);
      if (index !== -1) instances.splice(index, 1);
    });
    return instance;
  }

  /**
   * Like create(), but returns null (and calls options.onError) when the device
   * cannot run the simulation - handy for progressive enhancement.
   */
  function createIfSupported(options) {
    var opts = options || {};
    if (!isSupported()) {
      var reason = new FluidError(ERROR_CODES.NO_WEBGL, 'WebGL is not available in this browser.');
      if (typeof opts.onError === 'function') opts.onError(reason);
      else warn(reason.message);
      return null;
    }
    try {
      return create(options);
    } catch (error) {
      if (typeof opts.onError === 'function') opts.onError(error);
      else warn(error.message);
      return null;
    }
  }

  /** Feature test that does not leave a WebGL context behind. */
  function isSupported() {
    if (typeof document === 'undefined') return false;
    var canvas;
    try {
      canvas = document.createElement('canvas');
      var context = getWebGLContext(canvas, {});
      var lose = context.gl.getExtension('WEBGL_lose_context');
      if (lose) lose.loseContext();
      return true;
    } catch (error) {
      return false;
    }
  }

  /** Explicit alias of create() - reads well when the canvas already exists. */
  function attach(target, options) {
    return create(assign({}, options || {}, { canvas: target }));
  }

  /**
   * Instantiate every `[data-fluid]` element on the page (or your own selector).
   *
   *   <canvas data-fluid data-fluid-preset="vivid" data-fluid-config='{"CURL":45}'></canvas>
   *
   * @param {Object} [options] passed to every instance; `options.selector` overrides
   *   the query, `options.defaultsOnly` skips elements that already have an instance.
   * @returns {FluidSimulation[]} the instances created by this call
   */
  function autoInit(options) {
    var opts = options || {};
    if (typeof document === 'undefined') return [];
    var selector = opts.selector || '[data-fluid]';
    var elements = document.querySelectorAll(selector);
    var created = [];

    Array.prototype.forEach.call(elements, function (element) {
      if (element.__fluidInstance) return;

      var local = assign({}, opts);
      delete local.selector;

      var inline = element.getAttribute('data-fluid');
      if (inline && inline.trim() && inline.trim() !== 'true') {
        try {
          assign(local, JSON.parse(inline));
        } catch (error) {
          warn('data-fluid attribute is not valid JSON on <' + element.tagName.toLowerCase() + '>.');
        }
      }
      var config = element.getAttribute('data-fluid-config');
      if (config) {
        try {
          local.config = assign({}, local.config || {}, JSON.parse(config));
        } catch (error) {
          warn('data-fluid-config attribute is not valid JSON on <' + element.tagName.toLowerCase() + '>.');
        }
      }
      var preset = element.getAttribute('data-fluid-preset');
      if (preset) local.preset = preset;

      if (element.tagName === 'CANVAS') local.canvas = element;
      else local.container = element;

      try {
        var instance = create(local);
        element.__fluidInstance = instance;
        element.fluid = instance;
        created.push(instance);
      } catch (error) {
        warn('could not initialise the simulation on <' + element.tagName.toLowerCase() + '>: ' + error.message);
      }
    });

    return created;
  }

  /** Destroy every live instance; returns how many were destroyed. */
  function destroyAll() {
    var snapshot = instances.slice();
    snapshot.forEach(function (instance) { instance.destroy(); });
    return snapshot.length;
  }

  // ---------------------------------------------------------------------------
  // Public surface
  // ---------------------------------------------------------------------------

  FluidSimulation.version = VERSION;
  FluidSimulation.instances = instances;

  FluidSimulation.create = create;
  FluidSimulation.createIfSupported = createIfSupported;
  FluidSimulation.attach = attach;
  FluidSimulation.autoInit = autoInit;
  FluidSimulation.isSupported = isSupported;
  FluidSimulation.destroyAll = destroyAll;

  FluidSimulation.events = EVENTS;
  FluidSimulation.errorCodes = ERROR_CODES;
  FluidSimulation.Error = FluidError;

  /** Fresh copy of the default simulation configuration. */
  FluidSimulation.defaultConfig = function () {
    return cloneConfig(DEFAULT_CONFIG);
  };

  /** Fresh copy of the default options accepted by create(). */
  FluidSimulation.defaultOptions = function () {
    return cloneConfig(DEFAULT_OPTIONS);
  };

  FluidSimulation.defaults = {
    config: DEFAULT_CONFIG,
    options: DEFAULT_OPTIONS,
    presets: PRESETS
  };

  FluidSimulation.presets = PRESETS;

  /** The GLSL sources, exposed for advanced reuse/customisation. */
  FluidSimulation.shaders = SHADERS;

  FluidSimulation.helpers = {
    HSVtoRGB: HSVtoRGB,
    hexToRgb: hexToRgb,
    rgbToHex: rgbToHex,
    toRgb255: toRgb255,
    normalizeColor: normalizeColor,
    randomColor: defaultColorGenerator,
    clamp01: clamp01,
    clamp: clamp,
    wrap: wrap,
    isMobile: isMobile,
    hashCode: hashCode
  };

  FluidSimulation.prototype.constructor = FluidSimulation;

  return FluidSimulation;
});
