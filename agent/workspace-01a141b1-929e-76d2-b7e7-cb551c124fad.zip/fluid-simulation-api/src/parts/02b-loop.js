  // ---------------------------------------------------------------------------
  // Frame loop, simulation and rendering
  // ---------------------------------------------------------------------------

  function assertAlive(instance) {
    if (!instance || instance.destroyed) {
      throw new FluidError(ERROR_CODES.DESTROYED, 'This fluid simulation has been destroyed.');
    }
  }

  function warn(message) {
    if (typeof console !== 'undefined' && console.warn) console.warn('[FluidSimulation] ' + message);
  }

  FluidSimulation.prototype._tick = function () {
    if (this.destroyed || !this.running) return;

    var dt = (now() - this._lastUpdateTime) / 1000;
    dt = Math.min(dt, 0.016666);
    this._lastUpdateTime = now();

    this._advance(dt);

    this._rafId = requestAnimationFrame(this._boundTick);
  };

  /** One simulation+render iteration with an explicit timestep. */
  FluidSimulation.prototype.frame = function (dt) {
    assertAlive(this);
    this._advance(typeof dt === 'number' && dt > 0 ? Math.min(dt, 0.1) : 1 / 60);
    return this;
  };

  // Alias for people who think of frame() as an update step.
  FluidSimulation.prototype.update = function (dt) {
    return this.frame(dt);
  };

  FluidSimulation.prototype._advance = function (dt) {
    if (this._contextLost) return;
    if (this._resizeCanvas()) this._handleResize();
    this._updateColors(dt);
    this._applyInputs();
    if (!this.config.PAUSED) this.step(dt);
    this._render(null);
    this._emit(EVENTS.FRAME, { dt: dt, paused: !!this.config.PAUSED, drawCalls: this._drawCalls });
  };

  FluidSimulation.prototype._resizeCanvas = function () {
    var canvas = this.canvas;
    var displayWidth = canvas.clientWidth || canvas.width;
    var displayHeight = canvas.clientHeight || canvas.height;
    var width = scaleByPixelRatio(displayWidth);
    var height = scaleByPixelRatio(displayHeight);
    if (width === 0 || height === 0) return false;
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
      return true;
    }
    return false;
  };

  FluidSimulation.prototype._handleResize = function () {
    this._initFramebuffers();
    this._emit(EVENTS.RESIZE, { width: this.canvas.width, height: this.canvas.height });
  };

  FluidSimulation.prototype._updateColors = function (dt) {
    if (!this.config.COLORFUL) return;
    this._colorUpdateTimer += dt * this.config.COLOR_UPDATE_SPEED;
    if (this._colorUpdateTimer >= 1) {
      this._colorUpdateTimer = wrap(this._colorUpdateTimer, 0, 1);
      var color = this._nextPointerColor();
      this.pointers.forEach(function (pointer) { pointer.color = color; });
    }
  };

  FluidSimulation.prototype._applyInputs = function () {
    if (this._splatStack.length > 0) {
      this._multipleSplats(this._splatStack.pop());
    }
    this.pointers.forEach(function (pointer) {
      if (pointer.moved) {
        pointer.moved = false;
        this._splatPointer(pointer);
      }
    }, this);
  };

  /** One pressure-projection/transport iteration (ported from the original step()). */
  FluidSimulation.prototype.step = function (dt) {
    assertAlive(this);
    var gl = this.gl;
    var config = this.config;
    var programs = this.programs;
    var velocity = this.velocity;
    var ext = this.ext;

    gl.disable(gl.BLEND);

    programs.curl.bind();
    gl.uniform2f(programs.curl.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY);
    gl.uniform1i(programs.curl.uniforms.uVelocity, velocity.read.attach(0));
    this.blit(this.curl);

    programs.vorticity.bind();
    gl.uniform2f(programs.vorticity.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY);
    gl.uniform1i(programs.vorticity.uniforms.uVelocity, velocity.read.attach(0));
    gl.uniform1i(programs.vorticity.uniforms.uCurl, this.curl.attach(1));
    gl.uniform1f(programs.vorticity.uniforms.curl, config.CURL);
    gl.uniform1f(programs.vorticity.uniforms.dt, dt);
    this.blit(velocity.write);
    velocity.swap();

    programs.divergence.bind();
    gl.uniform2f(programs.divergence.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY);
    gl.uniform1i(programs.divergence.uniforms.uVelocity, velocity.read.attach(0));
    this.blit(this.divergence);

    programs.clear.bind();
    gl.uniform1i(programs.clear.uniforms.uTexture, this.pressure.read.attach(0));
    gl.uniform1f(programs.clear.uniforms.value, config.PRESSURE);
    this.blit(this.pressure.write);
    this.pressure.swap();

    programs.pressure.bind();
    gl.uniform2f(programs.pressure.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY);
    gl.uniform1i(programs.pressure.uniforms.uDivergence, this.divergence.attach(0));
    for (var i = 0; i < config.PRESSURE_ITERATIONS; i++) {
      gl.uniform1i(programs.pressure.uniforms.uPressure, this.pressure.read.attach(1));
      this.blit(this.pressure.write);
      this.pressure.swap();
    }

    programs.gradientSubtract.bind();
    gl.uniform2f(programs.gradientSubtract.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY);
    gl.uniform1i(programs.gradientSubtract.uniforms.uPressure, this.pressure.read.attach(0));
    gl.uniform1i(programs.gradientSubtract.uniforms.uVelocity, velocity.read.attach(1));
    this.blit(velocity.write);
    velocity.swap();

    programs.advection.bind();
    gl.uniform2f(programs.advection.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY);
    if (!ext.supportLinearFiltering) {
      gl.uniform2f(programs.advection.uniforms.dyeTexelSize, velocity.texelSizeX, velocity.texelSizeY);
    }
    var velocityId = velocity.read.attach(0);
    gl.uniform1i(programs.advection.uniforms.uVelocity, velocityId);
    gl.uniform1i(programs.advection.uniforms.uSource, velocityId);
    gl.uniform1f(programs.advection.uniforms.dt, dt);
    gl.uniform1f(programs.advection.uniforms.dissipation, config.VELOCITY_DISSIPATION);
    this.blit(velocity.write);
    velocity.swap();

    if (!ext.supportLinearFiltering) {
      gl.uniform2f(programs.advection.uniforms.dyeTexelSize, this.dye.texelSizeX, this.dye.texelSizeY);
    }
    gl.uniform1i(programs.advection.uniforms.uVelocity, velocity.read.attach(0));
    gl.uniform1i(programs.advection.uniforms.uSource, this.dye.read.attach(1));
    gl.uniform1f(programs.advection.uniforms.dissipation, config.DENSITY_DISSIPATION);
    this.blit(this.dye.write);
    this.dye.swap();
  };

  /** Composite the dye (plus bloom/sunrays) into `target`; null renders on screen. */
  FluidSimulation.prototype._render = function (target) {
    var gl = this.gl;
    var config = this.config;

    if (config.BLOOM) this._applyBloom(this.dye.read, this.bloom);
    if (config.SUNRAYS) {
      this._applySunrays(this.dye.read, this.dye.write, this.sunrays);
      this._blur(this.sunrays, this.sunraysTemp, 1);
    }

    if (target == null || !config.TRANSPARENT) {
      gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
      gl.enable(gl.BLEND);
    } else {
      gl.disable(gl.BLEND);
    }

    if (!config.TRANSPARENT) this._drawColor(target, normalizeColor(config.BACK_COLOR));
    if (target == null && config.TRANSPARENT) this._drawCheckerboard(target);
    this._drawDisplay(target);
  };

  FluidSimulation.prototype._drawColor = function (target, color) {
    var gl = this.gl;
    var program = this.programs.color;
    program.bind();
    gl.uniform4f(program.uniforms.color, color.r, color.g, color.b, 1);
    this.blit(target);
  };

  FluidSimulation.prototype._drawCheckerboard = function (target) {
    var gl = this.gl;
    var program = this.programs.checkerboard;
    program.bind();
    gl.uniform1f(program.uniforms.aspectRatio, this.canvas.width / this.canvas.height);
    this.blit(target);
  };

  FluidSimulation.prototype._drawDisplay = function (target) {
    var gl = this.gl;
    var config = this.config;
    var width = target == null ? gl.drawingBufferWidth : target.width;
    var height = target == null ? gl.drawingBufferHeight : target.height;

    this.displayMaterial.bind();
    if (config.SHADING) {
      gl.uniform2f(this.displayMaterial.uniforms.texelSize, 1.0 / width, 1.0 / height);
    }
    gl.uniform1i(this.displayMaterial.uniforms.uTexture, this.dye.read.attach(0));
    if (config.BLOOM) {
      gl.uniform1i(this.displayMaterial.uniforms.uBloom, this.bloom.attach(1));
      gl.uniform1i(this.displayMaterial.uniforms.uDithering, this.ditheringTexture.attach(2));
      var scale = getTextureScale(this.ditheringTexture, width, height);
      gl.uniform2f(this.displayMaterial.uniforms.ditherScale, scale.x, scale.y);
    }
    if (config.SUNRAYS) {
      gl.uniform1i(this.displayMaterial.uniforms.uSunrays, this.sunrays.attach(3));
    }
    this.blit(target);
  };

  FluidSimulation.prototype._applyBloom = function (source, destination) {
    var gl = this.gl;
    var config = this.config;
    var program = this.programs.bloomBlur;

    if (this.bloomFramebuffers.length < 2) return;

    var last = destination;

    gl.disable(gl.BLEND);
    var prefilter = this.programs.bloomPrefilter;
    prefilter.bind();
    var knee = config.BLOOM_THRESHOLD * config.BLOOM_SOFT_KNEE + 0.0001;
    var curve0 = config.BLOOM_THRESHOLD - knee;
    var curve1 = knee * 2;
    var curve2 = 0.25 / knee;
    gl.uniform3f(prefilter.uniforms.curve, curve0, curve1, curve2);
    gl.uniform1f(prefilter.uniforms.threshold, config.BLOOM_THRESHOLD);
    gl.uniform1i(prefilter.uniforms.uTexture, source.attach(0));
    this.blit(last);

    program.bind();
    for (var i = 0; i < this.bloomFramebuffers.length; i++) {
      var dest = this.bloomFramebuffers[i];
      gl.uniform2f(program.uniforms.texelSize, last.texelSizeX, last.texelSizeY);
      gl.uniform1i(program.uniforms.uTexture, last.attach(0));
      this.blit(dest);
      last = dest;
    }

    gl.blendFunc(gl.ONE, gl.ONE);
    gl.enable(gl.BLEND);

    for (var j = this.bloomFramebuffers.length - 2; j >= 0; j--) {
      var baseTex = this.bloomFramebuffers[j];
      gl.uniform2f(program.uniforms.texelSize, last.texelSizeX, last.texelSizeY);
      gl.uniform1i(program.uniforms.uTexture, last.attach(0));
      gl.viewport(0, 0, baseTex.width, baseTex.height);
      this.blit(baseTex);
      last = baseTex;
    }

    gl.disable(gl.BLEND);
    var final = this.programs.bloomFinal;
    final.bind();
    gl.uniform2f(final.uniforms.texelSize, last.texelSizeX, last.texelSizeY);
    gl.uniform1i(final.uniforms.uTexture, last.attach(0));
    gl.uniform1f(final.uniforms.intensity, config.BLOOM_INTENSITY);
    this.blit(destination);
  };

  FluidSimulation.prototype._applySunrays = function (source, mask, destination) {
    var gl = this.gl;
    gl.disable(gl.BLEND);

    var maskProgram = this.programs.sunraysMask;
    maskProgram.bind();
    gl.uniform1i(maskProgram.uniforms.uTexture, source.attach(0));
    this.blit(mask);

    var program = this.programs.sunrays;
    program.bind();
    gl.uniform1f(program.uniforms.weight, this.config.SUNRAYS_WEIGHT);
    gl.uniform1i(program.uniforms.uTexture, mask.attach(0));
    this.blit(destination);
  };

  FluidSimulation.prototype._blur = function (target, temp, iterations) {
    var gl = this.gl;
    var program = this.programs.blur;
    program.bind();
    for (var i = 0; i < iterations; i++) {
      gl.uniform2f(program.uniforms.texelSize, target.texelSizeX, 0.0);
      gl.uniform1i(program.uniforms.uTexture, target.attach(0));
      this.blit(temp);

      gl.uniform2f(program.uniforms.texelSize, 0.0, target.texelSizeY);
      gl.uniform1i(program.uniforms.uTexture, temp.attach(0));
      this.blit(target);
    }
  };

  // ---------------------------------------------------------------------------
  // Splats
  // ---------------------------------------------------------------------------

  FluidSimulation.prototype._splatPointer = function (pointer) {
    var dx = pointer.deltaX * this.config.SPLAT_FORCE;
    var dy = pointer.deltaY * this.config.SPLAT_FORCE;
    this.splat(pointer.texcoordX, pointer.texcoordY, dx, dy, pointer.color);
  };

  FluidSimulation.prototype._multipleSplats = function (amount) {
    for (var i = 0; i < amount; i++) {
      var color = this.randomColor();
      color.r *= 10.0;
      color.g *= 10.0;
      color.b *= 10.0;
      var x = Math.random();
      var y = Math.random();
      var dx = 1000 * (Math.random() - 0.5);
      var dy = 1000 * (Math.random() - 0.5);
      this.splat(x, y, dx, dy, color);
    }
  };

  /**
   * Inject dye + velocity at a point.
   *
   * @param {number} x        normalized 0..1, origin bottom-left
   * @param {number} y        normalized 0..1, origin bottom-left
   * @param {number} [dx]     horizontal velocity impulse
   * @param {number} [dy]     vertical velocity impulse
   * @param {string|Object|Array} [color] hex/array/object, defaults to a random color
   * @param {Object} [options] `{ radius }` - same scale as config.SPLAT_RADIUS
   * @returns {FluidSimulation} this
   */
  FluidSimulation.prototype.splat = function (x, y, dx, dy, color, options) {
    assertAlive(this);
    if (!this.ready || this._contextLost) return this;

    var gl = this.gl;
    var config = this.config;
    var program = this.programs.splat;
    var rgb = color == null ? this.randomColor() : normalizeColor(color);
    var radius = options && options.radius != null ? options.radius : config.SPLAT_RADIUS;

    program.bind();
    gl.uniform1i(program.uniforms.uTarget, this.velocity.read.attach(0));
    gl.uniform1f(program.uniforms.aspectRatio, this.canvas.width / this.canvas.height);
    gl.uniform2f(program.uniforms.point, x, y);
    gl.uniform3f(program.uniforms.color, dx || 0, dy || 0, 0.0);
    gl.uniform1f(program.uniforms.radius, this._correctRadius(radius / 100.0));
    this.blit(this.velocity.write);
    this.velocity.swap();

    gl.uniform1i(program.uniforms.uTarget, this.dye.read.attach(0));
    gl.uniform3f(program.uniforms.color, rgb.r, rgb.g, rgb.b);
    this.blit(this.dye.write);
    this.dye.swap();

    this._emit(EVENTS.SPLAT, { x: x, y: y, dx: dx || 0, dy: dy || 0, color: rgb, radius: radius });
    return this;
  };

  /**
   * Splat using CSS/client pixel coordinates (the event's clientX/clientY).
   * dx/dy are pixel deltas, exactly like dragging a pointer.
   */
  FluidSimulation.prototype.splatAt = function (clientX, clientY, dx, dy, color, options) {
    assertAlive(this);
    var rect = this.canvas.getBoundingClientRect();
    var width = rect.width || this.canvas.clientWidth || 1;
    var height = rect.height || this.canvas.clientHeight || 1;
    var x = (clientX - rect.left) / width;
    var y = 1.0 - (clientY - rect.top) / height;
    var deltaX = dx ? this._correctDeltaX(dx / width) : 0;
    var deltaY = dy ? this._correctDeltaY(-dy / height) : 0;
    return this.splat(x, y, deltaX, deltaY, color, options);
  };

  /** Throw `amount` random splats right now. */
  FluidSimulation.prototype.randomSplats = function (amount) {
    assertAlive(this);
    var count = clamp(amount == null ? 8 : amount | 0, 0, 100);
    this._multipleSplats(count);
    this._emit(EVENTS.SPLAT, { multiple: count });
    return this;
  };

  /** Queue random splats for the next frame (lets you burst on load). */
  FluidSimulation.prototype.queueSplats = function (amount) {
    assertAlive(this);
    this._splatStack.push(clamp(amount == null ? 8 : amount | 0, 0, 100));
    return this;
  };

  /** Wipe the dye and velocity fields (framebuffers are recreated empty). */
  FluidSimulation.prototype.clear = function () {
    assertAlive(this);
    var self = this;
    ['dye', 'velocity', 'divergence', 'curl', 'pressure'].forEach(function (key) {
      if (self[key] && self[key].dispose) self[key].dispose();
      self[key] = null;
    });
    this._splatStack.length = 0;
    this._initFramebuffers();
    this._emit(EVENTS.CLEAR, {});
    return this;
  };

  // ---------------------------------------------------------------------------
  // Scripted strokes
  // ---------------------------------------------------------------------------

  /** Begin a programmatic drag at normalized (0..1, bottom-left origin) coords. */
  FluidSimulation.prototype.startStroke = function (x, y, color) {
    assertAlive(this);
    var pointer = this._strokePointer || (this._strokePointer = new Pointer('stroke'));
    pointer.color = color == null ? this._nextPointerColor() : normalizeColor(color);
    pointer.reset(x, y, pointer.color);
    pointer.down = true;
    this.splat(x, y, 0, 0, pointer.color);
    return this;
  };

  /** Continue the programmatic drag; injects a force proportional to the movement. */
  FluidSimulation.prototype.moveStroke = function (x, y) {
    assertAlive(this);
    var pointer = this._strokePointer;
    if (!pointer || !pointer.down) return this;
    pointer.prevTexcoordX = pointer.texcoordX;
    pointer.prevTexcoordY = pointer.texcoordY;
    pointer.texcoordX = x;
    pointer.texcoordY = y;
    pointer.deltaX = this._correctDeltaX(pointer.texcoordX - pointer.prevTexcoordX);
    pointer.deltaY = this._correctDeltaY(pointer.texcoordY - pointer.prevTexcoordY);
    if (Math.abs(pointer.deltaX) > 0 || Math.abs(pointer.deltaY) > 0) this._splatPointer(pointer);
    return this;
  };

  FluidSimulation.prototype.endStroke = function () {
    if (this._strokePointer) this._strokePointer.down = false;
    return this;
  };

  // ---------------------------------------------------------------------------
  // Colors
  // ---------------------------------------------------------------------------

  FluidSimulation.prototype._nextPointerColor = function () {
    if (this.options.color != null && !this.config.COLORFUL) return normalizeColor(this.options.color);
    return this.randomColor();
  };

  /** Color produced by the current color generator, as 0..1 components. */
  FluidSimulation.prototype.randomColor = function () {
    var color = this._colorGenerator();
    if (!color || typeof color !== 'object') return { r: 0.1, g: 0.1, b: 0.1 };
    var max = Math.max(color.r, color.g, color.b);
    if (max > 1.0000001) return normalizeColor(color);
    return { r: +color.r || 0, g: +color.g || 0, b: +color.b || 0 };
  };

  /**
   * Replace the random color generator.
   * @param {function} generator `() => ({ r, g, b })` in 0..1 (values > 1 are allowed
   *   and produce the bright core seen in the original's random splats).
   */
  FluidSimulation.prototype.setColorGenerator = function (generator) {
    this._colorGenerator = typeof generator === 'function' ? generator : defaultColorGenerator;
    return this;
  };

  FluidSimulation.prototype.getColorGenerator = function () {
    return this._colorGenerator;
  };

  /** Set a fixed pointer/splat color (hex '#1e90ff', '#abc', [30,144,255] or object). */
  FluidSimulation.prototype.setColor = function (color) {
    this.options.color = color == null ? null : (toRgb255(color) ? color : null);
    var normalized = this.options.color == null ? null : normalizeColor(this.options.color);
    if (normalized) this.pointers.forEach(function (pointer) { pointer.color = normalized; });
    return this;
  };

  // ---------------------------------------------------------------------------
  // Configuration
  // ---------------------------------------------------------------------------

  /** Current configuration (a copy - mutate through setConfig). */
  FluidSimulation.prototype.getConfig = function () {
    return cloneConfig(this.config);
  };

  /**
   * Merge a partial configuration. Framebuffer-size changes rebuild framebuffers,
   * display toggles recompile the display shader.
   */
  FluidSimulation.prototype.setConfig = function (patch) {
    assertAlive(this);
    if (!patch) return this.config;

    var previous = cloneConfig(this.config);
    var self = this;
    var unknown = [];
    var needsFramebuffers = false;
    var needsKeywords = false;
    var needsDithering = false;

    var sizeKeys = ['SIM_RESOLUTION', 'DYE_RESOLUTION', 'BLOOM_RESOLUTION', 'BLOOM_ITERATIONS', 'SUNRAYS_RESOLUTION'];
    var keywordKeys = ['SHADING', 'BLOOM', 'SUNRAYS'];

    Object.keys(patch).forEach(function (key) {
      if (!(key in DEFAULT_CONFIG)) {
        unknown.push(key);
        return;
      }
      var value = patch[key];
      var next = isPlainObject(value) ? assign({}, value) : value;
      if (!sameValue(self.config[key], next)) {
        if (sizeKeys.indexOf(key) !== -1) needsFramebuffers = true;
        if (keywordKeys.indexOf(key) !== -1) needsKeywords = true;
        if (key === 'DITHERING') needsDithering = true;
      }
      self.config[key] = next;
    });

    if (unknown.length) {
      warn('ignoring unknown config key(s): ' + unknown.join(', ') +
        '. Valid keys: ' + Object.keys(DEFAULT_CONFIG).join(', '));
    }

    if (needsFramebuffers && !this._contextLost) this._initFramebuffers();
    if (needsKeywords) this._updateKeywords();
    if (needsDithering) this._initDithering();

    if (previous.PAUSED !== this.config.PAUSED) {
      this._emit(this.config.PAUSED ? EVENTS.PAUSE : EVENTS.RESUME, {});
    }
    this._emit(EVENTS.CONFIG, { config: this.getConfig(), changes: cloneConfig(patch), previous: previous });
    return this.config;
  };

  function sameValue(a, b) {
    if (a === b) return true;
    if (isPlainObject(a) && isPlainObject(b)) {
      return a.r === b.r && a.g === b.g && a.b === b.b;
    }
    return false;
  }

  /**
   * Restore the configuration this instance was created with (defaults, plus the
   * preset and any options.config it was given).
   */
  FluidSimulation.prototype.resetConfig = function () {
    assertAlive(this);
    var fresh = assign(cloneConfig(DEFAULT_CONFIG), cloneConfig(this._initialConfig || {}));
    this.setConfig(fresh);
    return this;
  };

  /** Apply one of FluidSimulation.presets ('classic', 'calm', 'vivid', 'smoke', 'ink'). */
  FluidSimulation.prototype.applyPreset = function (name) {
    assertAlive(this);
    var preset = PRESETS[name];
    if (!preset) {
      throw new FluidError(ERROR_CODES.NO_CANVAS,
        'Unknown preset "' + name + '". Available: ' + Object.keys(PRESETS).join(', '));
    }
    this.options.preset = name;
    return this.setConfig(preset);
  };

  /** Convenience for the two resolution knobs that dominate quality/perf. */
  FluidSimulation.prototype.setQuality = function (quality) {
    quality = quality || {};
    var patch = {};
    if (quality.sim != null) patch.SIM_RESOLUTION = quality.sim;
    if (quality.dye != null) patch.DYE_RESOLUTION = quality.dye;
    if (quality.capture != null) patch.CAPTURE_RESOLUTION = quality.capture;
    this.setConfig(patch);
    return this;
  };

  /** `setBackground('#101018')`, or `setBackground('transparent')`. */
  FluidSimulation.prototype.setBackground = function (value) {
    assertAlive(this);
    if (value === 'transparent' || value === null) {
      this.setConfig({ TRANSPARENT: true });
      return this;
    }
    var rgb = toRgb255(value);
    if (!rgb) {
      warn('setBackground() ignores "' + value + '"; pass a hex string, RGB array/object or "transparent".');
      return this;
    }
    this.setConfig({ TRANSPARENT: false, BACK_COLOR: { r: Math.round(rgb.r), g: Math.round(rgb.g), b: Math.round(rgb.b) } });
    return this;
  };

  FluidSimulation.prototype.setTransparent = function (transparent) {
    return this.setConfig({ TRANSPARENT: transparent !== false });
  };

  // ---------------------------------------------------------------------------
  // Sizing / diagnostics
  // ---------------------------------------------------------------------------

  FluidSimulation.prototype.getSize = function () {
    return {
      cssWidth: this.canvas.clientWidth,
      cssHeight: this.canvas.clientHeight,
      width: this.canvas.width,
      height: this.canvas.height,
      pixelRatio: (typeof window !== 'undefined' && window.devicePixelRatio) || 1
    };
  };

  FluidSimulation.prototype.getContextInfo = function () {
    var gl = this.gl;
    var info = {
      version: this.version,
      webgl2: !!this.isWebGL2,
      supportLinearFiltering: !!this.ext.supportLinearFiltering,
      renderer: null,
      vendor: null,
      degraded: { mobile: this.degraded.mobile, noLinearFiltering: this.degraded.noLinearFiltering },
      drawCalls: this._drawCalls
    };
    try {
      var debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
      if (debugInfo) {
        info.renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
        info.vendor = gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL);
      }
    } catch (error) {
      // Some browsers block the extension; not fatal.
    }
    return info;
  };

  // ---------------------------------------------------------------------------
  // Capture
  // ---------------------------------------------------------------------------

  FluidSimulation.prototype._readFloatPixels = function (width, height) {
    var gl = this.gl;
    while (gl.getError() !== gl.NO_ERROR) { /* clear stale errors */ }

    var floatData = new Float32Array(width * height * 4);
    gl.readPixels(0, 0, width, height, gl.RGBA, gl.FLOAT, floatData);
    if (gl.getError() === gl.NO_ERROR) return floatData;

    // Half-float color buffers may refuse a FLOAT read on some drivers.
    var halfType = this.ext.halfFloatTexType;
    if (halfType === gl.FLOAT) {
      throw new FluidError('CAPTURE_UNSUPPORTED', 'This device cannot read pixels from float framebuffers.');
    }
    var halfData = new Uint16Array(width * height * 4);
    gl.readPixels(0, 0, width, height, gl.RGBA, halfType, halfData);
    if (gl.getError() !== gl.NO_ERROR) {
      throw new FluidError('CAPTURE_UNSUPPORTED', 'This device cannot read pixels from float framebuffers.');
    }
    var decoded = new Float32Array(halfData.length);
    for (var i = 0; i < halfData.length; i++) decoded[i] = halfToFloat(halfData[i]);
    return decoded;
  };

  /** Half-float (IEEE 754 binary16) -> float32. */
  function halfToFloat(value) {
    var sign = (value & 0x8000) >> 15;
    var exponent = (value & 0x7C00) >> 10;
    var fraction = value & 0x03FF;
    if (exponent === 0) return (sign ? -1 : 1) * Math.pow(2, -14) * (fraction / 1024);
    if (exponent === 0x1F) return fraction ? NaN : (sign ? -Infinity : Infinity);
    return (sign ? -1 : 1) * Math.pow(2, exponent - 15) * (1 + fraction / 1024);
  }

  /** Render the current frame at `resolution` and return it as an RGBA byte buffer. */
  FluidSimulation.prototype.getImageData = function (options) {
    assertAlive(this);
    var gl = this.gl;
    var resolution = options && options.resolution != null ? options.resolution : this.config.CAPTURE_RESOLUTION;
    var res = getResolution(gl, resolution);
    var target = this._createFBO(res.width, res.height, this.ext.formatRGBA.internalFormat,
      this.ext.formatRGBA.format, this.ext.halfFloatTexType, gl.NEAREST);

    this._render(target);
    var pixels = this._readFloatPixels(target.width, target.height);
    var bytes = floatPixelsToBytes(pixels, target.width, target.height);
    target.dispose();

    return { width: target.width, height: target.height, data: bytes };
  };

  function floatPixelsToBytes(texture, width, height) {
    var result = new Uint8ClampedArray(texture.length);
    var id = 0;
    for (var i = height - 1; i >= 0; i--) {
      for (var j = 0; j < width; j++) {
        var nid = i * width * 4 + j * 4;
        result[nid + 0] = clamp01(texture[id + 0]) * 255;
        result[nid + 1] = clamp01(texture[id + 1]) * 255;
        result[nid + 2] = clamp01(texture[id + 2]) * 255;
        result[nid + 3] = clamp01(texture[id + 3]) * 255;
        id += 4;
      }
    }
    return result;
  }

  /**
   * Snapshot the simulation as an offscreen `<canvas>` (PNG-ready, top-left origin).
   * @param {Object} [options] `{ resolution }`
   * @returns {HTMLCanvasElement}
   */
  FluidSimulation.prototype.capture = function (options) {
    assertAlive(this);
    var image = this.getImageData(options);
    var canvas = document.createElement('canvas');
    canvas.width = image.width;
    canvas.height = image.height;
    var context = canvas.getContext('2d');
    var imageData = context.createImageData(image.width, image.height);
    imageData.data.set(image.data);
    context.putImageData(imageData, 0, 0);
    this._emit(EVENTS.CAPTURE, { canvas: canvas, width: image.width, height: image.height });
    return canvas;
  };

  /** Snapshot as a data URL, e.g. `'data:image/png;base64,...'`. */
  FluidSimulation.prototype.toDataURL = function (type, quality, options) {
    return this.capture(options).toDataURL(type || 'image/png', quality);
  };

  /** Snapshot and trigger a browser download. */
  FluidSimulation.prototype.download = function (filename, options) {
    var dataURL = this.toDataURL('image/png', undefined, options);
    if (typeof document === 'undefined') {
      warn('download() needs a DOM; use toDataURL() instead.');
      return this;
    }
    var link = document.createElement('a');
    link.download = filename || 'fluid.png';
    link.href = dataURL;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    return this;
  };

  // Alias kept for parity with the original app's menu entry.
  FluidSimulation.prototype.captureScreenshot = function (filename) {
    return this.download(filename || 'fluid.png');
  };

  // ---------------------------------------------------------------------------
  // Input
  // ---------------------------------------------------------------------------

  function isEditableTarget(target) {
    if (!target || !target.tagName) return false;
    var tag = target.tagName.toLowerCase();
    return tag === 'input' || tag === 'textarea' || tag === 'select' || target.isContentEditable === true;
  }

  FluidSimulation.prototype.enableInput = function () {
    if (this._inputEnabled || this.destroyed) return this;
    var canvas = this.canvas;
    var self = this;

    this._onPointerDownEvent = function (event) {
      if (event.button != null && event.button !== 0 && event.pointerType === 'mouse') return;
      self._pointerDownWithClient(event.pointerId == null ? -1 : event.pointerId, event.clientX, event.clientY);
    };
    this._onPointerMoveEvent = function (event) {
      self._pointerMoveWithClient(event.pointerId == null ? -1 : event.pointerId, event.clientX, event.clientY);
    };
    this._onPointerUpEvent = function (event) {
      self._pointerUpWithClient(event.pointerId == null ? -1 : event.pointerId);
    };

    if (typeof window !== 'undefined' && 'PointerEvent' in window) {
      canvas.addEventListener('pointerdown', this._onPointerDownEvent);
      canvas.addEventListener('pointermove', this._onPointerMoveEvent);
      window.addEventListener('pointerup', this._onPointerUpEvent);
      window.addEventListener('pointercancel', this._onPointerUpEvent);
    } else {
      this._onMouseDownEvent = function (event) {
        self._pointerDownWithClient(-1, event.clientX, event.clientY);
      };
      this._onMouseMoveEvent = function (event) {
        self._pointerMoveWithClient(-1, event.clientX, event.clientY);
      };
      this._onMouseUpEvent = function () {
        self._pointerUpWithClient(-1);
      };
      this._onTouchStartEvent = function (event) {
        event.preventDefault();
        for (var i = 0; i < event.changedTouches.length; i++) {
          var touch = event.changedTouches[i];
          self._pointerDownWithClient('t' + touch.identifier, touch.clientX, touch.clientY);
        }
      };
      this._onTouchMoveEvent = function (event) {
        event.preventDefault();
        for (var i = 0; i < event.changedTouches.length; i++) {
          var touch = event.changedTouches[i];
          self._pointerMoveWithClient('t' + touch.identifier, touch.clientX, touch.clientY);
        }
      };
      this._onTouchEndEvent = function (event) {
        for (var i = 0; i < event.changedTouches.length; i++) {
          self._pointerUpWithClient('t' + event.changedTouches[i].identifier);
        }
      };
      canvas.addEventListener('mousedown', this._onMouseDownEvent);
      window.addEventListener('mousemove', this._onMouseMoveEvent);
      window.addEventListener('mouseup', this._onMouseUpEvent);
      canvas.addEventListener('touchstart', this._onTouchStartEvent, { passive: false });
      canvas.addEventListener('touchmove', this._onTouchMoveEvent, { passive: false });
      window.addEventListener('touchend', this._onTouchEndEvent);
      window.addEventListener('touchcancel', this._onTouchEndEvent);
    }

    this._inputEnabled = true;
    return this;
  };

  FluidSimulation.prototype.disableInput = function () {
    if (!this._inputEnabled) return this;
    var canvas = this.canvas;
    var win = typeof window !== 'undefined' ? window : null;
    if (this._onPointerDownEvent) {
      canvas.removeEventListener('pointerdown', this._onPointerDownEvent);
      canvas.removeEventListener('pointermove', this._onPointerMoveEvent);
      if (win) {
        win.removeEventListener('pointerup', this._onPointerUpEvent);
        win.removeEventListener('pointercancel', this._onPointerUpEvent);
      }
    }
    if (this._onMouseDownEvent) {
      canvas.removeEventListener('mousedown', this._onMouseDownEvent);
      if (win) {
        win.removeEventListener('mousemove', this._onMouseMoveEvent);
        win.removeEventListener('mouseup', this._onMouseUpEvent);
        win.removeEventListener('touchend', this._onTouchEndEvent);
        win.removeEventListener('touchcancel', this._onTouchEndEvent);
      }
      canvas.removeEventListener('touchstart', this._onTouchStartEvent);
      canvas.removeEventListener('touchmove', this._onTouchMoveEvent);
    }
    this._inputEnabled = false;
    return this;
  };

  FluidSimulation.prototype.isInputEnabled = function () {
    return !!this._inputEnabled;
  };

  /** Enable the original app's P (pause) and Space (random splats) shortcuts. */
  FluidSimulation.prototype.enableKeyboard = function () {
    if (this._keyboardEnabled || this.destroyed || typeof window === 'undefined') return this;
    var self = this;
    this._onKeyDownEvent = function (event) {
      if (isEditableTarget(event.target) || event.metaKey || event.ctrlKey || event.altKey) return;
      var hotkeys = self.options.hotkeys;
      if (hotkeys.pause && event.code === hotkeys.pause) {
        self.togglePause();
      } else if (hotkeys.splat && (event.code === hotkeys.splat || event.key === ' ')) {
        self.queueSplats(5 + Math.floor(Math.random() * 20));
        if (event.key === ' ') event.preventDefault();
      }
    };
    window.addEventListener('keydown', this._onKeyDownEvent);
    this._keyboardEnabled = true;
    return this;
  };

  FluidSimulation.prototype.disableKeyboard = function () {
    if (!this._keyboardEnabled) return this;
    if (typeof window !== 'undefined') window.removeEventListener('keydown', this._onKeyDownEvent);
    this._keyboardEnabled = false;
    return this;
  };

  FluidSimulation.prototype._pointerFor = function (id) {
    if (!this._pointersById) {
      this._pointersById = {};
      this._activeIds = [];
    }
    var pointer = this._pointersById[id];
    if (!pointer) {
      pointer = new Pointer(id);
      this._pointersById[id] = pointer;
      if (id === -1) this.pointers[0] = pointer;
      else this.pointers.push(pointer);
      this._activeIds.push(id);
    }
    return pointer;
  };

  FluidSimulation.prototype._toTexcoord = function (clientX, clientY) {
    var rect = this.canvas.getBoundingClientRect();
    var width = rect.width || this.canvas.clientWidth || 1;
    var height = rect.height || this.canvas.clientHeight || 1;
    return {
      x: (clientX - rect.left) / width,
      y: 1.0 - (clientY - rect.top) / height
    };
  };

  FluidSimulation.prototype._pointerDownWithClient = function (id, clientX, clientY) {
    var pointer = this._pointerFor(id);
    var position = this._toTexcoord(clientX, clientY);
    pointer.down = true;
    pointer.moved = false;
    pointer.reset(position.x, position.y, this._nextPointerColor());
  };

  FluidSimulation.prototype._pointerMoveWithClient = function (id, clientX, clientY) {
    var pointer = this._pointersById && this._pointersById[id];
    if (!pointer || !pointer.down) return;
    var position = this._toTexcoord(clientX, clientY);
    pointer.prevTexcoordX = pointer.texcoordX;
    pointer.prevTexcoordY = pointer.texcoordY;
    pointer.texcoordX = position.x;
    pointer.texcoordY = position.y;
    pointer.deltaX = this._correctDeltaX(pointer.texcoordX - pointer.prevTexcoordX);
    pointer.deltaY = this._correctDeltaY(pointer.texcoordY - pointer.prevTexcoordY);
    pointer.moved = Math.abs(pointer.deltaX) > 0 || Math.abs(pointer.deltaY) > 0;
  };

  FluidSimulation.prototype._pointerUpWithClient = function (id) {
    var pointer = this._pointersById && this._pointersById[id];
    if (pointer) pointer.down = false;
  };

  /** Programmatic pointer press in normalized (0..1, bottom-left) coordinates. */
  FluidSimulation.prototype.pointerDown = function (x, y, color) {
    assertAlive(this);
    var pointer = this._pointerFor(-1);
    pointer.down = true;
    pointer.moved = false;
    pointer.reset(x, y, color == null ? this._nextPointerColor() : normalizeColor(color));
    return this;
  };

  FluidSimulation.prototype.pointerMove = function (x, y) {
    assertAlive(this);
    var pointer = this._pointerFor(-1);
    if (!pointer.down) return this;
    pointer.prevTexcoordX = pointer.texcoordX;
    pointer.prevTexcoordY = pointer.texcoordY;
    pointer.texcoordX = x;
    pointer.texcoordY = y;
    pointer.deltaX = this._correctDeltaX(pointer.texcoordX - pointer.prevTexcoordX);
    pointer.deltaY = this._correctDeltaY(pointer.texcoordY - pointer.prevTexcoordY);
    pointer.moved = Math.abs(pointer.deltaX) > 0 || Math.abs(pointer.deltaY) > 0;
    return this;
  };

  FluidSimulation.prototype.pointerUp = function () {
    if (this._pointersById && this._pointersById[-1]) this._pointersById[-1].down = false;
    return this;
  };

  FluidSimulation.prototype._correctRadius = function (radius) {
    var aspectRatio = this.canvas.width / this.canvas.height;
    if (aspectRatio > 1) radius *= aspectRatio;
    return radius;
  };

  FluidSimulation.prototype._correctDeltaX = function (delta) {
    var aspectRatio = this.canvas.width / this.canvas.height;
    if (aspectRatio < 1) delta *= aspectRatio;
    return delta;
  };

  FluidSimulation.prototype._correctDeltaY = function (delta) {
    var aspectRatio = this.canvas.width / this.canvas.height;
    if (aspectRatio > 1) delta /= aspectRatio;
    return delta;
  };

  // ---------------------------------------------------------------------------
  // Host integration: resize, visibility, context loss, events
  // ---------------------------------------------------------------------------

  FluidSimulation.prototype._bindResizeObserver = function () {
    var self = this;
    if (typeof ResizeObserver !== 'undefined') {
      this._resizeObserver = new ResizeObserver(function () {
        if (self.destroyed || self._contextLost) return;
        if (self._resizeCanvas()) self._handleResize();
      });
      this._resizeObserver.observe(this.canvas);
    }
    if (typeof window !== 'undefined') {
      this._onWindowResize = function () {
        if (self.destroyed || self._contextLost) return;
        if (self._resizeCanvas()) self._handleResize();
      };
      window.addEventListener('resize', this._onWindowResize);
    }
    this._onContextLost = function (event) {
      event.preventDefault();
      self._contextLost = true;
      self._emit(EVENTS.ERROR, { code: ERROR_CODES.CONTEXT_LOST, message: 'WebGL context lost.' });
    };
    this._onContextRestored = function () {
      try {
        self._initResources();
        self._contextLost = false;
      } catch (error) {
        self._emit(EVENTS.ERROR, { code: ERROR_CODES.CONTEXT_LOST, message: 'Could not restore the WebGL context.', error: error });
      }
    };
    this.canvas.addEventListener('webglcontextlost', this._onContextLost);
    this.canvas.addEventListener('webglcontextrestored', this._onContextRestored);
  };

  FluidSimulation.prototype._unbindResizeObserver = function () {
    if (this._resizeObserver) {
      this._resizeObserver.disconnect();
      this._resizeObserver = null;
    }
    if (typeof window !== 'undefined' && this._onWindowResize) {
      window.removeEventListener('resize', this._onWindowResize);
    }
  };

  FluidSimulation.prototype._bindVisibility = function () {
    var self = this;
    var pauseWhenHidden = this.options.pauseWhenHidden;
    if (this.options.visibilityPause != null) pauseWhenHidden = !!this.options.visibilityPause;
    if (!pauseWhenHidden || typeof document === 'undefined') return;

    this._onVisibilityChange = function () {
      var hidden = document.hidden;
      self._emit(EVENTS.VISIBILITY, { hidden: hidden });
      if (hidden) {
        if (!self.config.PAUSED) {
          self._pausedByVisibility = true;
          self.pause();
        }
      } else {
        self._lastUpdateTime = now();
        if (self._pausedByVisibility) {
          self._pausedByVisibility = false;
          self.resume();
        }
      }
    };
    document.addEventListener('visibilitychange', this._onVisibilityChange);
  };

  FluidSimulation.prototype._unbindVisibility = function () {
    if (this._onVisibilityChange && typeof document !== 'undefined') {
      document.removeEventListener('visibilitychange', this._onVisibilityChange);
    }
  };

  FluidSimulation.prototype._emit = function (name, payload) {
    var handlers = this._handlers[name];
    if (!handlers || !handlers.length) return this;
    var list = handlers.slice();
    for (var i = 0; i < list.length; i++) {
      try {
        list[i](payload, this);
      } catch (error) {
        warn('listener for "' + name + '" threw: ' + (error && error.message));
      }
    }
    return this;
  };

  /** Subscribe to an event. Returns this, so calls chain. */
  FluidSimulation.prototype.on = function (name, handler) {
    if (typeof handler !== 'function') return this;
    (this._handlers[name] = this._handlers[name] || []).push(handler);
    return this;
  };

  FluidSimulation.prototype.once = function (name, handler) {
    var self = this;
    function wrapper(payload, instance) {
      self.off(name, wrapper);
      handler(payload, instance);
    }
    wrapper.listener = handler;
    return this.on(name, wrapper);
  };

  FluidSimulation.prototype.off = function (name, handler) {
    if (name == null) {
      this._handlers = {};
      return this;
    }
    var handlers = this._handlers[name];
    if (!handlers) return this;
    if (!handler) {
      delete this._handlers[name];
      return this;
    }
    this._handlers[name] = handlers.filter(function (item) {
      return item !== handler && item.listener !== handler;
    });
    return this;
  };

  FluidSimulation.prototype.listeners = function (name) {
    return (this._handlers[name] || []).slice();
  };

  FluidSimulation.prototype.removeAllListeners = function (name) {
    return this.off(name);
  };
