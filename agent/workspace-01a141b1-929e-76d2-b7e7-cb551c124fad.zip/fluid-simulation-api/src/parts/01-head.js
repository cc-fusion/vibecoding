/*!
 * Fluid Simulation API - v1.0.0
 * A dependency-free, embeddable WebGL fluid simulation.
 *
 * Usage with a plain script tag (no bundler):
 *   1. put a canvas element on the page:   canvas id="fluid"
 *   2. load this file:                     src="fluid-simulation.js"
 *   3. FluidSimulation.create({ canvas: '#fluid', config: { CURL: 40 } });
 *
 * Derived from the WebGL Fluid Simulation by Pavel Dobryakov (MIT, c) 2017.
 * The GLSL programs are kept verbatim from that project; everything else is a
 * re-architecture of the same simulation into a reusable, instance-based API.
 * See LICENSE and NOTICE for the original MIT license text.
 *
 * Build: tools/build.py assembles this file from src/parts/*.js plus the shaders
 * extracted from tools/reference/original-app-script.js.
 */
(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else if (typeof define === 'function' && define.amd) {
    define([], factory);
  } else {
    root.FluidSimulation = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var VERSION = '1.0.0';

  /*__SHADERS__*/

  // ---------------------------------------------------------------------------
  // Defaults
  // ---------------------------------------------------------------------------

  /** Every knob of the simulation, using the original project's property names. */
  var DEFAULT_CONFIG = {
    SIM_RESOLUTION: 128,
    DYE_RESOLUTION: 1024,
    CAPTURE_RESOLUTION: 512,
    DENSITY_DISSIPATION: 1,
    VELOCITY_DISSIPATION: 0.2,
    PRESSURE: 0.8,
    PRESSURE_ITERATIONS: 20,
    CURL: 30,
    SPLAT_RADIUS: 0.25,
    SPLAT_FORCE: 6000,
    SHADING: true,
    COLORFUL: true,
    COLOR_UPDATE_SPEED: 10,
    PAUSED: false,
    BACK_COLOR: { r: 0, g: 0, b: 0 },
    TRANSPARENT: false,
    BLOOM: true,
    BLOOM_ITERATIONS: 8,
    BLOOM_RESOLUTION: 256,
    BLOOM_INTENSITY: 0.8,
    BLOOM_THRESHOLD: 0.6,
    BLOOM_SOFT_KNEE: 0.7,
    SUNRAYS: true,
    SUNRAYS_RESOLUTION: 196,
    SUNRAYS_WEIGHT: 1.0,
    DITHERING: true
  };

  /** Non-simulation options understood by create(). */
  var DEFAULT_OPTIONS = {
    canvas: null,
    container: null,
    config: null,
    preset: null,
    autoStart: true,
    autoUpdate: true,
    initialSplats: 'random',
    autoDegrade: true,
    mobileQuality: true,
    input: true,
    keyboard: false,
    hotkeys: { pause: 'KeyP', splat: 'Space' },
    pauseWhenHidden: true,
    visibilityPause: null,
    preserveDrawingBuffer: false,
    ditheringUrl: null,
    color: null,
    id: null,
    className: 'fluid-canvas',
    style: null,
    removeCanvasOnDestroy: false,
    throwOnError: true,
    onError: null
  };

  /** Ready-made configuration bundles usable through options.preset. */
  var PRESETS = {
    classic: {},
    calm: {
      DENSITY_DISSIPATION: 1.6,
      VELOCITY_DISSIPATION: 1.0,
      CURL: 12,
      SPLAT_RADIUS: 0.4,
      SPLAT_FORCE: 2200,
      BLOOM_INTENSITY: 0.5,
      COLOR_UPDATE_SPEED: 4
    },
    vivid: {
      DENSITY_DISSIPATION: 0.35,
      VELOCITY_DISSIPATION: 0.05,
      CURL: 46,
      SPLAT_RADIUS: 0.18,
      SPLAT_FORCE: 9000,
      BLOOM_INTENSITY: 1.3,
      SUNRAYS_WEIGHT: 1.2,
      COLOR_UPDATE_SPEED: 18
    },
    smoke: {
      DENSITY_DISSIPATION: 0.08,
      VELOCITY_DISSIPATION: 0.6,
      PRESSURE: 0.92,
      CURL: 24,
      SPLAT_RADIUS: 0.5,
      SPLAT_FORCE: 3000,
      SHADING: true,
      BLOOM: true,
      BLOOM_INTENSITY: 0.45,
      SUNRAYS: false,
      COLORFUL: false,
      BACK_COLOR: { r: 4, g: 4, b: 8 }
    },
    ink: {
      DENSITY_DISSIPATION: 0.6,
      VELOCITY_DISSIPATION: 0.9,
      PRESSURE: 0.8,
      CURL: 6,
      SPLAT_RADIUS: 0.12,
      SPLAT_FORCE: 5200,
      BLOOM: false,
      SUNRAYS: false,
      SHADING: false,
      COLORFUL: false,
      BACK_COLOR: { r: 250, g: 249, b: 246 }
    }
  };

  /** Event names emitted by an instance. */
  var EVENTS = {
    READY: 'ready',
    FRAME: 'frame',
    SPLAT: 'splat',
    RESIZE: 'resize',
    CONFIG: 'config',
    PAUSE: 'pause',
    RESUME: 'resume',
    VISIBILITY: 'visibility',
    CAPTURE: 'capture',
    CLEAR: 'clear',
    DESTROY: 'destroy',
    ERROR: 'error'
  };

  // ---------------------------------------------------------------------------
  // Errors
  // ---------------------------------------------------------------------------

  /** Error thrown by the API, carrying a stable machine-readable `code`. */
  function FluidError(code, message, details) {
    var error = Error.call(this, message);
    this.name = 'FluidSimulationError';
    this.code = code;
    this.message = message;
    this.details = details || null;
    this.stack = error.stack || new Error(message).stack;
  }
  FluidError.prototype = Object.create(Error.prototype);
  FluidError.prototype.constructor = FluidError;

  var ERROR_CODES = {
    NO_CANVAS: 'NO_CANVAS',
    NO_WEBGL: 'NO_WEBGL',
    FLOAT_TEXTURE_UNSUPPORTED: 'FLOAT_TEXTURE_UNSUPPORTED',
    SHADER_COMPILE: 'SHADER_COMPILE',
    CONTEXT_LOST: 'CONTEXT_LOST',
    DESTROYED: 'DESTROYED'
  };

  // ---------------------------------------------------------------------------
  // Small helpers
  // ---------------------------------------------------------------------------

  function isPlainObject(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
  }

  /** Shallow merge that copies nested color objects instead of aliasing them. */
  function cloneConfig(source) {
    var target = {};
    Object.keys(source).forEach(function (key) {
      var value = source[key];
      target[key] = isPlainObject(value) ? assign({}, value) : value;
    });
    return target;
  }

  function assign(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      if (!source) continue;
      Object.keys(source).forEach(function (key) {
        target[key] = source[key];
      });
    }
    return target;
  }

  function clamp01(input) {
    return Math.min(Math.max(input, 0), 1);
  }

  function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
  }

  function wrap(value, min, max) {
    var range = max - min;
    if (range === 0) return min;
    return (value - min) % range + min;
  }

  function hashCode(string) {
    if (string.length === 0) return 0;
    var hash = 0;
    for (var i = 0; i < string.length; i++) {
      hash = (hash << 5) - hash + string.charCodeAt(i);
      hash |= 0;
    }
    return hash;
  }

  function isMobile() {
    if (typeof navigator === 'undefined') return false;
    return /Mobi|Android/i.test(navigator.userAgent);
  }

  function scaleByPixelRatio(input) {
    var pixelRatio = (typeof window !== 'undefined' && window.devicePixelRatio) || 1;
    return Math.floor(input * pixelRatio);
  }

  function HSVtoRGB(h, s, v) {
    var r, g, b, i, f, p, q, t;
    i = Math.floor(h * 6);
    f = h * 6 - i;
    p = v * (1 - s);
    q = v * (1 - f * s);
    t = v * (1 - (1 - f) * s);

    switch (i % 6) {
      case 0: r = v, g = t, b = p; break;
      case 1: r = q, g = v, b = p; break;
      case 2: r = p, g = v, b = t; break;
      case 3: r = p, g = q, b = v; break;
      case 4: r = t, g = p, b = v; break;
      default: r = v, g = p, b = q; break;
    }
    return { r: r, g: g, b: b };
  }

  function hexToRgb(hex) {
    if (typeof hex !== 'string') return null;
    var value = hex.trim().replace(/^#/, '');
    if (value.length === 3) {
      value = value[0] + value[0] + value[1] + value[1] + value[2] + value[2];
    }
    if (!/^[0-9a-f]{6}$/i.test(value)) return null;
    var int = parseInt(value, 16);
    return { r: (int >> 16) & 255, g: (int >> 8) & 255, b: int & 255 };
  }

  function rgbToHex(color) {
    var r = Math.round(clamp(color.r, 0, 255));
    var g = Math.round(clamp(color.g, 0, 255));
    var b = Math.round(clamp(color.b, 0, 255));
    return '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
  }

  /**
   * Accepts '#1e90ff', '1e90ff', [30,144,255], { r: 30, g: 144, b: 255 },
   * { r: 0.1, g: 0.5, b: 1 } and returns 0-255 components.
   */
  function toRgb255(value) {
    if (value == null) return null;
    if (typeof value === 'string') {
      var fromHex = hexToRgb(value);
      if (fromHex) return fromHex;
      var match = value.match(/rgba?\(([^)]+)\)/i);
      if (match) {
        var bits = match[1].split(',').map(function (part) { return parseFloat(part); });
        return { r: bits[0] || 0, g: bits[1] || 0, b: bits[2] || 0 };
      }
      return null;
    }
    if (Array.isArray(value)) return { r: +value[0] || 0, g: +value[1] || 0, b: +value[2] || 0 };
    if (typeof value === 'object') {
      var max = Math.max(value.r, value.g, value.b);
      if (max <= 1.0000001) {
        return { r: (value.r || 0) * 255, g: (value.g || 0) * 255, b: (value.b || 0) * 255 };
      }
      return { r: value.r || 0, g: value.g || 0, b: value.b || 0 };
    }
    return null;
  }

  /** 0-255 color -> normalized WebGL color. */
  function normalizeColor(input) {
    var rgb = toRgb255(input) || { r: 0, g: 0, b: 0 };
    return { r: rgb.r / 255, g: rgb.g / 255, b: rgb.b / 255 };
  }

  /** Default color generator: random hue, low intensity (matches the original). */
  function defaultColorGenerator() {
    var color = HSVtoRGB(Math.random(), 1.0, 1.0);
    color.r *= 0.15;
    color.g *= 0.15;
    color.b *= 0.15;
    return color;
  }

  /** Deterministic PRNG so procedural noise textures are reproducible. */
  function mulberry32(seed) {
    var a = seed >>> 0;
    return function () {
      a += 0x6D2B79F5;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /**
   * Blue-ish noise data used to dither the bloom pass. The original app shipped a
   * PNG for this; generating it keeps the library free of any network request.
   */
  function createNoiseData(size, seed) {
    var random = mulberry32(seed == null ? 0x9E3779B9 : seed);
    var data = new Uint8Array(size * size * 4);
    for (var i = 0; i < size * size; i++) {
      var value = Math.floor(random() * 256);
      data[i * 4 + 0] = value;
      data[i * 4 + 1] = value;
      data[i * 4 + 2] = value;
      data[i * 4 + 3] = 255;
    }
    return data;
  }

  function getResolution(gl, resolution) {
    var aspectRatio = gl.drawingBufferWidth / gl.drawingBufferHeight;
    if (aspectRatio < 1) aspectRatio = 1.0 / aspectRatio;

    var min = Math.round(resolution);
    var max = Math.round(resolution * aspectRatio);

    if (gl.drawingBufferWidth > gl.drawingBufferHeight) {
      return { width: max, height: min };
    }
    return { width: min, height: max };
  }

  function getTextureScale(texture, width, height) {
    return { x: width / texture.width, y: height / texture.height };
  }

  // ---------------------------------------------------------------------------
  // WebGL plumbing
  // ---------------------------------------------------------------------------

  function getWebGLContext(canvas, options) {
    var params = {
      alpha: true,
      depth: false,
      stencil: false,
      antialias: false,
      preserveDrawingBuffer: !!(options && options.preserveDrawingBuffer),
      premultipliedAlpha: false,
      powerPreference: 'high-performance'
    };

    var gl = canvas.getContext('webgl2', params);
    var isWebGL2 = !!gl;
    if (!isWebGL2) {
      gl = canvas.getContext('webgl', params) || canvas.getContext('experimental-webgl', params);
    }
    if (!gl) {
      throw new FluidError(ERROR_CODES.NO_WEBGL,
        'Fluid Simulation requires WebGL, but this browser/context does not provide it.');
    }

    var halfFloat = null;
    var floatFallback = false;
    var supportLinearFiltering = false;

    if (isWebGL2) {
      gl.getExtension('EXT_color_buffer_float');
      supportLinearFiltering = !!gl.getExtension('OES_texture_float_linear');
    } else {
      halfFloat = gl.getExtension('OES_texture_half_float');
      supportLinearFiltering = !!gl.getExtension('OES_texture_half_float_linear');
      if (!halfFloat) {
        floatFallback = !!gl.getExtension('OES_texture_float');
      }
    }

    gl.clearColor(0.0, 0.0, 0.0, 1.0);

    var halfFloatTexType;
    if (isWebGL2) {
      halfFloatTexType = gl.HALF_FLOAT;
    } else if (halfFloat) {
      halfFloatTexType = halfFloat.HALF_FLOAT_OES;
    } else if (floatFallback) {
      halfFloatTexType = gl.FLOAT;
    } else {
      throw new FluidError(ERROR_CODES.NO_WEBGL,
        'Fluid Simulation needs half-float or float textures; neither OES_texture_half_float ' +
        'nor OES_texture_float is available in this browser.');
    }

    var formatRGBA, formatRG, formatR;
    if (isWebGL2) {
      formatRGBA = getSupportedFormat(gl, gl.RGBA16F, gl.RGBA, halfFloatTexType);
      formatRG = getSupportedFormat(gl, gl.RG16F, gl.RG, halfFloatTexType);
      formatR = getSupportedFormat(gl, gl.R16F, gl.RED, halfFloatTexType);
    } else {
      formatRGBA = getSupportedFormat(gl, gl.RGBA, gl.RGBA, halfFloatTexType);
      formatRG = getSupportedFormat(gl, gl.RGBA, gl.RGBA, halfFloatTexType);
      formatR = getSupportedFormat(gl, gl.RGBA, gl.RGBA, halfFloatTexType);
    }

    if (!formatRGBA || !formatRG || !formatR) {
      throw new FluidError(ERROR_CODES.FLOAT_TEXTURE_UNSUPPORTED,
        'Fluid Simulation needs float framebuffers, which this device cannot render to. ' +
        'Call FluidSimulation.isSupported() before creating an instance if you want to ' +
        'show a fallback instead.');
    }

    return {
      gl: gl,
      isWebGL2: isWebGL2,
      ext: {
        formatRGBA: formatRGBA,
        formatRG: formatRG,
        formatR: formatR,
        halfFloatTexType: halfFloatTexType,
        supportLinearFiltering: supportLinearFiltering
      }
    };
  }

  function getSupportedFormat(gl, internalFormat, format, type) {
    if (!supportRenderTextureFormat(gl, internalFormat, format, type)) {
      switch (internalFormat) {
        case gl.R16F:
          return getSupportedFormat(gl, gl.RG16F, gl.RG, type);
        case gl.RG16F:
          return getSupportedFormat(gl, gl.RGBA16F, gl.RGBA, type);
        default:
          return null;
      }
    }
    return { internalFormat: internalFormat, format: format };
  }

  function supportRenderTextureFormat(gl, internalFormat, format, type) {
    var texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texImage2D(gl.TEXTURE_2D, 0, internalFormat, 4, 4, 0, format, type, null);

    var fbo = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, texture, 0);
    var status = gl.checkFramebufferStatus(gl.FRAMEBUFFER);
    var complete = status === gl.FRAMEBUFFER_COMPLETE;

    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.deleteFramebuffer(fbo);
    gl.deleteTexture(texture);
    return complete;
  }

  function compileShader(gl, type, source, keywords) {
    source = addKeywords(source, keywords);
    var shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      var log = gl.getShaderInfoLog(shader);
      gl.deleteShader(shader);
      throw new FluidError(ERROR_CODES.SHADER_COMPILE, 'Shader compile error: ' + log, { log: log });
    }
    return shader;
  }

  function addKeywords(source, keywords) {
    if (!keywords || !keywords.length) return source;
    var keywordsString = '';
    keywords.forEach(function (keyword) {
      keywordsString += '#define ' + keyword + '\n';
    });
    return keywordsString + source;
  }

  function createProgram(gl, vertexShader, fragmentShader) {
    var program = gl.createProgram();
    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
      var log = gl.getProgramInfoLog(program);
      gl.deleteProgram(program);
      throw new FluidError(ERROR_CODES.SHADER_COMPILE, 'Program link error: ' + log, { log: log });
    }
    return program;
  }

  function getUniforms(gl, program) {
    var uniforms = {};
    var uniformCount = gl.getProgramParameter(program, gl.ACTIVE_UNIFORMS);
    for (var i = 0; i < uniformCount; i++) {
      var uniformName = gl.getActiveUniform(program, i).name;
      uniforms[uniformName] = gl.getUniformLocation(program, uniformName);
    }
    return uniforms;
  }

  // ---------------------------------------------------------------------------
  // Programs and materials
  // ---------------------------------------------------------------------------

  function Program(gl, vertexShader, fragmentShader) {
    this.gl = gl;
    this.vertexShader = vertexShader;
    this.fragmentShader = fragmentShader;
    this.program = createProgram(gl, vertexShader, fragmentShader);
    this.uniforms = getUniforms(gl, this.program);
  }

  Program.prototype.bind = function () {
    this.gl.useProgram(this.program);
  };

  Program.prototype.dispose = function () {
    this.gl.deleteProgram(this.program);
  };

  /**
   * A shader whose fragment source is recompiled on demand for #define keywords,
   * used by the display pass (SHADING / BLOOM / SUNRAYS toggles).
   */
  function Material(gl, vertexShader, fragmentShaderSource) {
    this.gl = gl;
    this.vertexShader = vertexShader;
    this.fragmentShaderSource = fragmentShaderSource;
    this.programs = {};
    this.activeProgram = null;
    this.activeKey = null;
    this.uniforms = {};
  }

  Material.prototype.setKeywords = function (keywords) {
    var gl = this.gl;
    var list = (keywords || []).slice();
    var key = list.join('|');
    var program = this.programs[key];
    if (!program) {
      var fragmentShader = compileShader(gl, gl.FRAGMENT_SHADER, this.fragmentShaderSource, list);
      program = createProgram(gl, this.vertexShader, fragmentShader);
      gl.deleteShader(fragmentShader);
      this.programs[key] = program;
    }
    if (program === this.activeProgram) return;
    this.uniforms = getUniforms(gl, program);
    this.activeProgram = program;
    this.activeKey = key;
  };

  Material.prototype.bind = function () {
    this.gl.useProgram(this.activeProgram);
  };

  Material.prototype.dispose = function () {
    var self = this;
    Object.keys(this.programs).forEach(function (key) {
      self.gl.deleteProgram(self.programs[key]);
    });
    this.programs = {};
    this.activeProgram = null;
    this.uniforms = {};
  };

  /** Pointer state for mouse, pen and touch input. */
  function Pointer(id) {
    this.id = id == null ? -1 : id;
    this.texcoordX = 0;
    this.texcoordY = 0;
    this.prevTexcoordX = 0;
    this.prevTexcoordY = 0;
    this.deltaX = 0;
    this.deltaY = 0;
    this.down = false;
    this.moved = false;
    this.color = { r: 0.1, g: 0, b: 0.5 };
  }

  Pointer.prototype.reset = function (texcoordX, texcoordY, color) {
    this.texcoordX = texcoordX;
    this.texcoordY = texcoordY;
    this.prevTexcoordX = texcoordX;
    this.prevTexcoordY = texcoordY;
    this.deltaX = 0;
    this.deltaY = 0;
    this.moved = false;
    if (color) this.color = color;
  };
