#!/usr/bin/env python3
"""
Build the single-file Fluid Simulation API library and the standalone demo pages.

Why a build step?
    The shaders in the original WebGL fluid simulation are the mathematical core of
    the app and are kept byte-for-byte identical to the original source. Rather than
    hand-copying ~600 lines of GLSL (and risking subtle transcription errors), this
    script extracts them from the reference copy of the original app and splices them
    into the library template.

Outputs
    fluid-simulation.js                 - single-file, dependency-free library
    index.html                          - self-contained flagship demo
    examples/standalone/<name>.html     - self-contained copies of every example

Usage
    python3 tools/build.py
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
REFERENCE_SCRIPT = ROOT / "tools" / "reference" / "original-app-script.js"

SHADER_ORDER = [
    ("baseVertex", "gl.VERTEX_SHADER"),
    ("blurVertex", "gl.VERTEX_SHADER"),
    ("blur", "gl.FRAGMENT_SHADER"),
    ("copy", "gl.FRAGMENT_SHADER"),
    ("clear", "gl.FRAGMENT_SHADER"),
    ("color", "gl.FRAGMENT_SHADER"),
    ("checkerboard", "gl.FRAGMENT_SHADER"),
    ("display", None),
    ("bloomPrefilter", "gl.FRAGMENT_SHADER"),
    ("bloomBlur", "gl.FRAGMENT_SHADER"),
    ("bloomFinal", "gl.FRAGMENT_SHADER"),
    ("sunraysMask", "gl.FRAGMENT_SHADER"),
    ("sunrays", "gl.FRAGMENT_SHADER"),
    ("splat", "gl.FRAGMENT_SHADER"),
    ("advection", "gl.FRAGMENT_SHADER"),
    ("divergence", "gl.FRAGMENT_SHADER"),
    ("curl", "gl.FRAGMENT_SHADER"),
    ("vorticity", "gl.FRAGMENT_SHADER"),
    ("pressure", "gl.FRAGMENT_SHADER"),
    ("gradientSubtract", "gl.FRAGMENT_SHADER"),
]

# name in original source -> name in SHADERS
SOURCE_NAMES = {
    "baseVertex": "baseVertexShader",
    "blurVertex": "blurVertexShader",
    "blur": "blurShader",
    "copy": "copyShader",
    "clear": "clearShader",
    "color": "colorShader",
    "checkerboard": "checkerboardShader",
    "display": "displayShaderSource",
    "bloomPrefilter": "bloomPrefilterShader",
    "bloomBlur": "bloomBlurShader",
    "bloomFinal": "bloomFinalShader",
    "sunraysMask": "sunraysMaskShader",
    "sunrays": "sunraysShader",
    "splat": "splatShader",
    "advection": "advectionShader",
    "divergence": "divergenceShader",
    "curl": "curlShader",
    "vorticity": "vorticityShader",
    "pressure": "pressureShader",
    "gradientSubtract": "gradientSubtractShader",
}


def extract_shaders(source: str) -> dict[str, str]:
    """
    Pull each GLSL program out of the original app script.

    A small scanner is used instead of a regex: the reference file declares some
    shaders as `const x = compileShader(gl.FRAGMENT_SHADER, `...`, ['KEYWORDS']);`,
    so the template literal has to be delimited by backticks, not by the first
    following semicolon.
    """
    shaders: dict[str, str] = {}
    for key, _stage in SHADER_ORDER:
        source_name = SOURCE_NAMES[key]
        declaration = re.search(r"const\s+%s\s*=" % re.escape(source_name), source)
        if declaration is None:
            raise SystemExit("could not find shader %s in the reference source" % source_name)
        start = source.find("`", declaration.end())
        if start == -1:
            raise SystemExit("shader %s is not a template literal" % source_name)
        end = source.find("`", start + 1)
        if end == -1:
            raise SystemExit("shader %s is unterminated" % source_name)
        body = source[start + 1 : end]
        tail = source[end + 1 : source.find(";", end)]
        if "`" in tail:
            raise SystemExit("shader %s has an unexpected trailing template literal" % source_name)
        shaders[key] = body.strip("\n")
    return shaders


def render_shader_block(shaders: dict[str, str]) -> str:
    parts = [
        "  // ---------------------------------------------------------------------------",
        "  // GLSL programs. Extracted verbatim from the original WebGL fluid simulation",
        "  // (MIT, Copyright (c) 2017 Pavel Dobryakov) by tools/build.py.",
        "  // Do not edit here: edit tools/reference/original-app-script.js instead.",
        "  // ---------------------------------------------------------------------------",
        "  const SHADERS = {",
    ]
    for key, _stage in SHADER_ORDER:
        body = shaders[key]
        parts.append("    %s: `" % key)
        parts.append(body)
        parts.append("`,")
    parts.append("  };")
    return "\n".join(parts)


def build_library() -> Path:
    template = (ROOT / "src" / "parts" / "01-head.js").read_text()
    middle = (ROOT / "src" / "parts" / "02-instance.js").read_text()
    loop = (ROOT / "src" / "parts" / "02b-loop.js").read_text()
    tail = (ROOT / "src" / "parts" / "03-tail.js").read_text()

    shaders = extract_shaders(REFERENCE_SCRIPT.read_text())
    block = render_shader_block(shaders)

    if "/*__SHADERS__*/" not in template:
        raise SystemExit("01-head.js is missing the /*__SHADERS__*/ placeholder")

    output = "\n".join([template.replace("/*__SHADERS__*/", block), middle, loop, tail])
    output = output.rstrip("\n") + "\n"

    target = ROOT / "fluid-simulation.js"
    target.write_text(output)
    return target


INLINE_PATTERN = re.compile(
    r'<script src="(?:\.\./)*(?:fluid-simulation\.js)"></script>',
    re.IGNORECASE,
)


def escape_for_inline(js: str) -> str:
    """Make JavaScript safe to paste inside an HTML <script> block."""
    return re.sub(r"</(script)", r"<\\/\1", js, flags=re.IGNORECASE)


def build_standalone(source: Path, target: Path, library_js: str) -> None:
    html = source.read_text()
    if INLINE_PATTERN.search(html) is None:
        raise SystemExit("%s does not reference fluid-simulation.js" % source)
    inline = ("<script>\n/* fluid-simulation.js inlined by tools/build.py */\n%s\n</script>"
              % escape_for_inline(library_js))
    html = INLINE_PATTERN.sub(lambda _m: inline, html, count=1)
    html = html.replace(
        "</title>",
        "</title>\n    <!-- Standalone copy: fluid-simulation.js is inlined so this page "
        "works from file:// and without any network access. -->",
        1,
    )
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(html)


def main() -> int:
    library = build_library()
    library_js = library.read_text()
    print("wrote %s (%d bytes)" % (library.relative_to(ROOT), len(library_js)))

    # Flagship demo + offline copies of every example.
    demo_src = ROOT / "demo" / "index.html"
    if demo_src.exists():
        build_standalone(demo_src, ROOT / "index.html", library_js)
        print("wrote index.html (self-contained demo)")

    for example in sorted((ROOT / "examples").glob("*.html")):
        build_standalone(example, ROOT / "examples" / "standalone" / example.name, library_js)
        print("wrote examples/standalone/%s" % example.name)
    return 0


if __name__ == "__main__":
    sys.exit(main())
