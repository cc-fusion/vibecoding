# API reference

Everything is exposed through the global `FluidSimulation` (UMD: also `require()` /
AMD). Create instances, drive them with methods, listen with events.

- [Loading](#loading)
- [Statics](#statics)
- [create(options)](#createoptions)
- [Creation options](#creation-options)
- [Instance properties](#instance-properties)
- [Lifecycle](#lifecycle)
- [Simulation control](#simulation-control)
- [Configuration](#configuration)
- [Colors](#colors)
- [Capturing](#capturing)
- [Pointer input](#pointer-input)
- [Events](#events)
- [Errors](#errors)
- [Shaders and helpers](#shaders-and-helpers)

---

## Loading

```html
<script src="fluid-simulation.js"></script>
<script>
  const fluid = FluidSimulation.create({ container: '#stage' });
</script>
```

CommonJS and AMD are supported as well (`const FluidSimulation = require('./fluid-simulation.js')`).

---

## Statics

| Member | Description |
| --- | --- |
| `FluidSimulation.create(options)` | Create an instance and register it in `instances`. |
| `FluidSimulation.createIfSupported(options)` | Same, but returns `null` (and calls `options.onError`) when WebGL is missing or creation fails. |
| `FluidSimulation.attach(elementOrSelector, options)` | `create()` with `options.canvas` pre-filled. |
| `FluidSimulation.autoInit(options)` | Create instances for every `[data-fluid]` element; returns the new instances. |
| `FluidSimulation.isSupported()` | Feature test that does not leave a context behind. |
| `FluidSimulation.destroyAll()` | Destroy every live instance; returns the number destroyed. |
| `FluidSimulation.instances` | Live array of instances created via `create()`. |
| `FluidSimulation.version` | `'1.0.0'`. |
| `FluidSimulation.defaultConfig()` | Fresh copy of the default simulation config. |
| `FluidSimulation.defaultOptions()` | Fresh copy of the default creation options. |
| `FluidSimulation.defaults` | `{ config, options, presets }` (live objects; treat as read-only). |
| `FluidSimulation.presets` | `{ classic, calm, vivid, smoke, ink }`. |
| `FluidSimulation.events` | Event-name constants, e.g. `FluidSimulation.events.SPLAT`. |
| `FluidSimulation.errorCodes` | `{ NO_CANVAS, NO_WEBGL, FLOAT_TEXTURE_UNSUPPORTED, SHADER_COMPILE, CONTEXT_LOST, DESTROYED }`. |
| `FluidSimulation.Error` | The error class thrown by the API (`error.code`). |
| `FluidSimulation.shaders` | The 20 GLSL sources, e.g. `FluidSimulation.shaders.splat`. |
| `FluidSimulation.helpers` | `HSVtoRGB`, `hexToRgb`, `rgbToHex`, `toRgb255`, `normalizeColor`, `randomColor`, `clamp01`, `clamp`, `wrap`, `isMobile`, `hashCode`. |

---

## create(options)

```js
const fluid = FluidSimulation.create({
  container: '#stage',
  preset: 'vivid',
  config: { BLOOM_INTENSITY: 1.1 },
  keyboard: true,
  onError: (error) => console.warn(error.code, error.message)
});
```

`create()` throws a `FluidSimulation.Error` for unrecoverable setup problems
(no WebGL, unknown selector, unknown preset). `createIfSupported()` never throws.

---

## Creation options

| Option | Default | Description |
| --- | --- | --- |
| `canvas` | `null` | Element or selector to render into. When the element is not a `<canvas>`, one is created inside it and fills it. |
| `container` | `null` | Element/selector that receives a new canvas filling its box. Ignored when `canvas` is set. |
| *(neither)* | - | A fixed, full-viewport canvas is appended to `<body>` with `pointer-events: none` and `z-index: -1` - the page-background mode. |
| `config` | `{}` | Partial configuration merged over the defaults (see below). |
| `preset` | `null` | `'classic'`, `'calm'`, `'vivid'`, `'smoke'` or `'ink'`; applied before `config`. |
| `initialSplats` | `'random'` | `'random'` (5-25 splats, like the original), a number, or `0`/`false` for a still start. |
| `autoStart` | `true` | Start the animation loop immediately. |
| `autoUpdate` | `true` | `false` disables the loop entirely; drive frames with `frame(dt)`. |
| `autoDegrade` | `true` | Disable shading/bloom/sunrays and lower the dye resolution when float filtering is unsupported. |
| `mobileQuality` | `true` | Cap `DYE_RESOLUTION` at 512 on mobile user agents. |
| `input` | `true` | Bind pointer/touch input to the canvas. |
| `keyboard` | `false` | Bind `hotkeys` on `window`. |
| `hotkeys` | `{ pause: 'KeyP', splat: 'Space' }` | KeyboardEvent `code` values. |
| `pauseWhenHidden` | `true` | Pause while the document is hidden, resume afterwards (only if the pause was automatic). |
| `visibilityPause` | `null` | Explicit override for `pauseWhenHidden`. |
| `preserveDrawingBuffer` | `false` | Sets the WebGL context flag; enables plain `canvas.toDataURL()` readback. |
| `ditheringUrl` | `null` | Load your own bloom-noise texture instead of the generated one. |
| `color` | `null` | Fixed color for pointers/splats (hex, array or object); `null` = random generator. |
| `id`, `className` | `null`, `'fluid-canvas'` | Applied to the canvas the library creates. |
| `style` | `null` | Extra inline styles, applied last (e.g. `{ pointerEvents: 'auto' }`). |
| `removeCanvasOnDestroy` | `false` | Remove a library-created canvas when the instance is destroyed. |
| `releaseContext` | `false` | Also drop the WebGL context on destroy (`WEBGL_lose_context`). |
| `throwOnError` / `onError` | `true` / `null` | Reserved for hosts that prefer callbacks over exceptions. |

### config keys

See the table in the [README](../README.md#configuration). Values are validated loosely:
unknown keys are ignored with a console warning, and changing a resolution key rebuilds the
affected framebuffers, while `SHADING` / `BLOOM` / `SUNRAYS` recompile the display shader.

---

## Instance properties

| Property | Type | Notes |
| --- | --- | --- |
| `canvas` | `HTMLCanvasElement` | The rendering canvas. |
| `config` | `Object` | Live configuration. Read it freely, change it through `setConfig()`. |
| `options` | `Object` | The resolved creation options. |
| `gl`, `ext` | WebGL objects | Advanced use only; the API does not guarantee their layout. |
| `pointers` | `Pointer[]` | Live pointer states (colors, positions). |
| `degraded` | `{ mobile, noLinearFiltering }` | What the constructor had to turn off. |
| `version` | `string` | Library version. |

---

## Lifecycle

```js
fluid.start();          // start/restart the animation loop        -> this
fluid.stop();           // stop the loop, keep GL state            -> this
fluid.pause();          // freeze the physics (still renders)      -> this
fluid.resume();         // un-freeze (starts the loop if stopped) -> this
fluid.togglePause();    //                                        -> this
fluid.frame(dt);        // one manual step+render (dt in seconds)  -> this
fluid.update(dt);       // alias of frame()
fluid.clear();          // wipe dye + velocity fields              -> this
fluid.resize();         // re-read the canvas size, rebuild FBOs   -> this
fluid.destroy();        // release listeners + GL resources        -> this
fluid.dispose();        // alias of destroy()

fluid.isRunning();      // loop active?
fluid.isPaused();       // physics frozen?
fluid.isDestroyed();
fluid.getSize();        // { cssWidth, cssHeight, width, height, pixelRatio }
fluid.getContextInfo(); // { webgl2, renderer, vendor, supportLinearFiltering, degraded, drawCalls }
```

`stop()` keeps all state, so `start()` continues where you left off. `destroy()` is final -
any further method call throws `DESTROYED`.

---

## Simulation control

```js
fluid.splat(x, y, dx, dy, color, { radius });   // normalized coords, 0..1, y up
fluid.splatAt(clientX, clientY, dx, dy, color); // client pixels (e.g. from a click)
fluid.randomSplats(12);                         // immediate burst
fluid.queueSplats(12);                          // burst on the next frame
fluid.startStroke(x, y, color);
fluid.moveStroke(x, y);                         // injects force along the path
fluid.endStroke();
fluid.pointerDown(x, y, color);
fluid.pointerMove(x, y);
fluid.pointerUp();
```

- Coordinates are normalized with the origin at the **bottom-left** (WebGL texture space).
- `dx`/`dy` are velocity impulses: `±1000` is a strong push, `0` only injects dye.
- `color` accepts `'#1e90ff'`, `'#abc'`, `[30,144,255]`, `{ r, g, b }` in 0-255 **or** 0-1;
  omit it for a random color. Values above 1 are allowed and glow.
- `{ radius }` overrides `config.SPLAT_RADIUS` for one splat.

```js
// Paint a sine wave without any pointer input.
fluid.startStroke(0.1, 0.5, '#7ef0c0');
for (let i = 0; i <= 30; i++) fluid.moveStroke(0.1 + i * 0.025, 0.5 + Math.sin(i / 3) * 0.2);
fluid.endStroke();
```

---

## Configuration

```js
fluid.getConfig();                          // full copy
fluid.setConfig({ CURL: 40, BLOOM: false }); // partial merge, fires 'config'
fluid.resetConfig();                        // back to the creation-time config
fluid.applyPreset('smoke');
fluid.setQuality({ sim: 128, dye: 1024, capture: 512 });
fluid.setBackground('#101018');             // or { r, g, b } / [r, g, b]
fluid.setBackground('transparent');         // or setTransparent(true)
fluid.setDithering(true | false | 'noise.png');
```

`setConfig()` returns the live config object (the instance itself is returned by every other
method, so calls chain).

---

## Colors

```js
fluid.setColor('#4fc3f7');                 // fixed color, null to go back to random
fluid.setColorGenerator(() => FluidSimulation.helpers.HSVtoRGB(Math.random(), 0.6, 1));
fluid.setColorGenerator(null);             // restore the default generator
fluid.randomColor();                       // { r, g, b } in 0..1 from the generator
```

A generator returns `{ r, g, b }`. Values in `0..1` are used directly; anything larger is
treated as 0-255 and normalized. Multiply a normalized color to add glow
(`1.0` = bright core, as in the original's random splats).

---

## Capturing

```js
const canvas = fluid.capture({ resolution: 2048 });   // offscreen <canvas>
const dataUrl = fluid.toDataURL('image/png');
fluid.download('fluid.png', { resolution: 1024 });
fluid.captureScreenshot('fluid.png');                  // alias of download()
const { width, height, data } = fluid.getImageData();  // RGBA bytes, top-left origin
```

`resolution` sets the **smaller** dimension; the canvas aspect ratio is preserved (a 16:9
canvas at `512` yields 910x512). The snapshot includes shading, bloom and sunrays. The
temporary framebuffer is disposed afterwards, and a `capture` event carries the result.

---

## Pointer input

```js
fluid.enableInput();   fluid.disableInput();   fluid.isInputEnabled();
fluid.enableKeyboard(); fluid.disableKeyboard();
```

Pointer Events are used when available (mouse, pen and multi-touch at once), with a
mouse/touch fallback. `touch-action: none` is set on the canvas so dragging does not scroll
the page. Keyboard shortcuts ignore events that originate from inputs, textareas, selects
and `contenteditable` elements, and are off unless you pass `keyboard: true`.

---

## Events

```js
fluid.on(FluidSimulation.events.SPLAT, (payload) => console.log(payload.x, payload.color));
fluid.once('ready', () => console.log('first frame is up'));
fluid.off('frame', handler);
fluid.listeners('frame');
fluid.removeAllListeners('frame');
```

| Event | Payload | Fired when |
| --- | --- | --- |
| `ready` | `{ canvas, gl, config }` | After construction (next macrotask, so listeners can attach). |
| `frame` | `{ dt, paused, drawCalls }` | Once per animation frame, after render. |
| `splat` | `{ x, y, dx, dy, color, radius }` or `{ multiple: n }` | A splat is injected. |
| `resize` | `{ width, height }` | The drawing buffer was resized and framebuffers rebuilt. |
| `config` | `{ config, changes, previous }` | `setConfig()` changed something. |
| `pause` / `resume` | `{}` | The physics was paused/resumed (`PAUSED` or the hotkey). |
| `visibility` | `{ hidden }` | The document became hidden/visible. |
| `capture` | `{ canvas, width, height }` | `capture()` produced a frame. |
| `clear` | `{}` | `clear()` wiped the fields. |
| `destroy` | `{}` | `destroy()` ran; the instance is unusable afterwards. |
| `error` | `{ code, message, error? }` | WebGL context lost, and other recoverable problems. |

Listener exceptions are caught and reported through `console.warn`, so one bad handler
cannot stop the loop.

---

## Errors

```js
try {
  FluidSimulation.create({ canvas: '#nope' });
} catch (error) {
  console.log(error.name);  // 'FluidSimulationError'
  console.log(error.code);  // 'NO_CANVAS'
}
```

| Code | Meaning |
| --- | --- |
| `NO_CANVAS` | Selector matched nothing, a bad element was passed, or an unknown preset name. |
| `NO_WEBGL` | No usable WebGL context, or no half-float/float texture support. |
| `FLOAT_TEXTURE_UNSUPPORTED` | Context exists but float framebuffers cannot be rendered to. |
| `SHADER_COMPILE` | A shader failed to compile or link (details in `error.details.log`). |
| `CONTEXT_LOST` | The GPU context was lost; the library tries to rebuild on restore. |
| `DESTROYED` | A method was called on a destroyed instance. |

---

## Shaders and helpers

```js
FluidSimulation.shaders.display;   // source string for the display pass
FluidSimulation.helpers.HSVtoRGB(0.55, 1, 1);   // { r, g, b } in 0..1
FluidSimulation.helpers.rgbToHex({ r: 30, g: 144, b: 255 }); // '#1e90ff'
```

The 20 programs are `baseVertex`, `blurVertex`, `blur`, `copy`, `clear`, `color`,
`checkerboard`, `display`, `bloomPrefilter`, `bloomBlur`, `bloomFinal`, `sunraysMask`,
`sunrays`, `splat`, `advection`, `divergence`, `curl`, `vorticity`, `pressure`,
`gradientSubtract`.
