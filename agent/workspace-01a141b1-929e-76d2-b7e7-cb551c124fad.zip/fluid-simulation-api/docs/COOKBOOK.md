# Cookbook

Short, copy-pasteable recipes. Every snippet uses only the public API.

---

## 1. Full-page background behind content

```html
<script src="fluid-simulation.js"></script>
<script>
  const fluid = FluidSimulation.create({
    config: { DENSITY_DISSIPATION: 1.2, CURL: 24 },
    input: false                       // click-through, so links still work
  });
</script>
```

The library creates a fixed, viewport-sized canvas with `z-index: -1` and
`pointer-events: none`. To let people draw on the background too:

```js
fluid.enableInput();
fluid.canvas.style.pointerEvents = 'auto';
fluid.canvas.style.zIndex = '0';       // put it above the page background
```

---

## 2. Contained widget inside a card or hero section

```js
const fluid = FluidSimulation.create({ container: '#hero', input: true });
```

`#hero` gets `position: relative` (if it was `static`) and a canvas that fills it. Give the
container a height - the canvas measures its CSS box, so a zero-height parent renders
nothing.

---

## 3. Cheap mode for low-end devices

```js
const fluid = FluidSimulation.create({
  config: {
    SIM_RESOLUTION: 64,
    DYE_RESOLUTION: 256,
    PRESSURE_ITERATIONS: 12,
    BLOOM: false,
    SUNRAYS: false
  }
});
```

`getContextInfo().renderer` reveals the GPU, and `degraded` tells you whether the library
already had to disable effects for missing float filtering.

---

## 4. Pause when scrolled out of view

```js
const observer = new IntersectionObserver(([entry]) => {
  entry.isIntersecting ? fluid.resume() : fluid.pause();
});
observer.observe(fluid.canvas);
```

`stop()` is the stronger option: it halts the loop completely (no GPU work at all) and
`start()` brings it back with the fluid state intact.

---

## 5. React

```jsx
import { useEffect, useRef } from 'react';

export function FluidBackdrop({ config }) {
  const host = useRef(null);
  const fluid = useRef(null);

  useEffect(() => {
    fluid.current = FluidSimulation.create({ container: host.current, config });
    return () => fluid.current.destroy();
  }, []);                                   // create once

  useEffect(() => {
    fluid.current?.setConfig(config);       // react to prop changes
  }, [config]);

  return <div ref={host} style={{ position: 'fixed', inset: 0 }} />;
}
```

Keep the instance in a ref: recreating it on every render would leak WebGL contexts. The
library is plain DOM code, so it works the same in Vue, Svelte, Angular or Lit.

---

## 6. Reacting to a click without the built-in input

```js
stage.addEventListener('pointerdown', (event) => {
  const rect = stage.getBoundingClientRect();
  const x = (event.clientX - rect.left) / rect.width;
  const y = 1 - (event.clientY - rect.top) / rect.height;
  fluid.splat(x, y, 0, 0, '#7ef0c0');
});
```

Or let the library do the coordinate maths: `fluid.splatAt(event.clientX, event.clientY, 0, 0)`.

---

## 7. Draw a shape or a signature

```js
function lissajous(steps = 240) {
  fluid.startStroke(0.5, 0.5, '#7ef0c0');
  for (let i = 0; i <= steps; i++) {
    const t = (i / steps) * Math.PI * 2;
    fluid.moveStroke(0.5 + Math.sin(3 * t) * 0.3, 0.5 + Math.cos(2 * t) * 0.3);
  }
  fluid.endStroke();
}
```

Between calls, `frame()` must run for the fluid to react - either keep `autoStart` on, or
step manually (`for (let i = 0; i < 60; i++) fluid.frame(1 / 60);`) to render an animation
frame by frame, e.g. for a video export.

---

## 8. Audio, sensors or any other signal

```js
const audio = new AudioContext();                  // ...analysis omitted
analyser.getByteFrequencyData(spectrum);
const energy = spectrum.reduce((a, b) => a + b, 0) / spectrum.length / 255;

fluid.setConfig({ CURL: 20 + energy * 40 });
if (energy > 0.55) fluid.splat(Math.random(), 0.15, 0, 900 * energy, '#ff4d6d');
```

---

## 9. Snapshots and thumbnails

```js
const canvas = fluid.capture({ resolution: 320 });  // smaller dimension = 320
thumb.src = canvas.toDataURL('image/png');
```

Force a specific size by rendering the snapshot into your own canvas:

```js
const target = document.createElement('canvas');
target.width = 1280; target.height = 720;
target.getContext('2d').drawImage(fluid.capture({ resolution: 720 }), 0, 0, 1280, 720);
```

---

## 10. Several independent instances

```js
const tiles = document.querySelectorAll('.tile');
const fluids = Array.from(tiles, (tile) => FluidSimulation.create({ container: tile }));

window.addEventListener('beforeunload', () => fluids.forEach((f) => f.destroy()));
```

Or declaratively:

```html
<div data-fluid data-fluid-preset="vivid"></div>
<div data-fluid data-fluid-config='{"DYE_RESOLUTION":256,"BLOOM":false}'></div>
<script>FluidSimulation.autoInit({ initialSplats: 4 });</script>
```

Browsers limit live WebGL contexts (8-16); destroy the ones you no longer show.

---

## 11. Matching a brand color

```js
fluid.setConfig({ COLORFUL: false });
fluid.setColor('#0f62fe');

// Or vary within one hue so it still feels alive:
fluid.setColorGenerator(() => {
  const c = FluidSimulation.helpers.HSVtoRGB(0.58 + Math.random() * 0.06, 0.85, 1);
  return { r: c.r * 0.45, g: c.g * 0.45, b: c.b * 0.45 };
});
```

---

## 12. Transparent canvas over CSS

```js
fluid.setTransparent(true);
fluid.canvas.style.background = 'transparent';
document.body.style.background = 'linear-gradient(135deg, #12c2e9, #c471ed, #f64f59)';
```

`TRANSPARENT` uses the original app's trick - a checkerboard behind the dye - so the result
is composited *in* the canvas; the canvas itself stays opaque unless you also clear the CSS
background as above.

---

## 13. Handling unsupported devices gracefully

```js
const fluid = FluidSimulation.createIfSupported({
  container: '#stage',
  onError: (error) => {
    document.querySelector('#stage').innerHTML =
      '<p class="fallback">This device cannot run the fluid simulation (' + error.code + ').</p>';
  }
});
if (fluid) fluid.randomSplats(8);
```

---

## 14. Deterministic screenshots in tests

```js
const fluid = FluidSimulation.create({
  container: '#stage', autoStart: false, initialSplats: 0, autoDegrade: false
});

fluid.splat(0.5, 0.5, 0, 0, '#ff0000');
fluid.frame(1 / 60);                       // one deterministic step
const url = fluid.toDataURL();             // pixel-stable across runs
```

Software rasterisers (SwiftShader, llvmpipe) do not support float-texture filtering, so
`autoDegrade: false` is what keeps shading/bloom enabled when you need identical output.
