#!/usr/bin/env python3
"""
Smoke tests for the demo app and every example page.

Each page is loaded from file:// (no server needed), left to run for a moment and
checked for: no console errors, a live instance, actual draw calls, and - for the
flagship demo - working controls.

    python3 tests/demo_test.py [--shot DIR]
"""

from __future__ import annotations

import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
LAUNCH_ARGS = [
    "--use-gl=angle",
    "--use-angle=swiftshader",
    "--enable-unsafe-swiftshader",
    "--disable-dev-shm-usage",
]

PAGES = [
    ("demo (self-contained, library inlined)", ROOT / "index.html"),
    ("demo (external fluid-simulation.js)", ROOT / "demo" / "index.html"),
    ("01 basic", ROOT / "examples" / "standalone" / "01-basic.html"),
    ("02 page background", ROOT / "examples" / "standalone" / "02-page-background.html"),
    ("03 programmatic splats", ROOT / "examples" / "standalone" / "03-programmatic-splats.html"),
    ("04 custom controls", ROOT / "examples" / "standalone" / "04-custom-controls.html"),
    ("05 events and capture", ROOT / "examples" / "standalone" / "05-events-and-capture.html"),
    ("06 auto-init multiple", ROOT / "examples" / "standalone" / "06-auto-init-multiple.html"),
]

PASSED: list[str] = []
FAILED: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    (PASSED if condition else FAILED).append(name if condition else f"{name} {detail}".strip())
    print(("PASS: " if condition else "FAIL: ") + name + ("" if condition else f"  {detail}"))


def main() -> int:
    shot_dir = None
    if "--shot" in sys.argv:
        shot_dir = Path(sys.argv[sys.argv.index("--shot") + 1])
        shot_dir.mkdir(parents=True, exist_ok=True)

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(args=LAUNCH_ARGS)

        for label, path in PAGES:
            context = browser.new_context(viewport={"width": 1120, "height": 700}, device_scale_factor=1)
            page = context.new_page()
            errors: list[str] = []
            page.on("console", lambda message: errors.append(message.text) if message.type == "error" else None)
            page.on("pageerror", lambda error: errors.append(str(error)))
            page.goto(path.as_uri())
            page.wait_for_timeout(1200)

            state = page.evaluate(
                """() => ({
                     instances: FluidSimulation.instances.length,
                     running: FluidSimulation.instances.filter(i => i.isRunning()).length,
                     drawCalls: FluidSimulation.instances.reduce((sum, i) => sum + i.getContextInfo().drawCalls, 0),
                     canvases: document.querySelectorAll('canvas').length
                   })"""
            )
            check(f"{label}: no console errors", not errors, " | ".join(errors[:2]))
            check(f"{label}: instance(s) created", state["instances"] >= 1, str(state))
            check(f"{label}: canvas present", state["canvases"] >= 1, str(state))
            check(f"{label}: rendering frames", state["drawCalls"] > 0, str(state))

            if shot_dir and "demo (self-contained" in label:
                page.evaluate("() => { fluid.randomSplats(24); }")
                page.wait_for_timeout(900)
                page.screenshot(path=str(shot_dir / "demo.png"))
                page.click("#collapse")
                page.wait_for_timeout(200)
                page.screenshot(path=str(shot_dir / "demo-collapsed.png"))

            # Interactive checks only make sense on the flagship demo.
            if "self-contained" in label:
                # The screenshot pass may have collapsed the panel; make sure it is open.
                if page.evaluate("document.getElementById('panel').classList.contains('collapsed')"):
                    page.click("#collapse")
                page.select_option("#preset", "ink")
                page.wait_for_timeout(300)
                preset_config = page.evaluate("fluid.getConfig()")
                check("demo: preset select applies a preset",
                      preset_config["CURL"] == 6 and preset_config["BLOOM"] is False, str(preset_config))

                page.select_option("#quality", "512")
                page.wait_for_timeout(300)
                check("demo: quality select changes the dye resolution",
                      page.evaluate("fluid.getConfig().DYE_RESOLUTION") == 512)

                page.evaluate("""() => {
                    const input = document.getElementById('curl');
                    input.value = '44';
                    input.dispatchEvent(new Event('input', { bubbles: true }));
                  }""")
                check("demo: slider writes through setConfig",
                      page.evaluate("fluid.getConfig().CURL") == 44)

                draw_calls_before = page.evaluate("fluid.getContextInfo().drawCalls")
                page.click("#splats")
                page.wait_for_timeout(300)
                check("demo: Random splats button reacts", page.evaluate("fluid.getContextInfo().drawCalls") > draw_calls_before)

                with page.expect_download() as download_info:
                    page.click("#capture")
                check("demo: Save PNG downloads a file",
                      download_info.value.suggested_filename.startswith("fluid-"))

                page.click("#clear")
                page.click("#reset")
                page.wait_for_timeout(200)
                check("demo: reset restores the classic defaults",
                      page.evaluate("fluid.getConfig().CURL") == 30)

                page.check("#paused")
                page.wait_for_timeout(200)
                check("demo: pause checkbox pauses the physics",
                      page.evaluate("fluid.isPaused()") is True)
                page.uncheck("#paused")

                page.check("#transparent")
                page.wait_for_timeout(200)
                check("demo: transparency checkbox updates the canvas",
                      page.evaluate("fluid.getConfig().TRANSPARENT") is True and
                      page.evaluate("fluid.canvas.style.background") == "transparent")
                page.uncheck("#transparent")

                # Keyboard shortcuts: P pauses, Space bursts.
                page.click("canvas", position={"x": 300, "y": 300})
                page.keyboard.press("p")
                page.wait_for_timeout(150)
                check("demo: P hotkey pauses", page.evaluate("fluid.isPaused()") is True)
                page.keyboard.press("p")
                page.keyboard.press(" ")
                page.wait_for_timeout(250)
                check("demo: Space hotkey bursts splats and unpauses",
                      page.evaluate("fluid.isPaused()") is False)

                # Dragging the canvas moves the fluid.
                before = page.evaluate("fluid.getContextInfo().drawCalls")
                page.mouse.move(400, 300)
                page.mouse.down()
                page.mouse.move(700, 420, steps=12)
                page.mouse.up()
                page.wait_for_timeout(300)
                check("demo: dragging injects fluid", page.evaluate("fluid.getContextInfo().drawCalls") > before)

            context.close()

        browser.close()

    print()
    print(f"{len(PASSED)} passed, {len(FAILED)} failed")
    for failure in FAILED:
        print(f"  - {failure}")
    return 1 if FAILED else 0


if __name__ == "__main__":
    sys.exit(main())
