#!/usr/bin/env python3
"""
End-to-end tests for the Fluid Simulation API.

Runs the real library in headless Chromium (SwiftShader software WebGL) and drives
it through the public API only - the same surface a user would touch.

    python3 tests/browser_test.py            # from the project root
    python3 tests/browser_test.py --headed   # watch it run

Requires: pip install playwright && python -m playwright install --with-deps chromium
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
HARNESS = (ROOT / "tests" / "harness.html").as_uri()
LAUNCH_ARGS = [
    "--use-gl=angle",
    "--use-angle=swiftshader",
    "--enable-unsafe-swiftshader",
    "--disable-dev-shm-usage",
    "--hide-scrollbars",
]

PASSED: list[str] = []
FAILED: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    if condition:
        PASSED.append(name)
        print(f"PASS: {name}")
    else:
        FAILED.append(f"{name} {detail}".strip())
        print(f"FAIL: {name} {detail}")


def frames(page, count: int = 3) -> None:
    """Let the simulation advance a few real animation frames."""
    page.evaluate(
        """(count) => new Promise(resolve => {
             let seen = 0;
             const step = () => (++seen >= count ? resolve() : requestAnimationFrame(step));
             requestAnimationFrame(step);
           })""",
        count,
    )


def main() -> int:
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(args=LAUNCH_ARGS)
        context = browser.new_context(viewport={"width": 800, "height": 600})
        page = context.new_page()

        console_errors: list[str] = []
        page.on("console", lambda message: console_errors.append(message.text) if message.type == "error" else None)
        page.on("pageerror", lambda error: console_errors.append(str(error)))

        page.goto(HARNESS)

        # -- module surface ------------------------------------------------------
        version = page.evaluate("FluidSimulation.version")
        check("library exposes its version", version == "1.0.0", version)
        check(
            "static API is complete",
            page.evaluate(
                """() => ['create','createIfSupported','attach','autoInit','isSupported','destroyAll',
                          'defaultConfig','defaultOptions','presets','shaders','helpers','events','Error']
                       .every(key => key in FluidSimulation)"""
            ),
        )
        check("WebGL is reported as supported", page.evaluate("FluidSimulation.isSupported()") is True)
        check(
            "all 20 GLSL programs are exposed",
            page.evaluate(
                """() => Object.keys(FluidSimulation.shaders).filter(k =>
                     /(vec2|void main|gl_FragColor)/.test(FluidSimulation.shaders[k])).length"""
            )
            == 20,
        )
        check("helpers convert colors",
              page.evaluate("JSON.stringify(FluidSimulation.helpers.hexToRgb('#1e90ff'))") == '{"r":30,"g":144,"b":255}' and
              page.evaluate("FluidSimulation.helpers.rgbToHex({ r: 30, g: 144, b: 255 })") == "#1e90ff")
        check("presets are shipped", page.evaluate("Object.keys(FluidSimulation.presets).sort().join(',')") ==
              "calm,classic,ink,smoke,vivid")

        # -- construction --------------------------------------------------------
        page.evaluate(
            """() => {
                 window.host = document.getElementById('host');
                 window.instance = FluidSimulation.create({
                   container: host,
                   config: { CURL: 40, DYE_RESOLUTION: 256, SIM_RESOLUTION: 64 },
                   initialSplats: 0,
                   keyboard: true
                 });
               }"""
        )
        check("instance is created from a container element",
              page.evaluate("!!instance.canvas && instance.canvas.tagName") == "CANVAS")
        check("container gets a filling canvas",
              page.evaluate("instance.canvas.clientWidth") == 320 and page.evaluate("instance.canvas.clientHeight") == 240)
        check("config patch is merged over defaults",
              page.evaluate("instance.getConfig().CURL") == 40 and page.evaluate("instance.getConfig().BLOOM_ITERATIONS") == 8)
        check("unknown config keys are rejected with a warning but ignored",
              page.evaluate("() => { const before = instance.getConfig(); instance.setConfig({ NONSENSE: 1 }); return JSON.stringify(before) === JSON.stringify(instance.getConfig()); }") is True)
        check("the canvas is sized in device pixels",
              page.evaluate("instance.canvas.width") == page.evaluate("instance.getSize().width"))
        check("context info is reported",
              page.evaluate("typeof instance.getContextInfo().webgl2") == "boolean")
        check("exactly one instance is registered",
              page.evaluate("FluidSimulation.instances.length") == 1)

        # -- the loop ------------------------------------------------------------
        frames(page, 5)
        check("frames are rendered", page.evaluate("instance.getContextInfo().drawCalls") > 0)
        frame_events = page.evaluate(
            """() => new Promise(resolve => {
                 let count = 0;
                 const off = payload => { count++; if (count >= 3) { instance.off('frame', off); resolve(count); } };
                 instance.on('frame', off);
               })"""
        )
        check("the frame event fires with a timestep", frame_events >= 3)
        check("isRunning()/isPaused() report the loop state",
              page.evaluate("instance.isRunning() === true && instance.isPaused() === false") is True)

        # -- splats and pixels ---------------------------------------------------
        page.evaluate("() => { window.before = instance.getImageData({resolution: 128}); }")
        page.evaluate("() => instance.splat(0.5, 0.5, 0, 0, '#ff0000')")
        frames(page, 2)
        pixel_report = page.evaluate(
            """() => {
                 const after = instance.getImageData({ resolution: 128 });
                 const before = window.before.data;
                 let changed = 0, red = 0;
                 for (let i = 0; i < after.data.length; i += 4) {
                   if (Math.abs(after.data[i] - before[i]) > 2) changed++;
                   if (after.data[i] > after.data[i + 1] + 8 && after.data[i] > after.data[i + 2] + 8) red++;
                 }
                 return { changed, red, width: after.width, height: after.height, total: after.data.length / 4 };
               }"""
        )
        check("a same-color splat changes pixels", pixel_report["changed"] > 20, str(pixel_report))
        check("a splat of '#ff0000' is red-dominant", pixel_report["red"] > 10, str(pixel_report))
        # `resolution` is the smaller dimension, preserving the canvas aspect ratio (4:3 here).
        check("getImageData() honours the requested resolution and aspect ratio",
              pixel_report["height"] == 128 and pixel_report["width"] == 171, str(pixel_report))

        splat_event = page.evaluate(
            """() => new Promise(resolve => {
                 instance.once('splat', payload => resolve({ x: payload.x, y: payload.y, color: payload.color }));
                 instance.splat(0.25, 0.75, 200, -100, '#00ff00');
               })"""
        )
        check("the splat event carries coordinates and color",
              splat_event["x"] == 0.25 and splat_event["y"] == 0.75 and splat_event["color"]["g"] == 1.0,
              json.dumps(splat_event))
        check("splatAt() maps client pixels onto the canvas",
              page.evaluate("() => typeof instance.splatAt(10, 10, 5, 5, '#0000ff')") == "object")
        check("randomSplats() and queueSplats() are chainable",
              page.evaluate("instance.randomSplats(2).queueSplats(2) === instance") is True)
        check("scripted strokes run",
              page.evaluate(
                  """() => {
                       instance.startStroke(0.1, 0.1, '#ffffff');
                       instance.moveStroke(0.6, 0.6);
                       instance.endStroke();
                       return true;
                     }"""
              ) is True)
        check("programmatic pointers work",
              page.evaluate("instance.pointerDown(0.2, 0.2).pointerMove(0.4, 0.4).pointerUp() === instance") is True)

        # -- configuration -------------------------------------------------------
        page.evaluate("() => instance.setConfig({ CURL: 15, DYE_RESOLUTION: 512 })")
        frames(page, 2)
        check("resolution changes rebuild the dye framebuffer",
              page.evaluate("instance.dye.width") >= 512 and page.evaluate("instance.getConfig().CURL") == 15)
        keywords = page.evaluate(
            """() => {
                 instance.setConfig({ SHADING: false, BLOOM: false, SUNRAYS: false });
                 const off = instance.displayMaterial.activeKey;
                 instance.setConfig({ SHADING: true, BLOOM: true, SUNRAYS: true });
                 return { off, on: instance.displayMaterial.activeKey,
                          expectedOn: ['SHADING','BLOOM','SUNRAYS'].filter(k => instance.getConfig()[k]).join('|') };
               }"""
        )
        check("display keywords follow the config",
              keywords["off"] == "" and keywords["on"] == keywords["expectedOn"], json.dumps(keywords))
        config_events = page.evaluate(
            """() => new Promise(resolve => {
                 instance.once('config', payload => resolve(Object.keys(payload.changes).join(',')));
                 instance.setConfig({ CURL: 22 });
               })"""
        )
        check("config events report the change set", config_events == "CURL", config_events)
        check("setQuality() maps to the resolution knobs",
              page.evaluate("() => { instance.setQuality({ sim: 32, dye: 128 }); return instance.getConfig().SIM_RESOLUTION === 32 && instance.getConfig().DYE_RESOLUTION === 128; }") is True)
        check("presets can be applied at runtime",
              page.evaluate("() => { instance.applyPreset('calm'); const c = instance.getConfig(); return c.SPLAT_RADIUS === 0.4 && c.CURL === 12; }") is True)
        check("resetConfig() restores the creation-time configuration",
              page.evaluate("() => { instance.resetConfig(); const c = instance.getConfig(); return c.CURL === 40 && c.DYE_RESOLUTION === 256 && c.SIM_RESOLUTION === 64; }") is True)
        check("setBackground() accepts hex and 'transparent'",
              page.evaluate(
                  """() => {
                       instance.setBackground('#203040');
                       const solid = JSON.stringify(instance.getConfig().BACK_COLOR);
                       instance.setBackground('transparent');
                       const transparent = instance.getConfig().TRANSPARENT;
                       instance.setBackground({ r: 10, g: 20, b: 30 });
                       return solid === '{"r":32,"g":48,"b":64}' && transparent === true &&
                              instance.getConfig().BACK_COLOR.r === 10 && instance.getConfig().TRANSPARENT === false;
                     }"""
              ) is True)
        check("setColorGenerator() drives splat colors",
              page.evaluate(
                  """() => {
                       instance.setColorGenerator(() => ({ r: 1, g: 1, b: 1 }));
                       const color = instance.randomColor();
                       instance.setColorGenerator(null);
                       return color.r === 1 && color.g === 1 && color.b === 1;
                     }"""
              ) is True)
        check("setDithering() can switch the dither texture",
              page.evaluate("() => { instance.setDithering(false); const flat = instance.ditheringTexture.width === 1; instance.setDithering(true); return flat && instance.ditheringTexture.width === 64; }") is True)

        # -- pause / resume / stop ----------------------------------------------
        check("pause() stops the physics but keeps rendering",
              page.evaluate(
                  """() => {
                       instance.pause();
                       const paused = instance.isPaused();
                       instance.setConfig({ PAUSED: false });
                       return paused === true && instance.isPaused() === false;
                     }"""
              ) is True)
        pause_events = page.evaluate(
            """() => new Promise(resolve => {
                 const seen = [];
                 instance.on('pause', () => seen.push('pause')).on('resume', () => seen.push('resume'));
                 instance.pause(); instance.resume(); instance.togglePause(); instance.togglePause();
                 setTimeout(() => resolve(seen.join(',')), 0);
               })"""
        )
        check("pause/resume events fire", pause_events == "pause,resume,pause,resume", pause_events)
        check("stop() halts the loop and start() restarts it",
              page.evaluate(
                  """() => {
                       instance.stop();
                       const stopped = !instance.isRunning();
                       instance.start();
                       return stopped && instance.isRunning();
                     }"""
              ) is True)
        check("frame() advances manually when autoUpdate is off",
              page.evaluate(
                  """() => {
                       const manual = FluidSimulation.create({ container: second, autoStart: false, initialSplats: 0 });
                       const calls = manual.getContextInfo().drawCalls;
                       manual.frame(1 / 60);
                       const grew = manual.getContextInfo().drawCalls > calls;
                       manual.destroy();
                       return grew && !manual.isRunning();
                     }"""
              ) is True)

        # -- capture -------------------------------------------------------------
        data_url = page.evaluate("() => instance.toDataURL('image/png')")
        check("toDataURL() returns a PNG data URL", isinstance(data_url, str) and data_url.startswith("data:image/png;base64,"), str(data_url)[:40])
        check("capture() returns a canvas at the requested resolution",
              page.evaluate("() => { const c = instance.capture({ resolution: 64 }); return c.tagName === 'CANVAS' && c.height === 64 && c.width === 85; }") is True)
        with page.expect_download() as download_info:
            page.evaluate("() => instance.download('fluid-test.png')")
        download = download_info.value
        check("download() triggers a PNG download",
              download.suggested_filename == "fluid-test.png", download.suggested_filename)
        capture_event = page.evaluate(
            """() => new Promise(resolve => {
                 instance.once('capture', payload => resolve(payload.width + 'x' + payload.height));
                 instance.capture({ resolution: 96 });
               })"""
        )
        check("capture events report the size", capture_event == "128x96", capture_event)

        # -- keyboard, visibility, errors ---------------------------------------
        keyboard = page.evaluate(
            """() => {
                 instance.resume();
                 window.dispatchEvent(new KeyboardEvent('keydown', { code: 'KeyP', key: 'p', bubbles: true }));
                 const paused = instance.isPaused();
                 window.dispatchEvent(new KeyboardEvent('keydown', { code: 'Space', key: ' ', bubbles: true }));
                 instance.resume();
                 return paused;
             }"""
        )
        check("hotkeys pause and burst splats", keyboard is True)
        check("typing in an input is not hijacked",
              page.evaluate(
                  """() => {
                       const input = document.createElement('input');
                       document.body.appendChild(input);
                       input.focus();
                       const before = instance.isPaused();
                       input.dispatchEvent(new KeyboardEvent('keydown', { code: 'KeyP', key: 'p', bubbles: true }));
                       const after = instance.isPaused();
                       input.remove();
                       return before === after;
                     }"""
              ) is True)
        visibility = page.evaluate(
            """() => new Promise(resolve => {
                 const seen = [];
                 instance.on('visibility', payload => seen.push(payload.hidden));
                 document.dispatchEvent(new Event('visibilitychange'));
                 setTimeout(() => resolve(seen.length), 0);
               })"""
        )
        check("visibility changes are reported", visibility == 1)
        error_codes = page.evaluate(
            """() => {
                 const codes = [];
                 try { FluidSimulation.create({ canvas: '#does-not-exist' }); }
                 catch (error) { codes.push(error.code); }
                 try { FluidSimulation.create({ preset: 'nope', container: second }); }
                 catch (error) { codes.push(error.code); }
                 try { FluidSimulation.create({ container: second }).destroy().splat(0.5, 0.5); }
                 catch (error) { codes.push(error.code); }
                 return codes;
               }"""
        )
        check("invalid input produces coded errors",
              error_codes == ["NO_CANVAS", "NO_CANVAS", "DESTROYED"], json.dumps(error_codes))
        check("createIfSupported() returns an instance",
              page.evaluate("() => { const i = FluidSimulation.createIfSupported({ container: second, autoStart: false }); const ok = !!i; i.destroy(); return ok; }") is True)
        check("createIfSupported() returns null with a reason when impossible",
              page.evaluate("() => { const i = FluidSimulation.createIfSupported({ canvas: '#missing', onError: () => {} }); return i === null; }") is True)

        # -- multiple instances --------------------------------------------------
        multi = page.evaluate(
            """() => new Promise(resolve => {
                 const a = FluidSimulation.create({ container: host, autoStart: false, initialSplats: 0 });
                 const b = FluidSimulation.create({ container: second, autoStart: false, initialSplats: 0 });
                 a.frame(); b.frame();
                 a.splat(0.5, 0.5, 0, 0, '#ff0000');
                 a.frame(); b.frame();
                 const red = a.getImageData({ resolution: 64 });
                 const other = b.getImageData({ resolution: 64 });
                 let aBright = 0, bBright = 0;
                 for (let i = 0; i < red.data.length; i += 4) aBright += red.data[i] + red.data[i + 1];
                 for (let i = 0; i < other.data.length; i += 4) bBright += other.data[i] + other.data[i + 1];
                 const independent = aBright > bBright && a.canvas !== b.canvas && a.gl !== b.gl;
                 a.destroy(); b.destroy();
                 resolve({ independent, remaining: FluidSimulation.instances.length });
               })"""
        )
        check("instances are fully independent", multi["independent"] is True, json.dumps(multi))
        check("destroy() unregisters instances", multi["remaining"] == 1, json.dumps(multi))
        check("destroy(el) removes an owned canvas",
              page.evaluate("() => { const i = FluidSimulation.create({ container: second, initialSplats: 0, removeCanvasOnDestroy: true }); const canvas = i.canvas; i.destroy(); return !canvas.parentNode; }") is True)

        # -- auto-init -----------------------------------------------------------
        page.evaluate("() => FluidSimulation.autoInit({ initialSplats: 0 })")
        frames(page, 2)
        auto = page.evaluate(
            """() => {
                 const canvas = document.querySelector('canvas[data-fluid]');
                 return {
                   created: FluidSimulation.instances.length,
                   hasInstance: !!canvas.fluid,
                   preset: canvas.fluid ? canvas.fluid.getConfig().CURL : null,
                   again: FluidSimulation.autoInit().length
                 };
               }"""
        )
        check("autoInit() builds instances from data attributes",
              auto["hasInstance"] is True and auto["preset"] == 46, json.dumps(auto))
        check("autoInit() is idempotent", auto["again"] == 0, json.dumps(auto))
        check("auto-init instance renders", page.evaluate("document.querySelector('canvas[data-fluid]').fluid.getContextInfo().drawCalls") > 0)

        # -- teardown ------------------------------------------------------------
        check("destroyAll() cleans up and reports the count",
              page.evaluate("() => { const destroyed = FluidSimulation.destroyAll(); return destroyed >= 1 && FluidSimulation.instances.length === 0; }") is True)
        check("no console errors or exceptions", not console_errors, " | ".join(console_errors[:3]))

        browser.close()

    print()
    print(f"{len(PASSED)} passed, {len(FAILED)} failed")
    if FAILED:
        print("Failures:")
        for failure in FAILED:
            print(f"  - {failure}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
