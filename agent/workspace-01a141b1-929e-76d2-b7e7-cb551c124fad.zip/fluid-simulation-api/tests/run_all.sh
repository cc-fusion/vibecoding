#!/usr/bin/env bash
# Run every test suite. Usage: bash tests/run_all.sh
set -euo pipefail
cd "$(dirname "$0")/.."

echo "== node (no DOM / CommonJS) =="
node tests/node_test.js | tail -n 3

echo
echo "== browser: library API (headless Chromium / SwiftShader) =="
python3 tests/browser_test.py | tail -n 4

echo
echo "== browser: demo + examples =="
python3 tests/demo_test.py | tail -n 4
