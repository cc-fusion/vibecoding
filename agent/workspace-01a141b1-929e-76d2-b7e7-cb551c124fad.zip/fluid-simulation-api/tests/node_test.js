/**
 * Environment-independent checks: the library must load without a DOM
 * (CommonJS / SSR) and behave sensibly when it cannot render.
 *
 *   node tests/node_test.js
 */
const assert = require('node:assert');
const path = require('node:path');

const FluidSimulation = require(path.join(__dirname, '..', 'fluid-simulation.js'));

let passed = 0;
function check(name, fn) {
  try {
    fn();
    passed++;
    console.log('PASS: ' + name);
  } catch (error) {
    console.error('FAIL: ' + name + ' - ' + error.message);
    process.exitCode = 1;
  }
}

check('loads as CommonJS without a DOM', () => {
  assert.equal(typeof FluidSimulation, 'function');
  assert.equal(FluidSimulation.version, '1.0.0');
});

check('exposes the documented statics', () => {
  ['create', 'createIfSupported', 'attach', 'autoInit', 'isSupported', 'destroyAll',
    'defaultConfig', 'defaultOptions', 'presets', 'shaders', 'helpers', 'events', 'Error']
    .forEach((key) => assert.ok(key in FluidSimulation, `missing static ${key}`));
});

check('default config is a fresh copy', () => {
  const a = FluidSimulation.defaultConfig();
  const b = FluidSimulation.defaultConfig();
  a.CURL = 999;
  assert.equal(b.CURL, 30);
  assert.equal(FluidSimulation.defaultConfig().CURL, 30);
});

check('every preset is a valid partial config', () => {
  const valid = Object.keys(FluidSimulation.defaultConfig());
  Object.entries(FluidSimulation.presets).forEach(([name, preset]) => {
    Object.keys(preset).forEach((key) => {
      assert.ok(valid.indexOf(key) !== -1, `${name} has unknown key ${key}`);
    });
  });
});

check('all 20 shaders are present and non-trivial', () => {
  const sources = FluidSimulation.shaders;
  assert.equal(Object.keys(sources).length, 20);
  Object.entries(sources).forEach(([name, source]) => {
    assert.equal(typeof source, 'string', `${name} is not a string`);
    assert.ok(source.length > 100, `${name} looks empty`);
  });
  assert.match(sources.display, /void main/);
  assert.match(sources.splat, /void main/);
});

check('color helpers round-trip', () => {
  const helpers = FluidSimulation.helpers;
  assert.deepEqual(helpers.hexToRgb('#1e90ff'), { r: 30, g: 144, b: 255 });
  assert.deepEqual(helpers.hexToRgb('#abc'), { r: 170, g: 187, b: 204 });
  assert.equal(helpers.rgbToHex({ r: 30, g: 144, b: 255 }), '#1e90ff');
  assert.deepEqual(helpers.toRgb255({ r: 1, g: 0, b: 0 }), { r: 255, g: 0, b: 0 });
  assert.deepEqual(helpers.toRgb255([255, 128, 0]), { r: 255, g: 128, b: 0 });
});

check('isSupported() is false without a DOM', () => {
  assert.equal(FluidSimulation.isSupported(), false);
});

check('createIfSupported() reports the reason instead of throwing', () => {
  let reported = null;
  const instance = FluidSimulation.createIfSupported({ onError: (error) => { reported = error; } });
  assert.equal(instance, null);
  assert.ok(reported, 'no error was reported');
  assert.equal(reported.code, FluidSimulation.errorCodes.NO_WEBGL);
});

check('autoInit() degrades to an empty list without a DOM', () => {
  assert.deepEqual(FluidSimulation.autoInit(), []);
});

check('destroyAll() is safe with no instances', () => {
  assert.equal(FluidSimulation.destroyAll(), 0);
});

check('creating a canvas-driven instance fails cleanly without a DOM', () => {
  assert.throws(() => FluidSimulation.create({}), (error) => {
    assert.equal(error.name, 'FluidSimulationError');
    assert.equal(error.code, FluidSimulation.errorCodes.NO_CANVAS);
    return true;
  });
});

console.log(`\n${passed} passed${process.exitCode ? ', with failures' : ''}`);
