# Fluid Simulation API

A dependency-free, embeddable WebGL fluid simulation you can add to any page with one
classic script tag. It is a re-architecture of Pavel Dobryakov's
[WebGL Fluid Simulation](https://github.com/PavelDoGreat/WebGL-Fluid-Simulation) (MIT)
into a documented, instance-based JavaScript API. The GLSL programs are unchanged; the
application shell around them (dat.gui menu, global state, hard-coded canvas) is replaced
by an object you create, configure and drive from your own code.

```
fluid-simulation-api/
├── fluid-simulation.js        the whole library - one file, no dependencies
├── index.html                 self-contained demo app (library inlined)
├── demo/index.html            the same demo, but loading fluid-simulation.js
├── examples/                  six runnable examples, from 20 lines to a control panel
├── docs/API.md                complete method / option / event reference
├── docs/COOKBOOK.md           recipes: backgrounds, React, mobile, performance, capture
├── docs/demo-screenshot.png   what index.html looks like
├── src/parts/                 the library split into readable parts (build input)
├── tools/build.py             builds fluid-simulation.js + standalone pages
└── tests/browser_test.py      55 end-to-end checks in headless Chromium
```

## Quick start

```html
<div id="stage" style="position:fixed; inset:0"></div>

<script src="fluid-simulation.js"></script>
<script>
  const fluid = FluidSimulation.create({
    container: '#stage',          // or a <canvas>, or omit for a full-page background
    keyboard: true,               // P = pause, Space = random splats
    config: { CURL: 32, SPLAT_FORCE: 6000 }
  });
</script>
```

Drag on the canvas and the fluid follows. No bundler, no build step, no CDN, and no
network requests at runtime - the binary noise texture used for bloom dithering is
generated in code.

## What you get

| Area | Highlights |
| --- | --- |
| Lifecycle | `create`, `attach`, `autoInit`, `start`, `stop`, `pause`, `resume`, `togglePause`, `frame`, `clear`, `destroy`, `destroyAll` |
| Simulation | `splat`, `splatAt`, `randomSplats`, `queueSplats`, `startStroke`/`moveStroke`/`endStroke`, `pointerDown`/`Move`/`Up` |
| Configuration | `getConfig`, `setConfig`, `resetConfig`, `applyPreset`, `setQuality`, `setBackground`, `setTransparent`, `setDithering`, `setColor`, `setColorGenerator` |
| Output | `capture`, `toDataURL`, `download`, `captureScreenshot`, `getImageData` |
| Introspection | `getSize`, `getContextInfo`, `isRunning`, `isPaused`, `isDestroyed`, `FluidSimulation.isSupported()` |
| Events | `ready`, `frame`, `splat`, `resize`, `config`, `pause`, `resume`, `visibility`, `capture`, `clear`, `destroy`, `error` |
| Extras | 5 presets, 20 exposed GLSL programs, color helpers, UMD wrapper (script tag, CommonJS, AMD) |

Everything is opt-in: `FluidSimulation.create()` with no arguments gives you the classic
look as a full-screen background layer.

## Examples

Open any file in `examples/` directly from disk - they only need `fluid-simulation.js`
next to them. `examples/standalone/` holds the same pages with the library inlined, so
they also work when a relative script path is not available.

| Example | Shows |
| --- | --- |
| [`01-basic.html`](examples/01-basic.html) | The minimum viable embed, ~20 lines |
| [`02-page-background.html`](examples/02-page-background.html) | Click-through background behind real content, scripted strokes |
| [`03-programmatic-splats.html`](examples/03-programmatic-splats.html) | Driving the fluid from `requestAnimationFrame` / timers, no mouse needed |
| [`04-custom-controls.html`](examples/04-custom-controls.html) | Building your own control panel against `setConfig`, capture previews |
| [`05-events-and-capture.html`](examples/05-events-and-capture.html) | Event telemetry, FPS/draw-call meters, snapshots and PNG downloads |
| [`06-auto-init-multiple.html`](examples/06-auto-init-multiple.html) | Declarative `data-fluid` setup and six independent instances |

`index.html` in the project root is the flagship demo: presets, quality selectors,
sliders for every fluid parameter, transparency, save-to-PNG and live FPS.

![The demo app](docs/demo-screenshot.png)

## Configuration

`config` uses the original project's property names, so existing tuning values carry over.
Defaults live in `FluidSimulation.defaultConfig()`.

| Key | Default | Meaning |
| --- | --- | --- |
| `SIM_RESOLUTION` | `128` | Velocity grid resolution |
| `DYE_RESOLUTION` | `1024` | Dye (color) grid resolution - the main quality/perf knob |
| `CAPTURE_RESOLUTION` | `512` | Default resolution for `capture()` / `toDataURL()` |
| `DENSITY_DISSIPATION` | `1` | How fast the dye fades (0 = permanent) |
| `VELOCITY_DISSIPATION` | `0.2` | How fast motion settles |
| `PRESSURE` | `0.8` | Pressure retained between iterations |
| `PRESSURE_ITERATIONS` | `20` | Jacobi iterations (cost vs. incompressibility) |
| `CURL` | `30` | Vorticity confinement - higher is swirlier |
| `SPLAT_RADIUS` | `0.25` | Radius of a splat, in percent of the screen |
| `SPLAT_FORCE` | `6000` | Force applied by a drag |
| `SHADING` | `true` | Fake 3D lighting |
| `COLORFUL` | `true` | Cycle pointer colors over time |
| `COLOR_UPDATE_SPEED` | `10` | How fast those colors cycle |
| `PAUSED` | `false` | Stop stepping physics (rendering continues) |
| `BACK_COLOR` | `{r: 0, g: 0, b: 0}` | Background color, 0-255 |
| `TRANSPARENT` | `false` | Fake transparency via a checkerboard |
| `BLOOM` / `BLOOM_*` | `true`, 8 iterations, 256 res, 0.8 intensity, 0.6 threshold, 0.7 soft knee | Glow pass |
| `SUNRAYS` / `SUNRAYS_*` | `true`, 196 res, 1.0 weight | God-ray pass |
| `DITHERING` | `true` | Noise that hides bloom banding |

`FluidSimulation.presets` ships `classic`, `calm`, `vivid`, `smoke` and `ink`; apply one at
creation (`preset: 'vivid'`) or later (`fluid.applyPreset('ink')`).

Full details, including every creation option and event payload, are in
[docs/API.md](docs/API.md).

## Capturing frames

```js
const canvas = fluid.capture({ resolution: 2048 });   // offscreen <canvas>
image.src = canvas.toDataURL('image/png');

fluid.download('fluid.png');                          // straight to a file
const { width, height, data } = fluid.getImageData(); // raw RGBA bytes
```

`resolution` sets the *smaller* dimension; the aspect ratio of the canvas is preserved.

## Notes and limits

- The canvas is sized from its CSS box times `devicePixelRatio`; a `ResizeObserver` keeps
  framebuffers in sync. Give the container a height (or use the background mode) so it has
  something to measure.
- Devices without float-texture filtering automatically drop to 512 dye resolution with
  shading, bloom and sunrays disabled; `instance.degraded` records what happened.
- On mobile user agents the dye resolution is capped at 512 unless you pass
  `mobileQuality: false`.
- Simulations pause while the tab is hidden (`pauseWhenHidden: false` to opt out).
- This is a *visual* simulation: `SIM_RESOLUTION` and `DYE_RESOLUTION` trade quality for
  GPU time, and `PRESSURE_ITERATIONS` is the usual first thing to lower on integrated GPUs.
- One WebGL context is created per instance. Browsers cap the number of live contexts
  (usually 8-16), so destroy instances you no longer render.

## Tests

```bash
pip install playwright && python -m playwright install --with-deps chromium
bash tests/run_all.sh            # or run the three suites individually
```

| Suite | Checks | Covers |
| --- | --- | --- |
| `tests/node_test.js` | 11 | CommonJS/SSR loading, statics, presets, shader inventory, color helpers, graceful failure without a DOM |
| `tests/browser_test.py` | 55 | The real library in headless Chromium (SwiftShader): pixel verification of splats, framebuffer resizing, keyword recompilation, events, capture and download, hotkeys, coded errors, multiple instances, `autoInit`, teardown |
| `tests/demo_test.py` | 43 | The demo and all six examples load with no console errors and keep rendering; the demo's panel, hotkeys, save-PNG, transparency and dragging are exercised |

PASS/FAIL output for each suite is checked into `tests/*-results.txt`.

## Rebuilding

`fluid-simulation.js` is generated so the GLSL stays byte-identical to the original:

```bash
python3 tools/build.py     # fluid-simulation.js + index.html + examples/standalone/*
```

`src/parts/*.js` holds the hand-written source (head/utilities, instance, loop, public
surface) and `tools/reference/` keeps the original app for provenance.

## License and credits

MIT. The simulation, the GLSL programs and the derived architecture come from
[Pavel Dobryakov's WebGL Fluid Simulation](https://github.com/PavelDoGreat/WebGL-Fluid-Simulation)
(c) 2017 Pavel Dobryakov, also MIT. See [LICENSE](LICENSE) and [NOTICE](NOTICE).
