declare module 'poly-decomp';
